export const memberNav = [
	{
		label: "Overview",
		path: "/dashboard",
		icon: "chart"
	},
	{
		label: "Workouts",
		path: "/workouts",
		icon: "bolt"
	},
	{
		label: "Progress",
		path: "/progress",
		icon: "calendar"
	},
	{
		label: "Generate",
		path: "/generate",
		icon: "spark"
	},
	{
		label: "Profile",
		path: "/profile",
		icon: "user"
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxNQUFNLFlBQVk7Q0FDdkI7RUFBRSxPQUFPO0VBQVksTUFBTTtFQUFjLE1BQU07Q0FBUTtDQUN2RDtFQUFFLE9BQU87RUFBWSxNQUFNO0VBQWEsTUFBTTtDQUFPO0NBQ3JEO0VBQUUsT0FBTztFQUFZLE1BQU07RUFBYSxNQUFNO0NBQVc7Q0FDekQ7RUFBRSxPQUFPO0VBQVksTUFBTTtFQUFhLE1BQU07Q0FBUTtDQUN0RDtFQUFFLE9BQU87RUFBVyxNQUFNO0VBQVksTUFBTTtDQUFPO0FBQ3JEIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm5hdi50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgbWVtYmVyTmF2ID0gW1xyXG4gIHsgbGFiZWw6IFwiT3ZlcnZpZXdcIiwgcGF0aDogXCIvZGFzaGJvYXJkXCIsIGljb246IFwiY2hhcnRcIiB9LFxyXG4gIHsgbGFiZWw6IFwiV29ya291dHNcIiwgcGF0aDogXCIvd29ya291dHNcIiwgaWNvbjogXCJib2x0XCIgfSxcclxuICB7IGxhYmVsOiBcIlByb2dyZXNzXCIsIHBhdGg6IFwiL3Byb2dyZXNzXCIsIGljb246IFwiY2FsZW5kYXJcIiB9LFxyXG4gIHsgbGFiZWw6IFwiR2VuZXJhdGVcIiwgcGF0aDogXCIvZ2VuZXJhdGVcIiwgaWNvbjogXCJzcGFya1wiIH0sXHJcbiAgeyBsYWJlbDogXCJQcm9maWxlXCIsIHBhdGg6IFwiL3Byb2ZpbGVcIiwgaWNvbjogXCJ1c2VyXCIgfSxcclxuXSBhcyBjb25zdDtcclxuIl19