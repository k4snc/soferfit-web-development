import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/PageHeader.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/PageHeader.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function PageHeader({ eyebrow, title }) {
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "dash-header",
		children: /* @__PURE__ */ _jsxDEV("div", { children: [eyebrow && /* @__PURE__ */ _jsxDEV("span", { children: eyebrow }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 2,
			columnNumber: 59
		}, this), /* @__PURE__ */ _jsxDEV("h1", { children: title }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 2,
			columnNumber: 82
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 2,
			columnNumber: 42
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 2,
		columnNumber: 10
	}, this);
}
_c = PageHeader;
var _c;
$RefreshReg$(_c, "PageHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/PageHeader.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/PageHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/PageHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/PageHeader.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsV0FBVyxFQUFFLFNBQVMsU0FBOEM7Q0FDbEYsT0FBTyx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFjLHdCQUFDLE9BQUQsYUFBTSxXQUFXLHdCQUFDLFFBQUQsWUFBTyxRQUFjOzs7O1lBQUUsd0JBQUMsTUFBRCxZQUFLLE1BQVU7Ozs7VUFBTTs7Ozs7Q0FBUzs7Ozs7QUFDL0ciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUGFnZUhlYWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIFBhZ2VIZWFkZXIoeyBleWVicm93LCB0aXRsZSB9OiB7IGV5ZWJyb3c/OiBzdHJpbmc7IHRpdGxlOiBzdHJpbmcgfSkge1xyXG4gIHJldHVybiA8aGVhZGVyIGNsYXNzTmFtZT1cImRhc2gtaGVhZGVyXCI+PGRpdj57ZXllYnJvdyAmJiA8c3Bhbj57ZXllYnJvd308L3NwYW4+fTxoMT57dGl0bGV9PC9oMT48L2Rpdj48L2hlYWRlcj47XHJcbn1cclxuIl19