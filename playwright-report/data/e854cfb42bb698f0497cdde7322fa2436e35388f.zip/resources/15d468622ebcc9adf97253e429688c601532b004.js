import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/modals/SignupModal.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { InfoTip } from "/src/frontend/components/InfoTip.tsx";
import { LogoMark } from "/src/frontend/components/LogoMark.tsx";
import { glossaryTerms } from "/src/frontend/data/glossary.ts";
import { emailPattern, parseHeightCm, parseWeightKg } from "/src/frontend/lib/format.ts";
import { api } from "/src/frontend/services/api.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/SignupModal.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function SignupModal({ open, initialAnswers, onClose, onLogin, onOpenGlossary, onComplete }) {
	_s();
	const [step, setStep] = useState(1);
	const [direction, setDirection] = useState("forward");
	const [showLeavePrompt, setShowLeavePrompt] = useState(false);
	const [showPassword, setShowPassword] = useState(false);
	const [avatarError, setAvatarError] = useState("");
	const [returnToReview, setReturnToReview] = useState(false);
	const [generationProgress, setGenerationProgress] = useState(0);
	const [generationStatus, setGenerationStatus] = useState(0);
	const [answers, setAnswers] = useState(initialAnswers);
	const titleRef = useRef(null);
	const fileInputRef = useRef(null);
	const customSessionRef = useRef(null);
	const totalSteps = 4;
	const setAnswer = (key, value) => setAnswers((current) => ({
		...current,
		[key]: value
	}));
	const passwordRules = {
		length: answers.password.length >= 8,
		number: /[\d\p{P}\p{S}]/u.test(answers.password),
		case: /[a-z]/.test(answers.password) && /[A-Z]/.test(answers.password)
	};
	const validPassword = Object.values(passwordRules).every(Boolean);
	const ageNumber = Number(answers.age);
	const heightCm = parseHeightCm(answers.height, answers.unitSystem);
	const weightKg = parseWeightKg(answers.weight, answers.unitSystem);
	const validAge = ageNumber >= 10 && ageNumber <= 100;
	const validHeight = heightCm >= 100 && heightCm <= 250;
	const validWeight = weightKg >= 25 && weightKg <= 300;
	const stepOneValid = Boolean(answers.name.trim()) && emailPattern.test(answers.email) && validPassword && validAge && validHeight && validWeight;
	const targetKg = parseWeightKg(answers.targetWeight, answers.unitSystem);
	const hasTargetWeight = Boolean(answers.targetWeight.trim());
	const targetValid = !hasTargetWeight || targetKg >= 25 && targetKg <= 300;
	const timelineWeeks = answers.targetTimeline === "First 30 days" ? 4.3 : answers.targetTimeline === "By day 60" ? 8.6 : 12.9;
	const targetCaution = hasTargetWeight && targetValid && validHeight && (targetKg / (heightCm / 100) ** 2 < 18.5 || (weightKg - targetKg) / timelineWeeks > 1);
	const stepTwoValid = Boolean(answers.somatotype && answers.goal && answers.experience && answers.activity && answers.availableEquipment && targetValid);
	const customSessionValue = Number(answers.customSessionMinutes);
	const customSessionValid = Number.isInteger(customSessionValue) && customSessionValue >= 5 && customSessionValue <= 180;
	const sessionValid = answers.sessionChoice === "custom" ? customSessionValid : Boolean(answers.sessionChoice && answers.sessionMinutes);
	const stepThreeValid = Boolean(answers.challengeDays && answers.workoutDays && sessionValid);
	const stepValid = step === 1 ? stepOneValid : step === 2 ? stepTwoValid : step === 3 ? stepThreeValid : true;
	const strength = Object.values(passwordRules).filter(Boolean).length;
	useEffect(() => {
		if (!open) return;
		setAnswers(initialAnswers);
		setStep(1);
		setDirection("forward");
		setShowLeavePrompt(false);
		setAvatarError("");
		setReturnToReview(false);
		setGenerationProgress(0);
		setGenerationStatus(0);
	}, [open]);
	useEffect(() => {
		if (step !== 5) return;
		const startedAt = Date.now();
		const progressTimer = window.setInterval(() => {
			setGenerationProgress(Math.min(100, Math.round((Date.now() - startedAt) / 4e3 * 100)));
		}, 50);
		const statusTimer = window.setInterval(() => setGenerationStatus((current) => Math.min(2, current + 1)), 1300);
		const finishTimer = window.setTimeout(() => {
			setGenerationProgress(100);
			setStep(6);
		}, 4100);
		return () => {
			window.clearInterval(progressTimer);
			window.clearInterval(statusTimer);
			window.clearTimeout(finishTimer);
		};
	}, [step]);
	useEffect(() => {
		if (!open) return;
		const previousOverflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = previousOverflow;
		};
	}, [open]);
	useEffect(() => {
		if (!open) return;
		window.setTimeout(() => titleRef.current?.focus(), 20);
	}, [open, step]);
	useEffect(() => {
		if (step === 3 && answers.sessionChoice === "custom") {
			window.setTimeout(() => customSessionRef.current?.focus(), 20);
		}
	}, [answers.sessionChoice, step]);
	useEffect(() => {
		if (!open) return;
		const handleKeyDown = (event) => {
			if (event.key === "Escape" && step !== 5) {
				event.preventDefault();
				setShowLeavePrompt(true);
			}
			if (event.key === "Enter" && !showLeavePrompt && stepValid && step < 4) {
				const target = event.target;
				if (target.tagName !== "BUTTON" && target.tagName !== "SELECT" && step < totalSteps) {
					event.preventDefault();
					setDirection("forward");
					setStep((current) => current + 1);
				}
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [
		open,
		showLeavePrompt,
		step,
		stepValid
	]);
	if (!open) return null;
	const goBack = () => {
		if (step === 5) return;
		if (step === 1) return setShowLeavePrompt(true);
		setDirection("back");
		setStep((current) => current - 1);
	};
	const goNext = () => {
		if (!stepValid || step >= totalSteps) return;
		setDirection("forward");
		if (returnToReview) {
			setReturnToReview(false);
			setStep(4);
		} else {
			setStep((current) => current + 1);
		}
	};
	const changeUnit = (unit) => {
		if (unit === answers.unitSystem) return;
		const nextHeight = answers.height ? unit === "imperial" ? `${Math.floor(heightCm / 30.48)} ft ${Math.round(heightCm % 30.48 / 2.54)} in` : String(Math.round(heightCm)) : "";
		const nextWeight = answers.weight ? unit === "imperial" ? String(Math.round(weightKg * 2.20462)) : String(Math.round(weightKg)) : "";
		const nextTarget = hasTargetWeight ? unit === "imperial" ? String(Math.round(targetKg * 2.20462)) : String(Math.round(targetKg)) : "";
		setAnswers((current) => ({
			...current,
			unitSystem: unit,
			height: nextHeight,
			weight: nextWeight,
			targetWeight: nextTarget
		}));
	};
	const uploadAvatar = (file) => {
		if (!file) return;
		if (!file.type.startsWith("image/")) return setAvatarError("Please choose an image file.");
		if (file.size > 5 * 1024 * 1024) return setAvatarError("Please choose an image smaller than 5 MB.");
		setAvatarError("");
		const reader = new FileReader();
		reader.onload = () => setAnswer("avatarUrl", String(reader.result));
		reader.readAsDataURL(file);
	};
	const pill = (value, selected, onSelect) => /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		className: `signup-pill ${selected ? "selected" : ""}`,
		onClick: () => onSelect(value),
		children: [selected && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 174,
			columnNumber: 20
		}, this), value]
	}, value, true, {
		fileName: _jsxFileName,
		lineNumber: 173,
		columnNumber: 5
	}, this);
	const initials = answers.name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "SF";
	const statusMessages = [
		"Analyzing body type and metabolic profile...",
		`Calibrating your ${answers.challengeDays ?? 60}-day challenge schedule and rest intervals...`,
		"Finalizing Day 1 session and guided cues..."
	];
	const editStep = (nextStep) => {
		setReturnToReview(true);
		setDirection("back");
		setStep(nextStep);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "signup-backdrop",
		onMouseDown: () => step !== 5 && setShowLeavePrompt(true),
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: `signup-modal ${step > 4 ? "signup-final-state" : ""}`,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "signup-step-title",
			onMouseDown: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "signup-form-column",
					children: [
						step <= 4 && /* @__PURE__ */ _jsxDEV("header", {
							className: "signup-header",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "signup-topline",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										className: "signup-icon-button",
										type: "button",
										onClick: goBack,
										"aria-label": step === 1 ? "Leave sign up" : "Previous step",
										children: /* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 195,
											columnNumber: 145
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "signup-member-actions",
										children: /* @__PURE__ */ _jsxDEV("span", { children: ["Already a member? ", /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: onLogin,
											children: "Log in"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 78
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 54
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "signup-progress",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [
										"Step ",
										step,
										" of ",
										totalSteps
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "signup-progress-track",
										"aria-label": `Step ${step} of ${totalSteps}`,
										children: [
											1,
											2,
											3,
											4
										].map((item) => /* @__PURE__ */ _jsxDEV("i", { className: item < step || step === 4 ? "complete" : item === step ? "current" : "" }, item, false, {
											fileName: _jsxFileName,
											lineNumber: 201,
											columnNumber: 45
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 198,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "signup-mobile-preview",
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: step === 2 ? "chart" : step === 3 ? "calendar" : step === 4 ? "check" : "calendar" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 52
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: step === 2 ? "Your starting point" : step === 3 ? "Weekly rhythm" : step === 4 ? "Ready to review" : "Day 1 Kickoff" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 150
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "signup-scroll",
							children: [
								step === 1 && /* @__PURE__ */ _jsxDEV("div", {
									className: `signup-step-content signup-slide-${direction}`,
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "signup-step-title",
											ref: titleRef,
											tabIndex: -1,
											children: "Create your account."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 210,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "signup-step-intro",
											children: "Save your routine and keep your 60/90-day challenge progress in one place."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 211,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-avatar-upload",
											children: [
												/* @__PURE__ */ _jsxDEV("input", {
													ref: fileInputRef,
													type: "file",
													accept: "image/*",
													onChange: (event) => uploadAvatar(event.target.files?.[0])
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 213,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: "signup-avatar-button",
													onClick: () => fileInputRef.current?.click(),
													"aria-label": "Upload profile photo",
													children: answers.avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
														src: answers.avatarUrl,
														alt: "Profile preview"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 215,
														columnNumber: 42
													}, this) : /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "camera" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 215,
														columnNumber: 104
													}, this), /* @__PURE__ */ _jsxDEV("b", { children: "+" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 215,
														columnNumber: 126
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 215,
														columnNumber: 98
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("strong", { children: ["Upload profile photo ", /* @__PURE__ */ _jsxDEV("span", { children: "(Optional)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 217,
													columnNumber: 48
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 217,
													columnNumber: 19
												}, this),
												answers.avatarUrl && /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: "signup-change-avatar",
													onClick: () => fileInputRef.current?.click(),
													children: "Change"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 218,
													columnNumber: 41
												}, this),
												avatarError && /* @__PURE__ */ _jsxDEV("small", {
													className: "signup-field-error",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 219,
														columnNumber: 73
													}, this), avatarError]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 219,
													columnNumber: 35
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 212,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-account-fields",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: ["Username", /* @__PURE__ */ _jsxDEV("input", {
														value: answers.name,
														onChange: (event) => setAnswer("name", event.target.value),
														placeholder: "Choose a username"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 222,
														columnNumber: 59
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 222,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: [
														"Email Address",
														/* @__PURE__ */ _jsxDEV("input", {
															type: "email",
															value: answers.email,
															onChange: (event) => setAnswer("email", event.target.value),
															placeholder: "you@example.com"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 223,
															columnNumber: 64
														}, this),
														answers.email && !emailPattern.test(answers.email) && /* @__PURE__ */ _jsxDEV("small", {
															className: "signup-field-error",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 223,
																columnNumber: 292
															}, this), "Enter a valid email address."]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 223,
															columnNumber: 254
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 223,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: ["Password", /* @__PURE__ */ _jsxDEV("span", {
														className: "signup-password-field",
														children: [/* @__PURE__ */ _jsxDEV("input", {
															type: showPassword ? "text" : "password",
															value: answers.password,
															onChange: (event) => setAnswer("password", event.target.value),
															placeholder: "Create a strong password"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 224,
															columnNumber: 99
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => setShowPassword((current) => !current),
															"aria-label": showPassword ? "Hide password" : "Show password",
															children: /* @__PURE__ */ _jsxDEV(Icon, { name: showPassword ? "eyeOff" : "eye" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 224,
																columnNumber: 417
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 224,
															columnNumber: 278
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 224,
														columnNumber: 59
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 224,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-password-status",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "signup-strength-meter",
														"aria-label": `Password strength ${strength} of 3`,
														children: [
															1,
															2,
															3
														].map((item) => /* @__PURE__ */ _jsxDEV("i", { className: item <= strength ? "passed" : "" }, item, false, {
															fileName: _jsxFileName,
															lineNumber: 226,
															columnNumber: 135
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 226,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "signup-password-rules",
														children: [
															[passwordRules.length, "At least 8 characters"],
															[passwordRules.number, "At least one number or symbol"],
															[passwordRules.case, "Upper and lowercase letters"]
														].map(([passed, label]) => /* @__PURE__ */ _jsxDEV("span", {
															className: passed ? "passed" : "",
															children: [/* @__PURE__ */ _jsxDEV("i", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 228,
																columnNumber: 273
															}, this) }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 228,
																columnNumber: 270
															}, this), label]
														}, String(label), true, {
															fileName: _jsxFileName,
															lineNumber: 228,
															columnNumber: 209
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 227,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 225,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-section-heading",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "About you" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-unit-toggle",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: answers.unitSystem === "metric" ? "active" : "",
													onClick: () => changeUnit("metric"),
													children: ["Metric ", /* @__PURE__ */ _jsxDEV("small", { children: "kg/cm" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 234,
														columnNumber: 181
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 234,
													columnNumber: 55
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: answers.unitSystem === "imperial" ? "active" : "",
													onClick: () => changeUnit("imperial"),
													children: ["Imperial ", /* @__PURE__ */ _jsxDEV("small", { children: "lbs/ft" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 234,
														columnNumber: 342
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 234,
													columnNumber: 210
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 234,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 232,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-biometric-grid",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: [
														"Age",
														/* @__PURE__ */ _jsxDEV("input", {
															inputMode: "numeric",
															value: answers.age,
															onChange: (event) => setAnswer("age", event.target.value),
															placeholder: "24"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 237,
															columnNumber: 54
														}, this),
														answers.age && !validAge && /* @__PURE__ */ _jsxDEV("small", {
															className: "signup-field-error",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 237,
																columnNumber: 246
															}, this), "Enter an age from 10–100."]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 237,
															columnNumber: 208
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 237,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: [
														"Height",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "signup-input-with-unit",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																inputMode: answers.unitSystem === "metric" ? "numeric" : "text",
																value: answers.height,
																onChange: (event) => setAnswer("height", event.target.value),
																placeholder: answers.unitSystem === "metric" ? "175 cm" : "5 ft 9 in"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 238,
																columnNumber: 98
															}, this), /* @__PURE__ */ _jsxDEV("b", { children: answers.unitSystem === "metric" ? "cm" : "ft / in" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 238,
																columnNumber: 328
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 238,
															columnNumber: 57
														}, this),
														answers.height && !validHeight && /* @__PURE__ */ _jsxDEV("small", {
															className: "signup-field-error",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 238,
																columnNumber: 467
															}, this), answers.unitSystem === "metric" ? "100–250 cm" : "3 ft 3 in–8 ft 2 in"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 238,
															columnNumber: 429
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 238,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: [
														"Current Weight",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "signup-input-with-unit",
															children: [/* @__PURE__ */ _jsxDEV("input", {
																inputMode: "decimal",
																value: answers.weight,
																onChange: (event) => setAnswer("weight", event.target.value),
																placeholder: answers.unitSystem === "metric" ? "68 kg" : "150 lbs"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 239,
																columnNumber: 106
															}, this), /* @__PURE__ */ _jsxDEV("b", { children: answers.unitSystem === "metric" ? "kg" : "lbs" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 239,
																columnNumber: 288
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 239,
															columnNumber: 65
														}, this),
														answers.weight && !validWeight && /* @__PURE__ */ _jsxDEV("small", {
															className: "signup-field-error",
															children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 239,
																columnNumber: 423
															}, this), answers.unitSystem === "metric" ? "25–300 kg" : "55–661 lbs"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 239,
															columnNumber: 385
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 239,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 17
										}, this),
										validAge && ageNumber < 18 && /* @__PURE__ */ _jsxDEV("p", {
											className: "signup-notice",
											children: "Under 18? Please ask a parent or guardian before starting a fitness challenge."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 48
										}, this)
									]
								}, "step-1", true, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 15
								}, this),
								step === 2 && /* @__PURE__ */ _jsxDEV("div", {
									className: `signup-step-content signup-slide-${direction}`,
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "signup-step-title",
											ref: titleRef,
											tabIndex: -1,
											children: "Tell us about your starting point."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "signup-step-intro",
											children: "These details help us customize practical volume, exercise selection, and recovery."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 248,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "signup-label-with-tip",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "SOMATOTYPE" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 250,
													columnNumber: 58
												}, this), /* @__PURE__ */ _jsxDEV(InfoTip, {
													term: "Somatotype",
													definition: glossaryTerms.find(([term]) => term === "Somatotype")?.[1] ?? "",
													onLearnMore: () => onOpenGlossary("Somatotype"),
													actionLabel: "Open Glossary",
													showTerm: false
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 250,
													columnNumber: 81
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 250,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-somatotype-grid",
												children: [
													["Ectomorph", "Naturally leaner frame, fast metabolism."],
													["Mesomorph", "Naturally athletic, builds muscle and burns fat easily."],
													["Endomorph", "Naturally broader, tends to store body fat easily."],
													["Not Sure", "We will use your other baseline answers."]
												].map(([title, subtitle]) => /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: answers.somatotype === title ? "selected" : "",
													onClick: () => setAnswer("somatotype", title),
													children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: title }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 254,
														columnNumber: 31
													}, this), /* @__PURE__ */ _jsxDEV("small", { children: subtitle }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 254,
														columnNumber: 55
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 254,
														columnNumber: 25
													}, this), answers.somatotype === title && /* @__PURE__ */ _jsxDEV("b", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 254,
														columnNumber: 123
													}, this) }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 254,
														columnNumber: 120
													}, this)]
												}, title, true, {
													fileName: _jsxFileName,
													lineNumber: 253,
													columnNumber: 23
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 251,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "signup-section-label",
												children: "PRIMARY GOAL"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 259,
												columnNumber: 54
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-pill-group",
												children: [
													"Lose Fat & Get Lean",
													"Build Muscle & Strength",
													"Body Recomposition"
												].map((item) => pill(item, answers.goal === item, (value) => setAnswer("goal", value)))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 259,
												columnNumber: 112
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 259,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "signup-section-label",
													children: "EXPERIENCE LEVEL"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 260,
													columnNumber: 54
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "signup-helper",
													children: "Where are you in your fitness journey?"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 260,
													columnNumber: 116
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-pill-group",
													children: [
														"Starting Out",
														"Some Experience",
														"Consistent"
													].map((item) => pill(item, answers.experience === item, (value) => setAnswer("experience", value)))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 260,
													columnNumber: 187
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "signup-section-label",
													children: "CURRENT ACTIVITY LEVEL"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 261,
													columnNumber: 54
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "signup-helper",
													children: "How active are you outside your planned workouts?"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 261,
													columnNumber: 122
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-pill-group",
													children: [
														"Sedentary",
														"Sometimes Active",
														"Moderately Active",
														"Very Active"
													].map((item) => pill(item, answers.activity === item, (value) => setAnswer("activity", value)))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 261,
													columnNumber: 204
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "signup-section-label",
													children: "TARGET GOAL METRIC"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 263,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-target-grid",
													children: [/* @__PURE__ */ _jsxDEV("label", {
														className: "signup-field signup-target-weight-field",
														children: [
															/* @__PURE__ */ _jsxDEV("span", {
																className: "signup-target-label",
																children: ["Target Weight ", /* @__PURE__ */ _jsxDEV("small", { children: "(Optional)" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 266,
																	columnNumber: 75
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 266,
																columnNumber: 23
															}, this),
															/* @__PURE__ */ _jsxDEV("span", {
																className: "signup-target-input-row",
																children: /* @__PURE__ */ _jsxDEV("span", {
																	className: "signup-input-with-unit",
																	children: [/* @__PURE__ */ _jsxDEV("input", {
																		inputMode: "decimal",
																		value: answers.targetWeight,
																		onChange: (event) => setAnswer("targetWeight", event.target.value),
																		placeholder: answers.unitSystem === "metric" ? "62 kg" : "137 lbs"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 268,
																		columnNumber: 66
																	}, this), /* @__PURE__ */ _jsxDEV("b", { children: answers.unitSystem === "metric" ? "kg" : "lbs" }, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 268,
																		columnNumber: 260
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 268,
																	columnNumber: 25
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 267,
																columnNumber: 23
															}, this),
															hasTargetWeight && !targetValid && /* @__PURE__ */ _jsxDEV("small", {
																className: "signup-field-error",
																children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 270,
																	columnNumber: 97
																}, this), answers.unitSystem === "metric" ? "Enter 25–300 kg or leave blank." : "Enter 55–661 lbs or leave blank."]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 270,
																columnNumber: 59
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 265,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("label", {
														className: "signup-field",
														children: ["Target Timeline Focus", /* @__PURE__ */ _jsxDEV("select", {
															value: answers.targetTimeline,
															onChange: (event) => setAnswer("targetTimeline", event.target.value),
															children: [
																/* @__PURE__ */ _jsxDEV("option", { children: "First 30 days" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 272,
																	columnNumber: 183
																}, this),
																/* @__PURE__ */ _jsxDEV("option", { children: "By day 60" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 272,
																	columnNumber: 213
																}, this),
																/* @__PURE__ */ _jsxDEV("option", { children: "By day 90" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 272,
																	columnNumber: 239
																}, this),
																/* @__PURE__ */ _jsxDEV("option", { children: "Whole challenge" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 272,
																	columnNumber: 265
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 272,
															columnNumber: 74
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 272,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 264,
													columnNumber: 19
												}, this),
												targetCaution && /* @__PURE__ */ _jsxDEV("p", {
													className: "signup-notice",
													children: "That’s a big change. Gradual progress is safer; we’ll pace your plan."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 274,
													columnNumber: 37
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 262,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "signup-section-label",
												children: "AVAILABLE EQUIPMENT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 276,
												columnNumber: 54
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-pill-group",
												children: [
													"Bodyweight / Home Only",
													"Dumbbells & Bands",
													"Full Gym Access"
												].map((item) => pill(item, answers.availableEquipment === item, (value) => setAnswer("availableEquipment", value)))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 276,
												columnNumber: 119
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 276,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-medical-block",
											children: [
												/* @__PURE__ */ _jsxDEV("p", { children: "SoferFit offers general fitness guidance, not medical advice. If you have an injury or health condition, check with a doctor first." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 278,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("label", { children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: answers.hasCondition,
													onChange: (event) => setAnswer("hasCondition", event.target.checked)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 26
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "I have an injury or health condition" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 152
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 19
												}, this),
												answers.hasCondition && /* @__PURE__ */ _jsxDEV("small", { children: "We’ll favor lower-impact exercises in your plan." }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 280,
													columnNumber: 44
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 277,
											columnNumber: 17
										}, this)
									]
								}, "step-2", true, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 15
								}, this),
								step === 3 && /* @__PURE__ */ _jsxDEV("div", {
									className: `signup-step-content signup-slide-${direction}`,
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "signup-step-title",
											ref: titleRef,
											tabIndex: -1,
											children: "Build your weekly rhythm."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 287,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "signup-step-intro",
											children: "Select your transformation duration and weekly schedule."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 288,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section signup-duration-section",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "signup-section-label",
												children: "CHOOSE YOUR CHALLENGE DURATION"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 290,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-duration-grid",
												children: [60, 90].map((days) => /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: answers.challengeDays === days ? "selected" : "",
													onClick: () => setAnswer("challengeDays", days),
													children: [
														/* @__PURE__ */ _jsxDEV("span", {
															className: "signup-duration-chip",
															children: days === 60 ? "Sprint" : "Most sustainable"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 294,
															columnNumber: 25
														}, this),
														/* @__PURE__ */ _jsxDEV("strong", { children: [days, "-Day Challenge"] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 295,
															columnNumber: 25
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: days === 60 ? "A high-intensity, focused sprint. Best for rapid routine formation and fast fat loss." : "Comprehensive body transformation. Best for sustainable recomposition and deep habit building." }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 296,
															columnNumber: 25
														}, this),
														answers.challengeDays === days && /* @__PURE__ */ _jsxDEV("b", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 297,
															columnNumber: 63
														}, this) }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 297,
															columnNumber: 60
														}, this)
													]
												}, days, true, {
													fileName: _jsxFileName,
													lineNumber: 293,
													columnNumber: 23
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 291,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 289,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "signup-section-label",
													children: "WORKOUT DAYS PER WEEK"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 303,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-number-pills",
													children: [
														2,
														3,
														4,
														5,
														6
													].map((days) => /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														className: answers.workoutDays === days ? "selected" : "",
														onClick: () => setAnswer("workoutDays", days),
														children: [
															answers.workoutDays === days && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 304,
																columnNumber: 259
															}, this),
															days,
															" days"
														]
													}, days, true, {
														fileName: _jsxFileName,
														lineNumber: 304,
														columnNumber: 87
													}, this))
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 304,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "signup-live-helper",
													children: answers.workoutDays ? `That leaves ${7 - answers.workoutDays} rest ${7 - answers.workoutDays === 1 ? "day" : "days"} each week for recovery.` : "Choose a pace that leaves room for recovery."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 305,
													columnNumber: 19
												}, this),
												answers.workoutDays === 6 && answers.experience === "Starting Out" && /* @__PURE__ */ _jsxDEV("p", {
													className: "signup-notice",
													children: "New to training? 3-4 days a week is a great way to start."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 306,
													columnNumber: 90
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 302,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-step-section",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "signup-section-label",
												children: "SESSION DURATION"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 309,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "signup-session-controls",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field",
													children: /* @__PURE__ */ _jsxDEV("select", {
														value: answers.sessionChoice,
														onChange: (event) => {
															const choice = event.target.value;
															setAnswers((current) => ({
																...current,
																sessionChoice: choice,
																sessionMinutes: choice && choice !== "custom" ? Number(choice) : null,
																customSessionMinutes: choice === "custom" ? current.customSessionMinutes : ""
															}));
														},
														"aria-label": "Session duration",
														children: [
															/* @__PURE__ */ _jsxDEV("option", {
																value: "",
																disabled: true,
																children: "Select session length"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 325,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "15",
																children: "15 minutes"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 326,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "30",
																children: "30 minutes"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 327,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "45",
																children: "45 minutes"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 328,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "60",
																children: "60 minutes"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 329,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "custom",
																children: "Custom..."
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 330,
																columnNumber: 25
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 312,
														columnNumber: 23
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 311,
													columnNumber: 21
												}, this), answers.sessionChoice === "custom" && /* @__PURE__ */ _jsxDEV("label", {
													className: "signup-field signup-custom-session",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "signup-input-with-unit",
														children: [/* @__PURE__ */ _jsxDEV("input", {
															ref: customSessionRef,
															inputMode: "numeric",
															value: answers.customSessionMinutes,
															onChange: (event) => {
																const value = event.target.value.replace(/\D/g, "");
																setAnswers((current) => ({
																	...current,
																	customSessionMinutes: value,
																	sessionMinutes: value && Number(value) >= 5 && Number(value) <= 180 ? Number(value) : null
																}));
															},
															placeholder: "50"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 334,
															columnNumber: 64
														}, this), /* @__PURE__ */ _jsxDEV("b", { children: "min" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 337,
															columnNumber: 45
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 334,
														columnNumber: 23
													}, this), answers.customSessionMinutes && !customSessionValid && /* @__PURE__ */ _jsxDEV("small", {
														className: "signup-field-error",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "!" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 338,
															columnNumber: 117
														}, this), "Enter 5-180 minutes"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 338,
														columnNumber: 79
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 333,
													columnNumber: 60
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 310,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 17
										}, this)
									]
								}, "step-3", true, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 15
								}, this),
								step === 4 && /* @__PURE__ */ _jsxDEV("div", {
									className: `signup-step-content signup-slide-${direction}`,
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "signup-step-title",
											ref: titleRef,
											tabIndex: -1,
											children: "Review your transformation profile."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "signup-step-intro",
											children: "Confirm your details before we structure your challenge."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 348,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-review-card",
											children: [
												/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-group-head",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "ACCOUNT" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 351,
														columnNumber: 63
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => editStep(1),
														children: "Edit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 351,
														columnNumber: 83
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 351,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-account",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "signup-review-avatar",
														children: answers.avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
															src: answers.avatarUrl,
															alt: ""
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 352,
															columnNumber: 120
														}, this) : initials
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 352,
														columnNumber: 60
													}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: answers.name }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 352,
														columnNumber: 182
													}, this), /* @__PURE__ */ _jsxDEV("small", { children: answers.email }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 352,
														columnNumber: 213
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 352,
														columnNumber: 177
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 352,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 350,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-group-head",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "BODY PROFILE" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 355,
														columnNumber: 63
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => editStep(2),
														children: "Edit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 355,
														columnNumber: 88
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 355,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-values",
													children: [
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Age" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 357,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.age }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 357,
															columnNumber: 44
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 357,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Height" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 358,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
															answers.height,
															" ",
															answers.unitSystem === "metric" && !answers.height.toLowerCase().includes("cm") ? "cm" : ""
														] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 358,
															columnNumber: 47
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 358,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Current → target weight" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 359,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
															answers.weight || "—",
															" ",
															answers.unitSystem === "metric" ? "kg" : "lbs",
															" → ",
															answers.targetWeight ? `${answers.targetWeight} ${answers.unitSystem === "metric" ? "kg" : "lbs"}` : "N/A"
														] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 359,
															columnNumber: 64
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 359,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Unit system" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 360,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.unitSystem === "metric" ? "Metric" : "Imperial" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 360,
															columnNumber: 52
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 360,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Somatotype" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 361,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.somatotype }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 361,
															columnNumber: 51
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 361,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Activity level" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 362,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.activity }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 362,
															columnNumber: 55
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 362,
															columnNumber: 23
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 356,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 354,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-group-head",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "SCHEDULE" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 366,
														columnNumber: 63
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => editStep(3),
														children: "Edit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 366,
														columnNumber: 84
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 366,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-values",
													children: [
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Challenge duration" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 368,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [answers.challengeDays, " Days"] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 368,
															columnNumber: 59
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 368,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Frequency" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 369,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
															answers.workoutDays,
															" days/week, ",
															answers.sessionMinutes,
															" min/session"
														] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 369,
															columnNumber: 50
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 369,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Timeline focus" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 370,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.targetTimeline }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 370,
															columnNumber: 55
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 370,
															columnNumber: 23
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 367,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 365,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-group-head",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "FOCUS & GEAR" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 374,
														columnNumber: 63
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => editStep(2),
														children: "Edit"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 374,
														columnNumber: 88
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 374,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "signup-review-values",
													children: [
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Primary goal" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 376,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.goal }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 376,
															columnNumber: 53
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 376,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Experience level" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 377,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.experience }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 377,
															columnNumber: 57
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 377,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Available equipment" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 378,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.availableEquipment }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 378,
															columnNumber: 60
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 378,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Explorer focus" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 379,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.focusArea }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 379,
															columnNumber: 55
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 379,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Training mode" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 380,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.mode }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 380,
															columnNumber: 54
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 380,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("p", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "Injury or condition" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 381,
															columnNumber: 26
														}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.hasCondition ? "Yes — favor lower impact" : "No" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 381,
															columnNumber: 60
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 381,
															columnNumber: 23
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 375,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 373,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 349,
											columnNumber: 17
										}, this)
									]
								}, "step-4", true, {
									fileName: _jsxFileName,
									lineNumber: 346,
									columnNumber: 15
								}, this),
								step === 5 && /* @__PURE__ */ _jsxDEV("div", {
									className: "signup-generation-state signup-slide-forward",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-generation-ring",
											style: { "--generation-progress": `${generationProgress * 3.6}deg` },
											children: /* @__PURE__ */ _jsxDEV("span", { children: [generationProgress, "%"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 390,
												columnNumber: 150
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 390,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-reduced-progress",
											children: /* @__PURE__ */ _jsxDEV("i", { style: { width: `${generationProgress}%` } }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 391,
												columnNumber: 58
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("strong", {
											className: "signup-generation-status",
											children: statusMessages[generationStatus]
										}, generationStatus, false, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", { children: "This only takes a moment." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 393,
											columnNumber: 17
										}, this)
									]
								}, "generation", true, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 15
								}, this),
								step === 6 && /* @__PURE__ */ _jsxDEV("div", {
									className: "signup-reveal signup-slide-forward",
									children: [
										/* @__PURE__ */ _jsxDEV("h2", {
											id: "signup-step-title",
											ref: titleRef,
											tabIndex: -1,
											children: "Your challenge is ready."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 399,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "signup-step-intro",
											children: "Your fitness journey starts today! Based on your answers, here is what your challenge includes:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 400,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "signup-reveal-list",
											children: [
												[
													"clipboard",
													"Complete, Easy-to-Follow Plan",
													"Clear scheduled workouts, structured rest days, and progressive cues."
												],
												[
													"sliders",
													"Absolute Freedom to Customize",
													"Adjust your equipment, intensity, and workout days to fit your week."
												],
												[
													"camera",
													"Progress Photos & Weight Tracking",
													"Capture your transformation with regular photos and track every pound lost."
												],
												[
													"timer",
													"Structured Guided Sessions",
													"Built-in countdown timers, rep counters, and motivational cues."
												]
											].map(([icon, title, description], index) => /* @__PURE__ */ _jsxDEV("article", {
												style: { "--reveal-index": index },
												children: [/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: icon }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 407,
													columnNumber: 150
												}, this) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 407,
													columnNumber: 144
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: title }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 407,
													columnNumber: 230
												}, this), /* @__PURE__ */ _jsxDEV("p", { children: description }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 407,
													columnNumber: 254
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 407,
													columnNumber: 225
												}, this)]
											}, title, true, {
												fileName: _jsxFileName,
												lineNumber: 407,
												columnNumber: 64
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 17
										}, this)
									]
								}, "reveal", true, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 11
						}, this),
						step <= 3 && /* @__PURE__ */ _jsxDEV("footer", {
							className: "signup-actions",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "signup-back-link",
								type: "button",
								onClick: goBack,
								children: "Back"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 60
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								onClick: goNext,
								disabled: !stepValid,
								children: returnToReview ? "Return to review" : "Next"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 141
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 25
						}, this),
						step === 4 && /* @__PURE__ */ _jsxDEV("footer", {
							className: "signup-actions signup-review-actions",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "signup-back-link",
								type: "button",
								onClick: goBack,
								children: "Back"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 417,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Button, {
								onClick: async () => {
									try {
										// 1. Register user account on Django backend
										await api.register(answers.email, answers.password);
										// 2. Save onboarding profile data to Django backend
										await api.saveOnboarding({
											name: answers.name,
											age: answers.age,
											height: answers.height,
											currentWeight: answers.weight,
											targetWeight: answers.targetWeight,
											unitSystem: answers.unitSystem,
											somatotype: answers.somatotype,
											goal: answers.goal,
											experience: answers.experience,
											activity: answers.activity,
											workoutDays: String(answers.workoutDays),
											sessionLength: String(answers.sessionMinutes ?? 30),
											focusArea: answers.focusArea || "General Fitness",
											mode: answers.mode || "Standard",
											equipment: answers.availableEquipment,
											challengeDays: answers.challengeDays,
											targetTimeline: answers.targetTimeline,
											hasCondition: answers.hasCondition
										});
										// 3. Trigger generation state animation
										setGenerationProgress(0);
										setGenerationStatus(0);
										setStep(5);
									} catch (error) {
										console.error("Backend integration failed during signup:", error);
										alert("Could not connect to the backend server. Make sure Django is running.");
									}
								},
								children: "Generate My Plan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 419,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("small", { children: "AI generation is limited. This uses one of your plan generations." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 459,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 418,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 416,
							columnNumber: 13
						}, this),
						step === 6 && /* @__PURE__ */ _jsxDEV("footer", {
							className: "signup-actions signup-reveal-actions",
							children: /* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => onComplete(answers),
								children: ["Dashboard ", /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 464,
									columnNumber: 137
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 83
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 464,
							columnNumber: 26
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 9
				}, this),
				step <= 4 && /* @__PURE__ */ _jsxDEV("aside", {
					className: "signup-preview-panel",
					"aria-label": "Your plan preview",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "signup-preview-brand",
							children: [/* @__PURE__ */ _jsxDEV(LogoMark, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 468,
								columnNumber: 49
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "SoferFit" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 468,
								columnNumber: 61
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 468,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { className: "signup-orb signup-orb-one" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 468,
							columnNumber: 88
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { className: "signup-orb signup-orb-two" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 468,
							columnNumber: 133
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "signup-preview-stack",
							children: step === 1 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-primary",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "signup-glass-icon",
										children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 471,
											columnNumber: 111
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 75
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "DAY 1" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 142
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: "Starts the day you sign up" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 162
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 471,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-secondary",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "signup-mini-check",
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "flame" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 472,
										columnNumber: 113
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 77
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "HABIT STREAK" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 146
								}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "Show up daily to build your streak!" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 173
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 141
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 472,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 470,
								columnNumber: 27
							}, this) : step === 2 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-primary signup-weekly-card",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "signup-progress-ring",
										children: ["4", /* @__PURE__ */ _jsxDEV("small", { children: "DAYS" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 474,
											columnNumber: 134
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 94
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "WEEKLY TARGET" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 160
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: "Build a steady rhythm" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 188
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 474,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-secondary",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "signup-mini-check",
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "chart" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 475,
										columnNumber: 113
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 77
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "YOUR STARTING POINT" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 146
								}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.goal || "Choose your primary goal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 180
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 141
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 475,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 473,
								columnNumber: 32
							}, this) : step === 3 ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-primary signup-week-card",
								children: [
									/* @__PURE__ */ _jsxDEV("small", { children: "YOUR WEEK" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 477,
										columnNumber: 92
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										0,
										1,
										2,
										3,
										4,
										5,
										6
									].map((day) => /* @__PURE__ */ _jsxDEV("i", {
										className: day < (answers.workoutDays ?? 0) ? "workout" : "rest",
										children: [
											"M",
											"T",
											"W",
											"T",
											"F",
											"S",
											"S"
										][day]
									}, day, false, {
										fileName: _jsxFileName,
										lineNumber: 477,
										columnNumber: 157
									}, this)) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 477,
										columnNumber: 116
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: answers.workoutDays ? `${answers.workoutDays} training days` : "Choose your rhythm" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 477,
										columnNumber: 290
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 477,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-secondary",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "signup-mini-check",
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "flame" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 478,
										columnNumber: 113
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 77
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "CHALLENGE LENGTH" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 146
								}, this), /* @__PURE__ */ _jsxDEV("strong", { children: answers.challengeDays ? `${answers.challengeDays} days` : "Choose 60 or 90 days" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 177
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 141
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 478,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 476,
								columnNumber: 32
							}, this) : /* @__PURE__ */ _jsxDEV("article", {
								className: "signup-glass-card signup-glass-primary signup-ready-card",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "signup-day-one-chip",
										children: "DAY 1"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 479,
										columnNumber: 97
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "READY TO START" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 479,
										columnNumber: 147
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: [
										"Your ",
										answers.challengeDays,
										"-day challenge"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 479,
										columnNumber: 176
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "Everything is set for your first session." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 479,
										columnNumber: 235
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 479,
								columnNumber: 19
							}, this)
						}, step, false, {
							fileName: _jsxFileName,
							lineNumber: 469,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "signup-preview-quote",
							children: "Small steps. Stronger days."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 481,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 467,
					columnNumber: 23
				}, this),
				showLeavePrompt && /* @__PURE__ */ _jsxDEV("div", {
					className: "signup-confirm-wrap",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "signup-confirm",
						role: "alertdialog",
						"aria-modal": "true",
						"aria-labelledby": "leave-signup-title",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "signup-confirm-icon",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 485,
									columnNumber: 210
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 172
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								id: "leave-signup-title",
								children: "Leave sign up?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 237
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Your answers will be lost." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 284
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "ghost",
								onClick: () => setShowLeavePrompt(false),
								children: "Stay"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 322
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								variant: "dark",
								onClick: onClose,
								children: "Leave"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 401
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 317
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 485,
						columnNumber: 66
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 485,
					columnNumber: 29
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 191,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 190,
		columnNumber: 5
	}, this);
}
_s(SignupModal, "cCZs2o84TTgQcLaEE+xsEEuwDzs=");
_c = SignupModal;
var _c;
$RefreshReg$(_c, "SignupModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/modals/SignupModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/SignupModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/SignupModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/SignupModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsY0FBYztBQUN2QixTQUFTLFlBQVk7QUFDckIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsY0FBYyxlQUFlLHFCQUFxQjtBQUMzRCxTQUFTLFdBQVc7Ozs7QUFHcEIsT0FBTyxTQUFTLFlBQVksRUFDMUIsTUFDQSxnQkFDQSxTQUNBLFNBQ0EsZ0JBQ0EsY0FRQzs7Q0FDRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsQ0FBQztDQUNsQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBNkIsU0FBUztDQUN4RSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLENBQUM7Q0FDOUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxDQUFDO0NBQzFELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBd0IsY0FBYztDQUNwRSxNQUFNLFdBQVcsT0FBMkIsSUFBSTtDQUNoRCxNQUFNLGVBQWUsT0FBeUIsSUFBSTtDQUNsRCxNQUFNLG1CQUFtQixPQUF5QixJQUFJO0NBQ3RELE1BQU0sYUFBYTtDQUNuQixNQUFNLGFBQTRDLEtBQVEsVUFBNEIsWUFBWSxhQUFhO0VBQUUsR0FBRztHQUFVLE1BQU07Q0FBTSxFQUFFO0NBRTVJLE1BQU0sZ0JBQWdCO0VBQ3BCLFFBQVEsUUFBUSxTQUFTLFVBQVU7RUFDbkMsUUFBUSxrQkFBa0IsS0FBSyxRQUFRLFFBQVE7RUFDL0MsTUFBTSxRQUFRLEtBQUssUUFBUSxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsUUFBUTtDQUN2RTtDQUNBLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxhQUFhLENBQUMsQ0FBQyxNQUFNLE9BQU87Q0FDaEUsTUFBTSxZQUFZLE9BQU8sUUFBUSxHQUFHO0NBQ3BDLE1BQU0sV0FBVyxjQUFjLFFBQVEsUUFBUSxRQUFRLFVBQVU7Q0FDakUsTUFBTSxXQUFXLGNBQWMsUUFBUSxRQUFRLFFBQVEsVUFBVTtDQUNqRSxNQUFNLFdBQVcsYUFBYSxNQUFNLGFBQWE7Q0FDakQsTUFBTSxjQUFjLFlBQVksT0FBTyxZQUFZO0NBQ25ELE1BQU0sY0FBYyxZQUFZLE1BQU0sWUFBWTtDQUNsRCxNQUFNLGVBQWUsUUFBUSxRQUFRLEtBQUssS0FBSyxDQUFDLEtBQUssYUFBYSxLQUFLLFFBQVEsS0FBSyxLQUFLLGlCQUFpQixZQUFZLGVBQWU7Q0FDckksTUFBTSxXQUFXLGNBQWMsUUFBUSxjQUFjLFFBQVEsVUFBVTtDQUN2RSxNQUFNLGtCQUFrQixRQUFRLFFBQVEsYUFBYSxLQUFLLENBQUM7Q0FDM0QsTUFBTSxjQUFjLENBQUMsbUJBQW9CLFlBQVksTUFBTSxZQUFZO0NBQ3ZFLE1BQU0sZ0JBQWdCLFFBQVEsbUJBQW1CLGtCQUFrQixNQUFNLFFBQVEsbUJBQW1CLGNBQWMsTUFBTTtDQUN4SCxNQUFNLGdCQUFnQixtQkFBbUIsZUFBZSxnQkFBaUIsWUFBYSxXQUFXLFFBQVEsSUFBTSxTQUFTLFdBQVcsWUFBWSxnQkFBZ0I7Q0FDL0osTUFBTSxlQUFlLFFBQVEsUUFBUSxjQUFjLFFBQVEsUUFBUSxRQUFRLGNBQWMsUUFBUSxZQUFZLFFBQVEsc0JBQXNCLFdBQVc7Q0FDdEosTUFBTSxxQkFBcUIsT0FBTyxRQUFRLG9CQUFvQjtDQUM5RCxNQUFNLHFCQUFxQixPQUFPLFVBQVUsa0JBQWtCLEtBQUssc0JBQXNCLEtBQUssc0JBQXNCO0NBQ3BILE1BQU0sZUFBZSxRQUFRLGtCQUFrQixXQUFXLHFCQUFxQixRQUFRLFFBQVEsaUJBQWlCLFFBQVEsY0FBYztDQUN0SSxNQUFNLGlCQUFpQixRQUFRLFFBQVEsaUJBQWlCLFFBQVEsZUFBZSxZQUFZO0NBQzNGLE1BQU0sWUFBWSxTQUFTLElBQUksZUFBZSxTQUFTLElBQUksZUFBZSxTQUFTLElBQUksaUJBQWlCO0NBQ3hHLE1BQU0sV0FBVyxPQUFPLE9BQU8sYUFBYSxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQztDQUU5RCxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsTUFBTTtFQUNYLFdBQVcsY0FBYztFQUN6QixRQUFRLENBQUM7RUFDVCxhQUFhLFNBQVM7RUFDdEIsbUJBQW1CLEtBQUs7RUFDeEIsZUFBZSxFQUFFO0VBQ2pCLGtCQUFrQixLQUFLO0VBQ3ZCLHNCQUFzQixDQUFDO0VBQ3ZCLG9CQUFvQixDQUFDO0NBQ3ZCLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxnQkFBZ0I7RUFDZCxJQUFJLFNBQVMsR0FBRztFQUNoQixNQUFNLFlBQVksS0FBSyxJQUFJO0VBQzNCLE1BQU0sZ0JBQWdCLE9BQU8sa0JBQWtCO0dBQzdDLHNCQUFzQixLQUFLLElBQUksS0FBSyxLQUFLLE9BQVEsS0FBSyxJQUFJLElBQUksYUFBYSxNQUFRLEdBQUcsQ0FBQyxDQUFDO0VBQzFGLEdBQUcsRUFBRTtFQUNMLE1BQU0sY0FBYyxPQUFPLGtCQUFrQixxQkFBcUIsWUFBWSxLQUFLLElBQUksR0FBRyxVQUFVLENBQUMsQ0FBQyxHQUFHLElBQUk7RUFDN0csTUFBTSxjQUFjLE9BQU8saUJBQWlCO0dBQzFDLHNCQUFzQixHQUFHO0dBQ3pCLFFBQVEsQ0FBQztFQUNYLEdBQUcsSUFBSTtFQUNQLGFBQWE7R0FDWCxPQUFPLGNBQWMsYUFBYTtHQUNsQyxPQUFPLGNBQWMsV0FBVztHQUNoQyxPQUFPLGFBQWEsV0FBVztFQUNqQztDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsTUFBTTtFQUNYLE1BQU0sbUJBQW1CLFNBQVMsS0FBSyxNQUFNO0VBQzdDLFNBQVMsS0FBSyxNQUFNLFdBQVc7RUFDL0IsYUFBYTtHQUFFLFNBQVMsS0FBSyxNQUFNLFdBQVc7RUFBa0I7Q0FDbEUsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBQ1gsT0FBTyxpQkFBaUIsU0FBUyxTQUFTLE1BQU0sR0FBRyxFQUFFO0NBQ3ZELEdBQUcsQ0FBQyxNQUFNLElBQUksQ0FBQztDQUVmLGdCQUFnQjtFQUNkLElBQUksU0FBUyxLQUFLLFFBQVEsa0JBQWtCLFVBQVU7R0FDcEQsT0FBTyxpQkFBaUIsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7RUFDL0Q7Q0FDRixHQUFHLENBQUMsUUFBUSxlQUFlLElBQUksQ0FBQztDQUVoQyxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsTUFBTTtFQUNYLE1BQU0saUJBQWlCLFVBQXlCO0dBQzlDLElBQUksTUFBTSxRQUFRLFlBQVksU0FBUyxHQUFHO0lBQ3hDLE1BQU0sZUFBZTtJQUNyQixtQkFBbUIsSUFBSTtHQUN6QjtHQUNBLElBQUksTUFBTSxRQUFRLFdBQVcsQ0FBQyxtQkFBbUIsYUFBYSxPQUFPLEdBQUc7SUFDdEUsTUFBTSxTQUFTLE1BQU07SUFDckIsSUFBSSxPQUFPLFlBQVksWUFBWSxPQUFPLFlBQVksWUFBWSxPQUFPLFlBQVk7S0FDbkYsTUFBTSxlQUFlO0tBQ3JCLGFBQWEsU0FBUztLQUN0QixTQUFTLFlBQVksVUFBVSxDQUFDO0lBQ2xDO0dBQ0Y7RUFDRjtFQUNBLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxhQUFhLE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtDQUNsRSxHQUFHO0VBQUM7RUFBTTtFQUFpQjtFQUFNO0NBQVMsQ0FBQztDQUUzQyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBRWxCLE1BQU0sZUFBZTtFQUNuQixJQUFJLFNBQVMsR0FBRztFQUNoQixJQUFJLFNBQVMsR0FBRyxPQUFPLG1CQUFtQixJQUFJO0VBQzlDLGFBQWEsTUFBTTtFQUNuQixTQUFTLFlBQVksVUFBVSxDQUFDO0NBQ2xDO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLElBQUksQ0FBQyxhQUFhLFFBQVEsWUFBWTtFQUN0QyxhQUFhLFNBQVM7RUFDdEIsSUFBSSxnQkFBZ0I7R0FDbEIsa0JBQWtCLEtBQUs7R0FDdkIsUUFBUSxDQUFDO0VBQ1gsT0FBTztHQUNMLFNBQVMsWUFBWSxVQUFVLENBQUM7RUFDbEM7Q0FDRjtDQUNBLE1BQU0sY0FBYyxTQUFxQjtFQUN2QyxJQUFJLFNBQVMsUUFBUSxZQUFZO0VBQ2pDLE1BQU0sYUFBYSxRQUFRLFNBQVMsU0FBUyxhQUN6QyxHQUFHLEtBQUssTUFBTSxXQUFXLEtBQUssRUFBRSxNQUFNLEtBQUssTUFBTyxXQUFXLFFBQVMsSUFBSSxFQUFFLE9BQzVFLE9BQU8sS0FBSyxNQUFNLFFBQVEsQ0FBQyxJQUFJO0VBQ25DLE1BQU0sYUFBYSxRQUFRLFNBQVMsU0FBUyxhQUFhLE9BQU8sS0FBSyxNQUFNLFdBQVcsT0FBTyxDQUFDLElBQUksT0FBTyxLQUFLLE1BQU0sUUFBUSxDQUFDLElBQUk7RUFDbEksTUFBTSxhQUFhLGtCQUFrQixTQUFTLGFBQWEsT0FBTyxLQUFLLE1BQU0sV0FBVyxPQUFPLENBQUMsSUFBSSxPQUFPLEtBQUssTUFBTSxRQUFRLENBQUMsSUFBSTtFQUNuSSxZQUFZLGFBQWE7R0FBRSxHQUFHO0dBQVMsWUFBWTtHQUFNLFFBQVE7R0FBWSxRQUFRO0dBQVksY0FBYztFQUFXLEVBQUU7Q0FDOUg7Q0FDQSxNQUFNLGdCQUFnQixTQUFnQjtFQUNwQyxJQUFJLENBQUMsTUFBTTtFQUNYLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxRQUFRLEdBQUcsT0FBTyxlQUFlLDhCQUE4QjtFQUN6RixJQUFJLEtBQUssT0FBTyxJQUFJLE9BQU8sTUFBTSxPQUFPLGVBQWUsMkNBQTJDO0VBQ2xHLGVBQWUsRUFBRTtFQUNqQixNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sZUFBZSxVQUFVLGFBQWEsT0FBTyxPQUFPLE1BQU0sQ0FBQztFQUNsRSxPQUFPLGNBQWMsSUFBSTtDQUMzQjtDQUVBLE1BQU0sUUFBMEIsT0FBVSxVQUFtQixhQUMzRCx3QkFBQyxVQUFEO0VBQW9CLE1BQUs7RUFBUyxXQUFXLGVBQWUsV0FBVyxhQUFhO0VBQU0sZUFBZSxTQUFTLEtBQUs7WUFBdkgsQ0FDRyxZQUFZLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7WUFBRyxLQUM5QjtJQUZLOzs7O1FBRUw7Q0FFVixNQUFNLFdBQVcsUUFBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsWUFBWSxLQUFLO0NBQy9HLE1BQU0saUJBQWlCO0VBQ3JCO0VBQ0Esb0JBQW9CLFFBQVEsaUJBQWlCLEdBQUc7RUFDaEQ7Q0FDRjtDQUNBLE1BQU0sWUFBWSxhQUFxQjtFQUNyQyxrQkFBa0IsSUFBSTtFQUN0QixhQUFhLE1BQU07RUFDbkIsUUFBUSxRQUFRO0NBQ2xCO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFrQixtQkFBbUIsU0FBUyxLQUFLLG1CQUFtQixJQUFJO1lBQ3ZGLHdCQUFDLFdBQUQ7R0FBUyxXQUFXLGdCQUFnQixPQUFPLElBQUksdUJBQXVCO0dBQU0sTUFBSztHQUFTLGNBQVc7R0FBTyxtQkFBZ0I7R0FBb0IsY0FBYyxVQUFVLE1BQU0sZ0JBQWdCO2FBQTlMO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNHLFFBQVEsS0FBSyx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBbEI7UUFDWix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO1VBQXFCLE1BQUs7VUFBUyxTQUFTO1VBQVEsY0FBWSxTQUFTLElBQUksa0JBQWtCO29CQUFpQix3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7OztTQUFTOzs7O21CQUM5Six3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBd0Isd0JBQUMsUUFBRCxhQUFNLHNCQUFrQix3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLFNBQVM7cUJBQVM7VUFBYzs7OztrQkFBTzs7Ozs7U0FBTTs7OztpQkFDL0g7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNO1VBQU07VUFBSztVQUFLO1NBQWlCOzs7O21CQUN2Qyx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUF3QixjQUFZLFFBQVEsS0FBSyxNQUFNO29CQUNuRTtXQUFDO1dBQUc7V0FBRztXQUFHO1VBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyx3QkFBQyxLQUFELEVBQWMsV0FBVyxPQUFPLFFBQVEsU0FBUyxJQUFJLGFBQWEsU0FBUyxPQUFPLFlBQVksR0FBSyxHQUEzRjs7OztpQkFBMkYsQ0FBQztTQUM3SDs7OztpQkFDRjs7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FBdUMsd0JBQUMsTUFBRCxFQUFNLE1BQU0sU0FBUyxJQUFJLFVBQVUsU0FBUyxJQUFJLGFBQWEsU0FBUyxJQUFJLFVBQVUsV0FBYTs7OzttQkFBQyx3QkFBQyxRQUFELFlBQU8sU0FBUyxJQUFJLHdCQUF3QixTQUFTLElBQUksa0JBQWtCLFNBQVMsSUFBSSxvQkFBb0IsZ0JBQXNCOzs7O2lCQUFNOzs7Ozs7T0FDM1E7Ozs7OztNQUVSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0csU0FBUyxLQUNSLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLG9DQUFvQzttQkFBcEQ7VUFDRSx3QkFBQyxNQUFEO1dBQUksSUFBRztXQUFvQixLQUFLO1dBQVUsVUFBVSxDQUFDO3FCQUFHO1VBQXdCOzs7OztVQUNoRix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBb0I7VUFBNkU7Ozs7O1VBQzlHLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsU0FBRDthQUFPLEtBQUs7YUFBYyxNQUFLO2FBQU8sUUFBTzthQUFVLFdBQVcsVUFBVSxhQUFhLE1BQU0sT0FBTyxRQUFRLEVBQUU7WUFBSTs7Ozs7WUFDcEgsd0JBQUMsVUFBRDthQUFRLE1BQUs7YUFBUyxXQUFVO2FBQXVCLGVBQWUsYUFBYSxTQUFTLE1BQU07YUFBRyxjQUFXO3VCQUM3RyxRQUFRLFlBQVksd0JBQUMsT0FBRDtjQUFLLEtBQUssUUFBUTtjQUFXLEtBQUk7YUFBbUI7Ozs7d0JBQUksd0JBQUMsUUFBRCxhQUFNLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7dUJBQUMsd0JBQUMsS0FBRCxZQUFHLElBQUk7Ozs7cUJBQU87Ozs7O1lBQ2pIOzs7OztZQUNSLHdCQUFDLFVBQUQsYUFBUSx5QkFBcUIsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O29CQUFTOzs7OztZQUMzRCxRQUFRLGFBQWEsd0JBQUMsVUFBRDthQUFRLE1BQUs7YUFBUyxXQUFVO2FBQXVCLGVBQWUsYUFBYSxTQUFTLE1BQU07dUJBQUc7WUFBYzs7Ozs7WUFDeEksZUFBZSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakIsQ0FBc0Msd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7dUJBQUUsV0FBbUI7Ozs7OztXQUNyRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakIsQ0FBZ0MsWUFBUSx3QkFBQyxTQUFEO2NBQU8sT0FBTyxRQUFRO2NBQU0sV0FBVyxVQUFVLFVBQVUsUUFBUSxNQUFNLE9BQU8sS0FBSztjQUFHLGFBQVk7YUFBcUI7Ozs7cUJBQVE7Ozs7OztZQUN6Syx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakI7Y0FBZ0M7Y0FBYSx3QkFBQyxTQUFEO2VBQU8sTUFBSztlQUFRLE9BQU8sUUFBUTtlQUFPLFdBQVcsVUFBVSxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7ZUFBRyxhQUFZO2NBQW1COzs7OztjQUFFLFFBQVEsU0FBUyxDQUFDLGFBQWEsS0FBSyxRQUFRLEtBQUssS0FBSyx3QkFBQyxTQUFEO2VBQU8sV0FBVTt5QkFBakIsQ0FBc0Msd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7eUJBQUMsOEJBQW1DOzs7Ozs7YUFBUzs7Ozs7O1lBQzNVLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFqQixDQUFnQyxZQUFRLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3Qyx3QkFBQyxTQUFEO2VBQU8sTUFBTSxlQUFlLFNBQVM7ZUFBWSxPQUFPLFFBQVE7ZUFBVSxXQUFXLFVBQVUsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUFLO2VBQUcsYUFBWTtjQUE0Qjs7Ozt3QkFBQyx3QkFBQyxVQUFEO2VBQVEsTUFBSztlQUFTLGVBQWUsaUJBQWlCLFlBQVksQ0FBQyxPQUFPO2VBQUcsY0FBWSxlQUFlLGtCQUFrQjt5QkFBaUIsd0JBQUMsTUFBRCxFQUFNLE1BQU0sZUFBZSxXQUFXLE1BQVE7Ozs7O2NBQVM7Ozs7c0JBQU87Ozs7O3FCQUFROzs7Ozs7WUFDcGQsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxPQUFEO2NBQUssV0FBVTtjQUF3QixjQUFZLHFCQUFxQixTQUFTO3dCQUFTO2VBQUM7ZUFBRztlQUFHO2NBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyx3QkFBQyxLQUFELEVBQWMsV0FBVyxRQUFRLFdBQVcsV0FBVyxHQUFLLEdBQXBEOzs7O3FCQUFvRCxDQUFDO2FBQU87Ozs7dUJBQ3RMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUNaO2VBQUMsQ0FBQyxjQUFjLFFBQVEsdUJBQXVCO2VBQUcsQ0FBQyxjQUFjLFFBQVEsK0JBQStCO2VBQUcsQ0FBQyxjQUFjLE1BQU0sNkJBQTZCO2NBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLFdBQVcsd0JBQUMsUUFBRDtlQUFNLFdBQVcsU0FBUyxXQUFXO3lCQUFyQyxDQUE2RCx3QkFBQyxLQUFELFlBQUcsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozt3QkFBSTs7Ozt5QkFBRSxLQUFZO2lCQUF4RCxPQUFPLEtBQUs7Ozs7cUJBQTRDLENBQUM7YUFDOVI7Ozs7cUJBQ0Y7Ozs7OztXQUNGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O3FCQUNyQix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUFvQyx3QkFBQyxVQUFEO2FBQVEsTUFBSzthQUFTLFdBQVcsUUFBUSxlQUFlLFdBQVcsV0FBVzthQUFJLGVBQWUsV0FBVyxRQUFRO3VCQUFwSCxDQUF1SCxXQUFPLHdCQUFDLFNBQUQsWUFBTyxRQUFZOzs7O3FCQUFTOzs7OztzQkFBQyx3QkFBQyxVQUFEO2FBQVEsTUFBSzthQUFTLFdBQVcsUUFBUSxlQUFlLGFBQWEsV0FBVzthQUFJLGVBQWUsV0FBVyxVQUFVO3VCQUF4SCxDQUEySCxhQUFTLHdCQUFDLFNBQUQsWUFBTyxTQUFhOzs7O3FCQUFTOzs7OztvQkFBTTs7Ozs7bUJBQ25XOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFqQjtjQUFnQztjQUFHLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO2VBQVUsT0FBTyxRQUFRO2VBQUssV0FBVyxVQUFVLFVBQVUsT0FBTyxNQUFNLE9BQU8sS0FBSztlQUFHLGFBQVk7Y0FBTTs7Ozs7Y0FBRSxRQUFRLE9BQU8sQ0FBQyxZQUFZLHdCQUFDLFNBQUQ7ZUFBTyxXQUFVO3lCQUFqQixDQUFzQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozt5QkFBQywyQkFBZ0M7Ozs7OzthQUFTOzs7Ozs7WUFDMVIsd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQWpCO2NBQWdDO2NBQU0sd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQWhCLENBQXlDLHdCQUFDLFNBQUQ7Z0JBQU8sV0FBVyxRQUFRLGVBQWUsV0FBVyxZQUFZO2dCQUFRLE9BQU8sUUFBUTtnQkFBUSxXQUFXLFVBQVUsVUFBVSxVQUFVLE1BQU0sT0FBTyxLQUFLO2dCQUFHLGFBQWEsUUFBUSxlQUFlLFdBQVcsV0FBVztlQUFjOzs7O3lCQUFDLHdCQUFDLEtBQUQsWUFBSSxRQUFRLGVBQWUsV0FBVyxPQUFPLFVBQWE7Ozs7dUJBQU87Ozs7OztjQUFFLFFBQVEsVUFBVSxDQUFDLGVBQWUsd0JBQUMsU0FBRDtlQUFPLFdBQVU7eUJBQWpCLENBQXNDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3lCQUFFLFFBQVEsZUFBZSxXQUFXLGVBQWUscUJBQTZCOzs7Ozs7YUFBUzs7Ozs7O1lBQ3RpQix3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakI7Y0FBZ0M7Y0FBYyx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBaEIsQ0FBeUMsd0JBQUMsU0FBRDtnQkFBTyxXQUFVO2dCQUFVLE9BQU8sUUFBUTtnQkFBUSxXQUFXLFVBQVUsVUFBVSxVQUFVLE1BQU0sT0FBTyxLQUFLO2dCQUFHLGFBQWEsUUFBUSxlQUFlLFdBQVcsVUFBVTtlQUFZOzs7O3lCQUFDLHdCQUFDLEtBQUQsWUFBSSxRQUFRLGVBQWUsV0FBVyxPQUFPLE1BQVM7Ozs7dUJBQU87Ozs7OztjQUFFLFFBQVEsVUFBVSxDQUFDLGVBQWUsd0JBQUMsU0FBRDtlQUFPLFdBQVU7eUJBQWpCLENBQXNDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3lCQUFFLFFBQVEsZUFBZSxXQUFXLGNBQWMsWUFBb0I7Ozs7OzthQUFTOzs7Ozs7V0FDN2U7Ozs7OztVQUNKLFlBQVksWUFBWSxNQUFNLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFnQjtVQUFpRjs7Ozs7U0FDMUk7V0FqQ2dFOzs7O2VBaUNoRTtRQUdOLFNBQVMsS0FDUix3QkFBQyxPQUFEO1NBQUssV0FBVyxvQ0FBb0M7bUJBQXBEO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLElBQUc7V0FBb0IsS0FBSztXQUFVLFVBQVUsQ0FBQztxQkFBRztVQUFzQzs7Ozs7VUFDOUYsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQW9CO1VBQXNGOzs7OztVQUN2SCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQXVDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztzQkFBQyx3QkFBQyxTQUFEO2FBQVMsTUFBSzthQUFhLFlBQVksY0FBYyxNQUFNLENBQUMsVUFBVSxTQUFTLFlBQVksQ0FBQyxHQUFHLE1BQU07YUFBSSxtQkFBbUIsZUFBZSxZQUFZO2FBQUcsYUFBWTthQUFnQixVQUFVO1lBQVE7Ozs7b0JBQU07Ozs7O3FCQUM1USx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWjthQUFDLENBQUMsYUFBYSwwQ0FBMEM7YUFBRyxDQUFDLGFBQWEseURBQXlEO2FBQUcsQ0FBQyxhQUFhLG9EQUFvRDthQUFHLENBQUMsWUFBWSwwQ0FBMEM7WUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sY0FDalIsd0JBQUMsVUFBRDthQUFRLE1BQUs7YUFBcUIsV0FBVyxRQUFRLGVBQWUsUUFBUSxhQUFhO2FBQUksZUFBZSxVQUFVLGNBQWMsS0FBSzt1QkFBekksQ0FDRSx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFTLE1BQWM7Ozs7dUJBQUMsd0JBQUMsU0FBRCxZQUFRLFNBQWdCOzs7O3FCQUFPOzs7O3VCQUFFLFFBQVEsZUFBZSxTQUFTLHdCQUFDLEtBQUQsWUFBRyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O3NCQUFJOzs7O3FCQUNwSDtlQUZtQjs7OzttQkFFbkIsQ0FDVDtXQUNFOzs7O21CQUNGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUFxQyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBdUI7V0FBa0I7Ozs7cUJBQUMsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXNCO2FBQUM7YUFBdUI7YUFBMkI7WUFBb0IsQ0FBQyxDQUFZLEtBQUssU0FBUyxLQUFLLE1BQU0sUUFBUSxTQUFTLE9BQU8sVUFBVSxVQUFVLFFBQVEsS0FBSyxDQUFDLENBQUM7V0FBTzs7OzttQkFBTTs7Ozs7O1VBQ3pULHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQXFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF1QjtZQUFzQjs7Ozs7WUFBQyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBZ0I7WUFBeUM7Ozs7O1lBQUMsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQXNCO2NBQUM7Y0FBZ0I7Y0FBbUI7YUFBWSxDQUFDLENBQWtCLEtBQUssU0FBUyxLQUFLLE1BQU0sUUFBUSxlQUFlLE9BQU8sVUFBVSxVQUFVLGNBQWMsS0FBSyxDQUFDLENBQUM7WUFBTzs7Ozs7V0FBTTs7Ozs7O1VBQy9YLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQXFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF1QjtZQUE0Qjs7Ozs7WUFBQyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBZ0I7WUFBb0Q7Ozs7O1lBQUMsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQXNCO2NBQUM7Y0FBYTtjQUFvQjtjQUFxQjthQUFhLENBQUMsQ0FBZ0IsS0FBSyxTQUFTLEtBQUssTUFBTSxRQUFRLGFBQWEsT0FBTyxVQUFVLFVBQVUsWUFBWSxLQUFLLENBQUMsQ0FBQztZQUFPOzs7OztXQUFNOzs7Ozs7VUFDOVosd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBdUI7WUFBd0I7Ozs7O1lBQy9ELHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQWpCO2VBQ0Usd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUFoQixDQUFzQyxrQkFBYyx3QkFBQyxTQUFELFlBQU8sYUFBaUI7Ozs7d0JBQU87Ozs7OztlQUNuRix3QkFBQyxRQUFEO2dCQUFNLFdBQVU7MEJBQ2Qsd0JBQUMsUUFBRDtpQkFBTSxXQUFVOzJCQUFoQixDQUF5Qyx3QkFBQyxTQUFEO2tCQUFPLFdBQVU7a0JBQVUsT0FBTyxRQUFRO2tCQUFjLFdBQVcsVUFBVSxVQUFVLGdCQUFnQixNQUFNLE9BQU8sS0FBSztrQkFBRyxhQUFhLFFBQVEsZUFBZSxXQUFXLFVBQVU7aUJBQVk7Ozs7MkJBQUMsd0JBQUMsS0FBRCxZQUFJLFFBQVEsZUFBZSxXQUFXLE9BQU8sTUFBUzs7Ozt5QkFBTzs7Ozs7O2VBQ3BTOzs7OztlQUNMLG1CQUFtQixDQUFDLGVBQWUsd0JBQUMsU0FBRDtnQkFBTyxXQUFVOzBCQUFqQixDQUFzQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OzswQkFBRSxRQUFRLGVBQWUsV0FBVyxvQ0FBb0Msa0NBQTBDOzs7Ozs7Y0FDcE07Ozs7O3VCQUNQLHdCQUFDLFNBQUQ7Y0FBTyxXQUFVO3dCQUFqQixDQUFnQyx5QkFBcUIsd0JBQUMsVUFBRDtlQUFRLE9BQU8sUUFBUTtlQUFnQixXQUFXLFVBQVUsVUFBVSxrQkFBa0IsTUFBTSxPQUFPLEtBQUs7eUJBQTFHO2dCQUE2Ryx3QkFBQyxVQUFELFlBQVEsZ0JBQXFCOzs7OztnQkFBQyx3QkFBQyxVQUFELFlBQVEsWUFBaUI7Ozs7O2dCQUFDLHdCQUFDLFVBQUQsWUFBUSxZQUFpQjs7Ozs7Z0JBQUMsd0JBQUMsVUFBRCxZQUFRLGtCQUF1Qjs7Ozs7ZUFBUzs7Ozs7c0JBQVE7Ozs7O3FCQUNqUzs7Ozs7O1lBQ0osaUJBQWlCLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFnQjtZQUF3RTs7Ozs7V0FDcEg7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQXFDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF1QjtXQUF5Qjs7OztxQkFBQyx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBc0I7YUFBQzthQUEwQjthQUFxQjtZQUFpQixDQUFDLENBQXVCLEtBQUssU0FBUyxLQUFLLE1BQU0sUUFBUSx1QkFBdUIsT0FBTyxVQUFVLFVBQVUsc0JBQXNCLEtBQUssQ0FBQyxDQUFDO1dBQU87Ozs7bUJBQU07Ozs7OztVQUNqVyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQsWUFBRyxzSUFBc0k7Ozs7O1lBQ3pJLHdCQUFDLFNBQUQsYUFBTyx3QkFBQyxTQUFEO2FBQU8sTUFBSzthQUFXLFNBQVMsUUFBUTthQUFjLFdBQVcsVUFBVSxVQUFVLGdCQUFnQixNQUFNLE9BQU8sT0FBTztZQUFJOzs7O3NCQUFDLHdCQUFDLFFBQUQsWUFBTSx1Q0FBMEM7Ozs7b0JBQVE7Ozs7O1lBQzVMLFFBQVEsZ0JBQWdCLHdCQUFDLFNBQUQsWUFBTyxtREFBdUQ7Ozs7O1dBQ3BGOzs7Ozs7U0FDRjtXQXBDZ0U7Ozs7ZUFvQ2hFO1FBR04sU0FBUyxLQUNSLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLG9DQUFvQzttQkFBcEQ7VUFDRSx3QkFBQyxNQUFEO1dBQUksSUFBRztXQUFvQixLQUFLO1dBQVUsVUFBVSxDQUFDO3FCQUFHO1VBQTZCOzs7OztVQUNyRix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBb0I7VUFBMkQ7Ozs7O1VBQzVGLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVCO1dBQW9DOzs7O3FCQUMzRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDWCxDQUFDLElBQUksRUFBRSxDQUFDLENBQVcsS0FBSyxTQUN4Qix3QkFBQyxVQUFEO2FBQVEsTUFBSzthQUFvQixXQUFXLFFBQVEsa0JBQWtCLE9BQU8sYUFBYTthQUFJLGVBQWUsVUFBVSxpQkFBaUIsSUFBSTt1QkFBNUk7Y0FDRSx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBd0IsU0FBUyxLQUFLLFdBQVc7Y0FBeUI7Ozs7O2NBQzFGLHdCQUFDLFVBQUQsYUFBUyxNQUFLLGdCQUFzQjs7Ozs7Y0FDcEMsd0JBQUMsS0FBRCxZQUFJLFNBQVMsS0FBSywwRkFBMEYsaUdBQW9HOzs7OztjQUMvTSxRQUFRLGtCQUFrQixRQUFRLHdCQUFDLEtBQUQsWUFBRyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O3VCQUFJOzs7OzthQUN4RDtlQUxtQjs7OzttQkFLbkIsQ0FDVDtXQUNFOzs7O21CQUNGOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF1QjtZQUEyQjs7Ozs7WUFDbEUsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQXVCO2NBQUM7Y0FBRztjQUFHO2NBQUc7Y0FBRzthQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsd0JBQUMsVUFBRDtjQUFRLE1BQUs7Y0FBb0IsV0FBVyxRQUFRLGdCQUFnQixPQUFPLGFBQWE7Y0FBSSxlQUFlLFVBQVUsZUFBZSxJQUFJO3dCQUF4STtlQUE0SSxRQUFRLGdCQUFnQixRQUFRLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O2VBQUc7ZUFBSztjQUFhO2dCQUExTDs7OztvQkFBMEwsQ0FBQztZQUFPOzs7OztZQUNqUyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBc0IsUUFBUSxjQUFjLGVBQWUsSUFBSSxRQUFRLFlBQVksUUFBUSxJQUFJLFFBQVEsZ0JBQWdCLElBQUksUUFBUSxPQUFPLDRCQUE0QjtZQUFrRDs7Ozs7WUFDcE8sUUFBUSxnQkFBZ0IsS0FBSyxRQUFRLGVBQWUsa0JBQWtCLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFnQjtZQUE0RDs7Ozs7V0FDN0o7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVCO1dBQXNCOzs7O3FCQUM3RCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUNmLHdCQUFDLFVBQUQ7Y0FDRSxPQUFPLFFBQVE7Y0FDZixXQUFXLFVBQVU7ZUFDbkIsTUFBTSxTQUFTLE1BQU0sT0FBTztlQUM1QixZQUFZLGFBQWE7Z0JBQ3ZCLEdBQUc7Z0JBQ0gsZUFBZTtnQkFDZixnQkFBZ0IsVUFBVSxXQUFXLFdBQVcsT0FBTyxNQUFNLElBQUk7Z0JBQ2pFLHNCQUFzQixXQUFXLFdBQVcsUUFBUSx1QkFBdUI7ZUFDN0UsRUFBRTtjQUNKO2NBQ0EsY0FBVzt3QkFYYjtlQWFFLHdCQUFDLFVBQUQ7Z0JBQVEsT0FBTTtnQkFBRzswQkFBUztlQUE2Qjs7Ozs7ZUFDdkQsd0JBQUMsVUFBRDtnQkFBUSxPQUFNOzBCQUFLO2VBQWtCOzs7OztlQUNyQyx3QkFBQyxVQUFEO2dCQUFRLE9BQU07MEJBQUs7ZUFBa0I7Ozs7O2VBQ3JDLHdCQUFDLFVBQUQ7Z0JBQVEsT0FBTTswQkFBSztlQUFrQjs7Ozs7ZUFDckMsd0JBQUMsVUFBRDtnQkFBUSxPQUFNOzBCQUFLO2VBQWtCOzs7OztlQUNyQyx3QkFBQyxVQUFEO2dCQUFRLE9BQU07MEJBQVM7ZUFBaUI7Ozs7O2NBQ2xDOzs7Ozs7WUFDSDs7OztzQkFDTixRQUFRLGtCQUFrQixZQUFZLHdCQUFDLFNBQUQ7YUFBTyxXQUFVO3VCQUFqQixDQUNyQyx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEIsQ0FBeUMsd0JBQUMsU0FBRDtlQUFPLEtBQUs7ZUFBa0IsV0FBVTtlQUFVLE9BQU8sUUFBUTtlQUFzQixXQUFXLFVBQVU7Z0JBQ25KLE1BQU0sUUFBUSxNQUFNLE9BQU8sTUFBTSxRQUFRLE9BQU8sRUFBRTtnQkFDbEQsWUFBWSxhQUFhO2lCQUFFLEdBQUc7aUJBQVMsc0JBQXNCO2lCQUFPLGdCQUFnQixTQUFTLE9BQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSTtnQkFBSyxFQUFFO2VBQ25LO2VBQUcsYUFBWTtjQUFNOzs7O3dCQUFDLHdCQUFDLEtBQUQsWUFBRyxNQUFNOzs7O3NCQUFPOzs7Ozt1QkFDckMsUUFBUSx3QkFBd0IsQ0FBQyxzQkFBc0Isd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQWpCLENBQXNDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3dCQUFDLHFCQUEwQjs7Ozs7cUJBQ2pJOzs7OztvQkFDSjs7Ozs7bUJBQ0Y7Ozs7OztTQUNGO1dBeERnRTs7OztlQXdEaEU7UUFHTixTQUFTLEtBQ1Isd0JBQUMsT0FBRDtTQUFLLFdBQVcsb0NBQW9DO21CQUFwRDtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxJQUFHO1dBQW9CLEtBQUs7V0FBVSxVQUFVLENBQUM7cUJBQUc7VUFBdUM7Ozs7O1VBQy9GLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvQjtVQUEyRDs7Ozs7VUFDNUYsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxXQUFELGFBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FBMEMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7dUJBQUMsd0JBQUMsVUFBRDtjQUFRLE1BQUs7Y0FBUyxlQUFlLFNBQVMsQ0FBQzt3QkFBRzthQUFZOzs7O3FCQUFNOzs7OztzQkFDbEksd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FBdUMsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXdCLFFBQVEsWUFBWSx3QkFBQyxPQUFEO2VBQUssS0FBSyxRQUFRO2VBQVcsS0FBSTtjQUFJOzs7O3lCQUFJO2FBQWU7Ozs7dUJBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUyxRQUFRLEtBQWE7Ozs7dUJBQUMsd0JBQUMsU0FBRCxZQUFRLFFBQVEsTUFBYTs7OztxQkFBTTs7OztxQkFBTTs7Ozs7b0JBQ2xPOzs7OztZQUNULHdCQUFDLFdBQUQsYUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUEwQyx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7dUJBQUMsd0JBQUMsVUFBRDtjQUFRLE1BQUs7Y0FBUyxlQUFlLFNBQVMsQ0FBQzt3QkFBRzthQUFZOzs7O3FCQUFNOzs7OztzQkFDdkksd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLE1BQVU7Ozs7d0JBQUMsd0JBQUMsVUFBRCxZQUFTLFFBQVEsSUFBWTs7OztzQkFBSTs7Ozs7Y0FDdEQsd0JBQUMsS0FBRCxhQUFHLHdCQUFDLFNBQUQsWUFBTyxTQUFhOzs7O3dCQUFDLHdCQUFDLFVBQUQ7ZUFBUyxRQUFRO2VBQU87ZUFBRSxRQUFRLGVBQWUsWUFBWSxDQUFDLFFBQVEsT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxPQUFPO2NBQVc7Ozs7c0JBQUk7Ozs7O2NBQzFKLHdCQUFDLEtBQUQsYUFBRyx3QkFBQyxTQUFELFlBQU8sMEJBQThCOzs7O3dCQUFDLHdCQUFDLFVBQUQ7ZUFBUyxRQUFRLFVBQVU7ZUFBSTtlQUFFLFFBQVEsZUFBZSxXQUFXLE9BQU87ZUFBTTtlQUFJLFFBQVEsZUFBZSxHQUFHLFFBQVEsYUFBYSxHQUFHLFFBQVEsZUFBZSxXQUFXLE9BQU8sVUFBVTtjQUFjOzs7O3NCQUFJOzs7OztjQUNwUCx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGNBQWtCOzs7O3dCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLGVBQWUsV0FBVyxXQUFXLFdBQW1COzs7O3NCQUFJOzs7OztjQUMxRyx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGFBQWlCOzs7O3dCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFdBQW1COzs7O3NCQUFJOzs7OztjQUNwRSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGlCQUFxQjs7Ozt3QkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxTQUFpQjs7OztzQkFBSTs7Ozs7YUFDbkU7Ozs7O29CQUNFOzs7OztZQUNULHdCQUFDLFdBQUQsYUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUEwQyx3QkFBQyxRQUFELFlBQU0sV0FBYzs7Ozt1QkFBQyx3QkFBQyxVQUFEO2NBQVEsTUFBSztjQUFTLGVBQWUsU0FBUyxDQUFDO3dCQUFHO2FBQVk7Ozs7cUJBQU07Ozs7O3NCQUNuSSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNFLHdCQUFDLEtBQUQsYUFBRyx3QkFBQyxTQUFELFlBQU8scUJBQXlCOzs7O3dCQUFDLHdCQUFDLFVBQUQsYUFBUyxRQUFRLGVBQWMsT0FBYTs7OztzQkFBSTs7Ozs7Y0FDcEYsd0JBQUMsS0FBRCxhQUFHLHdCQUFDLFNBQUQsWUFBTyxZQUFnQjs7Ozt3QkFBQyx3QkFBQyxVQUFEO2VBQVMsUUFBUTtlQUFZO2VBQWEsUUFBUTtlQUFlO2NBQW9COzs7O3NCQUFJOzs7OztjQUNwSCx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGlCQUFxQjs7Ozt3QkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxlQUF1Qjs7OztzQkFBSTs7Ozs7YUFDekU7Ozs7O29CQUNFOzs7OztZQUNULHdCQUFDLFdBQUQsYUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUEwQyx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7dUJBQUMsd0JBQUMsVUFBRDtjQUFRLE1BQUs7Y0FBUyxlQUFlLFNBQVMsQ0FBQzt3QkFBRzthQUFZOzs7O3FCQUFNOzs7OztzQkFDdkksd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGVBQW1COzs7O3dCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLEtBQWE7Ozs7c0JBQUk7Ozs7O2NBQ2hFLHdCQUFDLEtBQUQsYUFBRyx3QkFBQyxTQUFELFlBQU8sbUJBQXVCOzs7O3dCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFdBQW1COzs7O3NCQUFJOzs7OztjQUMxRSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLHNCQUEwQjs7Ozt3QkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxtQkFBMkI7Ozs7c0JBQUk7Ozs7O2NBQ3JGLHdCQUFDLEtBQUQsYUFBRyx3QkFBQyxTQUFELFlBQU8saUJBQXFCOzs7O3dCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFVBQWtCOzs7O3NCQUFJOzs7OztjQUN2RSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLGdCQUFvQjs7Ozt3QkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxLQUFhOzs7O3NCQUFJOzs7OztjQUNqRSx3QkFBQyxLQUFELGFBQUcsd0JBQUMsU0FBRCxZQUFPLHNCQUEwQjs7Ozt3QkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxlQUFlLDZCQUE2QixLQUFhOzs7O3NCQUFJOzs7OzthQUNoSDs7Ozs7b0JBQ0U7Ozs7O1dBQ047Ozs7OztTQUNGO1dBdkNnRTs7OztlQXVDaEU7UUFHTixTQUFTLEtBQ1Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUF5QixPQUFPLEVBQUUseUJBQXlCLEdBQUcscUJBQXFCLElBQUksS0FBSztxQkFBMEIsd0JBQUMsUUFBRCxhQUFPLG9CQUFtQixHQUFPOzs7OztVQUFNOzs7OztVQUM1Syx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBMEIsd0JBQUMsS0FBRCxFQUFHLE9BQU8sRUFBRSxPQUFPLEdBQUcsbUJBQW1CLEdBQUcsRUFBSTs7Ozs7VUFBTTs7Ozs7VUFDL0Ysd0JBQUMsVUFBRDtXQUErQixXQUFVO3FCQUE0QixlQUFlO1VBQTBCLEdBQWpHOzs7O2lCQUFpRztVQUM5Ryx3QkFBQyxLQUFELFlBQUcsNEJBQTRCOzs7OztTQUM1QjtXQUw2RDs7OztlQUs3RDtRQUdOLFNBQVMsS0FDUix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxJQUFHO1dBQW9CLEtBQUs7V0FBVSxVQUFVLENBQUM7cUJBQUc7VUFBNEI7Ozs7O1VBQ3BGLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFvQjtVQUFrRzs7Ozs7VUFDbkksd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1o7WUFDQzthQUFDO2FBQWE7YUFBaUM7WUFBdUU7WUFDdEg7YUFBQzthQUFXO2FBQWlDO1lBQXNFO1lBQ25IO2FBQUM7YUFBVTthQUFxQztZQUE2RTtZQUM3SDthQUFDO2FBQVM7YUFBOEI7WUFBaUU7V0FDM0csQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLE9BQU8sY0FBYyxVQUFVLHdCQUFDLFdBQUQ7WUFBcUIsT0FBTyxFQUFFLGtCQUFrQixNQUFNO3NCQUF0RCxDQUFnRix3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQU0sS0FBdUQ7Ozs7cUJBQU87Ozs7c0JBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUyxNQUFjOzs7O3NCQUFDLHdCQUFDLEtBQUQsWUFBSSxZQUFlOzs7O29CQUFNOzs7O29CQUFVO2NBQW5OOzs7O2tCQUFtTixDQUFDO1VBQzVROzs7OztTQUNGO1dBWG1EOzs7O2VBV25EO09BRUo7Ozs7OztNQUVKLFFBQVEsS0FBSyx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBbEIsQ0FBbUMsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBbUIsTUFBSztRQUFTLFNBQVM7a0JBQVE7T0FBWTs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQVEsU0FBUztRQUFRLFVBQVUsQ0FBQztrQkFBWSxpQkFBaUIscUJBQXFCO09BQWU7Ozs7ZUFBUzs7Ozs7O01BRS9PLFNBQVMsS0FDUix3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBbEIsQ0FDRSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUFtQixNQUFLO1FBQVMsU0FBUztrQkFBUTtPQUFZOzs7O2lCQUNoRix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUNFLFNBQVMsWUFBWTtTQUNuQixJQUFJOztVQUVGLE1BQU0sSUFBSSxTQUFTLFFBQVEsT0FBTyxRQUFRLFFBQVE7O1VBR2xELE1BQU0sSUFBSSxlQUFlO1dBQ3ZCLE1BQU0sUUFBUTtXQUNkLEtBQUssUUFBUTtXQUNiLFFBQVEsUUFBUTtXQUNoQixlQUFlLFFBQVE7V0FDdkIsY0FBYyxRQUFRO1dBQ3RCLFlBQVksUUFBUTtXQUNwQixZQUFZLFFBQVE7V0FDcEIsTUFBTSxRQUFRO1dBQ2QsWUFBWSxRQUFRO1dBQ3BCLFVBQVUsUUFBUTtXQUNsQixhQUFhLE9BQU8sUUFBUSxXQUFXO1dBQ3ZDLGVBQWUsT0FBTyxRQUFRLGtCQUFrQixFQUFFO1dBQ2xELFdBQVcsUUFBUSxhQUFhO1dBQ2hDLE1BQU0sUUFBUSxRQUFRO1dBQ3RCLFdBQVcsUUFBUTtXQUNuQixlQUFlLFFBQVE7V0FDdkIsZ0JBQWdCLFFBQVE7V0FDeEIsY0FBYyxRQUFRO1VBQ3hCLENBQUM7O1VBR0Qsc0JBQXNCLENBQUM7VUFDdkIsb0JBQW9CLENBQUM7VUFDckIsUUFBUSxDQUFDO1NBQ1gsU0FBUyxPQUFPO1VBQ2QsUUFBUSxNQUFNLDZDQUE2QyxLQUFLO1VBQ2hFLE1BQU0sdUVBQXVFO1NBQy9FO1FBQ0Y7a0JBQ0Q7T0FFTzs7OztpQkFDUix3QkFBQyxTQUFELFlBQU8sb0VBQXdFOzs7O2VBQzVFOzs7O2VBQ0M7Ozs7OztNQUdULFNBQVMsS0FBSyx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBdUMsd0JBQUMsUUFBRDtRQUFRLGVBQWUsV0FBVyxPQUFPO2tCQUF6QyxDQUE0QyxjQUFVLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7Z0JBQVM7Ozs7OztNQUFTOzs7OztLQUNqSzs7Ozs7O0lBRUosUUFBUSxLQUFLLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO0tBQXVCLGNBQVc7ZUFBbkQ7TUFDWix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFzQyx3QkFBQyxVQUFELENBQVc7Ozs7aUJBQUMsd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7ZUFBTTs7Ozs7O01BQUMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsNEJBQTZCOzs7OztNQUFDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDRCQUE2Qjs7Ozs7TUFDdEssd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osU0FBUyxJQUFJLGdEQUNaLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFuQjtTQUE0RCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBb0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssV0FBWTs7Ozs7U0FBTzs7Ozs7U0FBQyx3QkFBQyxTQUFELFlBQU8sUUFBWTs7Ozs7U0FBQyx3QkFBQyxVQUFELFlBQVEsNkJBQWtDOzs7OztRQUFVOzs7OztpQkFDdk0sd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CLENBQThELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztRQUFPOzs7O2tCQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sZUFBbUI7Ozs7a0JBQUMsd0JBQUMsVUFBRCxZQUFRLHNDQUEyQzs7OztnQkFBTTs7OztnQkFBVTs7Ozs7ZUFDak87Ozs7a0JBQUksU0FBUyxJQUFJLGdEQUNqQix3QkFBQyxXQUFEO1FBQVMsV0FBVTtrQkFBbkI7U0FBK0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQXVDLEtBQUMsd0JBQUMsU0FBRCxZQUFPLE9BQVc7Ozs7a0JBQU87Ozs7OztTQUFDLHdCQUFDLFNBQUQsWUFBTyxnQkFBb0I7Ozs7O1NBQUMsd0JBQUMsVUFBRCxZQUFRLHdCQUE2Qjs7Ozs7UUFBVTs7Ozs7aUJBQzVOLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFuQixDQUE4RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBb0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7UUFBTzs7OztrQkFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLHNCQUEwQjs7OztrQkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxRQUFRLDJCQUFtQzs7OztnQkFBTTs7OztnQkFBVTs7Ozs7ZUFDalA7Ozs7a0JBQUksU0FBUyxJQUFJLGdEQUNqQix3QkFBQyxXQUFEO1FBQVMsV0FBVTtrQkFBbkI7U0FBNkUsd0JBQUMsU0FBRCxZQUFPLFlBQWdCOzs7OztTQUFDLHdCQUFDLE9BQUQsWUFBTTtVQUFDO1VBQUc7VUFBRztVQUFHO1VBQUc7VUFBRztVQUFHO1NBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSx3QkFBQyxLQUFEO1VBQWEsV0FBVyxPQUFPLFFBQVEsZUFBZSxLQUFLLFlBQVk7b0JBQVM7V0FBQztXQUFLO1dBQUs7V0FBSztXQUFLO1dBQUs7V0FBSztVQUFHLENBQUMsQ0FBQztTQUFRLEdBQXBIOzs7O2dCQUFvSCxDQUFDLEVBQU87Ozs7O1NBQUMsd0JBQUMsVUFBRCxZQUFTLFFBQVEsY0FBYyxHQUFHLFFBQVEsWUFBWSxrQkFBa0IscUJBQTZCOzs7OztRQUFVOzs7OztpQkFDbFksd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CLENBQThELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztRQUFPOzs7O2tCQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sbUJBQXVCOzs7O2tCQUFDLHdCQUFDLFVBQUQsWUFBUyxRQUFRLGdCQUFnQixHQUFHLFFBQVEsY0FBYyxTQUFTLHVCQUErQjs7OztnQkFBTTs7OztnQkFBVTs7Ozs7ZUFDcFI7Ozs7a0JBQUksd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CO1NBQThFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFzQjtTQUFXOzs7OztTQUFDLHdCQUFDLFNBQUQsWUFBTyxpQkFBcUI7Ozs7O1NBQUMsd0JBQUMsVUFBRDtVQUFRO1VBQU0sUUFBUTtVQUFjO1NBQXNCOzs7OztTQUFDLHdCQUFDLEtBQUQsWUFBRyw0Q0FBNEM7Ozs7O1FBQVU7Ozs7OztNQUNwUixHQVhzQzs7OzthQVd0QztNQUNMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF1QjtNQUE4Qjs7Ozs7S0FDN0Q7Ozs7OztJQUdOLG1CQUFtQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFzQix3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFpQixNQUFLO01BQWMsY0FBVztNQUFPLG1CQUFnQjtnQkFBckY7T0FBMEcsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O09BQU87Ozs7O09BQUMsd0JBQUMsTUFBRDtRQUFJLElBQUc7a0JBQXFCO09BQWtCOzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBRyw2QkFBNkI7Ozs7O09BQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFFBQUQ7UUFBUSxTQUFRO1FBQVEsZUFBZSxtQkFBbUIsS0FBSztrQkFBRztPQUFZOzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBUSxTQUFRO1FBQU8sU0FBUztrQkFBUztPQUFhOzs7O2VBQU07Ozs7O01BQU07Ozs7OztJQUFNOzs7OztHQUN6Yzs7Ozs7O0NBQ047Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2lnbnVwTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b25cIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgSW5mb1RpcCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0luZm9UaXBcIjtcclxuaW1wb3J0IHsgTG9nb01hcmsgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Mb2dvTWFya1wiO1xyXG5pbXBvcnQgeyBnbG9zc2FyeVRlcm1zIH0gZnJvbSBcIi4uL2RhdGEvZ2xvc3NhcnlcIjtcclxuaW1wb3J0IHsgZW1haWxQYXR0ZXJuLCBwYXJzZUhlaWdodENtLCBwYXJzZVdlaWdodEtnIH0gZnJvbSBcIi4uL2xpYi9mb3JtYXRcIjtcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaVwiO1xyXG5pbXBvcnQgdHlwZSB7IEFjdGl2aXR5LCBFeHBlcmllbmNlLCBHb2FsLCBTaWdudXBBbnN3ZXJzLCBTaWdudXBFcXVpcG1lbnQsIFVuaXRTeXN0ZW0gfSBmcm9tIFwiLi4vdHlwZXNcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTaWdudXBNb2RhbCh7XHJcbiAgb3BlbixcclxuICBpbml0aWFsQW5zd2VycyxcclxuICBvbkNsb3NlLFxyXG4gIG9uTG9naW4sXHJcbiAgb25PcGVuR2xvc3NhcnksXHJcbiAgb25Db21wbGV0ZSxcclxufToge1xyXG4gIG9wZW46IGJvb2xlYW47XHJcbiAgaW5pdGlhbEFuc3dlcnM6IFNpZ251cEFuc3dlcnM7XHJcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxuICBvbkxvZ2luOiAoKSA9PiB2b2lkO1xyXG4gIG9uT3Blbkdsb3NzYXJ5OiAodGVybTogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIG9uQ29tcGxldGU6IChwcm9maWxlOiBTaWdudXBBbnN3ZXJzKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGUoMSk7XHJcbiAgY29uc3QgW2RpcmVjdGlvbiwgc2V0RGlyZWN0aW9uXSA9IHVzZVN0YXRlPFwiZm9yd2FyZFwiIHwgXCJiYWNrXCI+KFwiZm9yd2FyZFwiKTtcclxuICBjb25zdCBbc2hvd0xlYXZlUHJvbXB0LCBzZXRTaG93TGVhdmVQcm9tcHRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F2YXRhckVycm9yLCBzZXRBdmF0YXJFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcmV0dXJuVG9SZXZpZXcsIHNldFJldHVyblRvUmV2aWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZ2VuZXJhdGlvblByb2dyZXNzLCBzZXRHZW5lcmF0aW9uUHJvZ3Jlc3NdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2dlbmVyYXRpb25TdGF0dXMsIHNldEdlbmVyYXRpb25TdGF0dXNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2Fuc3dlcnMsIHNldEFuc3dlcnNdID0gdXNlU3RhdGU8U2lnbnVwQW5zd2Vycz4oaW5pdGlhbEFuc3dlcnMpO1xyXG4gIGNvbnN0IHRpdGxlUmVmID0gdXNlUmVmPEhUTUxIZWFkaW5nRWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xyXG4gIGNvbnN0IGN1c3RvbVNlc3Npb25SZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3QgdG90YWxTdGVwcyA9IDQ7XHJcbiAgY29uc3Qgc2V0QW5zd2VyID0gPEsgZXh0ZW5kcyBrZXlvZiBTaWdudXBBbnN3ZXJzPihrZXk6IEssIHZhbHVlOiBTaWdudXBBbnN3ZXJzW0tdKSA9PiBzZXRBbnN3ZXJzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBba2V5XTogdmFsdWUgfSkpO1xyXG5cclxuICBjb25zdCBwYXNzd29yZFJ1bGVzID0ge1xyXG4gICAgbGVuZ3RoOiBhbnN3ZXJzLnBhc3N3b3JkLmxlbmd0aCA+PSA4LFxyXG4gICAgbnVtYmVyOiAvW1xcZFxccHtQfVxccHtTfV0vdS50ZXN0KGFuc3dlcnMucGFzc3dvcmQpLFxyXG4gICAgY2FzZTogL1thLXpdLy50ZXN0KGFuc3dlcnMucGFzc3dvcmQpICYmIC9bQS1aXS8udGVzdChhbnN3ZXJzLnBhc3N3b3JkKSxcclxuICB9O1xyXG4gIGNvbnN0IHZhbGlkUGFzc3dvcmQgPSBPYmplY3QudmFsdWVzKHBhc3N3b3JkUnVsZXMpLmV2ZXJ5KEJvb2xlYW4pO1xyXG4gIGNvbnN0IGFnZU51bWJlciA9IE51bWJlcihhbnN3ZXJzLmFnZSk7XHJcbiAgY29uc3QgaGVpZ2h0Q20gPSBwYXJzZUhlaWdodENtKGFuc3dlcnMuaGVpZ2h0LCBhbnN3ZXJzLnVuaXRTeXN0ZW0pO1xyXG4gIGNvbnN0IHdlaWdodEtnID0gcGFyc2VXZWlnaHRLZyhhbnN3ZXJzLndlaWdodCwgYW5zd2Vycy51bml0U3lzdGVtKTtcclxuICBjb25zdCB2YWxpZEFnZSA9IGFnZU51bWJlciA+PSAxMCAmJiBhZ2VOdW1iZXIgPD0gMTAwO1xyXG4gIGNvbnN0IHZhbGlkSGVpZ2h0ID0gaGVpZ2h0Q20gPj0gMTAwICYmIGhlaWdodENtIDw9IDI1MDtcclxuICBjb25zdCB2YWxpZFdlaWdodCA9IHdlaWdodEtnID49IDI1ICYmIHdlaWdodEtnIDw9IDMwMDtcclxuICBjb25zdCBzdGVwT25lVmFsaWQgPSBCb29sZWFuKGFuc3dlcnMubmFtZS50cmltKCkpICYmIGVtYWlsUGF0dGVybi50ZXN0KGFuc3dlcnMuZW1haWwpICYmIHZhbGlkUGFzc3dvcmQgJiYgdmFsaWRBZ2UgJiYgdmFsaWRIZWlnaHQgJiYgdmFsaWRXZWlnaHQ7XHJcbiAgY29uc3QgdGFyZ2V0S2cgPSBwYXJzZVdlaWdodEtnKGFuc3dlcnMudGFyZ2V0V2VpZ2h0LCBhbnN3ZXJzLnVuaXRTeXN0ZW0pO1xyXG4gIGNvbnN0IGhhc1RhcmdldFdlaWdodCA9IEJvb2xlYW4oYW5zd2Vycy50YXJnZXRXZWlnaHQudHJpbSgpKTtcclxuICBjb25zdCB0YXJnZXRWYWxpZCA9ICFoYXNUYXJnZXRXZWlnaHQgfHwgKHRhcmdldEtnID49IDI1ICYmIHRhcmdldEtnIDw9IDMwMCk7XHJcbiAgY29uc3QgdGltZWxpbmVXZWVrcyA9IGFuc3dlcnMudGFyZ2V0VGltZWxpbmUgPT09IFwiRmlyc3QgMzAgZGF5c1wiID8gNC4zIDogYW5zd2Vycy50YXJnZXRUaW1lbGluZSA9PT0gXCJCeSBkYXkgNjBcIiA/IDguNiA6IDEyLjk7XHJcbiAgY29uc3QgdGFyZ2V0Q2F1dGlvbiA9IGhhc1RhcmdldFdlaWdodCAmJiB0YXJnZXRWYWxpZCAmJiB2YWxpZEhlaWdodCAmJiAoKHRhcmdldEtnIC8gKChoZWlnaHRDbSAvIDEwMCkgKiogMikpIDwgMTguNSB8fCAod2VpZ2h0S2cgLSB0YXJnZXRLZykgLyB0aW1lbGluZVdlZWtzID4gMSk7XHJcbiAgY29uc3Qgc3RlcFR3b1ZhbGlkID0gQm9vbGVhbihhbnN3ZXJzLnNvbWF0b3R5cGUgJiYgYW5zd2Vycy5nb2FsICYmIGFuc3dlcnMuZXhwZXJpZW5jZSAmJiBhbnN3ZXJzLmFjdGl2aXR5ICYmIGFuc3dlcnMuYXZhaWxhYmxlRXF1aXBtZW50ICYmIHRhcmdldFZhbGlkKTtcclxuICBjb25zdCBjdXN0b21TZXNzaW9uVmFsdWUgPSBOdW1iZXIoYW5zd2Vycy5jdXN0b21TZXNzaW9uTWludXRlcyk7XHJcbiAgY29uc3QgY3VzdG9tU2Vzc2lvblZhbGlkID0gTnVtYmVyLmlzSW50ZWdlcihjdXN0b21TZXNzaW9uVmFsdWUpICYmIGN1c3RvbVNlc3Npb25WYWx1ZSA+PSA1ICYmIGN1c3RvbVNlc3Npb25WYWx1ZSA8PSAxODA7XHJcbiAgY29uc3Qgc2Vzc2lvblZhbGlkID0gYW5zd2Vycy5zZXNzaW9uQ2hvaWNlID09PSBcImN1c3RvbVwiID8gY3VzdG9tU2Vzc2lvblZhbGlkIDogQm9vbGVhbihhbnN3ZXJzLnNlc3Npb25DaG9pY2UgJiYgYW5zd2Vycy5zZXNzaW9uTWludXRlcyk7XHJcbiAgY29uc3Qgc3RlcFRocmVlVmFsaWQgPSBCb29sZWFuKGFuc3dlcnMuY2hhbGxlbmdlRGF5cyAmJiBhbnN3ZXJzLndvcmtvdXREYXlzICYmIHNlc3Npb25WYWxpZCk7XHJcbiAgY29uc3Qgc3RlcFZhbGlkID0gc3RlcCA9PT0gMSA/IHN0ZXBPbmVWYWxpZCA6IHN0ZXAgPT09IDIgPyBzdGVwVHdvVmFsaWQgOiBzdGVwID09PSAzID8gc3RlcFRocmVlVmFsaWQgOiB0cnVlO1xyXG4gIGNvbnN0IHN0cmVuZ3RoID0gT2JqZWN0LnZhbHVlcyhwYXNzd29yZFJ1bGVzKS5maWx0ZXIoQm9vbGVhbikubGVuZ3RoO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFvcGVuKSByZXR1cm47XHJcbiAgICBzZXRBbnN3ZXJzKGluaXRpYWxBbnN3ZXJzKTtcclxuICAgIHNldFN0ZXAoMSk7XHJcbiAgICBzZXREaXJlY3Rpb24oXCJmb3J3YXJkXCIpO1xyXG4gICAgc2V0U2hvd0xlYXZlUHJvbXB0KGZhbHNlKTtcclxuICAgIHNldEF2YXRhckVycm9yKFwiXCIpO1xyXG4gICAgc2V0UmV0dXJuVG9SZXZpZXcoZmFsc2UpO1xyXG4gICAgc2V0R2VuZXJhdGlvblByb2dyZXNzKDApO1xyXG4gICAgc2V0R2VuZXJhdGlvblN0YXR1cygwKTtcclxuICB9LCBbb3Blbl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHN0ZXAgIT09IDUpIHJldHVybjtcclxuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IERhdGUubm93KCk7XHJcbiAgICBjb25zdCBwcm9ncmVzc1RpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgc2V0R2VuZXJhdGlvblByb2dyZXNzKE1hdGgubWluKDEwMCwgTWF0aC5yb3VuZCgoKERhdGUubm93KCkgLSBzdGFydGVkQXQpIC8gNDAwMCkgKiAxMDApKSk7XHJcbiAgICB9LCA1MCk7XHJcbiAgICBjb25zdCBzdGF0dXNUaW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiBzZXRHZW5lcmF0aW9uU3RhdHVzKChjdXJyZW50KSA9PiBNYXRoLm1pbigyLCBjdXJyZW50ICsgMSkpLCAxMzAwKTtcclxuICAgIGNvbnN0IGZpbmlzaFRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBzZXRHZW5lcmF0aW9uUHJvZ3Jlc3MoMTAwKTtcclxuICAgICAgc2V0U3RlcCg2KTtcclxuICAgIH0sIDQxMDApO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LmNsZWFySW50ZXJ2YWwocHJvZ3Jlc3NUaW1lcik7XHJcbiAgICAgIHdpbmRvdy5jbGVhckludGVydmFsKHN0YXR1c1RpbWVyKTtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dChmaW5pc2hUaW1lcik7XHJcbiAgICB9O1xyXG4gIH0sIFtzdGVwXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcclxuICAgIGNvbnN0IHByZXZpb3VzT3ZlcmZsb3cgPSBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93O1xyXG4gICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XHJcbiAgICByZXR1cm4gKCkgPT4geyBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gcHJldmlvdXNPdmVyZmxvdzsgfTtcclxuICB9LCBbb3Blbl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFvcGVuKSByZXR1cm47XHJcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB0aXRsZVJlZi5jdXJyZW50Py5mb2N1cygpLCAyMCk7XHJcbiAgfSwgW29wZW4sIHN0ZXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzdGVwID09PSAzICYmIGFuc3dlcnMuc2Vzc2lvbkNob2ljZSA9PT0gXCJjdXN0b21cIikge1xyXG4gICAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBjdXN0b21TZXNzaW9uUmVmLmN1cnJlbnQ/LmZvY3VzKCksIDIwKTtcclxuICAgIH1cclxuICB9LCBbYW5zd2Vycy5zZXNzaW9uQ2hvaWNlLCBzdGVwXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcclxuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcclxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFc2NhcGVcIiAmJiBzdGVwICE9PSA1KSB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBzZXRTaG93TGVhdmVQcm9tcHQodHJ1ZSk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiICYmICFzaG93TGVhdmVQcm9tcHQgJiYgc3RlcFZhbGlkICYmIHN0ZXAgPCA0KSB7XHJcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0IGFzIEhUTUxFbGVtZW50O1xyXG4gICAgICAgIGlmICh0YXJnZXQudGFnTmFtZSAhPT0gXCJCVVRUT05cIiAmJiB0YXJnZXQudGFnTmFtZSAhPT0gXCJTRUxFQ1RcIiAmJiBzdGVwIDwgdG90YWxTdGVwcykge1xyXG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgIHNldERpcmVjdGlvbihcImZvcndhcmRcIik7XHJcbiAgICAgICAgICBzZXRTdGVwKChjdXJyZW50KSA9PiBjdXJyZW50ICsgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24pO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duKTtcclxuICB9LCBbb3Blbiwgc2hvd0xlYXZlUHJvbXB0LCBzdGVwLCBzdGVwVmFsaWRdKTtcclxuXHJcbiAgaWYgKCFvcGVuKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgZ29CYWNrID0gKCkgPT4ge1xyXG4gICAgaWYgKHN0ZXAgPT09IDUpIHJldHVybjtcclxuICAgIGlmIChzdGVwID09PSAxKSByZXR1cm4gc2V0U2hvd0xlYXZlUHJvbXB0KHRydWUpO1xyXG4gICAgc2V0RGlyZWN0aW9uKFwiYmFja1wiKTtcclxuICAgIHNldFN0ZXAoKGN1cnJlbnQpID0+IGN1cnJlbnQgLSAxKTtcclxuICB9O1xyXG4gIGNvbnN0IGdvTmV4dCA9ICgpID0+IHtcclxuICAgIGlmICghc3RlcFZhbGlkIHx8IHN0ZXAgPj0gdG90YWxTdGVwcykgcmV0dXJuO1xyXG4gICAgc2V0RGlyZWN0aW9uKFwiZm9yd2FyZFwiKTtcclxuICAgIGlmIChyZXR1cm5Ub1Jldmlldykge1xyXG4gICAgICBzZXRSZXR1cm5Ub1JldmlldyhmYWxzZSk7XHJcbiAgICAgIHNldFN0ZXAoNCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRTdGVwKChjdXJyZW50KSA9PiBjdXJyZW50ICsgMSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBjaGFuZ2VVbml0ID0gKHVuaXQ6IFVuaXRTeXN0ZW0pID0+IHtcclxuICAgIGlmICh1bml0ID09PSBhbnN3ZXJzLnVuaXRTeXN0ZW0pIHJldHVybjtcclxuICAgIGNvbnN0IG5leHRIZWlnaHQgPSBhbnN3ZXJzLmhlaWdodCA/IHVuaXQgPT09IFwiaW1wZXJpYWxcIlxyXG4gICAgICA/IGAke01hdGguZmxvb3IoaGVpZ2h0Q20gLyAzMC40OCl9IGZ0ICR7TWF0aC5yb3VuZCgoaGVpZ2h0Q20gJSAzMC40OCkgLyAyLjU0KX0gaW5gXHJcbiAgICAgIDogU3RyaW5nKE1hdGgucm91bmQoaGVpZ2h0Q20pKSA6IFwiXCI7XHJcbiAgICBjb25zdCBuZXh0V2VpZ2h0ID0gYW5zd2Vycy53ZWlnaHQgPyB1bml0ID09PSBcImltcGVyaWFsXCIgPyBTdHJpbmcoTWF0aC5yb3VuZCh3ZWlnaHRLZyAqIDIuMjA0NjIpKSA6IFN0cmluZyhNYXRoLnJvdW5kKHdlaWdodEtnKSkgOiBcIlwiO1xyXG4gICAgY29uc3QgbmV4dFRhcmdldCA9IGhhc1RhcmdldFdlaWdodCA/IHVuaXQgPT09IFwiaW1wZXJpYWxcIiA/IFN0cmluZyhNYXRoLnJvdW5kKHRhcmdldEtnICogMi4yMDQ2MikpIDogU3RyaW5nKE1hdGgucm91bmQodGFyZ2V0S2cpKSA6IFwiXCI7XHJcbiAgICBzZXRBbnN3ZXJzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCB1bml0U3lzdGVtOiB1bml0LCBoZWlnaHQ6IG5leHRIZWlnaHQsIHdlaWdodDogbmV4dFdlaWdodCwgdGFyZ2V0V2VpZ2h0OiBuZXh0VGFyZ2V0IH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IHVwbG9hZEF2YXRhciA9IChmaWxlPzogRmlsZSkgPT4ge1xyXG4gICAgaWYgKCFmaWxlKSByZXR1cm47XHJcbiAgICBpZiAoIWZpbGUudHlwZS5zdGFydHNXaXRoKFwiaW1hZ2UvXCIpKSByZXR1cm4gc2V0QXZhdGFyRXJyb3IoXCJQbGVhc2UgY2hvb3NlIGFuIGltYWdlIGZpbGUuXCIpO1xyXG4gICAgaWYgKGZpbGUuc2l6ZSA+IDUgKiAxMDI0ICogMTAyNCkgcmV0dXJuIHNldEF2YXRhckVycm9yKFwiUGxlYXNlIGNob29zZSBhbiBpbWFnZSBzbWFsbGVyIHRoYW4gNSBNQi5cIik7XHJcbiAgICBzZXRBdmF0YXJFcnJvcihcIlwiKTtcclxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICByZWFkZXIub25sb2FkID0gKCkgPT4gc2V0QW5zd2VyKFwiYXZhdGFyVXJsXCIsIFN0cmluZyhyZWFkZXIucmVzdWx0KSk7XHJcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBwaWxsID0gPFQgZXh0ZW5kcyBzdHJpbmc+KHZhbHVlOiBULCBzZWxlY3RlZDogYm9vbGVhbiwgb25TZWxlY3Q6ICh2YWx1ZTogVCkgPT4gdm9pZCkgPT4gKFxyXG4gICAgPGJ1dHRvbiBrZXk9e3ZhbHVlfSB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtgc2lnbnVwLXBpbGwgJHtzZWxlY3RlZCA/IFwic2VsZWN0ZWRcIiA6IFwiXCJ9YH0gb25DbGljaz17KCkgPT4gb25TZWxlY3QodmFsdWUpfT5cclxuICAgICAge3NlbGVjdGVkICYmIDxJY29uIG5hbWU9XCJjaGVja1wiIC8+fXt2YWx1ZX1cclxuICAgIDwvYnV0dG9uPlxyXG4gICk7XHJcbiAgY29uc3QgaW5pdGlhbHMgPSBhbnN3ZXJzLm5hbWUudHJpbSgpLnNwbGl0KC9cXHMrLykuc2xpY2UoMCwgMikubWFwKChwYXJ0KSA9PiBwYXJ0WzBdKS5qb2luKFwiXCIpLnRvVXBwZXJDYXNlKCkgfHwgXCJTRlwiO1xyXG4gIGNvbnN0IHN0YXR1c01lc3NhZ2VzID0gW1xyXG4gICAgXCJBbmFseXppbmcgYm9keSB0eXBlIGFuZCBtZXRhYm9saWMgcHJvZmlsZS4uLlwiLFxyXG4gICAgYENhbGlicmF0aW5nIHlvdXIgJHthbnN3ZXJzLmNoYWxsZW5nZURheXMgPz8gNjB9LWRheSBjaGFsbGVuZ2Ugc2NoZWR1bGUgYW5kIHJlc3QgaW50ZXJ2YWxzLi4uYCxcclxuICAgIFwiRmluYWxpemluZyBEYXkgMSBzZXNzaW9uIGFuZCBndWlkZWQgY3Vlcy4uLlwiLFxyXG4gIF07XHJcbiAgY29uc3QgZWRpdFN0ZXAgPSAobmV4dFN0ZXA6IG51bWJlcikgPT4ge1xyXG4gICAgc2V0UmV0dXJuVG9SZXZpZXcodHJ1ZSk7XHJcbiAgICBzZXREaXJlY3Rpb24oXCJiYWNrXCIpO1xyXG4gICAgc2V0U3RlcChuZXh0U3RlcCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLWJhY2tkcm9wXCIgb25Nb3VzZURvd249eygpID0+IHN0ZXAgIT09IDUgJiYgc2V0U2hvd0xlYXZlUHJvbXB0KHRydWUpfT5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPXtgc2lnbnVwLW1vZGFsICR7c3RlcCA+IDQgPyBcInNpZ251cC1maW5hbC1zdGF0ZVwiIDogXCJcIn1gfSByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsbGVkYnk9XCJzaWdudXAtc3RlcC10aXRsZVwiIG9uTW91c2VEb3duPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1mb3JtLWNvbHVtblwiPlxyXG4gICAgICAgICAge3N0ZXAgPD0gNCAmJiA8aGVhZGVyIGNsYXNzTmFtZT1cInNpZ251cC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtdG9wbGluZVwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwic2lnbnVwLWljb24tYnV0dG9uXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2dvQmFja30gYXJpYS1sYWJlbD17c3RlcCA9PT0gMSA/IFwiTGVhdmUgc2lnbiB1cFwiIDogXCJQcmV2aW91cyBzdGVwXCJ9PjxJY29uIG5hbWU9XCJiYWNrXCIgLz48L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1tZW1iZXItYWN0aW9uc1wiPjxzcGFuPkFscmVhZHkgYSBtZW1iZXI/IDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uTG9naW59PkxvZyBpbjwvYnV0dG9uPjwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXByb2dyZXNzXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+U3RlcCB7c3RlcH0gb2Yge3RvdGFsU3RlcHN9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXByb2dyZXNzLXRyYWNrXCIgYXJpYS1sYWJlbD17YFN0ZXAgJHtzdGVwfSBvZiAke3RvdGFsU3RlcHN9YH0+XHJcbiAgICAgICAgICAgICAgICB7WzEsIDIsIDMsIDRdLm1hcCgoaXRlbSkgPT4gPGkga2V5PXtpdGVtfSBjbGFzc05hbWU9e2l0ZW0gPCBzdGVwIHx8IHN0ZXAgPT09IDQgPyBcImNvbXBsZXRlXCIgOiBpdGVtID09PSBzdGVwID8gXCJjdXJyZW50XCIgOiBcIlwifSAvPil9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1tb2JpbGUtcHJldmlld1wiPjxJY29uIG5hbWU9e3N0ZXAgPT09IDIgPyBcImNoYXJ0XCIgOiBzdGVwID09PSAzID8gXCJjYWxlbmRhclwiIDogc3RlcCA9PT0gNCA/IFwiY2hlY2tcIiA6IFwiY2FsZW5kYXJcIn0gLz48c3Bhbj57c3RlcCA9PT0gMiA/IFwiWW91ciBzdGFydGluZyBwb2ludFwiIDogc3RlcCA9PT0gMyA/IFwiV2Vla2x5IHJoeXRobVwiIDogc3RlcCA9PT0gNCA/IFwiUmVhZHkgdG8gcmV2aWV3XCIgOiBcIkRheSAxIEtpY2tvZmZcIn08L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICA8L2hlYWRlcj59XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc2Nyb2xsXCI+XHJcbiAgICAgICAgICAgIHtzdGVwID09PSAxICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHNpZ251cC1zdGVwLWNvbnRlbnQgc2lnbnVwLXNsaWRlLSR7ZGlyZWN0aW9ufWB9IGtleT1cInN0ZXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGlkPVwic2lnbnVwLXN0ZXAtdGl0bGVcIiByZWY9e3RpdGxlUmVmfSB0YWJJbmRleD17LTF9PkNyZWF0ZSB5b3VyIGFjY291bnQuPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpZ251cC1zdGVwLWludHJvXCI+U2F2ZSB5b3VyIHJvdXRpbmUgYW5kIGtlZXAgeW91ciA2MC85MC1kYXkgY2hhbGxlbmdlIHByb2dyZXNzIGluIG9uZSBwbGFjZS48L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1hdmF0YXItdXBsb2FkXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCByZWY9e2ZpbGVJbnB1dFJlZn0gdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9eyhldmVudCkgPT4gdXBsb2FkQXZhdGFyKGV2ZW50LnRhcmdldC5maWxlcz8uWzBdKX0gLz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwic2lnbnVwLWF2YXRhci1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX0gYXJpYS1sYWJlbD1cIlVwbG9hZCBwcm9maWxlIHBob3RvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Fuc3dlcnMuYXZhdGFyVXJsID8gPGltZyBzcmM9e2Fuc3dlcnMuYXZhdGFyVXJsfSBhbHQ9XCJQcm9maWxlIHByZXZpZXdcIiAvPiA6IDxzcGFuPjxJY29uIG5hbWU9XCJjYW1lcmFcIiAvPjxiPis8L2I+PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VXBsb2FkIHByb2ZpbGUgcGhvdG8gPHNwYW4+KE9wdGlvbmFsKTwvc3Bhbj48L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAge2Fuc3dlcnMuYXZhdGFyVXJsICYmIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInNpZ251cC1jaGFuZ2UtYXZhdGFyXCIgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9PkNoYW5nZTwvYnV0dG9uPn1cclxuICAgICAgICAgICAgICAgICAge2F2YXRhckVycm9yICYmIDxzbWFsbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGQtZXJyb3JcIj48c3Bhbj4hPC9zcGFuPnthdmF0YXJFcnJvcn08L3NtYWxsPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtYWNjb3VudC1maWVsZHNcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNpZ251cC1maWVsZFwiPlVzZXJuYW1lPGlucHV0IHZhbHVlPXthbnN3ZXJzLm5hbWV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcIm5hbWVcIiwgZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJDaG9vc2UgYSB1c2VybmFtZVwiIC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNpZ251cC1maWVsZFwiPkVtYWlsIEFkZHJlc3M8aW5wdXQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2Fuc3dlcnMuZW1haWx9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcImVtYWlsXCIsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwieW91QGV4YW1wbGUuY29tXCIgLz57YW5zd2Vycy5lbWFpbCAmJiAhZW1haWxQYXR0ZXJuLnRlc3QoYW5zd2Vycy5lbWFpbCkgJiYgPHNtYWxsIGNsYXNzTmFtZT1cInNpZ251cC1maWVsZC1lcnJvclwiPjxzcGFuPiE8L3NwYW4+RW50ZXIgYSB2YWxpZCBlbWFpbCBhZGRyZXNzLjwvc21hbGw+fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGRcIj5QYXNzd29yZDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1wYXNzd29yZC1maWVsZFwiPjxpbnB1dCB0eXBlPXtzaG93UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn0gdmFsdWU9e2Fuc3dlcnMucGFzc3dvcmR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcInBhc3N3b3JkXCIsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiQ3JlYXRlIGEgc3Ryb25nIHBhc3N3b3JkXCIgLz48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoKGN1cnJlbnQpID0+ICFjdXJyZW50KX0gYXJpYS1sYWJlbD17c2hvd1Bhc3N3b3JkID8gXCJIaWRlIHBhc3N3b3JkXCIgOiBcIlNob3cgcGFzc3dvcmRcIn0+PEljb24gbmFtZT17c2hvd1Bhc3N3b3JkID8gXCJleWVPZmZcIiA6IFwiZXllXCJ9IC8+PC9idXR0b24+PC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXBhc3N3b3JkLXN0YXR1c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXN0cmVuZ3RoLW1ldGVyXCIgYXJpYS1sYWJlbD17YFBhc3N3b3JkIHN0cmVuZ3RoICR7c3RyZW5ndGh9IG9mIDNgfT57WzEsIDIsIDNdLm1hcCgoaXRlbSkgPT4gPGkga2V5PXtpdGVtfSBjbGFzc05hbWU9e2l0ZW0gPD0gc3RyZW5ndGggPyBcInBhc3NlZFwiIDogXCJcIn0gLz4pfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXBhc3N3b3JkLXJ1bGVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7W1twYXNzd29yZFJ1bGVzLmxlbmd0aCwgXCJBdCBsZWFzdCA4IGNoYXJhY3RlcnNcIl0sIFtwYXNzd29yZFJ1bGVzLm51bWJlciwgXCJBdCBsZWFzdCBvbmUgbnVtYmVyIG9yIHN5bWJvbFwiXSwgW3Bhc3N3b3JkUnVsZXMuY2FzZSwgXCJVcHBlciBhbmQgbG93ZXJjYXNlIGxldHRlcnNcIl1dLm1hcCgoW3Bhc3NlZCwgbGFiZWxdKSA9PiA8c3BhbiBjbGFzc05hbWU9e3Bhc3NlZCA/IFwicGFzc2VkXCIgOiBcIlwifSBrZXk9e1N0cmluZyhsYWJlbCl9PjxpPjxJY29uIG5hbWU9XCJjaGVja1wiIC8+PC9pPntsYWJlbH08L3NwYW4+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXNlY3Rpb24taGVhZGluZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5BYm91dCB5b3U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXVuaXQtdG9nZ2xlXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcImFjdGl2ZVwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gY2hhbmdlVW5pdChcIm1ldHJpY1wiKX0+TWV0cmljIDxzbWFsbD5rZy9jbTwvc21hbGw+PC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwiaW1wZXJpYWxcIiA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiBjaGFuZ2VVbml0KFwiaW1wZXJpYWxcIil9PkltcGVyaWFsIDxzbWFsbD5sYnMvZnQ8L3NtYWxsPjwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1iaW9tZXRyaWMtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2lnbnVwLWZpZWxkXCI+QWdlPGlucHV0IGlucHV0TW9kZT1cIm51bWVyaWNcIiB2YWx1ZT17YW5zd2Vycy5hZ2V9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcImFnZVwiLCBldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjI0XCIgLz57YW5zd2Vycy5hZ2UgJiYgIXZhbGlkQWdlICYmIDxzbWFsbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGQtZXJyb3JcIj48c3Bhbj4hPC9zcGFuPkVudGVyIGFuIGFnZSBmcm9tIDEw4oCTMTAwLjwvc21hbGw+fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGRcIj5IZWlnaHQ8c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtaW5wdXQtd2l0aC11bml0XCI+PGlucHV0IGlucHV0TW9kZT17YW5zd2Vycy51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCJudW1lcmljXCIgOiBcInRleHRcIn0gdmFsdWU9e2Fuc3dlcnMuaGVpZ2h0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRBbnN3ZXIoXCJoZWlnaHRcIiwgZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9e2Fuc3dlcnMudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwiMTc1IGNtXCIgOiBcIjUgZnQgOSBpblwifSAvPjxiPnthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcImNtXCIgOiBcImZ0IC8gaW5cIn08L2I+PC9zcGFuPnthbnN3ZXJzLmhlaWdodCAmJiAhdmFsaWRIZWlnaHQgJiYgPHNtYWxsIGNsYXNzTmFtZT1cInNpZ251cC1maWVsZC1lcnJvclwiPjxzcGFuPiE8L3NwYW4+e2Fuc3dlcnMudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwiMTAw4oCTMjUwIGNtXCIgOiBcIjMgZnQgMyBpbuKAkzggZnQgMiBpblwifTwvc21hbGw+fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGRcIj5DdXJyZW50IFdlaWdodDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1pbnB1dC13aXRoLXVuaXRcIj48aW5wdXQgaW5wdXRNb2RlPVwiZGVjaW1hbFwiIHZhbHVlPXthbnN3ZXJzLndlaWdodH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QW5zd2VyKFwid2VpZ2h0XCIsIGV2ZW50LnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPXthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcIjY4IGtnXCIgOiBcIjE1MCBsYnNcIn0gLz48Yj57YW5zd2Vycy51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCJrZ1wiIDogXCJsYnNcIn08L2I+PC9zcGFuPnthbnN3ZXJzLndlaWdodCAmJiAhdmFsaWRXZWlnaHQgJiYgPHNtYWxsIGNsYXNzTmFtZT1cInNpZ251cC1maWVsZC1lcnJvclwiPjxzcGFuPiE8L3NwYW4+e2Fuc3dlcnMudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwiMjXigJMzMDAga2dcIiA6IFwiNTXigJM2NjEgbGJzXCJ9PC9zbWFsbD59PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAge3ZhbGlkQWdlICYmIGFnZU51bWJlciA8IDE4ICYmIDxwIGNsYXNzTmFtZT1cInNpZ251cC1ub3RpY2VcIj5VbmRlciAxOD8gUGxlYXNlIGFzayBhIHBhcmVudCBvciBndWFyZGlhbiBiZWZvcmUgc3RhcnRpbmcgYSBmaXRuZXNzIGNoYWxsZW5nZS48L3A+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc2lnbnVwLXN0ZXAtY29udGVudCBzaWdudXAtc2xpZGUtJHtkaXJlY3Rpb259YH0ga2V5PVwic3RlcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgaWQ9XCJzaWdudXAtc3RlcC10aXRsZVwiIHJlZj17dGl0bGVSZWZ9IHRhYkluZGV4PXstMX0+VGVsbCB1cyBhYm91dCB5b3VyIHN0YXJ0aW5nIHBvaW50LjwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1pbnRyb1wiPlRoZXNlIGRldGFpbHMgaGVscCB1cyBjdXN0b21pemUgcHJhY3RpY2FsIHZvbHVtZSwgZXhlcmNpc2Ugc2VsZWN0aW9uLCBhbmQgcmVjb3ZlcnkuPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLWxhYmVsLXdpdGgtdGlwXCI+PHNwYW4+U09NQVRPVFlQRTwvc3Bhbj48SW5mb1RpcCB0ZXJtPVwiU29tYXRvdHlwZVwiIGRlZmluaXRpb249e2dsb3NzYXJ5VGVybXMuZmluZCgoW3Rlcm1dKSA9PiB0ZXJtID09PSBcIlNvbWF0b3R5cGVcIik/LlsxXSA/PyBcIlwifSBvbkxlYXJuTW9yZT17KCkgPT4gb25PcGVuR2xvc3NhcnkoXCJTb21hdG90eXBlXCIpfSBhY3Rpb25MYWJlbD1cIk9wZW4gR2xvc3NhcnlcIiBzaG93VGVybT17ZmFsc2V9IC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXNvbWF0b3R5cGUtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbW1wiRWN0b21vcnBoXCIsIFwiTmF0dXJhbGx5IGxlYW5lciBmcmFtZSwgZmFzdCBtZXRhYm9saXNtLlwiXSwgW1wiTWVzb21vcnBoXCIsIFwiTmF0dXJhbGx5IGF0aGxldGljLCBidWlsZHMgbXVzY2xlIGFuZCBidXJucyBmYXQgZWFzaWx5LlwiXSwgW1wiRW5kb21vcnBoXCIsIFwiTmF0dXJhbGx5IGJyb2FkZXIsIHRlbmRzIHRvIHN0b3JlIGJvZHkgZmF0IGVhc2lseS5cIl0sIFtcIk5vdCBTdXJlXCIsIFwiV2Ugd2lsbCB1c2UgeW91ciBvdGhlciBiYXNlbGluZSBhbnN3ZXJzLlwiXV0ubWFwKChbdGl0bGUsIHN1YnRpdGxlXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIga2V5PXt0aXRsZX0gY2xhc3NOYW1lPXthbnN3ZXJzLnNvbWF0b3R5cGUgPT09IHRpdGxlID8gXCJzZWxlY3RlZFwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gc2V0QW5zd2VyKFwic29tYXRvdHlwZVwiLCB0aXRsZSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nPnt0aXRsZX08L3N0cm9uZz48c21hbGw+e3N1YnRpdGxlfTwvc21hbGw+PC9zcGFuPnthbnN3ZXJzLnNvbWF0b3R5cGUgPT09IHRpdGxlICYmIDxiPjxJY29uIG5hbWU9XCJjaGVja1wiIC8+PC9iPn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+PHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLXNlY3Rpb24tbGFiZWxcIj5QUklNQVJZIEdPQUw8L3NwYW4+PGRpdiBjbGFzc05hbWU9XCJzaWdudXAtcGlsbC1ncm91cFwiPnsoW1wiTG9zZSBGYXQgJiBHZXQgTGVhblwiLCBcIkJ1aWxkIE11c2NsZSAmIFN0cmVuZ3RoXCIsIFwiQm9keSBSZWNvbXBvc2l0aW9uXCJdIGFzIEdvYWxbXSkubWFwKChpdGVtKSA9PiBwaWxsKGl0ZW0sIGFuc3dlcnMuZ29hbCA9PT0gaXRlbSwgKHZhbHVlKSA9PiBzZXRBbnN3ZXIoXCJnb2FsXCIsIHZhbHVlKSkpfTwvZGl2PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+PHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLXNlY3Rpb24tbGFiZWxcIj5FWFBFUklFTkNFIExFVkVMPC9zcGFuPjxwIGNsYXNzTmFtZT1cInNpZ251cC1oZWxwZXJcIj5XaGVyZSBhcmUgeW91IGluIHlvdXIgZml0bmVzcyBqb3VybmV5PzwvcD48ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1waWxsLWdyb3VwXCI+eyhbXCJTdGFydGluZyBPdXRcIiwgXCJTb21lIEV4cGVyaWVuY2VcIiwgXCJDb25zaXN0ZW50XCJdIGFzIEV4cGVyaWVuY2VbXSkubWFwKChpdGVtKSA9PiBwaWxsKGl0ZW0sIGFuc3dlcnMuZXhwZXJpZW5jZSA9PT0gaXRlbSwgKHZhbHVlKSA9PiBzZXRBbnN3ZXIoXCJleHBlcmllbmNlXCIsIHZhbHVlKSkpfTwvZGl2PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+PHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLXNlY3Rpb24tbGFiZWxcIj5DVVJSRU5UIEFDVElWSVRZIExFVkVMPC9zcGFuPjxwIGNsYXNzTmFtZT1cInNpZ251cC1oZWxwZXJcIj5Ib3cgYWN0aXZlIGFyZSB5b3Ugb3V0c2lkZSB5b3VyIHBsYW5uZWQgd29ya291dHM/PC9wPjxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXBpbGwtZ3JvdXBcIj57KFtcIlNlZGVudGFyeVwiLCBcIlNvbWV0aW1lcyBBY3RpdmVcIiwgXCJNb2RlcmF0ZWx5IEFjdGl2ZVwiLCBcIlZlcnkgQWN0aXZlXCJdIGFzIEFjdGl2aXR5W10pLm1hcCgoaXRlbSkgPT4gcGlsbChpdGVtLCBhbnN3ZXJzLmFjdGl2aXR5ID09PSBpdGVtLCAodmFsdWUpID0+IHNldEFuc3dlcihcImFjdGl2aXR5XCIsIHZhbHVlKSkpfTwvZGl2PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1zZWN0aW9uLWxhYmVsXCI+VEFSR0VUIEdPQUwgTUVUUklDPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC10YXJnZXQtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGQgc2lnbnVwLXRhcmdldC13ZWlnaHQtZmllbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC10YXJnZXQtbGFiZWxcIj5UYXJnZXQgV2VpZ2h0IDxzbWFsbD4oT3B0aW9uYWwpPC9zbWFsbD48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtdGFyZ2V0LWlucHV0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtaW5wdXQtd2l0aC11bml0XCI+PGlucHV0IGlucHV0TW9kZT1cImRlY2ltYWxcIiB2YWx1ZT17YW5zd2Vycy50YXJnZXRXZWlnaHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcInRhcmdldFdlaWdodFwiLCBldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj17YW5zd2Vycy51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCI2MiBrZ1wiIDogXCIxMzcgbGJzXCJ9IC8+PGI+e2Fuc3dlcnMudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwia2dcIiA6IFwibGJzXCJ9PC9iPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtoYXNUYXJnZXRXZWlnaHQgJiYgIXRhcmdldFZhbGlkICYmIDxzbWFsbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGQtZXJyb3JcIj48c3Bhbj4hPC9zcGFuPnthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcIkVudGVyIDI14oCTMzAwIGtnIG9yIGxlYXZlIGJsYW5rLlwiIDogXCJFbnRlciA1NeKAkzY2MSBsYnMgb3IgbGVhdmUgYmxhbmsuXCJ9PC9zbWFsbD59XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2lnbnVwLWZpZWxkXCI+VGFyZ2V0IFRpbWVsaW5lIEZvY3VzPHNlbGVjdCB2YWx1ZT17YW5zd2Vycy50YXJnZXRUaW1lbGluZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QW5zd2VyKFwidGFyZ2V0VGltZWxpbmVcIiwgZXZlbnQudGFyZ2V0LnZhbHVlKX0+PG9wdGlvbj5GaXJzdCAzMCBkYXlzPC9vcHRpb24+PG9wdGlvbj5CeSBkYXkgNjA8L29wdGlvbj48b3B0aW9uPkJ5IGRheSA5MDwvb3B0aW9uPjxvcHRpb24+V2hvbGUgY2hhbGxlbmdlPC9vcHRpb24+PC9zZWxlY3Q+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHt0YXJnZXRDYXV0aW9uICYmIDxwIGNsYXNzTmFtZT1cInNpZ251cC1ub3RpY2VcIj5UaGF04oCZcyBhIGJpZyBjaGFuZ2UuIEdyYWR1YWwgcHJvZ3Jlc3MgaXMgc2FmZXI7IHdl4oCZbGwgcGFjZSB5b3VyIHBsYW4uPC9wPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uXCI+PHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLXNlY3Rpb24tbGFiZWxcIj5BVkFJTEFCTEUgRVFVSVBNRU5UPC9zcGFuPjxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXBpbGwtZ3JvdXBcIj57KFtcIkJvZHl3ZWlnaHQgLyBIb21lIE9ubHlcIiwgXCJEdW1iYmVsbHMgJiBCYW5kc1wiLCBcIkZ1bGwgR3ltIEFjY2Vzc1wiXSBhcyBTaWdudXBFcXVpcG1lbnRbXSkubWFwKChpdGVtKSA9PiBwaWxsKGl0ZW0sIGFuc3dlcnMuYXZhaWxhYmxlRXF1aXBtZW50ID09PSBpdGVtLCAodmFsdWUpID0+IHNldEFuc3dlcihcImF2YWlsYWJsZUVxdWlwbWVudFwiLCB2YWx1ZSkpKX08L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLW1lZGljYWwtYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgPHA+U29mZXJGaXQgb2ZmZXJzIGdlbmVyYWwgZml0bmVzcyBndWlkYW5jZSwgbm90IG1lZGljYWwgYWR2aWNlLiBJZiB5b3UgaGF2ZSBhbiBpbmp1cnkgb3IgaGVhbHRoIGNvbmRpdGlvbiwgY2hlY2sgd2l0aCBhIGRvY3RvciBmaXJzdC48L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbD48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17YW5zd2Vycy5oYXNDb25kaXRpb259IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFuc3dlcihcImhhc0NvbmRpdGlvblwiLCBldmVudC50YXJnZXQuY2hlY2tlZCl9IC8+PHNwYW4+SSBoYXZlIGFuIGluanVyeSBvciBoZWFsdGggY29uZGl0aW9uPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIHthbnN3ZXJzLmhhc0NvbmRpdGlvbiAmJiA8c21hbGw+V2XigJlsbCBmYXZvciBsb3dlci1pbXBhY3QgZXhlcmNpc2VzIGluIHlvdXIgcGxhbi48L3NtYWxsPn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3N0ZXAgPT09IDMgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc2lnbnVwLXN0ZXAtY29udGVudCBzaWdudXAtc2xpZGUtJHtkaXJlY3Rpb259YH0ga2V5PVwic3RlcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgaWQ9XCJzaWdudXAtc3RlcC10aXRsZVwiIHJlZj17dGl0bGVSZWZ9IHRhYkluZGV4PXstMX0+QnVpbGQgeW91ciB3ZWVrbHkgcmh5dGhtLjwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1pbnRyb1wiPlNlbGVjdCB5b3VyIHRyYW5zZm9ybWF0aW9uIGR1cmF0aW9uIGFuZCB3ZWVrbHkgc2NoZWR1bGUuPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtc3RlcC1zZWN0aW9uIHNpZ251cC1kdXJhdGlvbi1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1zZWN0aW9uLWxhYmVsXCI+Q0hPT1NFIFlPVVIgQ0hBTExFTkdFIERVUkFUSU9OPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1kdXJhdGlvbi1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgeyhbNjAsIDkwXSBhcyBjb25zdCkubWFwKChkYXlzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBrZXk9e2RheXN9IGNsYXNzTmFtZT17YW5zd2Vycy5jaGFsbGVuZ2VEYXlzID09PSBkYXlzID8gXCJzZWxlY3RlZFwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gc2V0QW5zd2VyKFwiY2hhbGxlbmdlRGF5c1wiLCBkYXlzKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1kdXJhdGlvbi1jaGlwXCI+e2RheXMgPT09IDYwID8gXCJTcHJpbnRcIiA6IFwiTW9zdCBzdXN0YWluYWJsZVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57ZGF5c30tRGF5IENoYWxsZW5nZTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD57ZGF5cyA9PT0gNjAgPyBcIkEgaGlnaC1pbnRlbnNpdHksIGZvY3VzZWQgc3ByaW50LiBCZXN0IGZvciByYXBpZCByb3V0aW5lIGZvcm1hdGlvbiBhbmQgZmFzdCBmYXQgbG9zcy5cIiA6IFwiQ29tcHJlaGVuc2l2ZSBib2R5IHRyYW5zZm9ybWF0aW9uLiBCZXN0IGZvciBzdXN0YWluYWJsZSByZWNvbXBvc2l0aW9uIGFuZCBkZWVwIGhhYml0IGJ1aWxkaW5nLlwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Fuc3dlcnMuY2hhbGxlbmdlRGF5cyA9PT0gZGF5cyAmJiA8Yj48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPjwvYj59XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXN0ZXAtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtc2VjdGlvbi1sYWJlbFwiPldPUktPVVQgREFZUyBQRVIgV0VFSzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtbnVtYmVyLXBpbGxzXCI+e1syLCAzLCA0LCA1LCA2XS5tYXAoKGRheXMpID0+IDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGtleT17ZGF5c30gY2xhc3NOYW1lPXthbnN3ZXJzLndvcmtvdXREYXlzID09PSBkYXlzID8gXCJzZWxlY3RlZFwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gc2V0QW5zd2VyKFwid29ya291dERheXNcIiwgZGF5cyl9PnthbnN3ZXJzLndvcmtvdXREYXlzID09PSBkYXlzICYmIDxJY29uIG5hbWU9XCJjaGVja1wiIC8+fXtkYXlzfSBkYXlzPC9idXR0b24+KX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2lnbnVwLWxpdmUtaGVscGVyXCI+e2Fuc3dlcnMud29ya291dERheXMgPyBgVGhhdCBsZWF2ZXMgJHs3IC0gYW5zd2Vycy53b3Jrb3V0RGF5c30gcmVzdCAkezcgLSBhbnN3ZXJzLndvcmtvdXREYXlzID09PSAxID8gXCJkYXlcIiA6IFwiZGF5c1wifSBlYWNoIHdlZWsgZm9yIHJlY292ZXJ5LmAgOiBcIkNob29zZSBhIHBhY2UgdGhhdCBsZWF2ZXMgcm9vbSBmb3IgcmVjb3ZlcnkuXCJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICB7YW5zd2Vycy53b3Jrb3V0RGF5cyA9PT0gNiAmJiBhbnN3ZXJzLmV4cGVyaWVuY2UgPT09IFwiU3RhcnRpbmcgT3V0XCIgJiYgPHAgY2xhc3NOYW1lPVwic2lnbnVwLW5vdGljZVwiPk5ldyB0byB0cmFpbmluZz8gMy00IGRheXMgYSB3ZWVrIGlzIGEgZ3JlYXQgd2F5IHRvIHN0YXJ0LjwvcD59XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXN0ZXAtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtc2VjdGlvbi1sYWJlbFwiPlNFU1NJT04gRFVSQVRJT048L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXNlc3Npb24tY29udHJvbHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic2lnbnVwLWZpZWxkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthbnN3ZXJzLnNlc3Npb25DaG9pY2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaG9pY2UgPSBldmVudC50YXJnZXQudmFsdWUgYXMgU2lnbnVwQW5zd2Vyc1tcInNlc3Npb25DaG9pY2VcIl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QW5zd2VycygoY3VycmVudCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmN1cnJlbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uQ2hvaWNlOiBjaG9pY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uTWludXRlczogY2hvaWNlICYmIGNob2ljZSAhPT0gXCJjdXN0b21cIiA/IE51bWJlcihjaG9pY2UpIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbVNlc3Npb25NaW51dGVzOiBjaG9pY2UgPT09IFwiY3VzdG9tXCIgPyBjdXJyZW50LmN1c3RvbVNlc3Npb25NaW51dGVzIDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZXNzaW9uIGR1cmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkPlNlbGVjdCBzZXNzaW9uIGxlbmd0aDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMTVcIj4xNSBtaW51dGVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIzMFwiPjMwIG1pbnV0ZXM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIjQ1XCI+NDUgbWludXRlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiNjBcIj42MCBtaW51dGVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjdXN0b21cIj5DdXN0b20uLi48L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAge2Fuc3dlcnMuc2Vzc2lvbkNob2ljZSA9PT0gXCJjdXN0b21cIiAmJiA8bGFiZWwgY2xhc3NOYW1lPVwic2lnbnVwLWZpZWxkIHNpZ251cC1jdXN0b20tc2Vzc2lvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLWlucHV0LXdpdGgtdW5pdFwiPjxpbnB1dCByZWY9e2N1c3RvbVNlc3Npb25SZWZ9IGlucHV0TW9kZT1cIm51bWVyaWNcIiB2YWx1ZT17YW5zd2Vycy5jdXN0b21TZXNzaW9uTWludXRlc30gb25DaGFuZ2U9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGV2ZW50LnRhcmdldC52YWx1ZS5yZXBsYWNlKC9cXEQvZywgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFuc3dlcnMoKGN1cnJlbnQpID0+ICh7IC4uLmN1cnJlbnQsIGN1c3RvbVNlc3Npb25NaW51dGVzOiB2YWx1ZSwgc2Vzc2lvbk1pbnV0ZXM6IHZhbHVlICYmIE51bWJlcih2YWx1ZSkgPj0gNSAmJiBOdW1iZXIodmFsdWUpIDw9IDE4MCA/IE51bWJlcih2YWx1ZSkgOiBudWxsIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19IHBsYWNlaG9sZGVyPVwiNTBcIiAvPjxiPm1pbjwvYj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YW5zd2Vycy5jdXN0b21TZXNzaW9uTWludXRlcyAmJiAhY3VzdG9tU2Vzc2lvblZhbGlkICYmIDxzbWFsbCBjbGFzc05hbWU9XCJzaWdudXAtZmllbGQtZXJyb3JcIj48c3Bhbj4hPC9zcGFuPkVudGVyIDUtMTgwIG1pbnV0ZXM8L3NtYWxsPn1cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtzdGVwID09PSA0ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHNpZ251cC1zdGVwLWNvbnRlbnQgc2lnbnVwLXNsaWRlLSR7ZGlyZWN0aW9ufWB9IGtleT1cInN0ZXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGlkPVwic2lnbnVwLXN0ZXAtdGl0bGVcIiByZWY9e3RpdGxlUmVmfSB0YWJJbmRleD17LTF9PlJldmlldyB5b3VyIHRyYW5zZm9ybWF0aW9uIHByb2ZpbGUuPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpZ251cC1zdGVwLWludHJvXCI+Q29uZmlybSB5b3VyIGRldGFpbHMgYmVmb3JlIHdlIHN0cnVjdHVyZSB5b3VyIGNoYWxsZW5nZS48L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctZ3JvdXAtaGVhZFwiPjxzcGFuPkFDQ09VTlQ8L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZWRpdFN0ZXAoMSl9PkVkaXQ8L2J1dHRvbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctYWNjb3VudFwiPjxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctYXZhdGFyXCI+e2Fuc3dlcnMuYXZhdGFyVXJsID8gPGltZyBzcmM9e2Fuc3dlcnMuYXZhdGFyVXJsfSBhbHQ9XCJcIiAvPiA6IGluaXRpYWxzfTwvc3Bhbj48ZGl2PjxzdHJvbmc+e2Fuc3dlcnMubmFtZX08L3N0cm9uZz48c21hbGw+e2Fuc3dlcnMuZW1haWx9PC9zbWFsbD48L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8c2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctZ3JvdXAtaGVhZFwiPjxzcGFuPkJPRFkgUFJPRklMRTwvc3Bhbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBlZGl0U3RlcCgyKX0+RWRpdDwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXJldmlldy12YWx1ZXNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5BZ2U8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMuYWdlfTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5IZWlnaHQ8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMuaGVpZ2h0fSB7YW5zd2Vycy51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiICYmICFhbnN3ZXJzLmhlaWdodC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiY21cIikgPyBcImNtXCIgOiBcIlwifTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5DdXJyZW50IOKGkiB0YXJnZXQgd2VpZ2h0PC9zbWFsbD48c3Ryb25nPnthbnN3ZXJzLndlaWdodCB8fCBcIuKAlFwifSB7YW5zd2Vycy51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCJrZ1wiIDogXCJsYnNcIn0g4oaSIHthbnN3ZXJzLnRhcmdldFdlaWdodCA/IGAke2Fuc3dlcnMudGFyZ2V0V2VpZ2h0fSAke2Fuc3dlcnMudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwia2dcIiA6IFwibGJzXCJ9YCA6IFwiTi9BXCJ9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPlVuaXQgc3lzdGVtPC9zbWFsbD48c3Ryb25nPnthbnN3ZXJzLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcIk1ldHJpY1wiIDogXCJJbXBlcmlhbFwifTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5Tb21hdG90eXBlPC9zbWFsbD48c3Ryb25nPnthbnN3ZXJzLnNvbWF0b3R5cGV9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPkFjdGl2aXR5IGxldmVsPC9zbWFsbD48c3Ryb25nPnthbnN3ZXJzLmFjdGl2aXR5fTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8c2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZpZXctZ3JvdXAtaGVhZFwiPjxzcGFuPlNDSEVEVUxFPC9zcGFuPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGVkaXRTdGVwKDMpfT5FZGl0PC9idXR0b24+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtcmV2aWV3LXZhbHVlc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPkNoYWxsZW5nZSBkdXJhdGlvbjwvc21hbGw+PHN0cm9uZz57YW5zd2Vycy5jaGFsbGVuZ2VEYXlzfSBEYXlzPC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPkZyZXF1ZW5jeTwvc21hbGw+PHN0cm9uZz57YW5zd2Vycy53b3Jrb3V0RGF5c30gZGF5cy93ZWVrLCB7YW5zd2Vycy5zZXNzaW9uTWludXRlc30gbWluL3Nlc3Npb248L3N0cm9uZz48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cD48c21hbGw+VGltZWxpbmUgZm9jdXM8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMudGFyZ2V0VGltZWxpbmV9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXJldmlldy1ncm91cC1oZWFkXCI+PHNwYW4+Rk9DVVMgJiBHRUFSPC9zcGFuPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGVkaXRTdGVwKDIpfT5FZGl0PC9idXR0b24+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtcmV2aWV3LXZhbHVlc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPlByaW1hcnkgZ29hbDwvc21hbGw+PHN0cm9uZz57YW5zd2Vycy5nb2FsfTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5FeHBlcmllbmNlIGxldmVsPC9zbWFsbD48c3Ryb25nPnthbnN3ZXJzLmV4cGVyaWVuY2V9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPkF2YWlsYWJsZSBlcXVpcG1lbnQ8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMuYXZhaWxhYmxlRXF1aXBtZW50fTwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwPjxzbWFsbD5FeHBsb3JlciBmb2N1czwvc21hbGw+PHN0cm9uZz57YW5zd2Vycy5mb2N1c0FyZWF9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+PHNtYWxsPlRyYWluaW5nIG1vZGU8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMubW9kZX08L3N0cm9uZz48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cD48c21hbGw+SW5qdXJ5IG9yIGNvbmRpdGlvbjwvc21hbGw+PHN0cm9uZz57YW5zd2Vycy5oYXNDb25kaXRpb24gPyBcIlllcyDigJQgZmF2b3IgbG93ZXIgaW1wYWN0XCIgOiBcIk5vXCJ9PC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtzdGVwID09PSA1ICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1nZW5lcmF0aW9uLXN0YXRlIHNpZ251cC1zbGlkZS1mb3J3YXJkXCIga2V5PVwiZ2VuZXJhdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtZ2VuZXJhdGlvbi1yaW5nXCIgc3R5bGU9e3sgXCItLWdlbmVyYXRpb24tcHJvZ3Jlc3NcIjogYCR7Z2VuZXJhdGlvblByb2dyZXNzICogMy42fWRlZ2AgfSBhcyBSZWFjdC5DU1NQcm9wZXJ0aWVzfT48c3Bhbj57Z2VuZXJhdGlvblByb2dyZXNzfSU8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZWR1Y2VkLXByb2dyZXNzXCI+PGkgc3R5bGU9e3sgd2lkdGg6IGAke2dlbmVyYXRpb25Qcm9ncmVzc30lYCB9fSAvPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHN0cm9uZyBrZXk9e2dlbmVyYXRpb25TdGF0dXN9IGNsYXNzTmFtZT1cInNpZ251cC1nZW5lcmF0aW9uLXN0YXR1c1wiPntzdGF0dXNNZXNzYWdlc1tnZW5lcmF0aW9uU3RhdHVzXX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgIDxwPlRoaXMgb25seSB0YWtlcyBhIG1vbWVudC48L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7c3RlcCA9PT0gNiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtcmV2ZWFsIHNpZ251cC1zbGlkZS1mb3J3YXJkXCIga2V5PVwicmV2ZWFsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgaWQ9XCJzaWdudXAtc3RlcC10aXRsZVwiIHJlZj17dGl0bGVSZWZ9IHRhYkluZGV4PXstMX0+WW91ciBjaGFsbGVuZ2UgaXMgcmVhZHkuPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNpZ251cC1zdGVwLWludHJvXCI+WW91ciBmaXRuZXNzIGpvdXJuZXkgc3RhcnRzIHRvZGF5ISBCYXNlZCBvbiB5b3VyIGFuc3dlcnMsIGhlcmUgaXMgd2hhdCB5b3VyIGNoYWxsZW5nZSBpbmNsdWRlczo8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ251cC1yZXZlYWwtbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFtcImNsaXBib2FyZFwiLCBcIkNvbXBsZXRlLCBFYXN5LXRvLUZvbGxvdyBQbGFuXCIsIFwiQ2xlYXIgc2NoZWR1bGVkIHdvcmtvdXRzLCBzdHJ1Y3R1cmVkIHJlc3QgZGF5cywgYW5kIHByb2dyZXNzaXZlIGN1ZXMuXCJdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcInNsaWRlcnNcIiwgXCJBYnNvbHV0ZSBGcmVlZG9tIHRvIEN1c3RvbWl6ZVwiLCBcIkFkanVzdCB5b3VyIGVxdWlwbWVudCwgaW50ZW5zaXR5LCBhbmQgd29ya291dCBkYXlzIHRvIGZpdCB5b3VyIHdlZWsuXCJdLFxyXG4gICAgICAgICAgICAgICAgICAgIFtcImNhbWVyYVwiLCBcIlByb2dyZXNzIFBob3RvcyAmIFdlaWdodCBUcmFja2luZ1wiLCBcIkNhcHR1cmUgeW91ciB0cmFuc2Zvcm1hdGlvbiB3aXRoIHJlZ3VsYXIgcGhvdG9zIGFuZCB0cmFjayBldmVyeSBwb3VuZCBsb3N0LlwiXSxcclxuICAgICAgICAgICAgICAgICAgICBbXCJ0aW1lclwiLCBcIlN0cnVjdHVyZWQgR3VpZGVkIFNlc3Npb25zXCIsIFwiQnVpbHQtaW4gY291bnRkb3duIHRpbWVycywgcmVwIGNvdW50ZXJzLCBhbmQgbW90aXZhdGlvbmFsIGN1ZXMuXCJdLFxyXG4gICAgICAgICAgICAgICAgICBdLm1hcCgoW2ljb24sIHRpdGxlLCBkZXNjcmlwdGlvbl0sIGluZGV4KSA9PiA8YXJ0aWNsZSBrZXk9e3RpdGxlfSBzdHlsZT17eyBcIi0tcmV2ZWFsLWluZGV4XCI6IGluZGV4IH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc30+PHNwYW4+PEljb24gbmFtZT17aWNvbiBhcyBcImNsaXBib2FyZFwiIHwgXCJzbGlkZXJzXCIgfCBcImNhbWVyYVwiIHwgXCJ0aW1lclwifSAvPjwvc3Bhbj48ZGl2PjxzdHJvbmc+e3RpdGxlfTwvc3Ryb25nPjxwPntkZXNjcmlwdGlvbn08L3A+PC9kaXY+PC9hcnRpY2xlPil9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtzdGVwIDw9IDMgJiYgPGZvb3RlciBjbGFzc05hbWU9XCJzaWdudXAtYWN0aW9uc1wiPjxidXR0b24gY2xhc3NOYW1lPVwic2lnbnVwLWJhY2stbGlua1wiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtnb0JhY2t9PkJhY2s8L2J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9e2dvTmV4dH0gZGlzYWJsZWQ9eyFzdGVwVmFsaWR9PntyZXR1cm5Ub1JldmlldyA/IFwiUmV0dXJuIHRvIHJldmlld1wiIDogXCJOZXh0XCJ9PC9CdXR0b24+PC9mb290ZXI+fVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB7c3RlcCA9PT0gNCAmJiAoXHJcbiAgICAgICAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwic2lnbnVwLWFjdGlvbnMgc2lnbnVwLXJldmlldy1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzaWdudXAtYmFjay1saW5rXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2dvQmFja30+QmFjazwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgIC8vIDEuIFJlZ2lzdGVyIHVzZXIgYWNjb3VudCBvbiBEamFuZ28gYmFja2VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgYXdhaXQgYXBpLnJlZ2lzdGVyKGFuc3dlcnMuZW1haWwsIGFuc3dlcnMucGFzc3dvcmQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIC8vIDIuIFNhdmUgb25ib2FyZGluZyBwcm9maWxlIGRhdGEgdG8gRGphbmdvIGJhY2tlbmRcclxuICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5zYXZlT25ib2FyZGluZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGFuc3dlcnMubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWdlOiBhbnN3ZXJzLmFnZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBhbnN3ZXJzLmhlaWdodCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFdlaWdodDogYW5zd2Vycy53ZWlnaHQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldFdlaWdodDogYW5zd2Vycy50YXJnZXRXZWlnaHQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuaXRTeXN0ZW06IGFuc3dlcnMudW5pdFN5c3RlbSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc29tYXRvdHlwZTogYW5zd2Vycy5zb21hdG90eXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBnb2FsOiBhbnN3ZXJzLmdvYWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVyaWVuY2U6IGFuc3dlcnMuZXhwZXJpZW5jZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdHk6IGFuc3dlcnMuYWN0aXZpdHksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdvcmtvdXREYXlzOiBTdHJpbmcoYW5zd2Vycy53b3Jrb3V0RGF5cyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25MZW5ndGg6IFN0cmluZyhhbnN3ZXJzLnNlc3Npb25NaW51dGVzID8/IDMwKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXNBcmVhOiBhbnN3ZXJzLmZvY3VzQXJlYSB8fCBcIkdlbmVyYWwgRml0bmVzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlOiBhbnN3ZXJzLm1vZGUgfHwgXCJTdGFuZGFyZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlcXVpcG1lbnQ6IGFuc3dlcnMuYXZhaWxhYmxlRXF1aXBtZW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFsbGVuZ2VEYXlzOiBhbnN3ZXJzLmNoYWxsZW5nZURheXMhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRUaW1lbGluZTogYW5zd2Vycy50YXJnZXRUaW1lbGluZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFzQ29uZGl0aW9uOiBhbnN3ZXJzLmhhc0NvbmRpdGlvbixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIC8vIDMuIFRyaWdnZXIgZ2VuZXJhdGlvbiBzdGF0ZSBhbmltYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEdlbmVyYXRpb25Qcm9ncmVzcygwKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEdlbmVyYXRpb25TdGF0dXMoMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTdGVwKDUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQmFja2VuZCBpbnRlZ3JhdGlvbiBmYWlsZWQgZHVyaW5nIHNpZ251cDpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgYWxlcnQoXCJDb3VsZCBub3QgY29ubmVjdCB0byB0aGUgYmFja2VuZCBzZXJ2ZXIuIE1ha2Ugc3VyZSBEamFuZ28gaXMgcnVubmluZy5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHZW5lcmF0ZSBNeSBQbGFuXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxzbWFsbD5BSSBnZW5lcmF0aW9uIGlzIGxpbWl0ZWQuIFRoaXMgdXNlcyBvbmUgb2YgeW91ciBwbGFuIGdlbmVyYXRpb25zLjwvc21hbGw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9vdGVyPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gNiAmJiA8Zm9vdGVyIGNsYXNzTmFtZT1cInNpZ251cC1hY3Rpb25zIHNpZ251cC1yZXZlYWwtYWN0aW9uc1wiPjxCdXR0b24gb25DbGljaz17KCkgPT4gb25Db21wbGV0ZShhbnN3ZXJzKX0+RGFzaGJvYXJkIDxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PC9CdXR0b24+PC9mb290ZXI+fVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7c3RlcCA8PSA0ICYmIDxhc2lkZSBjbGFzc05hbWU9XCJzaWdudXAtcHJldmlldy1wYW5lbFwiIGFyaWEtbGFiZWw9XCJZb3VyIHBsYW4gcHJldmlld1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWdudXAtcHJldmlldy1icmFuZFwiPjxMb2dvTWFyayAvPjxzcGFuPlNvZmVyRml0PC9zcGFuPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLW9yYiBzaWdudXAtb3JiLW9uZVwiIC8+PGRpdiBjbGFzc05hbWU9XCJzaWdudXAtb3JiIHNpZ251cC1vcmItdHdvXCIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLXByZXZpZXctc3RhY2tcIiBrZXk9e3N0ZXB9PlxyXG4gICAgICAgICAgICB7c3RlcCA9PT0gMSA/IDw+XHJcbiAgICAgICAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwic2lnbnVwLWdsYXNzLWNhcmQgc2lnbnVwLWdsYXNzLXByaW1hcnlcIj48c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtZ2xhc3MtaWNvblwiPjxJY29uIG5hbWU9XCJjYWxlbmRhclwiIC8+PC9zcGFuPjxzbWFsbD5EQVkgMTwvc21hbGw+PHN0cm9uZz5TdGFydHMgdGhlIGRheSB5b3Ugc2lnbiB1cDwvc3Ryb25nPjwvYXJ0aWNsZT5cclxuICAgICAgICAgICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJzaWdudXAtZ2xhc3MtY2FyZCBzaWdudXAtZ2xhc3Mtc2Vjb25kYXJ5XCI+PHNwYW4gY2xhc3NOYW1lPVwic2lnbnVwLW1pbmktY2hlY2tcIj48SWNvbiBuYW1lPVwiZmxhbWVcIiAvPjwvc3Bhbj48ZGl2PjxzbWFsbD5IQUJJVCBTVFJFQUs8L3NtYWxsPjxzdHJvbmc+U2hvdyB1cCBkYWlseSB0byBidWlsZCB5b3VyIHN0cmVhayE8L3N0cm9uZz48L2Rpdj48L2FydGljbGU+XHJcbiAgICAgICAgICAgIDwvPiA6IHN0ZXAgPT09IDIgPyA8PlxyXG4gICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInNpZ251cC1nbGFzcy1jYXJkIHNpZ251cC1nbGFzcy1wcmltYXJ5IHNpZ251cC13ZWVrbHktY2FyZFwiPjxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1wcm9ncmVzcy1yaW5nXCI+NDxzbWFsbD5EQVlTPC9zbWFsbD48L3NwYW4+PHNtYWxsPldFRUtMWSBUQVJHRVQ8L3NtYWxsPjxzdHJvbmc+QnVpbGQgYSBzdGVhZHkgcmh5dGhtPC9zdHJvbmc+PC9hcnRpY2xlPlxyXG4gICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInNpZ251cC1nbGFzcy1jYXJkIHNpZ251cC1nbGFzcy1zZWNvbmRhcnlcIj48c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtbWluaS1jaGVja1wiPjxJY29uIG5hbWU9XCJjaGFydFwiIC8+PC9zcGFuPjxkaXY+PHNtYWxsPllPVVIgU1RBUlRJTkcgUE9JTlQ8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMuZ29hbCB8fCBcIkNob29zZSB5b3VyIHByaW1hcnkgZ29hbFwifTwvc3Ryb25nPjwvZGl2PjwvYXJ0aWNsZT5cclxuICAgICAgICAgICAgPC8+IDogc3RlcCA9PT0gMyA/IDw+XHJcbiAgICAgICAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwic2lnbnVwLWdsYXNzLWNhcmQgc2lnbnVwLWdsYXNzLXByaW1hcnkgc2lnbnVwLXdlZWstY2FyZFwiPjxzbWFsbD5ZT1VSIFdFRUs8L3NtYWxsPjxkaXY+e1swLCAxLCAyLCAzLCA0LCA1LCA2XS5tYXAoKGRheSkgPT4gPGkga2V5PXtkYXl9IGNsYXNzTmFtZT17ZGF5IDwgKGFuc3dlcnMud29ya291dERheXMgPz8gMCkgPyBcIndvcmtvdXRcIiA6IFwicmVzdFwifT57W1wiTVwiLCBcIlRcIiwgXCJXXCIsIFwiVFwiLCBcIkZcIiwgXCJTXCIsIFwiU1wiXVtkYXldfTwvaT4pfTwvZGl2PjxzdHJvbmc+e2Fuc3dlcnMud29ya291dERheXMgPyBgJHthbnN3ZXJzLndvcmtvdXREYXlzfSB0cmFpbmluZyBkYXlzYCA6IFwiQ2hvb3NlIHlvdXIgcmh5dGhtXCJ9PC9zdHJvbmc+PC9hcnRpY2xlPlxyXG4gICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInNpZ251cC1nbGFzcy1jYXJkIHNpZ251cC1nbGFzcy1zZWNvbmRhcnlcIj48c3BhbiBjbGFzc05hbWU9XCJzaWdudXAtbWluaS1jaGVja1wiPjxJY29uIG5hbWU9XCJmbGFtZVwiIC8+PC9zcGFuPjxkaXY+PHNtYWxsPkNIQUxMRU5HRSBMRU5HVEg8L3NtYWxsPjxzdHJvbmc+e2Fuc3dlcnMuY2hhbGxlbmdlRGF5cyA/IGAke2Fuc3dlcnMuY2hhbGxlbmdlRGF5c30gZGF5c2AgOiBcIkNob29zZSA2MCBvciA5MCBkYXlzXCJ9PC9zdHJvbmc+PC9kaXY+PC9hcnRpY2xlPlxyXG4gICAgICAgICAgICA8Lz4gOiA8YXJ0aWNsZSBjbGFzc05hbWU9XCJzaWdudXAtZ2xhc3MtY2FyZCBzaWdudXAtZ2xhc3MtcHJpbWFyeSBzaWdudXAtcmVhZHktY2FyZFwiPjxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1kYXktb25lLWNoaXBcIj5EQVkgMTwvc3Bhbj48c21hbGw+UkVBRFkgVE8gU1RBUlQ8L3NtYWxsPjxzdHJvbmc+WW91ciB7YW5zd2Vycy5jaGFsbGVuZ2VEYXlzfS1kYXkgY2hhbGxlbmdlPC9zdHJvbmc+PHA+RXZlcnl0aGluZyBpcyBzZXQgZm9yIHlvdXIgZmlyc3Qgc2Vzc2lvbi48L3A+PC9hcnRpY2xlPn1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2lnbnVwLXByZXZpZXctcXVvdGVcIj5TbWFsbCBzdGVwcy4gU3Ryb25nZXIgZGF5cy48L3A+XHJcbiAgICAgICAgPC9hc2lkZT59XHJcblxyXG5cclxuICAgICAgICB7c2hvd0xlYXZlUHJvbXB0ICYmIDxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLWNvbmZpcm0td3JhcFwiPjxkaXYgY2xhc3NOYW1lPVwic2lnbnVwLWNvbmZpcm1cIiByb2xlPVwiYWxlcnRkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWxsZWRieT1cImxlYXZlLXNpZ251cC10aXRsZVwiPjxzcGFuIGNsYXNzTmFtZT1cInNpZ251cC1jb25maXJtLWljb25cIj48SWNvbiBuYW1lPVwiYmFja1wiIC8+PC9zcGFuPjxoMyBpZD1cImxlYXZlLXNpZ251cC10aXRsZVwiPkxlYXZlIHNpZ24gdXA/PC9oMz48cD5Zb3VyIGFuc3dlcnMgd2lsbCBiZSBsb3N0LjwvcD48ZGl2PjxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0xlYXZlUHJvbXB0KGZhbHNlKX0+U3RheTwvQnV0dG9uPjxCdXR0b24gdmFyaWFudD1cImRhcmtcIiBvbkNsaWNrPXtvbkNsb3NlfT5MZWF2ZTwvQnV0dG9uPjwvZGl2PjwvZGl2PjwvZGl2Pn1cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSJdfQ==