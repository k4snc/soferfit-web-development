import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/DashboardPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport15_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { EmptyState } from "/src/frontend/components/EmptyState.tsx";
import { GlossaryDrawer } from "/src/frontend/components/GlossaryDrawer.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { LogoMark } from "/src/frontend/components/LogoMark.tsx";
import { memberNav } from "/src/frontend/data/nav.ts";
import { clearFitnessStore, readFitnessStore, writeFitnessStore } from "/src/frontend/fitnessStore.ts";
import { GeneratePage } from "/src/frontend/pages/GeneratePage.tsx";
import { OverviewPage } from "/src/frontend/pages/OverviewPage.tsx";
import { ProfilePage } from "/src/frontend/pages/ProfilePage.tsx";
import { ProgressPage } from "/src/frontend/pages/ProgressPage.tsx";
import { WorkoutsPage } from "/src/frontend/pages/WorkoutsPage.tsx";
import { api } from "/src/frontend/services/api.ts";
import { SessionPlayer } from "/src/frontend/session/SessionPlayer.tsx";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/DashboardPage.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function DashboardPage({ path, navigate, onHome, onLogout, profile }) {
	_s();
	const activePath = typeof path === "string" && path.length > 0 ? path : window.location.pathname || "/dashboard";
	const [store, setStore] = useState(() => readFitnessStore(profile));
	const [toast, setToast] = useState(null);
	const [profileGlossary, setProfileGlossary] = useState({ open: false });
	const update = (next) => {
		try {
			writeFitnessStore(next);
			setStore(next);
			return true;
		} catch {
			setToast({
				message: "We couldn't save that change. Try a smaller image or free some browser storage.",
				error: true
			});
			return false;
		}
	};
	const showToast = (message, error = false) => {
		setToast({
			message,
			error
		});
		window.setTimeout(() => setToast(null), 3200);
	};
	const challengeStart = new Date(`${store.challenge.startDate}T12:00:00`);
	const challengeDay = Math.max(1, Math.min(store.challenge.length, Math.floor((Date.now() - challengeStart.getTime()) / 864e5) + 1));
	const logout = async () => {
		try {
			await api.logout();
		} catch (err) {
			console.error("Backend logout failed, clearing local session anyway:", err);
		}
		clearFitnessStore();
		onLogout();
	};
	if (activePath.startsWith("/session/")) {
		const workout = store.plan.find((item) => item.id === decodeURIComponent(activePath.split("/").pop() || ""));
		return workout ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(SessionPlayer, {
			workout,
			store,
			update,
			navigate,
			toast: showToast
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 24
		}, this), toast && /* @__PURE__ */ _jsxDEV("div", {
			className: `app-toast ${toast.error ? "error" : ""}`,
			children: toast.message
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 137
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 22
		}, this) : /* @__PURE__ */ _jsxDEV("main", {
			className: "session-player",
			children: [/* @__PURE__ */ _jsxDEV(EmptyState, {
				title: "Workout not found",
				copy: "Return to your plan and choose another workout."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 257
			}, this), /* @__PURE__ */ _jsxDEV(Button, {
				onClick: () => navigate("/workouts"),
				children: "Back to workouts"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 352
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 224
		}, this);
	}
	const content = activePath === "/workouts" ? /* @__PURE__ */ _jsxDEV(WorkoutsPage, {
		store,
		update,
		navigate,
		toast: showToast
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 48
	}, this) : activePath === "/progress" ? /* @__PURE__ */ _jsxDEV(ProgressPage, {
		store,
		update,
		toast: showToast
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 36
	}, this) : activePath === "/generate" ? /* @__PURE__ */ _jsxDEV(GeneratePage, {
		store,
		update,
		navigate,
		toast: showToast
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 38
	}, this) : activePath === "/profile" ? /* @__PURE__ */ _jsxDEV(ProfilePage, {
		store,
		update,
		toast: showToast,
		onLogout: logout,
		onOpenGlossary: (term) => setProfileGlossary({
			open: true,
			term
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 39
	}, this) : /* @__PURE__ */ _jsxDEV(OverviewPage, {
		store,
		navigate
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 13
	}, this);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "dashboard-page",
		children: [
			/* @__PURE__ */ _jsxDEV("aside", {
				className: "dash-sidebar",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: "brand",
						onClick: onHome,
						children: [/* @__PURE__ */ _jsxDEV(LogoMark, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 52
						}, this), "SoferFit"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("nav", {
						"aria-label": "Dashboard navigation",
						children: memberNav.map((item) => /* @__PURE__ */ _jsxDEV("button", {
							className: activePath === item.path ? "active" : "",
							onClick: () => navigate(item.path),
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: item.icon }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 186
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 211
							}, this)]
						}, item.path, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 73
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "challenge-mini",
						children: [
							/* @__PURE__ */ _jsxDEV("small", { children: [store.challenge.length, "-DAY CHALLENGE"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 41
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: ["Day ", challengeDay] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 94
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("i", { style: { width: `${challengeDay / store.challenge.length * 100}%` } }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 134
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 129
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [Math.max(0, store.challenge.length - challengeDay), " days to go"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 216
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "sidebar-glossary",
						onClick: () => setProfileGlossary({ open: true }),
						"aria-label": "Open glossary",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "book" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 130
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 124
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("strong", { children: "Glossary" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 162
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 157
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "dash-main",
				children: content
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(GlossaryDrawer, {
				open: profileGlossary.open,
				initialTerm: profileGlossary.term,
				onClose: () => setProfileGlossary({ open: false })
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			toast && /* @__PURE__ */ _jsxDEV("div", {
				className: `app-toast ${toast.error ? "error" : ""}`,
				role: "status",
				children: toast.message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
}
_s(DashboardPage, "FprasgWbb+telaX3xcdcSHcajfU=");
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsWUFBWTtBQUNyQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLG1CQUFtQixrQkFBa0IseUJBQXlCO0FBRXZFLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsV0FBVztBQUNwQixTQUFTLHFCQUFxQjs7OztBQUc5QixPQUFPLFNBQVMsY0FBYyxFQUFFLE1BQU0sVUFBVSxRQUFRLFVBQVUsV0FBeUk7O0NBQ3pNLE1BQU0sYUFBYSxPQUFPLFNBQVMsWUFBWSxLQUFLLFNBQVMsSUFBSSxPQUFPLE9BQU8sU0FBUyxZQUFZO0NBQ3BHLE1BQU0sQ0FBQyxPQUFPLFlBQVksZUFBZSxpQkFBaUIsT0FBTyxDQUFDO0NBQ2xFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBc0QsSUFBSTtDQUNwRixNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUEyQyxFQUFFLE1BQU0sTUFBTSxDQUFDO0NBQ3hHLE1BQU0sVUFBVSxTQUF1QjtFQUNyQyxJQUFJO0dBQ0Ysa0JBQWtCLElBQUk7R0FDdEIsU0FBUyxJQUFJO0dBQ2IsT0FBTztFQUNULFFBQVE7R0FDTixTQUFTO0lBQUUsU0FBUztJQUFtRixPQUFPO0dBQUssQ0FBQztHQUNwSCxPQUFPO0VBQ1Q7Q0FDRjtDQUNBLE1BQU0sYUFBYSxTQUFpQixRQUFRLFVBQVU7RUFDcEQsU0FBUztHQUFFO0dBQVM7RUFBTSxDQUFDO0VBQzNCLE9BQU8saUJBQWlCLFNBQVMsSUFBSSxHQUFHLElBQUk7Q0FDOUM7Q0FDQSxNQUFNLGlCQUFpQixJQUFJLEtBQUssR0FBRyxNQUFNLFVBQVUsVUFBVSxVQUFVO0NBQ3ZFLE1BQU0sZUFBZSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksTUFBTSxVQUFVLFFBQVEsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLGVBQWUsUUFBUSxLQUFLLEtBQVUsSUFBSSxDQUFDLENBQUM7Q0FFdkksTUFBTSxTQUFTLFlBQVk7RUFDekIsSUFBSTtHQUNGLE1BQU0sSUFBSSxPQUFPO0VBQ25CLFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSx5REFBeUQsR0FBRztFQUM1RTtFQUNBLGtCQUFrQjtFQUNsQixTQUFTO0NBQ1g7Q0FFQSxJQUFJLFdBQVcsV0FBVyxXQUFXLEdBQUc7RUFDdEMsTUFBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLFNBQVMsS0FBSyxPQUFPLG1CQUFtQixXQUFXLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLEVBQUUsQ0FBQztFQUMzRyxPQUFPLFVBQVUsZ0RBQUUsd0JBQUMsZUFBRDtHQUF3QjtHQUFnQjtHQUFlO0dBQWtCO0dBQVUsT0FBTztFQUFZOzs7O1lBQUUsU0FBUyx3QkFBQyxPQUFEO0dBQUssV0FBVyxhQUFhLE1BQU0sUUFBUSxVQUFVO2FBQU8sTUFBTTtFQUFhOzs7O1VBQUk7Ozs7YUFBSSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFoQixDQUFpQyx3QkFBQyxZQUFEO0lBQVksT0FBTTtJQUFvQixNQUFLO0dBQW1EOzs7O2FBQUMsd0JBQUMsUUFBRDtJQUFRLGVBQWUsU0FBUyxXQUFXO2NBQUc7R0FBd0I7Ozs7V0FBTzs7Ozs7O0NBQzFhO0NBQ0EsTUFBTSxVQUFVLGVBQWUsY0FBYyx3QkFBQyxjQUFEO0VBQXFCO0VBQWU7RUFBa0I7RUFBVSxPQUFPO0NBQVk7Ozs7WUFDNUgsZUFBZSxjQUFjLHdCQUFDLGNBQUQ7RUFBcUI7RUFBZTtFQUFRLE9BQU87Q0FBWTs7OztZQUMxRixlQUFlLGNBQWMsd0JBQUMsY0FBRDtFQUFxQjtFQUFlO0VBQWtCO0VBQVUsT0FBTztDQUFZOzs7O1lBQzlHLGVBQWUsYUFBYSx3QkFBQyxhQUFEO0VBQW9CO0VBQWU7RUFBUSxPQUFPO0VBQVcsVUFBVTtFQUFRLGlCQUFpQixTQUFTLG1CQUFtQjtHQUFFLE1BQU07R0FBTTtFQUFLLENBQUM7Q0FBSTs7OztZQUM5Syx3QkFBQyxjQUFEO0VBQXFCO0VBQWlCO0NBQVc7Ozs7O0NBQzNELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQjtLQUNFLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQVEsU0FBUztnQkFBbkMsQ0FBMkMsd0JBQUMsVUFBRCxDQUFXOzs7O2dCQUFDLFVBQWdCOzs7Ozs7S0FDdkUsd0JBQUMsT0FBRDtNQUFLLGNBQVc7Z0JBQXdCLFVBQVUsS0FBSyxTQUFTLHdCQUFDLFVBQUQ7T0FBd0IsV0FBVyxlQUFlLEtBQUssT0FBTyxXQUFXO09BQUksZUFBZSxTQUFTLEtBQUssSUFBSTtpQkFBOUcsQ0FBaUgsd0JBQUMsTUFBRCxFQUFNLE1BQU0sS0FBSyxLQUFPOzs7O2lCQUFDLHdCQUFDLFFBQUQsWUFBTyxLQUFLLE1BQVk7Ozs7ZUFBUztTQUE5SixLQUFLOzs7O2FBQXlKLENBQUM7S0FBTzs7Ozs7S0FDblAsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBZ0Msd0JBQUMsU0FBRCxhQUFRLE1BQU0sVUFBVSxRQUFPLGdCQUFxQjs7Ozs7T0FBQyx3QkFBQyxVQUFELGFBQVEsUUFBSyxZQUFxQjs7Ozs7T0FBQyx3QkFBQyxPQUFELFlBQUssd0JBQUMsS0FBRCxFQUFHLE9BQU8sRUFBRSxPQUFPLEdBQUksZUFBZSxNQUFNLFVBQVUsU0FBVSxJQUFJLEdBQUcsRUFBSTs7OztnQkFBTTs7Ozs7T0FBQyx3QkFBQyxRQUFELGFBQU8sS0FBSyxJQUFJLEdBQUcsTUFBTSxVQUFVLFNBQVMsWUFBWSxHQUFFLGFBQWlCOzs7OztNQUFNOzs7Ozs7S0FDaFMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBbUIsZUFBZSxtQkFBbUIsRUFBRSxNQUFNLEtBQUssQ0FBQztNQUFHLGNBQVc7Z0JBQW5HLENBQW1ILHdCQUFDLFFBQUQsWUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O2VBQU87Ozs7Z0JBQUMsd0JBQUMsT0FBRCxZQUFLLHdCQUFDLFVBQUQsWUFBUSxXQUFnQjs7OztlQUFNOzs7O2NBQVM7Ozs7OztJQUMzTDs7Ozs7O0dBQ1Asd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBYTtHQUFpQjs7Ozs7R0FDakQsd0JBQUMsZ0JBQUQ7SUFBZ0IsTUFBTSxnQkFBZ0I7SUFBTSxhQUFhLGdCQUFnQjtJQUFNLGVBQWUsbUJBQW1CLEVBQUUsTUFBTSxNQUFNLENBQUM7R0FBSTs7Ozs7R0FDbkksU0FBUyx3QkFBQyxPQUFEO0lBQUssV0FBVyxhQUFhLE1BQU0sUUFBUSxVQUFVO0lBQU0sTUFBSztjQUFVLE1BQU07R0FBYTs7Ozs7RUFDbkc7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRW1wdHlTdGF0ZVwiO1xyXG5pbXBvcnQgeyBHbG9zc2FyeURyYXdlciB9IGZyb20gXCIuLi9jb21wb25lbnRzL0dsb3NzYXJ5RHJhd2VyXCI7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9JY29uXCI7XHJcbmltcG9ydCB7IExvZ29NYXJrIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvTG9nb01hcmtcIjtcclxuaW1wb3J0IHsgbWVtYmVyTmF2IH0gZnJvbSBcIi4uL2RhdGEvbmF2XCI7XHJcbmltcG9ydCB7IGNsZWFyRml0bmVzc1N0b3JlLCByZWFkRml0bmVzc1N0b3JlLCB3cml0ZUZpdG5lc3NTdG9yZSB9IGZyb20gXCIuLi9maXRuZXNzU3RvcmVcIjtcclxuaW1wb3J0IHR5cGUgeyBGaXRuZXNzU3RvcmUgfSBmcm9tIFwiLi4vZml0bmVzc1N0b3JlXCI7XHJcbmltcG9ydCB7IEdlbmVyYXRlUGFnZSB9IGZyb20gXCIuL0dlbmVyYXRlUGFnZVwiO1xyXG5pbXBvcnQgeyBPdmVydmlld1BhZ2UgfSBmcm9tIFwiLi9PdmVydmlld1BhZ2VcIjtcclxuaW1wb3J0IHsgUHJvZmlsZVBhZ2UgfSBmcm9tIFwiLi9Qcm9maWxlUGFnZVwiO1xyXG5pbXBvcnQgeyBQcm9ncmVzc1BhZ2UgfSBmcm9tIFwiLi9Qcm9ncmVzc1BhZ2VcIjtcclxuaW1wb3J0IHsgV29ya291dHNQYWdlIH0gZnJvbSBcIi4vV29ya291dHNQYWdlXCI7XHJcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGlcIjtcclxuaW1wb3J0IHsgU2Vzc2lvblBsYXllciB9IGZyb20gXCIuLi9zZXNzaW9uL1Nlc3Npb25QbGF5ZXJcIjtcclxuaW1wb3J0IHR5cGUgeyBTaWdudXBBbnN3ZXJzIH0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkUGFnZSh7IHBhdGgsIG5hdmlnYXRlLCBvbkhvbWUsIG9uTG9nb3V0LCBwcm9maWxlIH06IHsgcGF0aD86IHN0cmluZzsgbmF2aWdhdGU6IChwYXRoOiBzdHJpbmcpID0+IHZvaWQ7IG9uSG9tZTogKCkgPT4gdm9pZDsgb25Mb2dvdXQ6ICgpID0+IHZvaWQ7IHByb2ZpbGU6IFNpZ251cEFuc3dlcnMgfCBudWxsIH0pIHtcclxuICBjb25zdCBhY3RpdmVQYXRoID0gdHlwZW9mIHBhdGggPT09IFwic3RyaW5nXCIgJiYgcGF0aC5sZW5ndGggPiAwID8gcGF0aCA6IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSB8fCBcIi9kYXNoYm9hcmRcIjtcclxuICBjb25zdCBbc3RvcmUsIHNldFN0b3JlXSA9IHVzZVN0YXRlKCgpID0+IHJlYWRGaXRuZXNzU3RvcmUocHJvZmlsZSkpO1xyXG4gIGNvbnN0IFt0b2FzdCwgc2V0VG9hc3RdID0gdXNlU3RhdGU8eyBtZXNzYWdlOiBzdHJpbmc7IGVycm9yPzogYm9vbGVhbiB9IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3Byb2ZpbGVHbG9zc2FyeSwgc2V0UHJvZmlsZUdsb3NzYXJ5XSA9IHVzZVN0YXRlPHsgb3BlbjogYm9vbGVhbjsgdGVybT86IHN0cmluZyB9Pih7IG9wZW46IGZhbHNlIH0pO1xyXG4gIGNvbnN0IHVwZGF0ZSA9IChuZXh0OiBGaXRuZXNzU3RvcmUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHdyaXRlRml0bmVzc1N0b3JlKG5leHQpO1xyXG4gICAgICBzZXRTdG9yZShuZXh0KTtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgc2V0VG9hc3QoeyBtZXNzYWdlOiBcIldlIGNvdWxkbid0IHNhdmUgdGhhdCBjaGFuZ2UuIFRyeSBhIHNtYWxsZXIgaW1hZ2Ugb3IgZnJlZSBzb21lIGJyb3dzZXIgc3RvcmFnZS5cIiwgZXJyb3I6IHRydWUgfSk7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IHNob3dUb2FzdCA9IChtZXNzYWdlOiBzdHJpbmcsIGVycm9yID0gZmFsc2UpID0+IHtcclxuICAgIHNldFRvYXN0KHsgbWVzc2FnZSwgZXJyb3IgfSk7XHJcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRUb2FzdChudWxsKSwgMzIwMCk7XHJcbiAgfTtcclxuICBjb25zdCBjaGFsbGVuZ2VTdGFydCA9IG5ldyBEYXRlKGAke3N0b3JlLmNoYWxsZW5nZS5zdGFydERhdGV9VDEyOjAwOjAwYCk7XHJcbiAgY29uc3QgY2hhbGxlbmdlRGF5ID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCwgTWF0aC5mbG9vcigoRGF0ZS5ub3coKSAtIGNoYWxsZW5nZVN0YXJ0LmdldFRpbWUoKSkgLyA4Nl80MDBfMDAwKSArIDEpKTtcclxuICBcclxuICBjb25zdCBsb2dvdXQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkubG9nb3V0KCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkJhY2tlbmQgbG9nb3V0IGZhaWxlZCwgY2xlYXJpbmcgbG9jYWwgc2Vzc2lvbiBhbnl3YXk6XCIsIGVycik7XHJcbiAgICB9XHJcbiAgICBjbGVhckZpdG5lc3NTdG9yZSgpO1xyXG4gICAgb25Mb2dvdXQoKTtcclxuICB9O1xyXG5cclxuICBpZiAoYWN0aXZlUGF0aC5zdGFydHNXaXRoKFwiL3Nlc3Npb24vXCIpKSB7XHJcbiAgICBjb25zdCB3b3Jrb3V0ID0gc3RvcmUucGxhbi5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBkZWNvZGVVUklDb21wb25lbnQoYWN0aXZlUGF0aC5zcGxpdChcIi9cIikucG9wKCkgfHwgXCJcIikpO1xyXG4gICAgcmV0dXJuIHdvcmtvdXQgPyA8PjxTZXNzaW9uUGxheWVyIHdvcmtvdXQ9e3dvcmtvdXR9IHN0b3JlPXtzdG9yZX0gdXBkYXRlPXt1cGRhdGV9IG5hdmlnYXRlPXtuYXZpZ2F0ZX0gdG9hc3Q9e3Nob3dUb2FzdH0gLz57dG9hc3QgJiYgPGRpdiBjbGFzc05hbWU9e2BhcHAtdG9hc3QgJHt0b2FzdC5lcnJvciA/IFwiZXJyb3JcIiA6IFwiXCJ9YH0+e3RvYXN0Lm1lc3NhZ2V9PC9kaXY+fTwvPiA6IDxtYWluIGNsYXNzTmFtZT1cInNlc3Npb24tcGxheWVyXCI+PEVtcHR5U3RhdGUgdGl0bGU9XCJXb3Jrb3V0IG5vdCBmb3VuZFwiIGNvcHk9XCJSZXR1cm4gdG8geW91ciBwbGFuIGFuZCBjaG9vc2UgYW5vdGhlciB3b3Jrb3V0LlwiIC8+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi93b3Jrb3V0c1wiKX0+QmFjayB0byB3b3Jrb3V0czwvQnV0dG9uPjwvbWFpbj47XHJcbiAgfVxyXG4gIGNvbnN0IGNvbnRlbnQgPSBhY3RpdmVQYXRoID09PSBcIi93b3Jrb3V0c1wiID8gPFdvcmtvdXRzUGFnZSBzdG9yZT17c3RvcmV9IHVwZGF0ZT17dXBkYXRlfSBuYXZpZ2F0ZT17bmF2aWdhdGV9IHRvYXN0PXtzaG93VG9hc3R9IC8+XHJcbiAgICA6IGFjdGl2ZVBhdGggPT09IFwiL3Byb2dyZXNzXCIgPyA8UHJvZ3Jlc3NQYWdlIHN0b3JlPXtzdG9yZX0gdXBkYXRlPXt1cGRhdGV9IHRvYXN0PXtzaG93VG9hc3R9IC8+XHJcbiAgICAgIDogYWN0aXZlUGF0aCA9PT0gXCIvZ2VuZXJhdGVcIiA/IDxHZW5lcmF0ZVBhZ2Ugc3RvcmU9e3N0b3JlfSB1cGRhdGU9e3VwZGF0ZX0gbmF2aWdhdGU9e25hdmlnYXRlfSB0b2FzdD17c2hvd1RvYXN0fSAvPlxyXG4gICAgICAgIDogYWN0aXZlUGF0aCA9PT0gXCIvcHJvZmlsZVwiID8gPFByb2ZpbGVQYWdlIHN0b3JlPXtzdG9yZX0gdXBkYXRlPXt1cGRhdGV9IHRvYXN0PXtzaG93VG9hc3R9IG9uTG9nb3V0PXtsb2dvdXR9IG9uT3Blbkdsb3NzYXJ5PXsodGVybSkgPT4gc2V0UHJvZmlsZUdsb3NzYXJ5KHsgb3BlbjogdHJ1ZSwgdGVybSB9KX0gLz5cclxuICAgICAgICAgIDogPE92ZXJ2aWV3UGFnZSBzdG9yZT17c3RvcmV9IG5hdmlnYXRlPXtuYXZpZ2F0ZX0gLz47XHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cImRhc2hib2FyZC1wYWdlXCI+XHJcbiAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJkYXNoLXNpZGViYXJcIj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJyYW5kXCIgb25DbGljaz17b25Ib21lfT48TG9nb01hcmsgLz5Tb2ZlckZpdDwvYnV0dG9uPlxyXG4gICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIkRhc2hib2FyZCBuYXZpZ2F0aW9uXCI+e21lbWJlck5hdi5tYXAoKGl0ZW0pID0+IDxidXR0b24ga2V5PXtpdGVtLnBhdGh9IGNsYXNzTmFtZT17YWN0aXZlUGF0aCA9PT0gaXRlbS5wYXRoID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGl0ZW0ucGF0aCl9PjxJY29uIG5hbWU9e2l0ZW0uaWNvbn0gLz48c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+PC9idXR0b24+KX08L25hdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYWxsZW5nZS1taW5pXCI+PHNtYWxsPntzdG9yZS5jaGFsbGVuZ2UubGVuZ3RofS1EQVkgQ0hBTExFTkdFPC9zbWFsbD48c3Ryb25nPkRheSB7Y2hhbGxlbmdlRGF5fTwvc3Ryb25nPjxkaXY+PGkgc3R5bGU9e3sgd2lkdGg6IGAkeyhjaGFsbGVuZ2VEYXkgLyBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoKSAqIDEwMH0lYCB9fSAvPjwvZGl2PjxzcGFuPntNYXRoLm1heCgwLCBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoIC0gY2hhbGxlbmdlRGF5KX0gZGF5cyB0byBnbzwvc3Bhbj48L2Rpdj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNpZGViYXItZ2xvc3NhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRQcm9maWxlR2xvc3NhcnkoeyBvcGVuOiB0cnVlIH0pfSBhcmlhLWxhYmVsPVwiT3BlbiBnbG9zc2FyeVwiPjxzcGFuPjxJY29uIG5hbWU9XCJib29rXCIgLz48L3NwYW4+PGRpdj48c3Ryb25nPkdsb3NzYXJ5PC9zdHJvbmc+PC9kaXY+PC9idXR0b24+XHJcbiAgICAgIDwvYXNpZGU+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImRhc2gtbWFpblwiPntjb250ZW50fTwvc2VjdGlvbj5cclxuICAgICAgPEdsb3NzYXJ5RHJhd2VyIG9wZW49e3Byb2ZpbGVHbG9zc2FyeS5vcGVufSBpbml0aWFsVGVybT17cHJvZmlsZUdsb3NzYXJ5LnRlcm19IG9uQ2xvc2U9eygpID0+IHNldFByb2ZpbGVHbG9zc2FyeSh7IG9wZW46IGZhbHNlIH0pfSAvPlxyXG4gICAgICB7dG9hc3QgJiYgPGRpdiBjbGFzc05hbWU9e2BhcHAtdG9hc3QgJHt0b2FzdC5lcnJvciA/IFwiZXJyb3JcIiA6IFwiXCJ9YH0gcm9sZT1cInN0YXR1c1wiPnt0b2FzdC5tZXNzYWdlfTwvZGl2Pn1cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59Il19