const STORE_KEY = "soferfit-fitness-store-v1";
const dayKey = (date) => {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
};
const workoutTemplates = [
	{
		name: "Full Body Conditioning",
		tags: ["Full body", "Conditioning"],
		exercises: [
			"Marching warm-up",
			"Air squats",
			"Incline push-ups",
			"Reverse lunges",
			"Plank shoulder taps",
			"Glute bridges",
			"Mountain climbers",
			"Dead bug"
		]
	},
	{
		name: "Walk-Run Intervals",
		tags: ["Cardio", "Run"],
		exercises: [
			"Brisk walk warm-up",
			"Easy run interval",
			"Recovery walk",
			"Steady run",
			"Recovery walk",
			"Fast finish",
			"Cool-down walk",
			"Calf stretch"
		]
	},
	{
		name: "Lower Body & Core",
		tags: ["Lower body", "Core"],
		exercises: [
			"Hip circles",
			"Tempo squats",
			"Reverse lunges",
			"Single-leg bridges",
			"Wall sit",
			"Forearm plank",
			"Bird dog",
			"Dead bug"
		]
	},
	{
		name: "HIIT Circuit",
		tags: ["HIIT", "Full body"],
		exercises: [
			"Jumping jacks",
			"Squat thrusts",
			"High knees",
			"Push-ups",
			"Skater steps",
			"Mountain climbers",
			"Plank jacks",
			"Breathing reset"
		]
	}
];
const recoveryTemplate = {
	name: "Active Recovery & Stretch",
	tags: ["Recovery", "Mobility"],
	exercises: [
		"Easy walk",
		"Cat-cow",
		"World's greatest stretch",
		"Hip flexor stretch",
		"Hamstring fold",
		"Thoracic rotation",
		"Child's pose",
		"Box breathing"
	]
};
function buildPlan(startDate, length, daysPerWeek, minutes) {
	const start = new Date(`${startDate}T12:00:00`);
	const result = [];
	let workoutIndex = 0;
	for (let offset = 0; offset < length; offset += 1) {
		const date = new Date(start);
		date.setDate(start.getDate() + offset);
		const weekday = (date.getDay() + 6) % 7;
		if (weekday < daysPerWeek) {
			const template = workoutTemplates[workoutIndex % workoutTemplates.length];
			result.push({
				id: `plan-${offset}`,
				date: dayKey(date),
				name: template.name,
				minutes,
				equipment: "Bodyweight / Home",
				targetTags: [...template.tags],
				exercises: template.exercises.map((name) => ({
					name,
					prescription: template.name.includes("Intervals") ? "3 minutes" : "40 sec · 20 sec rest"
				})),
				intensity: "Moderate",
				sets: 3
			});
			workoutIndex += 1;
		} else if (weekday === 5) {
			result.push({
				id: `recovery-${offset}`,
				date: dayKey(date),
				name: recoveryTemplate.name,
				minutes: Math.min(30, minutes),
				equipment: "Bodyweight / Home",
				targetTags: [...recoveryTemplate.tags],
				exercises: recoveryTemplate.exercises.map((name) => ({
					name,
					prescription: "45 sec · easy pace"
				})),
				optional: true,
				intensity: "Easy",
				sets: 2
			});
		}
	}
	return result;
}
export function createFitnessStore(profile = {}) {
	const startDate = profile.challengeStartDate?.slice(0, 10) || dayKey(new Date());
	const length = profile.challengeDays ?? 60;
	const daysPerWeek = profile.workoutDays ?? 4;
	const sessionMinutes = profile.sessionMinutes ?? 60;
	return {
		user: {
			username: profile.name || "SoferFit Member",
			email: profile.email || "",
			avatar: profile.avatarUrl || "",
			memberSince: dayKey(new Date()),
			age: profile.age || "",
			height: profile.height || "",
			weight: profile.weight || "",
			targetWeight: profile.targetWeight || "",
			somatotype: profile.somatotype || "",
			goal: profile.goal || "",
			experience: profile.experience || "",
			activityLevel: profile.activity || "",
			unitSystem: profile.unitSystem || "metric",
			equipment: profile.availableEquipment || "Bodyweight / Home Only",
			injuryFlag: Boolean(profile.hasCondition)
		},
		preferences: {
			workoutReminders: true,
			reminderTime: "18:00",
			streakReminders: true,
			weeklySummary: true
		},
		challenge: {
			startDate,
			length,
			daysPerWeek,
			sessionMinutes
		},
		plan: buildPlan(startDate, length, daysPerWeek, sessionMinutes),
		sessions: [],
		weights: [],
		photos: [],
		badges: [
			{
				id: "streak-3",
				name: "3-day streak",
				unlocked: false
			},
			{
				id: "streak-7",
				name: "7-day streak",
				unlocked: false
			},
			{
				id: "streak-14",
				name: "14-day streak",
				unlocked: false
			},
			{
				id: "streak-30",
				name: "30-day streak",
				unlocked: false
			},
			{
				id: "workout-1",
				name: "First workout",
				unlocked: false
			},
			{
				id: "workout-10",
				name: "10 workouts",
				unlocked: false
			},
			{
				id: "workout-25",
				name: "25 workouts",
				unlocked: false
			},
			{
				id: "workout-50",
				name: "50 workouts",
				unlocked: false
			},
			{
				id: "week-1",
				name: "Week 1 done",
				unlocked: false
			},
			{
				id: "halfway",
				name: "Halfway",
				unlocked: false
			},
			{
				id: "finish",
				name: "Finish line",
				unlocked: false
			},
			{
				id: "weight-1",
				name: "First weigh-in",
				unlocked: false
			},
			{
				id: "photo-1",
				name: "First photo",
				unlocked: false
			}
		],
		aiGenerations: {
			usedCount: 0,
			resetDate: dayKey(new Date(Date.now() + 7 * 864e5))
		}
	};
}
export function readFitnessStore(profile) {
	try {
		const saved = localStorage.getItem(STORE_KEY);
		if (saved) {
			const parsed = JSON.parse(saved);
			const defaults = createFitnessStore(profile ?? {});
			const savedBadges = new Map((parsed.badges ?? []).map((badge) => [badge.id, badge]));
			const canonicalExercises = [
				"Bodyweight squats",
				"Incline push-ups",
				"Glute bridges",
				"Reverse lunges",
				"Mountain climbers",
				"Plank",
				"Bird dog",
				"Step jacks"
			];
			return {
				...defaults,
				...parsed,
				user: {
					...defaults.user,
					...parsed.user
				},
				preferences: {
					...defaults.preferences,
					...parsed.preferences
				},
				challenge: {
					...defaults.challenge,
					...parsed.challenge
				},
				plan: (parsed.plan ?? defaults.plan).map((workout) => ({
					...workout,
					intensity: workout.intensity ?? (workout.name.includes("Recovery") ? "Easy" : "Moderate"),
					exercises: workout.exercises.map((exercise, index) => /variation/i.test(exercise.name) ? {
						...exercise,
						name: canonicalExercises[index % canonicalExercises.length]
					} : exercise)
				})),
				sessions: parsed.sessions ?? [],
				weights: parsed.weights ?? [],
				photos: parsed.photos ?? [],
				badges: defaults.badges.map((badge) => savedBadges.get(badge.id) ?? badge),
				aiGenerations: {
					...defaults.aiGenerations,
					...parsed.aiGenerations
				}
			};
		}
	} catch {}
	return createFitnessStore(profile ?? {});
}
export function writeFitnessStore(store) {
	localStorage.setItem(STORE_KEY, JSON.stringify(store));
}
export function clearFitnessStore() {
	localStorage.removeItem(STORE_KEY);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBd0ZBLE1BQU0sWUFBWTtBQUNsQixNQUFNLFVBQVUsU0FBZTtDQUM3QixNQUFNLE9BQU8sS0FBSyxZQUFZO0NBQzlCLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQ3pELE1BQU0sTUFBTSxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUNsRCxPQUFPLEdBQUcsS0FBSyxHQUFHLE1BQU0sR0FBRztBQUM3QjtBQUVBLE1BQU0sbUJBQW1CO0NBQ3ZCO0VBQ0UsTUFBTTtFQUNOLE1BQU0sQ0FBQyxhQUFhLGNBQWM7RUFDbEMsV0FBVztHQUFDO0dBQW9CO0dBQWM7R0FBb0I7R0FBa0I7R0FBdUI7R0FBaUI7R0FBcUI7RUFBVTtDQUM3SjtDQUNBO0VBQ0UsTUFBTTtFQUNOLE1BQU0sQ0FBQyxVQUFVLEtBQUs7RUFDdEIsV0FBVztHQUFDO0dBQXNCO0dBQXFCO0dBQWlCO0dBQWM7R0FBaUI7R0FBZTtHQUFrQjtFQUFjO0NBQ3hKO0NBQ0E7RUFDRSxNQUFNO0VBQ04sTUFBTSxDQUFDLGNBQWMsTUFBTTtFQUMzQixXQUFXO0dBQUM7R0FBZTtHQUFnQjtHQUFrQjtHQUFzQjtHQUFZO0dBQWlCO0dBQVk7RUFBVTtDQUN4STtDQUNBO0VBQ0UsTUFBTTtFQUNOLE1BQU0sQ0FBQyxRQUFRLFdBQVc7RUFDMUIsV0FBVztHQUFDO0dBQWlCO0dBQWlCO0dBQWM7R0FBWTtHQUFnQjtHQUFxQjtHQUFlO0VBQWlCO0NBQy9JO0FBQ0Y7QUFFQSxNQUFNLG1CQUFtQjtDQUN2QixNQUFNO0NBQ04sTUFBTSxDQUFDLFlBQVksVUFBVTtDQUM3QixXQUFXO0VBQUM7RUFBYTtFQUFXO0VBQTRCO0VBQXNCO0VBQWtCO0VBQXFCO0VBQWdCO0NBQWU7QUFDOUo7QUFFQSxTQUFTLFVBQVUsV0FBbUIsUUFBZ0IsYUFBcUIsU0FBbUM7Q0FDNUcsTUFBTSxRQUFRLElBQUksS0FBSyxHQUFHLFVBQVUsVUFBVTtDQUM5QyxNQUFNLFNBQTJCLENBQUM7Q0FDbEMsSUFBSSxlQUFlO0NBRW5CLEtBQUssSUFBSSxTQUFTLEdBQUcsU0FBUyxRQUFRLFVBQVUsR0FBRztFQUNqRCxNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUs7RUFDM0IsS0FBSyxRQUFRLE1BQU0sUUFBUSxJQUFJLE1BQU07RUFDckMsTUFBTSxXQUFXLEtBQUssT0FBTyxJQUFJLEtBQUs7RUFDdEMsSUFBSSxVQUFVLGFBQWE7R0FDekIsTUFBTSxXQUFXLGlCQUFpQixlQUFlLGlCQUFpQjtHQUNsRSxPQUFPLEtBQUs7SUFDVixJQUFJLFFBQVE7SUFDWixNQUFNLE9BQU8sSUFBSTtJQUNqQixNQUFNLFNBQVM7SUFDZjtJQUNBLFdBQVc7SUFDWCxZQUFZLENBQUMsR0FBRyxTQUFTLElBQUk7SUFDN0IsV0FBVyxTQUFTLFVBQVUsS0FBSyxVQUFVO0tBQUU7S0FBTSxjQUFjLFNBQVMsS0FBSyxTQUFTLFdBQVcsSUFBSSxjQUFjO0lBQXVCLEVBQUU7SUFDaEosV0FBVztJQUNYLE1BQU07R0FDUixDQUFDO0dBQ0QsZ0JBQWdCO0VBQ2xCLE9BQU8sSUFBSSxZQUFZLEdBQUc7R0FDeEIsT0FBTyxLQUFLO0lBQ1YsSUFBSSxZQUFZO0lBQ2hCLE1BQU0sT0FBTyxJQUFJO0lBQ2pCLE1BQU0saUJBQWlCO0lBQ3ZCLFNBQVMsS0FBSyxJQUFJLElBQUksT0FBTztJQUM3QixXQUFXO0lBQ1gsWUFBWSxDQUFDLEdBQUcsaUJBQWlCLElBQUk7SUFDckMsV0FBVyxpQkFBaUIsVUFBVSxLQUFLLFVBQVU7S0FBRTtLQUFNLGNBQWM7SUFBcUIsRUFBRTtJQUNsRyxVQUFVO0lBQ1YsV0FBVztJQUNYLE1BQU07R0FDUixDQUFDO0VBQ0g7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxtQkFBbUIsVUFBdUIsQ0FBQyxHQUFpQjtDQUMxRSxNQUFNLFlBQVksUUFBUSxvQkFBb0IsTUFBTSxHQUFHLEVBQUUsS0FBSyxPQUFPLElBQUksS0FBSyxDQUFDO0NBQy9FLE1BQU0sU0FBUyxRQUFRLGlCQUFpQjtDQUN4QyxNQUFNLGNBQWMsUUFBUSxlQUFlO0NBQzNDLE1BQU0saUJBQWlCLFFBQVEsa0JBQWtCO0NBQ2pELE9BQU87RUFDTCxNQUFNO0dBQ0osVUFBVSxRQUFRLFFBQVE7R0FDMUIsT0FBTyxRQUFRLFNBQVM7R0FDeEIsUUFBUSxRQUFRLGFBQWE7R0FDN0IsYUFBYSxPQUFPLElBQUksS0FBSyxDQUFDO0dBQzlCLEtBQUssUUFBUSxPQUFPO0dBQ3BCLFFBQVEsUUFBUSxVQUFVO0dBQzFCLFFBQVEsUUFBUSxVQUFVO0dBQzFCLGNBQWMsUUFBUSxnQkFBZ0I7R0FDdEMsWUFBWSxRQUFRLGNBQWM7R0FDbEMsTUFBTSxRQUFRLFFBQVE7R0FDdEIsWUFBWSxRQUFRLGNBQWM7R0FDbEMsZUFBZSxRQUFRLFlBQVk7R0FDbkMsWUFBWSxRQUFRLGNBQWM7R0FDbEMsV0FBVyxRQUFRLHNCQUFzQjtHQUN6QyxZQUFZLFFBQVEsUUFBUSxZQUFZO0VBQzFDO0VBQ0EsYUFBYTtHQUNYLGtCQUFrQjtHQUNsQixjQUFjO0dBQ2QsaUJBQWlCO0dBQ2pCLGVBQWU7RUFDakI7RUFDQSxXQUFXO0dBQUU7R0FBVztHQUFRO0dBQWE7RUFBZTtFQUM1RCxNQUFNLFVBQVUsV0FBVyxRQUFRLGFBQWEsY0FBYztFQUM5RCxVQUFVLENBQUM7RUFDWCxTQUFTLENBQUM7RUFDVixRQUFRLENBQUM7RUFDVCxRQUFRO0dBQ047SUFBRSxJQUFJO0lBQVksTUFBTTtJQUFnQixVQUFVO0dBQU07R0FDeEQ7SUFBRSxJQUFJO0lBQVksTUFBTTtJQUFnQixVQUFVO0dBQU07R0FDeEQ7SUFBRSxJQUFJO0lBQWEsTUFBTTtJQUFpQixVQUFVO0dBQU07R0FDMUQ7SUFBRSxJQUFJO0lBQWEsTUFBTTtJQUFpQixVQUFVO0dBQU07R0FDMUQ7SUFBRSxJQUFJO0lBQWEsTUFBTTtJQUFpQixVQUFVO0dBQU07R0FDMUQ7SUFBRSxJQUFJO0lBQWMsTUFBTTtJQUFlLFVBQVU7R0FBTTtHQUN6RDtJQUFFLElBQUk7SUFBYyxNQUFNO0lBQWUsVUFBVTtHQUFNO0dBQ3pEO0lBQUUsSUFBSTtJQUFjLE1BQU07SUFBZSxVQUFVO0dBQU07R0FDekQ7SUFBRSxJQUFJO0lBQVUsTUFBTTtJQUFlLFVBQVU7R0FBTTtHQUNyRDtJQUFFLElBQUk7SUFBVyxNQUFNO0lBQVcsVUFBVTtHQUFNO0dBQ2xEO0lBQUUsSUFBSTtJQUFVLE1BQU07SUFBZSxVQUFVO0dBQU07R0FDckQ7SUFBRSxJQUFJO0lBQVksTUFBTTtJQUFrQixVQUFVO0dBQU07R0FDMUQ7SUFBRSxJQUFJO0lBQVcsTUFBTTtJQUFlLFVBQVU7R0FBTTtFQUN4RDtFQUNBLGVBQWU7R0FBRSxXQUFXO0dBQUcsV0FBVyxPQUFPLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQVUsQ0FBQztFQUFFO0NBQzFGO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsaUJBQWlCLFNBQTRDO0NBQzNFLElBQUk7RUFDRixNQUFNLFFBQVEsYUFBYSxRQUFRLFNBQVM7RUFDNUMsSUFBSSxPQUFPO0dBQ1QsTUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLO0dBQy9CLE1BQU0sV0FBVyxtQkFBbUIsV0FBVyxDQUFDLENBQUM7R0FDakQsTUFBTSxjQUFjLElBQUksS0FBSyxPQUFPLFVBQVUsQ0FBQyxFQUFDLENBQUUsS0FBSyxVQUFVLENBQUMsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDO0dBQ25GLE1BQU0scUJBQXFCO0lBQUM7SUFBcUI7SUFBb0I7SUFBaUI7SUFBa0I7SUFBcUI7SUFBUztJQUFZO0dBQVk7R0FDOUosT0FBTztJQUNMLEdBQUc7SUFDSCxHQUFHO0lBQ0gsTUFBTTtLQUFFLEdBQUcsU0FBUztLQUFNLEdBQUcsT0FBTztJQUFLO0lBQ3pDLGFBQWE7S0FBRSxHQUFHLFNBQVM7S0FBYSxHQUFHLE9BQU87SUFBWTtJQUM5RCxXQUFXO0tBQUUsR0FBRyxTQUFTO0tBQVcsR0FBRyxPQUFPO0lBQVU7SUFDeEQsT0FBTyxPQUFPLFFBQVEsU0FBUyxLQUFJLENBQUUsS0FBSyxhQUFhO0tBQ3JELEdBQUc7S0FDSCxXQUFXLFFBQVEsY0FBYyxRQUFRLEtBQUssU0FBUyxVQUFVLElBQUksU0FBUztLQUM5RSxXQUFXLFFBQVEsVUFBVSxLQUFLLFVBQVUsVUFBVSxhQUFhLEtBQUssU0FBUyxJQUFJLElBQUk7TUFBRSxHQUFHO01BQVUsTUFBTSxtQkFBbUIsUUFBUSxtQkFBbUI7S0FBUSxJQUFJLFFBQVE7SUFDbEwsRUFBRTtJQUNGLFVBQVUsT0FBTyxZQUFZLENBQUM7SUFDOUIsU0FBUyxPQUFPLFdBQVcsQ0FBQztJQUM1QixRQUFRLE9BQU8sVUFBVSxDQUFDO0lBQzFCLFFBQVEsU0FBUyxPQUFPLEtBQUssVUFBVSxZQUFZLElBQUksTUFBTSxFQUFFLEtBQUssS0FBSztJQUN6RSxlQUFlO0tBQUUsR0FBRyxTQUFTO0tBQWUsR0FBRyxPQUFPO0lBQWM7R0FDdEU7RUFDRjtDQUNGLFFBQVEsQ0FFUjtDQUNBLE9BQU8sbUJBQW1CLFdBQVcsQ0FBQyxDQUFDO0FBQ3pDO0FBRUEsT0FBTyxTQUFTLGtCQUFrQixPQUFxQjtDQUNyRCxhQUFhLFFBQVEsV0FBVyxLQUFLLFVBQVUsS0FBSyxDQUFDO0FBQ3ZEO0FBRUEsT0FBTyxTQUFTLG9CQUFvQjtDQUNsQyxhQUFhLFdBQVcsU0FBUztBQUNuQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmaXRuZXNzU3RvcmUudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHR5cGUgRXhlcmNpc2UgPSB7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIHByZXNjcmlwdGlvbjogc3RyaW5nO1xyXG59O1xyXG5cclxuZXhwb3J0IHR5cGUgUGxhbm5lZFdvcmtvdXQgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxuICBkYXRlOiBzdHJpbmc7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIG1pbnV0ZXM6IG51bWJlcjtcclxuICBlcXVpcG1lbnQ6IHN0cmluZztcclxuICB0YXJnZXRUYWdzOiBzdHJpbmdbXTtcclxuICBleGVyY2lzZXM6IEV4ZXJjaXNlW107XHJcbiAgb3B0aW9uYWw/OiBib29sZWFuO1xyXG4gIGludGVuc2l0eT86IFwiRWFzeVwiIHwgXCJNb2RlcmF0ZVwiIHwgXCJIYXJkXCI7XHJcbiAgbG93SW1wYWN0PzogYm9vbGVhbjtcclxuICBzZXRzPzogbnVtYmVyO1xyXG59O1xyXG5cclxuZXhwb3J0IHR5cGUgRml0bmVzc1N0b3JlID0ge1xyXG4gIHVzZXI6IHtcclxuICAgIHVzZXJuYW1lOiBzdHJpbmc7XHJcbiAgICBlbWFpbDogc3RyaW5nO1xyXG4gICAgYXZhdGFyOiBzdHJpbmc7XHJcbiAgICBtZW1iZXJTaW5jZTogc3RyaW5nO1xyXG4gICAgYWdlOiBzdHJpbmc7XHJcbiAgICBoZWlnaHQ6IHN0cmluZztcclxuICAgIHdlaWdodDogc3RyaW5nO1xyXG4gICAgdGFyZ2V0V2VpZ2h0OiBzdHJpbmc7XHJcbiAgICBzb21hdG90eXBlOiBzdHJpbmc7XHJcbiAgICBnb2FsOiBzdHJpbmc7XHJcbiAgICBleHBlcmllbmNlOiBzdHJpbmc7XHJcbiAgICBhY3Rpdml0eUxldmVsOiBzdHJpbmc7XHJcbiAgICB1bml0U3lzdGVtOiBcIm1ldHJpY1wiIHwgXCJpbXBlcmlhbFwiO1xyXG4gICAgZXF1aXBtZW50OiBzdHJpbmc7XHJcbiAgICBpbmp1cnlGbGFnOiBib29sZWFuO1xyXG4gIH07XHJcbiAgcHJlZmVyZW5jZXM6IHtcclxuICAgIHdvcmtvdXRSZW1pbmRlcnM6IGJvb2xlYW47XHJcbiAgICByZW1pbmRlclRpbWU6IHN0cmluZztcclxuICAgIHN0cmVha1JlbWluZGVyczogYm9vbGVhbjtcclxuICAgIHdlZWtseVN1bW1hcnk6IGJvb2xlYW47XHJcbiAgfTtcclxuICBjaGFsbGVuZ2U6IHtcclxuICAgIHN0YXJ0RGF0ZTogc3RyaW5nO1xyXG4gICAgbGVuZ3RoOiA2MCB8IDkwO1xyXG4gICAgZGF5c1BlcldlZWs6IG51bWJlcjtcclxuICAgIHNlc3Npb25NaW51dGVzOiBudW1iZXI7XHJcbiAgfTtcclxuICBwbGFuOiBQbGFubmVkV29ya291dFtdO1xyXG4gIHNlc3Npb25zOiB7XHJcbiAgICB3b3Jrb3V0SWQ6IHN0cmluZztcclxuICAgIGRhdGU6IHN0cmluZztcclxuICAgIGR1cmF0aW9uOiBudW1iZXI7XHJcbiAgICBleGVyY2lzZXNEb25lOiBzdHJpbmdbXTtcclxuICAgIGVmZm9ydDogbnVtYmVyO1xyXG4gIH1bXTtcclxuICB3ZWlnaHRzOiB7XHJcbiAgICBkYXRlOiBzdHJpbmc7XHJcbiAgICB3ZWlnaHQ6IG51bWJlcjtcclxuICAgIG1lYXN1cmVtZW50cz86IHsgd2Fpc3Q/OiBudW1iZXI7IGNoZXN0PzogbnVtYmVyOyBoaXBzPzogbnVtYmVyIH07XHJcbiAgfVtdO1xyXG4gIHBob3RvczogeyBkYXRlOiBzdHJpbmc7IGltYWdlOiBzdHJpbmc7IGFuZ2xlPzogXCJGcm9udFwiIHwgXCJTaWRlXCIgfCBcIkJhY2tcIiB9W107XHJcbiAgYmFkZ2VzOiB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZzsgdW5sb2NrZWQ6IGJvb2xlYW47IGRhdGU/OiBzdHJpbmcgfVtdO1xyXG4gIGFpR2VuZXJhdGlvbnM6IHsgdXNlZENvdW50OiBudW1iZXI7IHJlc2V0RGF0ZTogc3RyaW5nIH07XHJcbn07XHJcblxyXG5leHBvcnQgdHlwZSBQcm9maWxlU2VlZCA9IHtcclxuICBuYW1lPzogc3RyaW5nO1xyXG4gIGVtYWlsPzogc3RyaW5nO1xyXG4gIGF2YXRhclVybD86IHN0cmluZztcclxuICBhZ2U/OiBzdHJpbmc7XHJcbiAgaGVpZ2h0Pzogc3RyaW5nO1xyXG4gIHdlaWdodD86IHN0cmluZztcclxuICB0YXJnZXRXZWlnaHQ/OiBzdHJpbmc7XHJcbiAgc29tYXRvdHlwZT86IHN0cmluZztcclxuICBnb2FsPzogc3RyaW5nO1xyXG4gIGV4cGVyaWVuY2U/OiBzdHJpbmc7XHJcbiAgYWN0aXZpdHk/OiBzdHJpbmc7XHJcbiAgdW5pdFN5c3RlbT86IFwibWV0cmljXCIgfCBcImltcGVyaWFsXCI7XHJcbiAgYXZhaWxhYmxlRXF1aXBtZW50Pzogc3RyaW5nO1xyXG4gIGhhc0NvbmRpdGlvbj86IGJvb2xlYW47XHJcbiAgY2hhbGxlbmdlU3RhcnREYXRlPzogc3RyaW5nO1xyXG4gIGNoYWxsZW5nZURheXM/OiA2MCB8IDkwIHwgbnVsbDtcclxuICB3b3Jrb3V0RGF5cz86IG51bWJlciB8IG51bGw7XHJcbiAgc2Vzc2lvbk1pbnV0ZXM/OiBudW1iZXIgfCBudWxsO1xyXG59O1xyXG5cclxuY29uc3QgU1RPUkVfS0VZID0gXCJzb2ZlcmZpdC1maXRuZXNzLXN0b3JlLXYxXCI7XHJcbmNvbnN0IGRheUtleSA9IChkYXRlOiBEYXRlKSA9PiB7XHJcbiAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICBjb25zdCBtb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgY29uc3QgZGF5ID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbn07XHJcblxyXG5jb25zdCB3b3Jrb3V0VGVtcGxhdGVzID0gW1xyXG4gIHtcclxuICAgIG5hbWU6IFwiRnVsbCBCb2R5IENvbmRpdGlvbmluZ1wiLFxyXG4gICAgdGFnczogW1wiRnVsbCBib2R5XCIsIFwiQ29uZGl0aW9uaW5nXCJdLFxyXG4gICAgZXhlcmNpc2VzOiBbXCJNYXJjaGluZyB3YXJtLXVwXCIsIFwiQWlyIHNxdWF0c1wiLCBcIkluY2xpbmUgcHVzaC11cHNcIiwgXCJSZXZlcnNlIGx1bmdlc1wiLCBcIlBsYW5rIHNob3VsZGVyIHRhcHNcIiwgXCJHbHV0ZSBicmlkZ2VzXCIsIFwiTW91bnRhaW4gY2xpbWJlcnNcIiwgXCJEZWFkIGJ1Z1wiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiV2Fsay1SdW4gSW50ZXJ2YWxzXCIsXHJcbiAgICB0YWdzOiBbXCJDYXJkaW9cIiwgXCJSdW5cIl0sXHJcbiAgICBleGVyY2lzZXM6IFtcIkJyaXNrIHdhbGsgd2FybS11cFwiLCBcIkVhc3kgcnVuIGludGVydmFsXCIsIFwiUmVjb3Zlcnkgd2Fsa1wiLCBcIlN0ZWFkeSBydW5cIiwgXCJSZWNvdmVyeSB3YWxrXCIsIFwiRmFzdCBmaW5pc2hcIiwgXCJDb29sLWRvd24gd2Fsa1wiLCBcIkNhbGYgc3RyZXRjaFwiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiTG93ZXIgQm9keSAmIENvcmVcIixcclxuICAgIHRhZ3M6IFtcIkxvd2VyIGJvZHlcIiwgXCJDb3JlXCJdLFxyXG4gICAgZXhlcmNpc2VzOiBbXCJIaXAgY2lyY2xlc1wiLCBcIlRlbXBvIHNxdWF0c1wiLCBcIlJldmVyc2UgbHVuZ2VzXCIsIFwiU2luZ2xlLWxlZyBicmlkZ2VzXCIsIFwiV2FsbCBzaXRcIiwgXCJGb3JlYXJtIHBsYW5rXCIsIFwiQmlyZCBkb2dcIiwgXCJEZWFkIGJ1Z1wiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiSElJVCBDaXJjdWl0XCIsXHJcbiAgICB0YWdzOiBbXCJISUlUXCIsIFwiRnVsbCBib2R5XCJdLFxyXG4gICAgZXhlcmNpc2VzOiBbXCJKdW1waW5nIGphY2tzXCIsIFwiU3F1YXQgdGhydXN0c1wiLCBcIkhpZ2gga25lZXNcIiwgXCJQdXNoLXVwc1wiLCBcIlNrYXRlciBzdGVwc1wiLCBcIk1vdW50YWluIGNsaW1iZXJzXCIsIFwiUGxhbmsgamFja3NcIiwgXCJCcmVhdGhpbmcgcmVzZXRcIl0sXHJcbiAgfSxcclxuXSBhcyBjb25zdDtcclxuXHJcbmNvbnN0IHJlY292ZXJ5VGVtcGxhdGUgPSB7XHJcbiAgbmFtZTogXCJBY3RpdmUgUmVjb3ZlcnkgJiBTdHJldGNoXCIsXHJcbiAgdGFnczogW1wiUmVjb3ZlcnlcIiwgXCJNb2JpbGl0eVwiXSxcclxuICBleGVyY2lzZXM6IFtcIkVhc3kgd2Fsa1wiLCBcIkNhdC1jb3dcIiwgXCJXb3JsZCdzIGdyZWF0ZXN0IHN0cmV0Y2hcIiwgXCJIaXAgZmxleG9yIHN0cmV0Y2hcIiwgXCJIYW1zdHJpbmcgZm9sZFwiLCBcIlRob3JhY2ljIHJvdGF0aW9uXCIsIFwiQ2hpbGQncyBwb3NlXCIsIFwiQm94IGJyZWF0aGluZ1wiXSxcclxufTtcclxuXHJcbmZ1bmN0aW9uIGJ1aWxkUGxhbihzdGFydERhdGU6IHN0cmluZywgbGVuZ3RoOiBudW1iZXIsIGRheXNQZXJXZWVrOiBudW1iZXIsIG1pbnV0ZXM6IG51bWJlcik6IFBsYW5uZWRXb3Jrb3V0W10ge1xyXG4gIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoYCR7c3RhcnREYXRlfVQxMjowMDowMGApO1xyXG4gIGNvbnN0IHJlc3VsdDogUGxhbm5lZFdvcmtvdXRbXSA9IFtdO1xyXG4gIGxldCB3b3Jrb3V0SW5kZXggPSAwO1xyXG5cclxuICBmb3IgKGxldCBvZmZzZXQgPSAwOyBvZmZzZXQgPCBsZW5ndGg7IG9mZnNldCArPSAxKSB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoc3RhcnQpO1xyXG4gICAgZGF0ZS5zZXREYXRlKHN0YXJ0LmdldERhdGUoKSArIG9mZnNldCk7XHJcbiAgICBjb25zdCB3ZWVrZGF5ID0gKGRhdGUuZ2V0RGF5KCkgKyA2KSAlIDc7XHJcbiAgICBpZiAod2Vla2RheSA8IGRheXNQZXJXZWVrKSB7XHJcbiAgICAgIGNvbnN0IHRlbXBsYXRlID0gd29ya291dFRlbXBsYXRlc1t3b3Jrb3V0SW5kZXggJSB3b3Jrb3V0VGVtcGxhdGVzLmxlbmd0aF07XHJcbiAgICAgIHJlc3VsdC5wdXNoKHtcclxuICAgICAgICBpZDogYHBsYW4tJHtvZmZzZXR9YCxcclxuICAgICAgICBkYXRlOiBkYXlLZXkoZGF0ZSksXHJcbiAgICAgICAgbmFtZTogdGVtcGxhdGUubmFtZSxcclxuICAgICAgICBtaW51dGVzLFxyXG4gICAgICAgIGVxdWlwbWVudDogXCJCb2R5d2VpZ2h0IC8gSG9tZVwiLFxyXG4gICAgICAgIHRhcmdldFRhZ3M6IFsuLi50ZW1wbGF0ZS50YWdzXSxcclxuICAgICAgICBleGVyY2lzZXM6IHRlbXBsYXRlLmV4ZXJjaXNlcy5tYXAoKG5hbWUpID0+ICh7IG5hbWUsIHByZXNjcmlwdGlvbjogdGVtcGxhdGUubmFtZS5pbmNsdWRlcyhcIkludGVydmFsc1wiKSA/IFwiMyBtaW51dGVzXCIgOiBcIjQwIHNlYyDCtyAyMCBzZWMgcmVzdFwiIH0pKSxcclxuICAgICAgICBpbnRlbnNpdHk6IFwiTW9kZXJhdGVcIixcclxuICAgICAgICBzZXRzOiAzLFxyXG4gICAgICB9KTtcclxuICAgICAgd29ya291dEluZGV4ICs9IDE7XHJcbiAgICB9IGVsc2UgaWYgKHdlZWtkYXkgPT09IDUpIHtcclxuICAgICAgcmVzdWx0LnB1c2goe1xyXG4gICAgICAgIGlkOiBgcmVjb3ZlcnktJHtvZmZzZXR9YCxcclxuICAgICAgICBkYXRlOiBkYXlLZXkoZGF0ZSksXHJcbiAgICAgICAgbmFtZTogcmVjb3ZlcnlUZW1wbGF0ZS5uYW1lLFxyXG4gICAgICAgIG1pbnV0ZXM6IE1hdGgubWluKDMwLCBtaW51dGVzKSxcclxuICAgICAgICBlcXVpcG1lbnQ6IFwiQm9keXdlaWdodCAvIEhvbWVcIixcclxuICAgICAgICB0YXJnZXRUYWdzOiBbLi4ucmVjb3ZlcnlUZW1wbGF0ZS50YWdzXSxcclxuICAgICAgICBleGVyY2lzZXM6IHJlY292ZXJ5VGVtcGxhdGUuZXhlcmNpc2VzLm1hcCgobmFtZSkgPT4gKHsgbmFtZSwgcHJlc2NyaXB0aW9uOiBcIjQ1IHNlYyDCtyBlYXN5IHBhY2VcIiB9KSksXHJcbiAgICAgICAgb3B0aW9uYWw6IHRydWUsXHJcbiAgICAgICAgaW50ZW5zaXR5OiBcIkVhc3lcIixcclxuICAgICAgICBzZXRzOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHJlc3VsdDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUZpdG5lc3NTdG9yZShwcm9maWxlOiBQcm9maWxlU2VlZCA9IHt9KTogRml0bmVzc1N0b3JlIHtcclxuICBjb25zdCBzdGFydERhdGUgPSBwcm9maWxlLmNoYWxsZW5nZVN0YXJ0RGF0ZT8uc2xpY2UoMCwgMTApIHx8IGRheUtleShuZXcgRGF0ZSgpKTtcclxuICBjb25zdCBsZW5ndGggPSBwcm9maWxlLmNoYWxsZW5nZURheXMgPz8gNjA7XHJcbiAgY29uc3QgZGF5c1BlcldlZWsgPSBwcm9maWxlLndvcmtvdXREYXlzID8/IDQ7XHJcbiAgY29uc3Qgc2Vzc2lvbk1pbnV0ZXMgPSBwcm9maWxlLnNlc3Npb25NaW51dGVzID8/IDYwO1xyXG4gIHJldHVybiB7XHJcbiAgICB1c2VyOiB7XHJcbiAgICAgIHVzZXJuYW1lOiBwcm9maWxlLm5hbWUgfHwgXCJTb2ZlckZpdCBNZW1iZXJcIixcclxuICAgICAgZW1haWw6IHByb2ZpbGUuZW1haWwgfHwgXCJcIixcclxuICAgICAgYXZhdGFyOiBwcm9maWxlLmF2YXRhclVybCB8fCBcIlwiLFxyXG4gICAgICBtZW1iZXJTaW5jZTogZGF5S2V5KG5ldyBEYXRlKCkpLFxyXG4gICAgICBhZ2U6IHByb2ZpbGUuYWdlIHx8IFwiXCIsXHJcbiAgICAgIGhlaWdodDogcHJvZmlsZS5oZWlnaHQgfHwgXCJcIixcclxuICAgICAgd2VpZ2h0OiBwcm9maWxlLndlaWdodCB8fCBcIlwiLFxyXG4gICAgICB0YXJnZXRXZWlnaHQ6IHByb2ZpbGUudGFyZ2V0V2VpZ2h0IHx8IFwiXCIsXHJcbiAgICAgIHNvbWF0b3R5cGU6IHByb2ZpbGUuc29tYXRvdHlwZSB8fCBcIlwiLFxyXG4gICAgICBnb2FsOiBwcm9maWxlLmdvYWwgfHwgXCJcIixcclxuICAgICAgZXhwZXJpZW5jZTogcHJvZmlsZS5leHBlcmllbmNlIHx8IFwiXCIsXHJcbiAgICAgIGFjdGl2aXR5TGV2ZWw6IHByb2ZpbGUuYWN0aXZpdHkgfHwgXCJcIixcclxuICAgICAgdW5pdFN5c3RlbTogcHJvZmlsZS51bml0U3lzdGVtIHx8IFwibWV0cmljXCIsXHJcbiAgICAgIGVxdWlwbWVudDogcHJvZmlsZS5hdmFpbGFibGVFcXVpcG1lbnQgfHwgXCJCb2R5d2VpZ2h0IC8gSG9tZSBPbmx5XCIsXHJcbiAgICAgIGluanVyeUZsYWc6IEJvb2xlYW4ocHJvZmlsZS5oYXNDb25kaXRpb24pLFxyXG4gICAgfSxcclxuICAgIHByZWZlcmVuY2VzOiB7XHJcbiAgICAgIHdvcmtvdXRSZW1pbmRlcnM6IHRydWUsXHJcbiAgICAgIHJlbWluZGVyVGltZTogXCIxODowMFwiLFxyXG4gICAgICBzdHJlYWtSZW1pbmRlcnM6IHRydWUsXHJcbiAgICAgIHdlZWtseVN1bW1hcnk6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgY2hhbGxlbmdlOiB7IHN0YXJ0RGF0ZSwgbGVuZ3RoLCBkYXlzUGVyV2Vlaywgc2Vzc2lvbk1pbnV0ZXMgfSxcclxuICAgIHBsYW46IGJ1aWxkUGxhbihzdGFydERhdGUsIGxlbmd0aCwgZGF5c1BlcldlZWssIHNlc3Npb25NaW51dGVzKSxcclxuICAgIHNlc3Npb25zOiBbXSxcclxuICAgIHdlaWdodHM6IFtdLFxyXG4gICAgcGhvdG9zOiBbXSxcclxuICAgIGJhZGdlczogW1xyXG4gICAgICB7IGlkOiBcInN0cmVhay0zXCIsIG5hbWU6IFwiMy1kYXkgc3RyZWFrXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcInN0cmVhay03XCIsIG5hbWU6IFwiNy1kYXkgc3RyZWFrXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcInN0cmVhay0xNFwiLCBuYW1lOiBcIjE0LWRheSBzdHJlYWtcIiwgdW5sb2NrZWQ6IGZhbHNlIH0sXHJcbiAgICAgIHsgaWQ6IFwic3RyZWFrLTMwXCIsIG5hbWU6IFwiMzAtZGF5IHN0cmVha1wiLCB1bmxvY2tlZDogZmFsc2UgfSxcclxuICAgICAgeyBpZDogXCJ3b3Jrb3V0LTFcIiwgbmFtZTogXCJGaXJzdCB3b3Jrb3V0XCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcIndvcmtvdXQtMTBcIiwgbmFtZTogXCIxMCB3b3Jrb3V0c1wiLCB1bmxvY2tlZDogZmFsc2UgfSxcclxuICAgICAgeyBpZDogXCJ3b3Jrb3V0LTI1XCIsIG5hbWU6IFwiMjUgd29ya291dHNcIiwgdW5sb2NrZWQ6IGZhbHNlIH0sXHJcbiAgICAgIHsgaWQ6IFwid29ya291dC01MFwiLCBuYW1lOiBcIjUwIHdvcmtvdXRzXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcIndlZWstMVwiLCBuYW1lOiBcIldlZWsgMSBkb25lXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcImhhbGZ3YXlcIiwgbmFtZTogXCJIYWxmd2F5XCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcImZpbmlzaFwiLCBuYW1lOiBcIkZpbmlzaCBsaW5lXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgICB7IGlkOiBcIndlaWdodC0xXCIsIG5hbWU6IFwiRmlyc3Qgd2VpZ2gtaW5cIiwgdW5sb2NrZWQ6IGZhbHNlIH0sXHJcbiAgICAgIHsgaWQ6IFwicGhvdG8tMVwiLCBuYW1lOiBcIkZpcnN0IHBob3RvXCIsIHVubG9ja2VkOiBmYWxzZSB9LFxyXG4gICAgXSxcclxuICAgIGFpR2VuZXJhdGlvbnM6IHsgdXNlZENvdW50OiAwLCByZXNldERhdGU6IGRheUtleShuZXcgRGF0ZShEYXRlLm5vdygpICsgNyAqIDg2XzQwMF8wMDApKSB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZWFkRml0bmVzc1N0b3JlKHByb2ZpbGU/OiBQcm9maWxlU2VlZCB8IG51bGwpOiBGaXRuZXNzU3RvcmUge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JFX0tFWSk7XHJcbiAgICBpZiAoc2F2ZWQpIHtcclxuICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShzYXZlZCkgYXMgRml0bmVzc1N0b3JlO1xyXG4gICAgICBjb25zdCBkZWZhdWx0cyA9IGNyZWF0ZUZpdG5lc3NTdG9yZShwcm9maWxlID8/IHt9KTtcclxuICAgICAgY29uc3Qgc2F2ZWRCYWRnZXMgPSBuZXcgTWFwKChwYXJzZWQuYmFkZ2VzID8/IFtdKS5tYXAoKGJhZGdlKSA9PiBbYmFkZ2UuaWQsIGJhZGdlXSkpO1xyXG4gICAgICBjb25zdCBjYW5vbmljYWxFeGVyY2lzZXMgPSBbXCJCb2R5d2VpZ2h0IHNxdWF0c1wiLCBcIkluY2xpbmUgcHVzaC11cHNcIiwgXCJHbHV0ZSBicmlkZ2VzXCIsIFwiUmV2ZXJzZSBsdW5nZXNcIiwgXCJNb3VudGFpbiBjbGltYmVyc1wiLCBcIlBsYW5rXCIsIFwiQmlyZCBkb2dcIiwgXCJTdGVwIGphY2tzXCJdO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLmRlZmF1bHRzLFxyXG4gICAgICAgIC4uLnBhcnNlZCxcclxuICAgICAgICB1c2VyOiB7IC4uLmRlZmF1bHRzLnVzZXIsIC4uLnBhcnNlZC51c2VyIH0sXHJcbiAgICAgICAgcHJlZmVyZW5jZXM6IHsgLi4uZGVmYXVsdHMucHJlZmVyZW5jZXMsIC4uLnBhcnNlZC5wcmVmZXJlbmNlcyB9LFxyXG4gICAgICAgIGNoYWxsZW5nZTogeyAuLi5kZWZhdWx0cy5jaGFsbGVuZ2UsIC4uLnBhcnNlZC5jaGFsbGVuZ2UgfSxcclxuICAgICAgICBwbGFuOiAocGFyc2VkLnBsYW4gPz8gZGVmYXVsdHMucGxhbikubWFwKCh3b3Jrb3V0KSA9PiAoe1xyXG4gICAgICAgICAgLi4ud29ya291dCxcclxuICAgICAgICAgIGludGVuc2l0eTogd29ya291dC5pbnRlbnNpdHkgPz8gKHdvcmtvdXQubmFtZS5pbmNsdWRlcyhcIlJlY292ZXJ5XCIpID8gXCJFYXN5XCIgOiBcIk1vZGVyYXRlXCIpLFxyXG4gICAgICAgICAgZXhlcmNpc2VzOiB3b3Jrb3V0LmV4ZXJjaXNlcy5tYXAoKGV4ZXJjaXNlLCBpbmRleCkgPT4gL3ZhcmlhdGlvbi9pLnRlc3QoZXhlcmNpc2UubmFtZSkgPyB7IC4uLmV4ZXJjaXNlLCBuYW1lOiBjYW5vbmljYWxFeGVyY2lzZXNbaW5kZXggJSBjYW5vbmljYWxFeGVyY2lzZXMubGVuZ3RoXSB9IDogZXhlcmNpc2UpLFxyXG4gICAgICAgIH0pKSxcclxuICAgICAgICBzZXNzaW9uczogcGFyc2VkLnNlc3Npb25zID8/IFtdLFxyXG4gICAgICAgIHdlaWdodHM6IHBhcnNlZC53ZWlnaHRzID8/IFtdLFxyXG4gICAgICAgIHBob3RvczogcGFyc2VkLnBob3RvcyA/PyBbXSxcclxuICAgICAgICBiYWRnZXM6IGRlZmF1bHRzLmJhZGdlcy5tYXAoKGJhZGdlKSA9PiBzYXZlZEJhZGdlcy5nZXQoYmFkZ2UuaWQpID8/IGJhZGdlKSxcclxuICAgICAgICBhaUdlbmVyYXRpb25zOiB7IC4uLmRlZmF1bHRzLmFpR2VuZXJhdGlvbnMsIC4uLnBhcnNlZC5haUdlbmVyYXRpb25zIH0sXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBBIGNsZWFuIHN0b3JlIGlzIHNhZmVyIHRoYW4gYmxvY2tpbmcgdGhlIG1lbWJlciBhcmVhIHdoZW4gc3RvcmFnZSBpcyB1bmF2YWlsYWJsZS5cclxuICB9XHJcbiAgcmV0dXJuIGNyZWF0ZUZpdG5lc3NTdG9yZShwcm9maWxlID8/IHt9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHdyaXRlRml0bmVzc1N0b3JlKHN0b3JlOiBGaXRuZXNzU3RvcmUpIHtcclxuICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SRV9LRVksIEpTT04uc3RyaW5naWZ5KHN0b3JlKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjbGVhckZpdG5lc3NTdG9yZSgpIHtcclxuICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShTVE9SRV9LRVkpO1xyXG59XHJcbiJdfQ==