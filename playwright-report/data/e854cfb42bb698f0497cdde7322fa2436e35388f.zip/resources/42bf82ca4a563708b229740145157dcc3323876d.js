import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/GlossaryDrawer.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { glossaryId, glossaryTerms } from "/src/frontend/data/glossary.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/GlossaryDrawer.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function GlossaryDrawer({ open, initialTerm, onClose }) {
	_s();
	const [query, setQuery] = useState("");
	const filteredTerms = glossaryTerms.filter(([term, definition]) => `${term} ${definition}`.toLowerCase().includes(query.toLowerCase()));
	useEffect(() => {
		if (!open) return;
		setQuery("");
		const closeOnEscape = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", closeOnEscape);
		if (initialTerm) {
			window.setTimeout(() => document.getElementById(glossaryId(initialTerm))?.scrollIntoView({ block: "center" }), 0);
		}
		return () => window.removeEventListener("keydown", closeOnEscape);
	}, [
		open,
		initialTerm,
		onClose
	]);
	if (!open) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "glossary-backdrop",
		onMouseDown: onClose,
		children: /* @__PURE__ */ _jsxDEV("aside", {
			className: "glossary-drawer",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Glossary",
			onMouseDown: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "glossary-head",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "eyebrow",
						children: " REFERENCE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 16
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Glossary" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 59
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "modal-close",
						onClick: onClose,
						"aria-label": "Close glossary",
						children: "×"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: "glossary-search",
					children: ["Search terms", /* @__PURE__ */ _jsxDEV("input", {
						type: "search",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Search glossary"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 56
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "glossary-list",
					children: filteredTerms.map(([term, definition]) => /* @__PURE__ */ _jsxDEV("article", {
						id: glossaryId(term),
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: term }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: definition }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 15
						}, this)]
					}, term, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(GlossaryDrawer, "sgX83U/BR0KSTaPy5VTgsJCXi0Q=");
_c = GlossaryDrawer;
var _c;
$RefreshReg$(_c, "GlossaryDrawer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/GlossaryDrawer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/GlossaryDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/GlossaryDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/GlossaryDrawer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLFlBQVkscUJBQXFCOzs7O0FBRTFDLE9BQU8sU0FBUyxlQUFlLEVBQUUsTUFBTSxhQUFhLFdBQXlFOztDQUMzSCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLGdCQUFnQixjQUFjLFFBQVEsQ0FBQyxNQUFNLGdCQUFnQixHQUFHLEtBQUssR0FBRyxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxZQUFZLENBQUMsQ0FBQztDQUV0SSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsTUFBTTtFQUNYLFNBQVMsRUFBRTtFQUNYLE1BQU0saUJBQWlCLFVBQXlCO0dBQzlDLElBQUksTUFBTSxRQUFRLFVBQVUsUUFBUTtFQUN0QztFQUNBLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxJQUFJLGFBQWE7R0FDZixPQUFPLGlCQUFpQixTQUFTLGVBQWUsV0FBVyxXQUFXLENBQUMsQ0FBQyxFQUFFLGVBQWUsRUFBRSxPQUFPLFNBQVMsQ0FBQyxHQUFHLENBQUM7RUFDbEg7RUFDQSxhQUFhLE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtDQUNsRSxHQUFHO0VBQUM7RUFBTTtFQUFhO0NBQU8sQ0FBQztDQUUvQixJQUFJLENBQUMsTUFBTSxPQUFPO0NBRWxCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBb0IsYUFBYTtZQUM5Qyx3QkFBQyxTQUFEO0dBQU8sV0FBVTtHQUFrQixNQUFLO0dBQVMsY0FBVztHQUFPLGNBQVc7R0FBVyxjQUFjLFVBQVUsTUFBTSxnQkFBZ0I7YUFBdkk7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFVO0tBQWdCOzs7O2VBQUMsd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7YUFBTTs7OztlQUN0RSx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFjLFNBQVM7TUFBUyxjQUFXO2dCQUFpQjtLQUFTOzs7O2FBQ3BGOzs7Ozs7SUFDTCx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUFtQyxnQkFBWSx3QkFBQyxTQUFEO01BQU8sTUFBSztNQUFTLE9BQU87TUFBTyxXQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSztNQUFHLGFBQVk7S0FBbUI7Ozs7YUFBUTs7Ozs7O0lBQzVLLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osY0FBYyxLQUFLLENBQUMsTUFBTSxnQkFDekIsd0JBQUMsV0FBRDtNQUFTLElBQUksV0FBVyxJQUFJO2dCQUE1QixDQUNFLHdCQUFDLFVBQUQsWUFBUyxLQUFhOzs7O2dCQUN0Qix3QkFBQyxLQUFELFlBQUksV0FBYzs7OztjQUNYO1FBSDJCOzs7O1lBRzNCLENBQ1Y7SUFDRTs7Ozs7R0FDQTs7Ozs7O0NBQ0o7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2xvc3NhcnlEcmF3ZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgZ2xvc3NhcnlJZCwgZ2xvc3NhcnlUZXJtcyB9IGZyb20gXCIuLi9kYXRhL2dsb3NzYXJ5XCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gR2xvc3NhcnlEcmF3ZXIoeyBvcGVuLCBpbml0aWFsVGVybSwgb25DbG9zZSB9OiB7IG9wZW46IGJvb2xlYW47IGluaXRpYWxUZXJtPzogc3RyaW5nOyBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCBbcXVlcnksIHNldFF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IGZpbHRlcmVkVGVybXMgPSBnbG9zc2FyeVRlcm1zLmZpbHRlcigoW3Rlcm0sIGRlZmluaXRpb25dKSA9PiBgJHt0ZXJtfSAke2RlZmluaXRpb259YC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5LnRvTG93ZXJDYXNlKCkpKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3BlbikgcmV0dXJuO1xyXG4gICAgc2V0UXVlcnkoXCJcIik7XHJcbiAgICBjb25zdCBjbG9zZU9uRXNjYXBlID0gKGV2ZW50OiBLZXlib2FyZEV2ZW50KSA9PiB7XHJcbiAgICAgIGlmIChldmVudC5rZXkgPT09IFwiRXNjYXBlXCIpIG9uQ2xvc2UoKTtcclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgY2xvc2VPbkVzY2FwZSk7XHJcbiAgICBpZiAoaW5pdGlhbFRlcm0pIHtcclxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoZ2xvc3NhcnlJZChpbml0aWFsVGVybSkpPy5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiBcImNlbnRlclwiIH0pLCAwKTtcclxuICAgIH1cclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgY2xvc2VPbkVzY2FwZSk7XHJcbiAgfSwgW29wZW4sIGluaXRpYWxUZXJtLCBvbkNsb3NlXSk7XHJcblxyXG4gIGlmICghb3BlbikgcmV0dXJuIG51bGw7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdsb3NzYXJ5LWJhY2tkcm9wXCIgb25Nb3VzZURvd249e29uQ2xvc2V9PlxyXG4gICAgICA8YXNpZGUgY2xhc3NOYW1lPVwiZ2xvc3NhcnktZHJhd2VyXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIkdsb3NzYXJ5XCIgb25Nb3VzZURvd249eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xvc3NhcnktaGVhZFwiPlxyXG4gICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+IFJFRkVSRU5DRTwvc3Bhbj48aDI+R2xvc3Nhcnk8L2gyPjwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJtb2RhbC1jbG9zZVwiIG9uQ2xpY2s9e29uQ2xvc2V9IGFyaWEtbGFiZWw9XCJDbG9zZSBnbG9zc2FyeVwiPsOXPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImdsb3NzYXJ5LXNlYXJjaFwiPlNlYXJjaCB0ZXJtczxpbnB1dCB0eXBlPVwic2VhcmNoXCIgdmFsdWU9e3F1ZXJ5fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRRdWVyeShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlNlYXJjaCBnbG9zc2FyeVwiIC8+PC9sYWJlbD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsb3NzYXJ5LWxpc3RcIj5cclxuICAgICAgICAgIHtmaWx0ZXJlZFRlcm1zLm1hcCgoW3Rlcm0sIGRlZmluaXRpb25dKSA9PiAoXHJcbiAgICAgICAgICAgIDxhcnRpY2xlIGlkPXtnbG9zc2FyeUlkKHRlcm0pfSBrZXk9e3Rlcm19PlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+e3Rlcm19PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgPHA+e2RlZmluaXRpb259PC9wPlxyXG4gICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9hc2lkZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19