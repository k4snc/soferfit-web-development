import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/modals/LoginModal.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { api } from "/src/frontend/services/api.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/LoginModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function LoginModal({ open, onClose, onSignup, onSuccess }) {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [showPassword, setShowPassword] = useState(false);
	const [errors, setErrors] = useState({});
	const [loading, setLoading] = useState(false);
	useEffect(() => {
		if (!open) return;
		const closeOnEscape = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", closeOnEscape);
		return () => window.removeEventListener("keydown", closeOnEscape);
	}, [open, onClose]);
	if (!open) return null;
	const submit = async () => {
		const nextErrors = {
			email: email.includes("@") ? undefined : "Enter a valid email",
			password: password ? undefined : "Password is required"
		};
		setErrors(nextErrors);
		if (nextErrors.email || nextErrors.password) return;
		setLoading(true);
		setErrors({});
		try {
			await api.login(email, password);
			onSuccess();
		} catch (err) {
			console.error("Login failed:", err);
			setErrors({ general: "Invalid email or password. Please check your credentials." });
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "modal-backdrop login-backdrop",
		onMouseDown: onClose,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "modal login-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Log in",
			onMouseDown: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					className: "modal-close",
					onClick: onClose,
					"aria-label": "Close login",
					children: "×"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", { children: "Welcome back" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				errors.general && /* @__PURE__ */ _jsxDEV("small", {
					className: "field-error",
					style: {
						display: "block",
						marginBottom: "1rem"
					},
					children: errors.general
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 28
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: errors.email ? "field-invalid" : "",
					children: [
						"Email",
						/* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							value: email,
							onChange: (event) => {
								setEmail(event.target.value);
								setErrors((current) => ({
									...current,
									email: undefined
								}));
							},
							placeholder: "you@example.com",
							"aria-invalid": Boolean(errors.email)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this),
						errors.email && /* @__PURE__ */ _jsxDEV("small", {
							className: "field-error",
							children: errors.email
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 28
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					className: errors.password ? "field-invalid" : "",
					children: [
						"Password",
						/* @__PURE__ */ _jsxDEV("span", {
							className: "password-field",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: showPassword ? "text" : "password",
								value: password,
								onChange: (event) => {
									setPassword(event.target.value);
									setErrors((current) => ({
										...current,
										password: undefined
									}));
								},
								placeholder: "Enter your password",
								"aria-invalid": Boolean(errors.password)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowPassword((current) => !current),
								"aria-label": showPassword ? "Hide password" : "Show password",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: showPassword ? "eyeOff" : "eye" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 11
						}, this),
						errors.password && /* @__PURE__ */ _jsxDEV("small", {
							className: "field-error",
							children: errors.password
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 31
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Button, {
					onClick: submit,
					disabled: loading,
					children: loading ? "Logging in..." : "Log in"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "auth-switch",
					children: ["Don't have an account? ", /* @__PURE__ */ _jsxDEV("button", {
						onClick: onSignup,
						children: "Sign up to start your 60/90-day challenge."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 59
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 5
	}, this);
}
_s(LoginModal, "FTwAA3otBjO3mOjB+AdefP2uXdk=");
_c = LoginModal;
var _c;
$RefreshReg$(_c, "LoginModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/modals/LoginModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/LoginModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/LoginModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/modals/LoginModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsV0FBVzs7OztBQUVwQixPQUFPLFNBQVMsV0FBVyxFQUN6QixNQUNBLFNBQ0EsVUFDQSxhQU1DOztDQUNELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFrRSxDQUFDLENBQUM7Q0FDaEcsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FFNUMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE1BQU07RUFDWCxNQUFNLGlCQUFpQixVQUF5QjtHQUM5QyxJQUFJLE1BQU0sUUFBUSxVQUFVLFFBQVE7RUFDdEM7RUFDQSxPQUFPLGlCQUFpQixXQUFXLGFBQWE7RUFDaEQsYUFBYSxPQUFPLG9CQUFvQixXQUFXLGFBQWE7Q0FDbEUsR0FBRyxDQUFDLE1BQU0sT0FBTyxDQUFDO0NBRWxCLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FFbEIsTUFBTSxTQUFTLFlBQVk7RUFDekIsTUFBTSxhQUFzRTtHQUMxRSxPQUFPLE1BQU0sU0FBUyxHQUFHLElBQUksWUFBWTtHQUN6QyxVQUFVLFdBQVcsWUFBWTtFQUNuQztFQUNBLFVBQVUsVUFBVTtFQUNwQixJQUFJLFdBQVcsU0FBUyxXQUFXLFVBQVU7RUFFN0MsV0FBVyxJQUFJO0VBQ2YsVUFBVSxDQUFDLENBQUM7RUFFWixJQUFJO0dBQ0YsTUFBTSxJQUFJLE1BQU0sT0FBTyxRQUFRO0dBQy9CLFVBQVU7RUFDWixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0saUJBQWlCLEdBQUc7R0FDbEMsVUFBVSxFQUFFLFNBQVMsNERBQTRELENBQUM7RUFDcEYsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFnQyxhQUFhO1lBQzFELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQW9CLE1BQUs7R0FBUyxjQUFXO0dBQU8sY0FBVztHQUFTLGNBQWMsVUFBVSxNQUFNLGdCQUFnQjthQUFySTtJQUNFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQWMsU0FBUztLQUFTLGNBQVc7ZUFBYztJQUFTOzs7OztJQUNwRix3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7O0lBQ25CLE9BQU8sV0FBVyx3QkFBQyxTQUFEO0tBQU8sV0FBVTtLQUFjLE9BQU87TUFBRSxTQUFTO01BQVMsY0FBYztLQUFPO2VBQUksT0FBTztJQUFlOzs7OztJQUM1SCx3QkFBQyxTQUFEO0tBQU8sV0FBVyxPQUFPLFFBQVEsa0JBQWtCO2VBQW5EO01BQXVEO01BRXJELHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsVUFBVTtRQUNuQixTQUFTLE1BQU0sT0FBTyxLQUFLO1FBQzNCLFdBQVcsYUFBYTtTQUFFLEdBQUc7U0FBUyxPQUFPO1FBQVUsRUFBRTtPQUMzRDtPQUNBLGFBQVk7T0FDWixnQkFBYyxRQUFRLE9BQU8sS0FBSztNQUNuQzs7Ozs7TUFDQSxPQUFPLFNBQVMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWUsT0FBTztNQUFhOzs7OztLQUNoRTs7Ozs7O0lBQ1Asd0JBQUMsU0FBRDtLQUFPLFdBQVcsT0FBTyxXQUFXLGtCQUFrQjtlQUF0RDtNQUEwRDtNQUV4RCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRSx3QkFBQyxTQUFEO1FBQ0UsTUFBTSxlQUFlLFNBQVM7UUFDOUIsT0FBTztRQUNQLFdBQVcsVUFBVTtTQUNuQixZQUFZLE1BQU0sT0FBTyxLQUFLO1NBQzlCLFdBQVcsYUFBYTtVQUFFLEdBQUc7VUFBUyxVQUFVO1NBQVUsRUFBRTtRQUM5RDtRQUNBLGFBQVk7UUFDWixnQkFBYyxRQUFRLE9BQU8sUUFBUTtPQUN0Qzs7OztpQkFDRCx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLGVBQWUsaUJBQWlCLFlBQVksQ0FBQyxPQUFPO1FBQUcsY0FBWSxlQUFlLGtCQUFrQjtrQkFDeEgsd0JBQUMsTUFBRCxFQUFNLE1BQU0sZUFBZSxXQUFXLE1BQVE7Ozs7O09BQ3hDOzs7O2VBQ0o7Ozs7OztNQUNMLE9BQU8sWUFBWSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBZSxPQUFPO01BQWdCOzs7OztLQUN0RTs7Ozs7O0lBQ1Asd0JBQUMsUUFBRDtLQUFRLFNBQVM7S0FBUSxVQUFVO2VBQVUsVUFBVSxrQkFBa0I7SUFBaUI7Ozs7O0lBQzFGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FBMkIsMkJBQXVCLHdCQUFDLFVBQUQ7TUFBUSxTQUFTO2dCQUFVO0tBQWtEOzs7O2FBQUk7Ozs7OztHQUNoSTs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5Nb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b25cIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaVwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExvZ2luTW9kYWwoe1xyXG4gIG9wZW4sXHJcbiAgb25DbG9zZSxcclxuICBvblNpZ251cCxcclxuICBvblN1Y2Nlc3MsXHJcbn06IHtcclxuICBvcGVuOiBib29sZWFuO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgb25TaWdudXA6ICgpID0+IHZvaWQ7XHJcbiAgb25TdWNjZXNzOiAoKSA9PiB2b2lkO1xyXG59KSB7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlPHsgZW1haWw/OiBzdHJpbmc7IHBhc3N3b3JkPzogc3RyaW5nOyBnZW5lcmFsPzogc3RyaW5nIH0+KHt9KTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcclxuICAgIGNvbnN0IGNsb3NlT25Fc2NhcGUgPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcclxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFc2NhcGVcIikgb25DbG9zZSgpO1xyXG4gICAgfTtcclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBjbG9zZU9uRXNjYXBlKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgY2xvc2VPbkVzY2FwZSk7XHJcbiAgfSwgW29wZW4sIG9uQ2xvc2VdKTtcclxuXHJcbiAgaWYgKCFvcGVuKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgc3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgbmV4dEVycm9yczogeyBlbWFpbD86IHN0cmluZzsgcGFzc3dvcmQ/OiBzdHJpbmc7IGdlbmVyYWw/OiBzdHJpbmcgfSA9IHtcclxuICAgICAgZW1haWw6IGVtYWlsLmluY2x1ZGVzKFwiQFwiKSA/IHVuZGVmaW5lZCA6IFwiRW50ZXIgYSB2YWxpZCBlbWFpbFwiLFxyXG4gICAgICBwYXNzd29yZDogcGFzc3dvcmQgPyB1bmRlZmluZWQgOiBcIlBhc3N3b3JkIGlzIHJlcXVpcmVkXCIsXHJcbiAgICB9O1xyXG4gICAgc2V0RXJyb3JzKG5leHRFcnJvcnMpO1xyXG4gICAgaWYgKG5leHRFcnJvcnMuZW1haWwgfHwgbmV4dEVycm9ycy5wYXNzd29yZCkgcmV0dXJuO1xyXG5cclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5sb2dpbihlbWFpbCwgcGFzc3dvcmQpO1xyXG4gICAgICBvblN1Y2Nlc3MoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiTG9naW4gZmFpbGVkOlwiLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcnMoeyBnZW5lcmFsOiBcIkludmFsaWQgZW1haWwgb3IgcGFzc3dvcmQuIFBsZWFzZSBjaGVjayB5b3VyIGNyZWRlbnRpYWxzLlwiIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3AgbG9naW4tYmFja2Ryb3BcIiBvbk1vdXNlRG93bj17b25DbG9zZX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwgbG9naW4tbW9kYWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsPVwiTG9nIGluXCIgb25Nb3VzZURvd249eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwibW9kYWwtY2xvc2VcIiBvbkNsaWNrPXtvbkNsb3NlfSBhcmlhLWxhYmVsPVwiQ2xvc2UgbG9naW5cIj7DlzwvYnV0dG9uPlxyXG4gICAgICAgIDxoMj5XZWxjb21lIGJhY2s8L2gyPlxyXG4gICAgICAgIHtlcnJvcnMuZ2VuZXJhbCAmJiA8c21hbGwgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIiBzdHlsZT17eyBkaXNwbGF5OiBcImJsb2NrXCIsIG1hcmdpbkJvdHRvbTogXCIxcmVtXCIgfX0+e2Vycm9ycy5nZW5lcmFsfTwvc21hbGw+fVxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9e2Vycm9ycy5lbWFpbCA/IFwiZmllbGQtaW52YWxpZFwiIDogXCJcIn0+XHJcbiAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEVtYWlsKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgc2V0RXJyb3JzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBlbWFpbDogdW5kZWZpbmVkIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ5b3VAZXhhbXBsZS5jb21cIlxyXG4gICAgICAgICAgICBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3JzLmVtYWlsKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7ZXJyb3JzLmVtYWlsICYmIDxzbWFsbCBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMuZW1haWx9PC9zbWFsbD59XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtlcnJvcnMucGFzc3dvcmQgPyBcImZpZWxkLWludmFsaWRcIiA6IFwiXCJ9PlxyXG4gICAgICAgICAgUGFzc3dvcmRcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBhc3N3b3JkLWZpZWxkXCI+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRQYXNzd29yZChldmVudC50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3JzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBwYXNzd29yZDogdW5kZWZpbmVkIH0pKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgeW91ciBwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKGVycm9ycy5wYXNzd29yZCl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCgoY3VycmVudCkgPT4gIWN1cnJlbnQpfSBhcmlhLWxhYmVsPXtzaG93UGFzc3dvcmQgPyBcIkhpZGUgcGFzc3dvcmRcIiA6IFwiU2hvdyBwYXNzd29yZFwifT5cclxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtzaG93UGFzc3dvcmQgPyBcImV5ZU9mZlwiIDogXCJleWVcIn0gLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIDxzbWFsbCBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntlcnJvcnMucGFzc3dvcmR9PC9zbWFsbD59XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3N1Ym1pdH0gZGlzYWJsZWQ9e2xvYWRpbmd9Pntsb2FkaW5nID8gXCJMb2dnaW5nIGluLi4uXCIgOiBcIkxvZyBpblwifTwvQnV0dG9uPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImF1dGgtc3dpdGNoXCI+RG9uJ3QgaGF2ZSBhbiBhY2NvdW50PyA8YnV0dG9uIG9uQ2xpY2s9e29uU2lnbnVwfT5TaWduIHVwIHRvIHN0YXJ0IHlvdXIgNjAvOTAtZGF5IGNoYWxsZW5nZS48L2J1dHRvbj48L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSJdfQ==