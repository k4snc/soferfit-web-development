import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/ProfilePage.tsx");const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { CustomCheckbox } from "/src/frontend/components/CustomCheckbox.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { PageHeader } from "/src/frontend/components/PageHeader.tsx";
import { createFitnessStore } from "/src/frontend/fitnessStore.ts";
import { parseHeightCm, parseWeightKg, prettyDate } from "/src/frontend/lib/format.ts";
import { api } from "/src/frontend/services/api.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProfilePage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function ProfilePage({ store, update, toast, onLogout, onOpenGlossary }) {
	_s();
	const sectionNames = [
		"Account",
		"Body profile",
		"Training",
		"Health & safety",
		"Notifications",
		"Privacy & data",
		"Help"
	];
	const [user, setUser] = useState(store.user);
	const [challenge, setChallenge] = useState(store.challenge);
	const [preferences, setPreferences] = useState(store.preferences);
	const [editing, setEditing] = useState(null);
	const [expanded, setExpanded] = useState("Account");
	const [error, setError] = useState("");
	const [passwords, setPasswords] = useState({
		current: "",
		next: "",
		confirm: ""
	});
	const [showRestart, setShowRestart] = useState(false);
	const [deleteText, setDeleteText] = useState("");
	const [showDelete, setShowDelete] = useState(false);
	const avatarInputRef = useRef(null);
	const [durationChoice, setDurationChoice] = useState([
		15,
		30,
		45,
		60
	].includes(challenge.sessionMinutes) ? String(challenge.sessionMinutes) : "custom");
	const [customDuration, setCustomDuration] = useState([
		15,
		30,
		45,
		60
	].includes(challenge.sessionMinutes) ? "" : String(challenge.sessionMinutes));
	const challengeDay = Math.max(1, Math.min(challenge.length, Math.floor((Date.now() - new Date(`${challenge.startDate}T12:00:00`).getTime()) / 864e5) + 1));
	const initials = user.username.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
	const passwordRules = [
		["At least 8 characters", passwords.next.length >= 8],
		["One uppercase letter", /[A-Z]/.test(passwords.next)],
		["One lowercase letter", /[a-z]/.test(passwords.next)],
		["One number", /\d/.test(passwords.next)]
	];
	const cancel = () => {
		setUser(store.user);
		setChallenge(store.challenge);
		setPreferences(store.preferences);
		setPasswords({
			current: "",
			next: "",
			confirm: ""
		});
		setError("");
		setEditing(null);
	};
	const save = async (section) => {
		setError("");
		if (section === "Account") {
			if (!user.username.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)) return setError("Enter a name and valid email.");
			if (passwords.current || passwords.next || passwords.confirm) {
				if (!passwords.current) return setError("Enter your current password.");
				if (!passwordRules.every((rule) => rule[1])) return setError("Your new password does not meet all the rules.");
				if (passwords.next !== passwords.confirm) return setError("New passwords do not match.");
			}
		}
		if (section === "Body profile") {
			const ageValue = Number(user.age);
			const heightCm = parseHeightCm(user.height, user.unitSystem);
			const weightKg = parseWeightKg(user.weight, user.unitSystem);
			const targetKg = user.targetWeight ? parseWeightKg(user.targetWeight, user.unitSystem) : 0;
			if (!ageValue || ageValue < 10 || ageValue > 100) return setError("Age must be between 10 and 100.");
			if (!heightCm || heightCm < 100 || heightCm > 250) return setError(`Height must be between ${user.unitSystem === "metric" ? "100–250 cm" : "approximately 3 ft 3 in–8 ft 2 in"}.`);
			if (!weightKg || weightKg < 25 || weightKg > 300 || targetKg && (targetKg < 25 || targetKg > 300)) return setError(`Weight must be between ${user.unitSystem === "metric" ? "25–300 kg" : "55–661 lb"}.`);
			if (!user.somatotype || !user.goal || !user.experience || !user.activityLevel) return setError("Complete each body profile selection.");
			try {
				await api.saveOnboarding({
					name: user.username,
					age: user.age,
					height: user.height,
					currentWeight: user.weight,
					targetWeight: user.targetWeight,
					unitSystem: user.unitSystem,
					somatotype: user.somatotype,
					goal: user.goal,
					experience: user.experience,
					activity: user.activityLevel,
					workoutDays: String(challenge.daysPerWeek),
					sessionLength: String(challenge.sessionMinutes),
					focusArea: "General Fitness",
					mode: "Standard",
					equipment: user.equipment,
					challengeDays: challenge.length,
					hasCondition: user.injuryFlag
				});
			} catch (err) {
				console.error("Failed to sync body profile with backend:", err);
			}
		}
		if (section === "Training") {
			const minutes = durationChoice === "custom" ? Number(customDuration) : Number(durationChoice);
			if (challenge.daysPerWeek < 2 || challenge.daysPerWeek > 6 || minutes < 5 || minutes > 180) return setError("Choose 2–6 workout days and a session duration from 5–180 minutes.");
			setChallenge({
				...challenge,
				sessionMinutes: minutes
			});
			try {
				await api.saveOnboarding({
					name: user.username,
					age: user.age,
					height: user.height,
					currentWeight: user.weight,
					targetWeight: user.targetWeight,
					unitSystem: user.unitSystem,
					somatotype: user.somatotype,
					goal: user.goal,
					experience: user.experience,
					activity: user.activityLevel,
					workoutDays: String(challenge.daysPerWeek),
					sessionLength: String(minutes),
					focusArea: "General Fitness",
					mode: "Standard",
					equipment: user.equipment,
					challengeDays: challenge.length,
					hasCondition: user.injuryFlag
				});
			} catch (err) {
				console.error("Failed to sync training preferences with backend:", err);
			}
			if (!update({
				...store,
				user,
				challenge: {
					...challenge,
					sessionMinutes: minutes
				},
				preferences
			})) return;
		} else if (!update({
			...store,
			user,
			challenge,
			preferences
		})) return;
		setPasswords({
			current: "",
			next: "",
			confirm: ""
		});
		setEditing(null);
		toast(`${section} saved.`);
	};
	const sectionActions = (section) => editing === section ? /* @__PURE__ */ _jsxDEV("div", {
		className: "profile-section-actions",
		children: [/* @__PURE__ */ _jsxDEV(Button, {
			variant: "ghost",
			onClick: cancel,
			children: "Cancel"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 48
		}, this), /* @__PURE__ */ _jsxDEV(Button, {
			onClick: () => save(section),
			children: "Save"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 104
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 123,
		columnNumber: 7
	}, this) : /* @__PURE__ */ _jsxDEV("button", {
		className: "profile-edit",
		onClick: () => {
			setError("");
			setEditing(section);
		},
		children: "Edit"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 124,
		columnNumber: 7
	}, this);
	const selectSection = (section) => {
		setExpanded(section);
		document.getElementById(`profile-${section.toLowerCase().replace(/[^a-z]+/g, "-")}`)?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	};
	const chooseAvatar = (file) => {
		setError("");
		if (!file) return;
		if (![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(file.type)) return setError("Choose a JPG, PNG, or WebP image.");
		if (file.size > 5 * 1024 * 1024) return setError("Choose an image smaller than 5 MB.");
		const reader = new FileReader();
		reader.onload = () => {
			const image = new Image();
			image.onload = () => {
				const canvas = document.createElement("canvas");
				const scale = Math.min(1, 800 / Math.max(image.width, image.height));
				canvas.width = Math.max(1, Math.round(image.width * scale));
				canvas.height = Math.max(1, Math.round(image.height * scale));
				const context = canvas.getContext("2d");
				if (!context) return setError("We couldn't prepare that photo.");
				context.drawImage(image, 0, 0, canvas.width, canvas.height);
				const avatar = canvas.toDataURL("image/webp", .82);
				const nextUser = {
					...user,
					avatar
				};
				setUser(nextUser);
				if (update({
					...store,
					user: nextUser
				})) toast("Profile photo updated.");
			};
			image.src = String(reader.result);
		};
		reader.readAsDataURL(file);
	};
	const restartChallenge = () => {
		const fresh = createFitnessStore({
			name: user.username,
			email: user.email,
			avatarUrl: user.avatar,
			age: user.age,
			height: user.height,
			weight: user.weight,
			targetWeight: user.targetWeight,
			somatotype: user.somatotype,
			goal: user.goal,
			experience: user.experience,
			activity: user.activityLevel,
			unitSystem: user.unitSystem,
			availableEquipment: user.equipment,
			hasCondition: user.injuryFlag,
			challengeDays: challenge.length,
			workoutDays: challenge.daysPerWeek,
			sessionMinutes: challenge.sessionMinutes,
			challengeStartDate: new Date().toISOString()
		});
		const restarted = {
			...fresh,
			user: {
				...fresh.user,
				...user
			},
			preferences,
			weights: store.weights,
			photos: store.photos
		};
		if (update(restarted)) {
			setChallenge(restarted.challenge);
			setShowRestart(false);
			toast("Challenge restarted at Day 1. We kept your weights and photos.");
		}
	};
	const downloadData = () => {
		const blob = new Blob([JSON.stringify(store, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "soferfit-data.json";
		link.click();
		URL.revokeObjectURL(url);
		toast("Your data export is ready.");
	};
	const healthyPace = Boolean(user.weight && user.targetWeight) && (parseWeightKg(user.weight, user.unitSystem) - parseWeightKg(user.targetWeight, user.unitSystem)) / (challenge.length / 7) > 1;
	const cardClass = (section) => `profile-section-card ${expanded === section ? "mobile-expanded" : ""}`;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(PageHeader, {
			eyebrow: "YOUR ACCOUNT",
			title: "Profile"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 181,
			columnNumber: 12
		}, this),
		/* @__PURE__ */ _jsxDEV("article", {
			className: "profile-header-card",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-avatar-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-avatar-large",
							onClick: () => avatarInputRef.current?.click(),
							"aria-label": "Change photo",
							children: user.avatar ? /* @__PURE__ */ _jsxDEV("img", {
								src: user.avatar,
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 213
							}, this) : initials
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 83
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-avatar-camera",
							onClick: () => avatarInputRef.current?.click(),
							"aria-label": "Change photo",
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "camera" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 382
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								role: "tooltip",
								children: "Change photo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 404
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 266
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							ref: avatarInputRef,
							className: "profile-avatar-input",
							type: "file",
							accept: ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp",
							onChange: (event) => chooseAvatar(event.target.files?.[0])
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 453
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 46
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-header-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: user.username }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 694
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: user.email || "Add your email" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 718
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: ["Member since ", prettyDate(user.memberSince)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 757
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 657
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-header-actions",
					children: [/* @__PURE__ */ _jsxDEV("strong", { children: [
						"Day ",
						challengeDay,
						" / ",
						challenge.length
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 859
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onLogout,
						children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "logout" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 942
						}, this), "Log out"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 915
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 819
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 182,
			columnNumber: 5
		}, this),
		error && /* @__PURE__ */ _jsxDEV("p", {
			className: "profile-global-error inline-validation",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 183,
			columnNumber: 15
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "profile-layout",
			children: [/* @__PURE__ */ _jsxDEV("nav", {
				className: "profile-subnav",
				"aria-label": "Profile sections",
				children: sectionNames.map((section) => /* @__PURE__ */ _jsxDEV("button", {
					className: expanded === section ? "active" : "",
					onClick: () => selectSection(section),
					children: [section, /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 219
					}, this)]
				}, section, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 100
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "profile-sections",
				children: [
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-account",
						className: cardClass("Account"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Account"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "ACCOUNT" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 167
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Sign-in details" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 189
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 161
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Account" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 220
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 80
						}, this), sectionActions("Account")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 72
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "profile-field-grid",
								children: [/* @__PURE__ */ _jsxDEV("label", { children: ["Name", /* @__PURE__ */ _jsxDEV("input", {
									disabled: editing !== "Account",
									value: user.username,
									onChange: (event) => setUser({
										...user,
										username: event.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 393
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 382
								}, this), /* @__PURE__ */ _jsxDEV("label", { children: ["Email", /* @__PURE__ */ _jsxDEV("input", {
									disabled: editing !== "Account",
									type: "email",
									value: user.email,
									onChange: (event) => setUser({
										...user,
										email: event.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 550
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 538
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 346
							}, this), editing === "Account" && /* @__PURE__ */ _jsxDEV("div", {
								className: "password-edit",
								children: [
									/* @__PURE__ */ _jsxDEV("h3", { children: "Change password" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 765
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "profile-field-grid",
										children: [
											/* @__PURE__ */ _jsxDEV("label", { children: ["Current password", /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												value: passwords.current,
												onChange: (event) => setPasswords({
													...passwords,
													current: event.target.value
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 848
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 825
											}, this),
											/* @__PURE__ */ _jsxDEV("label", { children: ["New password", /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												value: passwords.next,
												onChange: (event) => setPasswords({
													...passwords,
													next: event.target.value
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 1008
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 989
											}, this),
											/* @__PURE__ */ _jsxDEV("label", { children: ["Confirm new password", /* @__PURE__ */ _jsxDEV("input", {
												type: "password",
												value: passwords.confirm,
												onChange: (event) => setPasswords({
													...passwords,
													confirm: event.target.value
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 1170
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 1143
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 789
									}, this),
									/* @__PURE__ */ _jsxDEV("ul", { children: passwordRules.map(([rule, met]) => /* @__PURE__ */ _jsxDEV("li", {
										className: met ? "met" : "",
										children: [/* @__PURE__ */ _jsxDEV(Icon, { name: met ? "check" : "close" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 1401
										}, this), rule]
									}, rule, true, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 1357
									}, this)) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 1317
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 734
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 308
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-body-profile",
						className: cardClass("Body profile"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Body profile"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "BODY PROFILE" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 182
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Your baseline" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 209
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 176
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Body profile" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 238
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 90
						}, this), sectionActions("Body profile")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 82
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "profile-choice-group",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Units" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 49
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
										disabled: editing !== "Body profile",
										className: user.unitSystem === "metric" ? "active" : "",
										onClick: () => setUser({
											...user,
											unitSystem: "metric"
										}),
										children: "Metric"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 72
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										disabled: editing !== "Body profile",
										className: user.unitSystem === "imperial" ? "active" : "",
										onClick: () => setUser({
											...user,
											unitSystem: "imperial"
										}),
										children: "Imperial"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 249
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 67
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "profile-field-grid four",
									children: [
										/* @__PURE__ */ _jsxDEV("label", { children: ["Age", /* @__PURE__ */ _jsxDEV("input", {
											disabled: editing !== "Body profile",
											type: "number",
											value: user.age,
											onChange: (event) => setUser({
												...user,
												age: event.target.value
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 62
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 52
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: [
											"Height (",
											user.unitSystem === "metric" ? "cm" : "ft / in",
											")",
											/* @__PURE__ */ _jsxDEV("input", {
												disabled: editing !== "Body profile",
												type: user.unitSystem === "metric" ? "number" : "text",
												placeholder: user.unitSystem === "metric" ? "175" : "5 ft 8 in",
												value: user.height,
												onChange: (event) => setUser({
													...user,
													height: event.target.value
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 281
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 216
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: [
											"Current weight (",
											user.unitSystem === "metric" ? "kg" : "lb",
											")",
											/* @__PURE__ */ _jsxDEV("input", {
												disabled: editing !== "Body profile",
												type: "number",
												value: user.weight,
												onChange: (event) => setUser({
													...user,
													weight: event.target.value
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 616
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 548
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: ["Target weight", /* @__PURE__ */ _jsxDEV("input", {
											disabled: editing !== "Body profile",
											type: "number",
											value: user.targetWeight,
											onChange: (event) => setUser({
												...user,
												targetWeight: event.target.value
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 796
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 776
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "somatotype-label",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Somatotype" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 45
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onOpenGlossary("Somatotype"),
										"aria-label": "Open somatotype glossary",
										children: "ⓘ"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 68
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "profile-somatotypes",
									children: [
										["Ectomorph", "Naturally leaner frame"],
										["Mesomorph", "Naturally athletic frame"],
										["Endomorph", "Naturally broader frame"],
										["Not Sure", "Use my other details"]
									].map(([name, copy]) => /* @__PURE__ */ _jsxDEV("button", {
										disabled: editing !== "Body profile",
										className: user.somatotype === name ? "active" : "",
										onClick: () => setUser({
											...user,
											somatotype: name
										}),
										children: [/* @__PURE__ */ _jsxDEV("strong", { children: name }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 565
										}, this), /* @__PURE__ */ _jsxDEV("small", { children: copy }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 588
										}, this)]
									}, name, true, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 400
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 192,
									columnNumber: 175
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "profile-field-grid three",
									children: [
										/* @__PURE__ */ _jsxDEV("label", { children: ["Primary goal", /* @__PURE__ */ _jsxDEV("select", {
											disabled: editing !== "Body profile",
											value: user.goal,
											onChange: (event) => setUser({
												...user,
												goal: event.target.value
											}),
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Choose a goal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 205
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Lose Fat & Get Lean" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 244
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Build Muscle & Strength" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 280
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Body Recomposition" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 320
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 72
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 53
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: ["Experience level", /* @__PURE__ */ _jsxDEV("select", {
											disabled: editing !== "Body profile",
											value: user.experience,
											onChange: (event) => setUser({
												...user,
												experience: event.target.value
											}),
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Choose experience"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 540
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Starting Out" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 583
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Some Experience" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 612
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Consistent" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 644
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 395
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 372
										}, this),
										/* @__PURE__ */ _jsxDEV("label", { children: ["Activity level", /* @__PURE__ */ _jsxDEV("select", {
											disabled: editing !== "Body profile",
											value: user.activityLevel,
											onChange: (event) => setUser({
												...user,
												activityLevel: event.target.value
											}),
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "",
													children: "Choose activity"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 860
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Sedentary" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 901
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Sometimes Active" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 927
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Moderately Active" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 960
												}, this),
												/* @__PURE__ */ _jsxDEV("option", { children: "Very Active" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 994
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 709
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 688
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 11
								}, this),
								healthyPace && /* @__PURE__ */ _jsxDEV("p", {
									className: "gentle-note",
									children: "That target may call for a faster pace. Gradual, sustainable changes are easier to maintain; your plan will stay balanced."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 1061
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 336
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-training",
						className: cardClass("Training"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Training"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "TRAINING" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 170
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Plan preferences" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 193
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 164
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Training" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 225
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 82
						}, this), sectionActions("Training")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 74
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "profile-field-grid three",
								children: [
									/* @__PURE__ */ _jsxDEV("label", { children: ["Equipment", /* @__PURE__ */ _jsxDEV("select", {
										disabled: editing !== "Training",
										value: user.equipment,
										onChange: (event) => setUser({
											...user,
											equipment: event.target.value
										}),
										children: [
											/* @__PURE__ */ _jsxDEV("option", { children: "Bodyweight / Home Only" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 550
											}, this),
											/* @__PURE__ */ _jsxDEV("option", { children: "Dumbbells & Bands" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 589
											}, this),
											/* @__PURE__ */ _jsxDEV("option", { children: "Full Gym Access" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 623
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 411
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 395
									}, this),
									/* @__PURE__ */ _jsxDEV("label", { children: ["Workout days per week", /* @__PURE__ */ _jsxDEV("input", {
										disabled: editing !== "Training",
										type: "number",
										min: "2",
										max: "6",
										value: challenge.daysPerWeek,
										onChange: (event) => setChallenge({
											...challenge,
											daysPerWeek: Number(event.target.value)
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 700
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 672
									}, this),
									/* @__PURE__ */ _jsxDEV("label", { children: ["Session duration", /* @__PURE__ */ _jsxDEV("select", {
										disabled: editing !== "Training",
										value: durationChoice,
										onChange: (event) => setDurationChoice(event.target.value),
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "15",
												children: "15 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 1053
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "30",
												children: "30 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 1091
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "45",
												children: "45 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 1129
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "60",
												children: "60 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 1167
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "custom",
												children: "Custom..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 1205
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 928
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 905
									}, this),
									durationChoice === "custom" && /* @__PURE__ */ _jsxDEV("label", { children: ["Custom minutes", /* @__PURE__ */ _jsxDEV("input", {
										disabled: editing !== "Training",
										type: "number",
										min: "5",
										max: "180",
										value: customDuration,
										onChange: (event) => setCustomDuration(event.target.value)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 1316
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 1295
									}, this),
									/* @__PURE__ */ _jsxDEV("label", { children: ["Challenge length", /* @__PURE__ */ _jsxDEV("input", {
										disabled: true,
										value: `${challenge.length} days`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 1506
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 1483
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 353
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "danger-row",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Restart challenge" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 1606
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Return the plan and calendar to Day 1." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 1640
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 1601
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowRestart(true),
									children: "Restart challenge"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 1697
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 1573
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 315
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-health-safety",
						className: cardClass("Health & safety"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Health & safety"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "HEALTH & SAFETY" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 189
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Exercise preferences" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 219
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 183
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Health & safety" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 255
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 94
						}, this), sectionActions("Health & safety")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 86
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: [/* @__PURE__ */ _jsxDEV(CustomCheckbox, {
								className: "profile-check checkbox-leading",
								disabled: editing !== "Health & safety",
								checked: user.injuryFlag,
								onChange: (checked) => setUser({
									...user,
									injuryFlag: checked
								}),
								children: /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "I have an injury or health condition" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 198,
									columnNumber: 595
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: "When on, lower-impact exercises are favored." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 198,
									columnNumber: 648
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 198,
									columnNumber: 589
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 397
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "safety-disclaimer",
								children: "SoferFit offers general fitness guidance, not medical advice. Check with a doctor before starting if you have a health condition."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 731
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 359
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-notifications",
						className: cardClass("Notifications"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Notifications"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "NOTIFICATIONS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 185
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Stay on track" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 213
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 179
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Notifications" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 242
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 92
						}, this), sectionActions("Notifications")] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 84
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "notification-list",
								children: [
									/* @__PURE__ */ _jsxDEV(CustomCheckbox, {
										className: "notification-option",
										disabled: editing !== "Notifications",
										checked: preferences.workoutReminders,
										onChange: (checked) => setPreferences({
											...preferences,
											workoutReminders: checked
										}),
										children: /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Workout reminders" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 633
										}, this), /* @__PURE__ */ _jsxDEV("small", { children: "A reminder on planned workout days." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 667
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 627
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 415
									}, this),
									preferences.workoutReminders && /* @__PURE__ */ _jsxDEV("label", {
										className: "reminder-time",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Reminder time" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 807
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											disabled: editing !== "Notifications",
											type: "time",
											value: preferences.reminderTime,
											onChange: (event) => setPreferences({
												...preferences,
												reminderTime: event.target.value
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 833
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 774
									}, this),
									/* @__PURE__ */ _jsxDEV(CustomCheckbox, {
										className: "notification-option",
										disabled: editing !== "Notifications",
										checked: preferences.streakReminders,
										onChange: (checked) => setPreferences({
											...preferences,
											streakReminders: checked
										}),
										children: /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Streak reminders" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1242
										}, this), /* @__PURE__ */ _jsxDEV("small", { children: "A gentle prompt when your streak is active." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1275
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1236
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 1026
									}, this),
									/* @__PURE__ */ _jsxDEV(CustomCheckbox, {
										className: "notification-option",
										disabled: editing !== "Notifications",
										checked: preferences.weeklySummary,
										onChange: (checked) => setPreferences({
											...preferences,
											weeklySummary: checked
										}),
										children: /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Weekly progress summaries" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1569
										}, this), /* @__PURE__ */ _jsxDEV("small", { children: "A short recap of your training week." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1611
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 1563
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 1357
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 380
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 342
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-privacy-data",
						className: cardClass("Privacy & data"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: /* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Privacy & data"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "PRIVACY & DATA" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 186
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Your information" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 215
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 180
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Privacy & data" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 247
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 92
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 84
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "privacy-statement",
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "camera" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 388
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Your progress photos are private" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 415
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "They are stored with your local profile and only visible to you." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 464
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 410
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 353
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									className: "profile-row-action",
									onClick: downloadData,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Download my data" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 621
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Export your profile and progress as JSON." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 654
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 615
									}, this), /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 717
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 553
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "danger-zone",
									children: [
										/* @__PURE__ */ _jsxDEV("strong", { children: "Delete my account" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 776
										}, this),
										/* @__PURE__ */ _jsxDEV("p", { children: "This removes your profile and all locally saved progress." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 810
										}, this),
										showDelete ? /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", { children: ["Type DELETE to confirm", /* @__PURE__ */ _jsxDEV("input", {
												value: deleteText,
												onChange: (event) => setDeleteText(event.target.value)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 922
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 893
											}, this),
											/* @__PURE__ */ _jsxDEV(Button, {
												variant: "ghost",
												disabled: deleteText !== "DELETE",
												onClick: onLogout,
												children: "Delete my account"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 1014
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													setShowDelete(false);
													setDeleteText("");
												},
												children: "Cancel"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 1118
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 888
										}, this) : /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setShowDelete(true),
											children: "Delete my account"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 1211
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 747
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 315
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("article", {
						id: "profile-help",
						className: cardClass("Help"),
						children: [/* @__PURE__ */ _jsxDEV("header", { children: /* @__PURE__ */ _jsxDEV("button", {
							className: "profile-mobile-toggle",
							onClick: () => setExpanded("Help"),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "HELP" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 158
							}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Resources" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 177
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 152
							}, this), /* @__PURE__ */ _jsxDEV("i", { children: expanded === "Help" ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 202
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 74
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 66
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "profile-section-body profile-help-links",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onOpenGlossary(),
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Glossary" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 364
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Plain-language fitness terms." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 389
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 358
									}, this), /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 440
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 317
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "mailto:feedback@soferfit.example",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Send feedback" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 519
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Tell us what would make SoferFit better." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 549
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 513
									}, this), /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 611
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 470
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "About SoferFit" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 647
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Adaptive fitness planning for sustainable routines." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 678
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 641
								}, this), /* @__PURE__ */ _jsxDEV("b", { children: "Version 1.0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 751
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 204,
									columnNumber: 636
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 260
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 186,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 184,
			columnNumber: 5
		}, this),
		showRestart && /* @__PURE__ */ _jsxDEV("div", {
			className: "progress-modal-backdrop",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "end-dialog",
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "dash-stat-icon",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 155
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 122
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: "Restart challenge?" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 186
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Your workout plan, sessions, badges, and calendar will reset to Day 1. Saved weights and progress photos will be kept." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 213
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: restartChallenge,
						children: "Restart at Day 1"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 338
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						onClick: () => setShowRestart(false),
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 398
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 62
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 21
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 181,
		columnNumber: 10
	}, this);
}
_s(ProfilePage, "Aco9R4JOaBGNu6ZcG4lpaL/bjGY=");
_c = ProfilePage;
var _c;
$RefreshReg$(_c, "ProfilePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/ProfilePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProfilePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProfilePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProfilePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLGdCQUFnQjtBQUNqQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsMEJBQTBCO0FBRW5DLFNBQVMsZUFBZSxlQUFlLGtCQUFrQjtBQUN6RCxTQUFTLFdBQVc7Ozs7QUFFcEIsT0FBTyxTQUFTLFlBQVksRUFBRSxPQUFPLFFBQVEsT0FBTyxVQUFVLGtCQUFzTTs7Q0FDbFEsTUFBTSxlQUFlO0VBQUM7RUFBVztFQUFnQjtFQUFZO0VBQW1CO0VBQWlCO0VBQWtCO0NBQU07Q0FFekgsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLE1BQU0sSUFBSTtDQUMzQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxNQUFNLFNBQVM7Q0FDMUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsTUFBTSxXQUFXO0NBQ2hFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBNkIsSUFBSTtDQUMvRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXNCLFNBQVM7Q0FDL0QsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVM7RUFBRSxTQUFTO0VBQUksTUFBTTtFQUFJLFNBQVM7Q0FBRyxDQUFDO0NBQ2pGLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0saUJBQWlCLE9BQXlCLElBQUk7Q0FDcEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUztFQUFDO0VBQUk7RUFBSTtFQUFJO0NBQUUsQ0FBQyxDQUFDLFNBQVMsVUFBVSxjQUFjLElBQUksT0FBTyxVQUFVLGNBQWMsSUFBSSxRQUFRO0NBQ3RKLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVM7RUFBQztFQUFJO0VBQUk7RUFBSTtDQUFFLENBQUMsQ0FBQyxTQUFTLFVBQVUsY0FBYyxJQUFJLEtBQUssT0FBTyxVQUFVLGNBQWMsQ0FBQztDQUNoSixNQUFNLGVBQWUsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLFVBQVUsUUFBUSxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEdBQUcsVUFBVSxVQUFVLFVBQVUsQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFVLElBQUksQ0FBQyxDQUFDO0NBQzlKLE1BQU0sV0FBVyxLQUFLLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxZQUFZO0NBQ3BHLE1BQU0sZ0JBQWdCO0VBQ3BCLENBQUMseUJBQXlCLFVBQVUsS0FBSyxVQUFVLENBQUM7RUFDcEQsQ0FBQyx3QkFBd0IsUUFBUSxLQUFLLFVBQVUsSUFBSSxDQUFDO0VBQ3JELENBQUMsd0JBQXdCLFFBQVEsS0FBSyxVQUFVLElBQUksQ0FBQztFQUNyRCxDQUFDLGNBQWMsS0FBSyxLQUFLLFVBQVUsSUFBSSxDQUFDO0NBQzFDO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLFFBQVEsTUFBTSxJQUFJO0VBQ2xCLGFBQWEsTUFBTSxTQUFTO0VBQzVCLGVBQWUsTUFBTSxXQUFXO0VBQ2hDLGFBQWE7R0FBRSxTQUFTO0dBQUksTUFBTTtHQUFJLFNBQVM7RUFBRyxDQUFDO0VBQ25ELFNBQVMsRUFBRTtFQUNYLFdBQVcsSUFBSTtDQUNqQjtDQUNBLE1BQU0sT0FBTyxPQUFPLFlBQXlCO0VBQzNDLFNBQVMsRUFBRTtFQUNYLElBQUksWUFBWSxXQUFXO0dBQ3pCLElBQUksQ0FBQyxLQUFLLFNBQVMsS0FBSyxLQUFLLENBQUMsNkJBQTZCLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTyxTQUFTLCtCQUErQjtHQUM1SCxJQUFJLFVBQVUsV0FBVyxVQUFVLFFBQVEsVUFBVSxTQUFTO0lBQzVELElBQUksQ0FBQyxVQUFVLFNBQVMsT0FBTyxTQUFTLDhCQUE4QjtJQUN0RSxJQUFJLENBQUMsY0FBYyxPQUFPLFNBQVMsS0FBSyxFQUFFLEdBQUcsT0FBTyxTQUFTLGdEQUFnRDtJQUM3RyxJQUFJLFVBQVUsU0FBUyxVQUFVLFNBQVMsT0FBTyxTQUFTLDZCQUE2QjtHQUN6RjtFQUNGO0VBQ0EsSUFBSSxZQUFZLGdCQUFnQjtHQUM5QixNQUFNLFdBQVcsT0FBTyxLQUFLLEdBQUc7R0FDaEMsTUFBTSxXQUFXLGNBQWMsS0FBSyxRQUFRLEtBQUssVUFBVTtHQUMzRCxNQUFNLFdBQVcsY0FBYyxLQUFLLFFBQVEsS0FBSyxVQUFVO0dBQzNELE1BQU0sV0FBVyxLQUFLLGVBQWUsY0FBYyxLQUFLLGNBQWMsS0FBSyxVQUFVLElBQUk7R0FDekYsSUFBSSxDQUFDLFlBQVksV0FBVyxNQUFNLFdBQVcsS0FBSyxPQUFPLFNBQVMsaUNBQWlDO0dBQ25HLElBQUksQ0FBQyxZQUFZLFdBQVcsT0FBTyxXQUFXLEtBQUssT0FBTyxTQUFTLDBCQUEwQixLQUFLLGVBQWUsV0FBVyxlQUFlLG9DQUFvQyxFQUFFO0dBQ2pMLElBQUksQ0FBQyxZQUFZLFdBQVcsTUFBTSxXQUFXLE9BQVEsYUFBYSxXQUFXLE1BQU0sV0FBVyxNQUFPLE9BQU8sU0FBUywwQkFBMEIsS0FBSyxlQUFlLFdBQVcsY0FBYyxZQUFZLEVBQUU7R0FDMU0sSUFBSSxDQUFDLEtBQUssY0FBYyxDQUFDLEtBQUssUUFBUSxDQUFDLEtBQUssY0FBYyxDQUFDLEtBQUssZUFBZSxPQUFPLFNBQVMsdUNBQXVDO0dBRXRJLElBQUk7SUFDRixNQUFNLElBQUksZUFBZTtLQUN2QixNQUFNLEtBQUs7S0FDWCxLQUFLLEtBQUs7S0FDVixRQUFRLEtBQUs7S0FDYixlQUFlLEtBQUs7S0FDcEIsY0FBYyxLQUFLO0tBQ25CLFlBQVksS0FBSztLQUNqQixZQUFZLEtBQUs7S0FDakIsTUFBTSxLQUFLO0tBQ1gsWUFBWSxLQUFLO0tBQ2pCLFVBQVUsS0FBSztLQUNmLGFBQWEsT0FBTyxVQUFVLFdBQVc7S0FDekMsZUFBZSxPQUFPLFVBQVUsY0FBYztLQUM5QyxXQUFXO0tBQ1gsTUFBTTtLQUNOLFdBQVcsS0FBSztLQUNoQixlQUFlLFVBQVU7S0FDekIsY0FBYyxLQUFLO0lBQ3JCLENBQUM7R0FDSCxTQUFTLEtBQUs7SUFDWixRQUFRLE1BQU0sNkNBQTZDLEdBQUc7R0FDaEU7RUFDRjtFQUNBLElBQUksWUFBWSxZQUFZO0dBQzFCLE1BQU0sVUFBVSxtQkFBbUIsV0FBVyxPQUFPLGNBQWMsSUFBSSxPQUFPLGNBQWM7R0FDNUYsSUFBSSxVQUFVLGNBQWMsS0FBSyxVQUFVLGNBQWMsS0FBSyxVQUFVLEtBQUssVUFBVSxLQUFLLE9BQU8sU0FBUyxvRUFBb0U7R0FDaEwsYUFBYTtJQUFFLEdBQUc7SUFBVyxnQkFBZ0I7R0FBUSxDQUFDO0dBRXRELElBQUk7SUFDRixNQUFNLElBQUksZUFBZTtLQUN2QixNQUFNLEtBQUs7S0FDWCxLQUFLLEtBQUs7S0FDVixRQUFRLEtBQUs7S0FDYixlQUFlLEtBQUs7S0FDcEIsY0FBYyxLQUFLO0tBQ25CLFlBQVksS0FBSztLQUNqQixZQUFZLEtBQUs7S0FDakIsTUFBTSxLQUFLO0tBQ1gsWUFBWSxLQUFLO0tBQ2pCLFVBQVUsS0FBSztLQUNmLGFBQWEsT0FBTyxVQUFVLFdBQVc7S0FDekMsZUFBZSxPQUFPLE9BQU87S0FDN0IsV0FBVztLQUNYLE1BQU07S0FDTixXQUFXLEtBQUs7S0FDaEIsZUFBZSxVQUFVO0tBQ3pCLGNBQWMsS0FBSztJQUNyQixDQUFDO0dBQ0gsU0FBUyxLQUFLO0lBQ1osUUFBUSxNQUFNLHFEQUFxRCxHQUFHO0dBQ3hFO0dBRUEsSUFBSSxDQUFDLE9BQU87SUFBRSxHQUFHO0lBQU87SUFBTSxXQUFXO0tBQUUsR0FBRztLQUFXLGdCQUFnQjtJQUFRO0lBQUc7R0FBWSxDQUFDLEdBQUc7RUFDdEcsT0FBTyxJQUFJLENBQUMsT0FBTztHQUFFLEdBQUc7R0FBTztHQUFNO0dBQVc7RUFBWSxDQUFDLEdBQUc7RUFDaEUsYUFBYTtHQUFFLFNBQVM7R0FBSSxNQUFNO0dBQUksU0FBUztFQUFHLENBQUM7RUFDbkQsV0FBVyxJQUFJO0VBQ2YsTUFBTSxHQUFHLFFBQVEsUUFBUTtDQUMzQjtDQUNBLE1BQU0sa0JBQWtCLFlBQXlCLFlBQVksVUFDekQsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUF5Qyx3QkFBQyxRQUFEO0dBQVEsU0FBUTtHQUFRLFNBQVM7YUFBUTtFQUFjOzs7O1lBQUMsd0JBQUMsUUFBRDtHQUFRLGVBQWUsS0FBSyxPQUFPO2FBQUc7RUFBWTs7OztVQUFNOzs7OztZQUN6Six3QkFBQyxVQUFEO0VBQVEsV0FBVTtFQUFlLGVBQWU7R0FBRSxTQUFTLEVBQUU7R0FBRyxXQUFXLE9BQU87RUFBRztZQUFHO0NBQVk7Ozs7O0NBQ3hHLE1BQU0saUJBQWlCLFlBQXlCO0VBQzlDLFlBQVksT0FBTztFQUNuQixTQUFTLGVBQWUsV0FBVyxRQUFRLFlBQVksQ0FBQyxDQUFDLFFBQVEsWUFBWSxHQUFHLEdBQUcsQ0FBQyxFQUFFLGVBQWU7R0FBRSxVQUFVO0dBQVUsT0FBTztFQUFRLENBQUM7Q0FDN0k7Q0FDQSxNQUFNLGdCQUFnQixTQUFnQjtFQUNwQyxTQUFTLEVBQUU7RUFDWCxJQUFJLENBQUMsTUFBTTtFQUNYLElBQUksQ0FBQztHQUFDO0dBQWM7R0FBYTtFQUFZLENBQUMsQ0FBQyxTQUFTLEtBQUssSUFBSSxHQUFHLE9BQU8sU0FBUyxtQ0FBbUM7RUFDdkgsSUFBSSxLQUFLLE9BQU8sSUFBSSxPQUFPLE1BQU0sT0FBTyxTQUFTLG9DQUFvQztFQUNyRixNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sZUFBZTtHQUNwQixNQUFNLFFBQVEsSUFBSSxNQUFNO0dBQ3hCLE1BQU0sZUFBZTtJQUNuQixNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE1BQU0sQ0FBQztJQUNuRSxPQUFPLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE1BQU0sUUFBUSxLQUFLLENBQUM7SUFDMUQsT0FBTyxTQUFTLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxDQUFDO0lBQzVELE1BQU0sVUFBVSxPQUFPLFdBQVcsSUFBSTtJQUN0QyxJQUFJLENBQUMsU0FBUyxPQUFPLFNBQVMsaUNBQWlDO0lBQy9ELFFBQVEsVUFBVSxPQUFPLEdBQUcsR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNO0lBQzFELE1BQU0sU0FBUyxPQUFPLFVBQVUsY0FBYyxHQUFHO0lBQ2pELE1BQU0sV0FBVztLQUFFLEdBQUc7S0FBTTtJQUFPO0lBQ25DLFFBQVEsUUFBUTtJQUNoQixJQUFJLE9BQU87S0FBRSxHQUFHO0tBQU8sTUFBTTtJQUFTLENBQUMsR0FBRyxNQUFNLHdCQUF3QjtHQUMxRTtHQUNBLE1BQU0sTUFBTSxPQUFPLE9BQU8sTUFBTTtFQUNsQztFQUNBLE9BQU8sY0FBYyxJQUFJO0NBQzNCO0NBQ0EsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxRQUFRLG1CQUFtQjtHQUMvQixNQUFNLEtBQUs7R0FBVSxPQUFPLEtBQUs7R0FBTyxXQUFXLEtBQUs7R0FBUSxLQUFLLEtBQUs7R0FBSyxRQUFRLEtBQUs7R0FBUSxRQUFRLEtBQUs7R0FBUSxjQUFjLEtBQUs7R0FDNUksWUFBWSxLQUFLO0dBQVksTUFBTSxLQUFLO0dBQU0sWUFBWSxLQUFLO0dBQVksVUFBVSxLQUFLO0dBQWUsWUFBWSxLQUFLO0dBQzFILG9CQUFvQixLQUFLO0dBQVcsY0FBYyxLQUFLO0dBQVksZUFBZSxVQUFVO0dBQVEsYUFBYSxVQUFVO0dBQzNILGdCQUFnQixVQUFVO0dBQWdCLG9CQUFvQixJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDdkYsQ0FBQztFQUNELE1BQU0sWUFBWTtHQUFFLEdBQUc7R0FBTyxNQUFNO0lBQUUsR0FBRyxNQUFNO0lBQU0sR0FBRztHQUFLO0dBQUc7R0FBYSxTQUFTLE1BQU07R0FBUyxRQUFRLE1BQU07RUFBTztFQUMxSCxJQUFJLE9BQU8sU0FBUyxHQUFHO0dBQ3JCLGFBQWEsVUFBVSxTQUFTO0dBQ2hDLGVBQWUsS0FBSztHQUNwQixNQUFNLGdFQUFnRTtFQUN4RTtDQUNGO0NBQ0EsTUFBTSxxQkFBcUI7RUFDekIsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLEtBQUssVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0VBQ3BGLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0VBQ3BDLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztFQUN2QyxLQUFLLE9BQU87RUFDWixLQUFLLFdBQVc7RUFDaEIsS0FBSyxNQUFNO0VBQ1gsSUFBSSxnQkFBZ0IsR0FBRztFQUN2QixNQUFNLDRCQUE0QjtDQUNwQztDQUNBLE1BQU0sY0FBYyxRQUFRLEtBQUssVUFBVSxLQUFLLFlBQVksTUFBTSxjQUFjLEtBQUssUUFBUSxLQUFLLFVBQVUsSUFBSSxjQUFjLEtBQUssY0FBYyxLQUFLLFVBQVUsTUFBTSxVQUFVLFNBQVMsS0FBSztDQUM5TCxNQUFNLGFBQWEsWUFBeUIsd0JBQXdCLGFBQWEsVUFBVSxvQkFBb0I7Q0FFL0csT0FBTztFQUFFLHdCQUFDLFlBQUQ7R0FBWSxTQUFRO0dBQWUsT0FBTTtFQUFXOzs7OztFQUMzRCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUF5Qyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQXFDLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQXVCLGVBQWUsZUFBZSxTQUFTLE1BQU07T0FBRyxjQUFXO2lCQUFnQixLQUFLLFNBQVMsd0JBQUMsT0FBRDtRQUFLLEtBQUssS0FBSztRQUFRLEtBQUk7T0FBSTs7OztrQkFBSTtNQUFpQjs7Ozs7TUFBQyx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF3QixlQUFlLGVBQWUsU0FBUyxNQUFNO09BQUcsY0FBVztpQkFBckcsQ0FBb0gsd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sTUFBSztrQkFBVTtPQUFrQjs7OztlQUFTOzs7Ozs7TUFBQyx3QkFBQyxTQUFEO09BQU8sS0FBSztPQUFnQixXQUFVO09BQXVCLE1BQUs7T0FBTyxRQUFPO09BQXdELFdBQVcsVUFBVSxhQUFhLE1BQU0sT0FBTyxRQUFRLEVBQUU7TUFBSTs7Ozs7S0FBTTs7Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUFxQyx3QkFBQyxNQUFELFlBQUssS0FBSyxTQUFhOzs7OztNQUFDLHdCQUFDLEtBQUQsWUFBSSxLQUFLLFNBQVMsaUJBQW9COzs7OztNQUFDLHdCQUFDLFFBQUQsYUFBTSxpQkFBYyxXQUFXLEtBQUssV0FBVyxDQUFROzs7OztLQUFNOzs7Ozs7SUFBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQXdDLHdCQUFDLFVBQUQ7TUFBUTtNQUFLO01BQWE7TUFBSSxVQUFVO0tBQWU7Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsU0FBUztnQkFBakIsQ0FBMkIsd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7OztnQkFBQyxTQUFlOzs7OzthQUFNOzs7Ozs7R0FBVTs7Ozs7O0VBQzc5QixTQUFTLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQTBDO0VBQVM7Ozs7O0VBQzFFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFpQixjQUFXO2NBQW9CLGFBQWEsS0FBSyxZQUFZLHdCQUFDLFVBQUQ7S0FBUSxXQUFXLGFBQWEsVUFBVSxXQUFXO0tBQWtCLGVBQWUsY0FBYyxPQUFPO2VBQTNHLENBQStHLFNBQVEsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OzthQUFTO09BQXRGOzs7O1dBQXNGLENBQUM7R0FBTzs7OzthQUN6UCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsV0FBRDtNQUFTLElBQUc7TUFBa0IsV0FBVyxVQUFVLFNBQVM7Z0JBQTVELENBQStELHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF3QixlQUFlLFlBQVksU0FBUztpQkFBOUUsQ0FBaUYsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFNBQUQsWUFBTyxVQUFjOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7ZUFBTzs7OztpQkFBQyx3QkFBQyxLQUFELFlBQUksYUFBYSxZQUFZLE1BQU0sSUFBTzs7OztlQUFTOzs7OztnQkFBRSxlQUFlLFNBQVMsQ0FBVTs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFzQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUFvQyx3QkFBQyxTQUFELGFBQU8sUUFBSSx3QkFBQyxTQUFEO1NBQU8sVUFBVSxZQUFZO1NBQVcsT0FBTyxLQUFLO1NBQVUsV0FBVyxVQUFVLFFBQVE7VUFBRSxHQUFHO1VBQU0sVUFBVSxNQUFNLE9BQU87U0FBTSxDQUFDO1FBQUk7Ozs7Z0JBQVE7Ozs7a0JBQUMsd0JBQUMsU0FBRCxhQUFPLFNBQUssd0JBQUMsU0FBRDtTQUFPLFVBQVUsWUFBWTtTQUFXLE1BQUs7U0FBUSxPQUFPLEtBQUs7U0FBTyxXQUFXLFVBQVUsUUFBUTtVQUFFLEdBQUc7VUFBTSxPQUFPLE1BQU0sT0FBTztTQUFNLENBQUM7UUFBSTs7OztnQkFBUTs7OztnQkFBTTs7Ozs7aUJBQUUsWUFBWSxhQUFhLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQStCLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7O1NBQUMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBb0Msd0JBQUMsU0FBRCxhQUFPLG9CQUFnQix3QkFBQyxTQUFEO1lBQU8sTUFBSztZQUFXLE9BQU8sVUFBVTtZQUFTLFdBQVcsVUFBVSxhQUFhO2FBQUUsR0FBRzthQUFXLFNBQVMsTUFBTSxPQUFPO1lBQU0sQ0FBQztXQUFJOzs7O21CQUFROzs7OztXQUFDLHdCQUFDLFNBQUQsYUFBTyxnQkFBWSx3QkFBQyxTQUFEO1lBQU8sTUFBSztZQUFXLE9BQU8sVUFBVTtZQUFNLFdBQVcsVUFBVSxhQUFhO2FBQUUsR0FBRzthQUFXLE1BQU0sTUFBTSxPQUFPO1lBQU0sQ0FBQztXQUFJOzs7O21CQUFROzs7OztXQUFDLHdCQUFDLFNBQUQsYUFBTyx3QkFBb0Isd0JBQUMsU0FBRDtZQUFPLE1BQUs7WUFBVyxPQUFPLFVBQVU7WUFBUyxXQUFXLFVBQVUsYUFBYTthQUFFLEdBQUc7YUFBVyxTQUFTLE1BQU0sT0FBTztZQUFNLENBQUM7V0FBSTs7OzttQkFBUTs7Ozs7VUFBTTs7Ozs7O1NBQUMsd0JBQUMsTUFBRCxZQUFLLGNBQWMsS0FBSyxDQUFDLE1BQU0sU0FBUyx3QkFBQyxNQUFEO1VBQUksV0FBVyxNQUFNLFFBQVE7b0JBQTdCLENBQTRDLHdCQUFDLE1BQUQsRUFBTSxNQUFNLE1BQU0sVUFBVSxRQUFVOzs7O29CQUFFLElBQVM7WUFBdkQ7Ozs7Z0JBQXVELENBQUMsRUFBTTs7Ozs7UUFBTTs7Ozs7ZUFBTzs7Ozs7Y0FBVTs7Ozs7O0tBRS83Qyx3QkFBQyxXQUFEO01BQVMsSUFBRztNQUF1QixXQUFXLFVBQVUsY0FBYztnQkFBdEUsQ0FBeUUsd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQXdCLGVBQWUsWUFBWSxjQUFjO2lCQUFuRixDQUFzRix3QkFBQyxRQUFELGFBQU0sd0JBQUMsU0FBRCxZQUFPLGVBQW1COzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSSxnQkFBaUI7Ozs7ZUFBTzs7OztpQkFBQyx3QkFBQyxLQUFELFlBQUksYUFBYSxpQkFBaUIsTUFBTSxJQUFPOzs7O2VBQVM7Ozs7O2dCQUFFLGVBQWUsY0FBYyxDQUFVOzs7O2dCQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ3JVLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQXNDLHdCQUFDLFFBQUQsWUFBTSxRQUFXOzs7O21CQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFEO1VBQVEsVUFBVSxZQUFZO1VBQWdCLFdBQVcsS0FBSyxlQUFlLFdBQVcsV0FBVztVQUFJLGVBQWUsUUFBUTtXQUFFLEdBQUc7V0FBTSxZQUFZO1VBQVMsQ0FBQztvQkFBRztTQUFjOzs7O21CQUFDLHdCQUFDLFVBQUQ7VUFBUSxVQUFVLFlBQVk7VUFBZ0IsV0FBVyxLQUFLLGVBQWUsYUFBYSxXQUFXO1VBQUksZUFBZSxRQUFRO1dBQUUsR0FBRztXQUFNLFlBQVk7VUFBVyxDQUFDO29CQUFHO1NBQWdCOzs7O2lCQUFNOzs7O2lCQUFNOzs7Ozs7UUFDaGIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBeUMsd0JBQUMsU0FBRCxhQUFPLE9BQUcsd0JBQUMsU0FBRDtXQUFPLFVBQVUsWUFBWTtXQUFnQixNQUFLO1dBQVMsT0FBTyxLQUFLO1dBQUssV0FBVyxVQUFVLFFBQVE7WUFBRSxHQUFHO1lBQU0sS0FBSyxNQUFNLE9BQU87V0FBTSxDQUFDO1VBQUk7Ozs7a0JBQVE7Ozs7O1VBQUMsd0JBQUMsU0FBRDtXQUFPO1dBQVMsS0FBSyxlQUFlLFdBQVcsT0FBTztXQUFVO1dBQUMsd0JBQUMsU0FBRDtZQUFPLFVBQVUsWUFBWTtZQUFnQixNQUFNLEtBQUssZUFBZSxXQUFXLFdBQVc7WUFBUSxhQUFhLEtBQUssZUFBZSxXQUFXLFFBQVE7WUFBYSxPQUFPLEtBQUs7WUFBUSxXQUFXLFVBQVUsUUFBUTthQUFFLEdBQUc7YUFBTSxRQUFRLE1BQU0sT0FBTztZQUFNLENBQUM7V0FBSTs7Ozs7VUFBUTs7Ozs7VUFBQyx3QkFBQyxTQUFEO1dBQU87V0FBaUIsS0FBSyxlQUFlLFdBQVcsT0FBTztXQUFLO1dBQUMsd0JBQUMsU0FBRDtZQUFPLFVBQVUsWUFBWTtZQUFnQixNQUFLO1lBQVMsT0FBTyxLQUFLO1lBQVEsV0FBVyxVQUFVLFFBQVE7YUFBRSxHQUFHO2FBQU0sUUFBUSxNQUFNLE9BQU87WUFBTSxDQUFDO1dBQUk7Ozs7O1VBQVE7Ozs7O1VBQUMsd0JBQUMsU0FBRCxhQUFPLGlCQUFhLHdCQUFDLFNBQUQ7V0FBTyxVQUFVLFlBQVk7V0FBZ0IsTUFBSztXQUFTLE9BQU8sS0FBSztXQUFjLFdBQVcsVUFBVSxRQUFRO1lBQUUsR0FBRztZQUFNLGNBQWMsTUFBTSxPQUFPO1dBQU0sQ0FBQztVQUFJOzs7O2tCQUFROzs7OztTQUFNOzs7Ozs7UUFDbDhCLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQWtDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OzttQkFBQyx3QkFBQyxVQUFEO1VBQVEsZUFBZSxlQUFlLFlBQVk7VUFBRyxjQUFXO29CQUEyQjtTQUFTOzs7O2lCQUFNOzs7Ozs7UUFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBdUI7VUFBQyxDQUFDLGFBQWEsd0JBQXdCO1VBQUcsQ0FBQyxhQUFhLDBCQUEwQjtVQUFHLENBQUMsYUFBYSx5QkFBeUI7VUFBRyxDQUFDLFlBQVksc0JBQXNCO1NBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLFVBQVUsd0JBQUMsVUFBRDtVQUFRLFVBQVUsWUFBWTtVQUFnQixXQUFXLEtBQUssZUFBZSxPQUFPLFdBQVc7VUFBZSxlQUFlLFFBQVE7V0FBRSxHQUFHO1dBQU0sWUFBWTtVQUFLLENBQUM7b0JBQWxLLENBQXFLLHdCQUFDLFVBQUQsWUFBUyxLQUFhOzs7O29CQUFDLHdCQUFDLFNBQUQsWUFBUSxLQUFZOzs7O2tCQUFTO1lBQWpIOzs7O2dCQUFpSCxDQUFDO1FBQU87Ozs7O1FBQ3RtQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUEwQyx3QkFBQyxTQUFELGFBQU8sZ0JBQVksd0JBQUMsVUFBRDtXQUFRLFVBQVUsWUFBWTtXQUFnQixPQUFPLEtBQUs7V0FBTSxXQUFXLFVBQVUsUUFBUTtZQUFFLEdBQUc7WUFBTSxNQUFNLE1BQU0sT0FBTztXQUFNLENBQUM7cUJBQWxJO1lBQXFJLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFHO1lBQXFCOzs7OztZQUFDLHdCQUFDLFVBQUQsWUFBUSxzQkFBMkI7Ozs7O1lBQUMsd0JBQUMsVUFBRCxZQUFRLDBCQUErQjs7Ozs7WUFBQyx3QkFBQyxVQUFELFlBQVEscUJBQTBCOzs7OztXQUFTOzs7OztrQkFBUTs7Ozs7VUFBQyx3QkFBQyxTQUFELGFBQU8sb0JBQWdCLHdCQUFDLFVBQUQ7V0FBUSxVQUFVLFlBQVk7V0FBZ0IsT0FBTyxLQUFLO1dBQVksV0FBVyxVQUFVLFFBQVE7WUFBRSxHQUFHO1lBQU0sWUFBWSxNQUFNLE9BQU87V0FBTSxDQUFDO3FCQUE5STtZQUFpSix3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBRztZQUF5Qjs7Ozs7WUFBQyx3QkFBQyxVQUFELFlBQVEsZUFBb0I7Ozs7O1lBQUMsd0JBQUMsVUFBRCxZQUFRLGtCQUF1Qjs7Ozs7WUFBQyx3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7O1dBQVM7Ozs7O2tCQUFROzs7OztVQUFDLHdCQUFDLFNBQUQsYUFBTyxrQkFBYyx3QkFBQyxVQUFEO1dBQVEsVUFBVSxZQUFZO1dBQWdCLE9BQU8sS0FBSztXQUFlLFdBQVcsVUFBVSxRQUFRO1lBQUUsR0FBRztZQUFNLGVBQWUsTUFBTSxPQUFPO1dBQU0sQ0FBQztxQkFBcEo7WUFBdUosd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQUc7WUFBdUI7Ozs7O1lBQUMsd0JBQUMsVUFBRCxZQUFRLFlBQWlCOzs7OztZQUFDLHdCQUFDLFVBQUQsWUFBUSxtQkFBd0I7Ozs7O1lBQUMsd0JBQUMsVUFBRCxZQUFRLG9CQUF5Qjs7Ozs7WUFBQyx3QkFBQyxVQUFELFlBQVEsY0FBbUI7Ozs7O1dBQVM7Ozs7O2tCQUFROzs7OztTQUFNOzs7Ozs7UUFBRSxlQUFlLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFjO1FBQTZIOzs7OztPQUMvcUM7Ozs7O2NBQVU7Ozs7OztLQUVmLHdCQUFDLFdBQUQ7TUFBUyxJQUFHO01BQW1CLFdBQVcsVUFBVSxVQUFVO2dCQUE5RCxDQUFpRSx3QkFBQyxVQUFELGFBQVEsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBd0IsZUFBZSxZQUFZLFVBQVU7aUJBQS9FLENBQWtGLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxTQUFELFlBQU8sV0FBZTs7OztpQkFBQyx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7O2VBQU87Ozs7aUJBQUMsd0JBQUMsS0FBRCxZQUFJLGFBQWEsYUFBYSxNQUFNLElBQU87Ozs7ZUFBUzs7Ozs7Z0JBQUUsZUFBZSxVQUFVLENBQVU7Ozs7Z0JBQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBc0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBMEMsd0JBQUMsU0FBRCxhQUFPLGFBQVMsd0JBQUMsVUFBRDtVQUFRLFVBQVUsWUFBWTtVQUFZLE9BQU8sS0FBSztVQUFXLFdBQVcsVUFBVSxRQUFRO1dBQUUsR0FBRztXQUFNLFdBQVcsTUFBTSxPQUFPO1VBQU0sQ0FBQztvQkFBeEk7V0FBMkksd0JBQUMsVUFBRCxZQUFRLHlCQUE4Qjs7Ozs7V0FBQyx3QkFBQyxVQUFELFlBQVEsb0JBQXlCOzs7OztXQUFDLHdCQUFDLFVBQUQsWUFBUSxrQkFBdUI7Ozs7O1VBQVM7Ozs7O2lCQUFROzs7OztTQUFDLHdCQUFDLFNBQUQsYUFBTyx5QkFBcUIsd0JBQUMsU0FBRDtVQUFPLFVBQVUsWUFBWTtVQUFZLE1BQUs7VUFBUyxLQUFJO1VBQUksS0FBSTtVQUFJLE9BQU8sVUFBVTtVQUFhLFdBQVcsVUFBVSxhQUFhO1dBQUUsR0FBRztXQUFXLGFBQWEsT0FBTyxNQUFNLE9BQU8sS0FBSztVQUFFLENBQUM7U0FBSTs7OztpQkFBUTs7Ozs7U0FBQyx3QkFBQyxTQUFELGFBQU8sb0JBQWdCLHdCQUFDLFVBQUQ7VUFBUSxVQUFVLFlBQVk7VUFBWSxPQUFPO1VBQWdCLFdBQVcsVUFBVSxrQkFBa0IsTUFBTSxPQUFPLEtBQUs7b0JBQTFIO1dBQTZILHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFLO1dBQWtCOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFLO1dBQWtCOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFLO1dBQWtCOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFLO1dBQWtCOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFTO1dBQWlCOzs7OztVQUFTOzs7OztpQkFBUTs7Ozs7U0FBRSxtQkFBbUIsWUFBWSx3QkFBQyxTQUFELGFBQU8sa0JBQWMsd0JBQUMsU0FBRDtVQUFPLFVBQVUsWUFBWTtVQUFZLE1BQUs7VUFBUyxLQUFJO1VBQUksS0FBSTtVQUFNLE9BQU87VUFBZ0IsV0FBVyxVQUFVLGtCQUFrQixNQUFNLE9BQU8sS0FBSztTQUFJOzs7O2lCQUFROzs7OztTQUFFLHdCQUFDLFNBQUQsYUFBTyxvQkFBZ0Isd0JBQUMsU0FBRDtVQUFPO1VBQVMsT0FBTyxHQUFHLFVBQVUsT0FBTztTQUFTOzs7O2lCQUFROzs7OztRQUFNOzs7OztpQkFBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUE0Qix3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFRLG9CQUF5Qjs7OztrQkFBQyx3QkFBQyxRQUFELFlBQU0seUNBQTRDOzs7O2dCQUFNOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxlQUFlLGVBQWUsSUFBSTttQkFBRztRQUF5Qjs7OztnQkFBTTs7Ozs7ZUFBTTs7Ozs7Y0FBVTs7Ozs7O0tBRXB2RCx3QkFBQyxXQUFEO01BQVMsSUFBRztNQUF3QixXQUFXLFVBQVUsaUJBQWlCO2dCQUExRSxDQUE2RSx3QkFBQyxVQUFELGFBQVEsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBd0IsZUFBZSxZQUFZLGlCQUFpQjtpQkFBdEYsQ0FBeUYsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFNBQUQsWUFBTyxrQkFBc0I7Ozs7aUJBQUMsd0JBQUMsTUFBRCxZQUFJLHVCQUF3Qjs7OztlQUFPOzs7O2lCQUFDLHdCQUFDLEtBQUQsWUFBSSxhQUFhLG9CQUFvQixNQUFNLElBQU87Ozs7ZUFBUzs7Ozs7Z0JBQUUsZUFBZSxpQkFBaUIsQ0FBVTs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFzQyx3QkFBQyxnQkFBRDtRQUFnQixXQUFVO1FBQWlDLFVBQVUsWUFBWTtRQUFtQixTQUFTLEtBQUs7UUFBWSxXQUFXLFlBQVksUUFBUTtTQUFFLEdBQUc7U0FBTSxZQUFZO1FBQVEsQ0FBQztrQkFBRyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFRLHVDQUE0Qzs7OztrQkFBQyx3QkFBQyxTQUFELFlBQU8sK0NBQW1EOzs7O2dCQUFPOzs7OztPQUFpQjs7OztpQkFBQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBb0I7T0FBb0k7Ozs7ZUFBTTs7Ozs7Y0FBVTs7Ozs7O0tBRXY0Qix3QkFBQyxXQUFEO01BQVMsSUFBRztNQUF3QixXQUFXLFVBQVUsZUFBZTtnQkFBeEUsQ0FBMkUsd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQXdCLGVBQWUsWUFBWSxlQUFlO2lCQUFwRixDQUF1Rix3QkFBQyxRQUFELGFBQU0sd0JBQUMsU0FBRCxZQUFPLGdCQUFvQjs7OztpQkFBQyx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7O2VBQU87Ozs7aUJBQUMsd0JBQUMsS0FBRCxZQUFJLGFBQWEsa0JBQWtCLE1BQU0sSUFBTzs7OztlQUFTOzs7OztnQkFBRSxlQUFlLGVBQWUsQ0FBVTs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBdUIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBbUMsd0JBQUMsZ0JBQUQ7VUFBZ0IsV0FBVTtVQUFzQixVQUFVLFlBQVk7VUFBaUIsU0FBUyxZQUFZO1VBQWtCLFdBQVcsWUFBWSxlQUFlO1dBQUUsR0FBRztXQUFhLGtCQUFrQjtVQUFRLENBQUM7b0JBQUcsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxvQkFBeUI7Ozs7b0JBQUMsd0JBQUMsU0FBRCxZQUFPLHNDQUEwQzs7OztrQkFBTzs7Ozs7U0FBaUI7Ozs7O1NBQUUsWUFBWSxvQkFBb0Isd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQWlDLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7b0JBQUMsd0JBQUMsU0FBRDtXQUFPLFVBQVUsWUFBWTtXQUFpQixNQUFLO1dBQU8sT0FBTyxZQUFZO1dBQWMsV0FBVyxVQUFVLGVBQWU7WUFBRSxHQUFHO1lBQWEsY0FBYyxNQUFNLE9BQU87V0FBTSxDQUFDO1VBQUk7Ozs7a0JBQVE7Ozs7OztTQUFFLHdCQUFDLGdCQUFEO1VBQWdCLFdBQVU7VUFBc0IsVUFBVSxZQUFZO1VBQWlCLFNBQVMsWUFBWTtVQUFpQixXQUFXLFlBQVksZUFBZTtXQUFFLEdBQUc7V0FBYSxpQkFBaUI7VUFBUSxDQUFDO29CQUFHLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsbUJBQXdCOzs7O29CQUFDLHdCQUFDLFNBQUQsWUFBTyw4Q0FBa0Q7Ozs7a0JBQU87Ozs7O1NBQWlCOzs7OztTQUFDLHdCQUFDLGdCQUFEO1VBQWdCLFdBQVU7VUFBc0IsVUFBVSxZQUFZO1VBQWlCLFNBQVMsWUFBWTtVQUFlLFdBQVcsWUFBWSxlQUFlO1dBQUUsR0FBRztXQUFhLGVBQWU7VUFBUSxDQUFDO29CQUFHLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsNEJBQWlDOzs7O29CQUFDLHdCQUFDLFNBQUQsWUFBTyx1Q0FBMkM7Ozs7a0JBQU87Ozs7O1NBQWlCOzs7OztRQUFNOzs7Ozs7TUFBTTs7OztjQUFVOzs7Ozs7S0FFbHFELHdCQUFDLFdBQUQ7TUFBUyxJQUFHO01BQXVCLFdBQVcsVUFBVSxnQkFBZ0I7Z0JBQXhFLENBQTJFLHdCQUFDLFVBQUQsWUFBUSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF3QixlQUFlLFlBQVksZ0JBQWdCO2lCQUFyRixDQUF3Rix3QkFBQyxRQUFELGFBQU0sd0JBQUMsU0FBRCxZQUFPLGlCQUFxQjs7OztpQkFBQyx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7O2VBQU87Ozs7aUJBQUMsd0JBQUMsS0FBRCxZQUFJLGFBQWEsbUJBQW1CLE1BQU0sSUFBTzs7OztlQUFTOzs7OztlQUFTOzs7O2dCQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQXNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQW1DLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7bUJBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSxtQ0FBd0M7Ozs7bUJBQUMsd0JBQUMsUUFBRCxZQUFNLG1FQUFzRTs7OztpQkFBTTs7OztpQkFBTTs7Ozs7O1FBQUMsd0JBQUMsVUFBRDtTQUFRLFdBQVU7U0FBcUIsU0FBUzttQkFBaEQsQ0FBOEQsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxtQkFBd0I7Ozs7bUJBQUMsd0JBQUMsU0FBRCxZQUFPLDRDQUFnRDs7OztpQkFBTzs7OzttQkFBQyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O2lCQUFTOzs7Ozs7UUFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUE2Qix3QkFBQyxVQUFELFlBQVEsb0JBQXlCOzs7OztVQUFDLHdCQUFDLEtBQUQsWUFBRyw0REFBNEQ7Ozs7O1VBQUUsYUFBYSx3QkFBQyxPQUFEO1dBQUssd0JBQUMsU0FBRCxhQUFPLDBCQUFzQix3QkFBQyxTQUFEO1lBQU8sT0FBTztZQUFZLFdBQVcsVUFBVSxjQUFjLE1BQU0sT0FBTyxLQUFLO1dBQUk7Ozs7bUJBQVE7Ozs7O1dBQUMsd0JBQUMsUUFBRDtZQUFRLFNBQVE7WUFBUSxVQUFVLGVBQWU7WUFBVSxTQUFTO3NCQUFVO1dBQXlCOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxlQUFlO2FBQUUsY0FBYyxLQUFLO2FBQUcsY0FBYyxFQUFFO1lBQUc7c0JBQUc7V0FBYzs7Ozs7VUFBTTs7OztxQkFBSSx3QkFBQyxVQUFEO1dBQVEsZUFBZSxjQUFjLElBQUk7cUJBQUc7VUFBeUI7Ozs7O1NBQU87Ozs7OztPQUFNOzs7OztjQUFVOzs7Ozs7S0FFOXdDLHdCQUFDLFdBQUQ7TUFBUyxJQUFHO01BQWUsV0FBVyxVQUFVLE1BQU07Z0JBQXRELENBQXlELHdCQUFDLFVBQUQsWUFBUSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUF3QixlQUFlLFlBQVksTUFBTTtpQkFBM0UsQ0FBOEUsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFNBQUQsWUFBTyxPQUFXOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7O2VBQU87Ozs7aUJBQUMsd0JBQUMsS0FBRCxZQUFJLGFBQWEsU0FBUyxNQUFNLElBQU87Ozs7ZUFBUzs7Ozs7ZUFBUzs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUF5RCx3QkFBQyxVQUFEO1NBQVEsZUFBZSxlQUFlO21CQUF0QyxDQUF5Qyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFRLFdBQWdCOzs7O21CQUFDLHdCQUFDLFNBQUQsWUFBTyxnQ0FBb0M7Ozs7aUJBQU87Ozs7bUJBQUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztpQkFBUzs7Ozs7O1FBQUMsd0JBQUMsS0FBRDtTQUFHLE1BQUs7bUJBQVIsQ0FBMkMsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxnQkFBcUI7Ozs7bUJBQUMsd0JBQUMsU0FBRCxZQUFPLDJDQUErQzs7OztpQkFBTzs7OzttQkFBQyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O2lCQUFJOzs7Ozs7UUFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxpQkFBc0I7Ozs7a0JBQUMsd0JBQUMsU0FBRCxZQUFPLHNEQUEwRDs7OztnQkFBTzs7OztrQkFBQyx3QkFBQyxLQUFELFlBQUcsY0FBYzs7OztnQkFBTTs7Ozs7T0FBTTs7Ozs7Y0FBVTs7Ozs7O0lBQzF3Qjs7Ozs7V0FDRjs7Ozs7O0VBQ0osZUFBZSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUEwQix3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFhLE1BQUs7SUFBUyxjQUFXO2NBQXJEO0tBQTRELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFpQix3QkFBQyxNQUFELEVBQU0sTUFBSyxXQUFZOzs7OztLQUFPOzs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSSxxQkFBc0I7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFHLHlIQUF5SDs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQVEsU0FBUztnQkFBa0I7S0FBd0I7Ozs7O0tBQUMsd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBUSxlQUFlLGVBQWUsS0FBSztnQkFBRztLQUFjOzs7OztJQUFNOzs7Ozs7RUFBTTs7Ozs7Q0FDamU7Ozs7O0FBQ0oiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZmlsZVBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEN1c3RvbUNoZWNrYm94IH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQ3VzdG9tQ2hlY2tib3hcIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcclxuaW1wb3J0IHsgY3JlYXRlRml0bmVzc1N0b3JlIH0gZnJvbSBcIi4uL2ZpdG5lc3NTdG9yZVwiO1xyXG5pbXBvcnQgdHlwZSB7IEZpdG5lc3NTdG9yZSB9IGZyb20gXCIuLi9maXRuZXNzU3RvcmVcIjtcclxuaW1wb3J0IHsgcGFyc2VIZWlnaHRDbSwgcGFyc2VXZWlnaHRLZywgcHJldHR5RGF0ZSB9IGZyb20gXCIuLi9saWIvZm9ybWF0XCI7XHJcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGlcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9maWxlUGFnZSh7IHN0b3JlLCB1cGRhdGUsIHRvYXN0LCBvbkxvZ291dCwgb25PcGVuR2xvc3NhcnkgfTogeyBzdG9yZTogRml0bmVzc1N0b3JlOyB1cGRhdGU6IChuZXh0OiBGaXRuZXNzU3RvcmUpID0+IGJvb2xlYW47IHRvYXN0OiAobWVzc2FnZTogc3RyaW5nLCBlcnJvcj86IGJvb2xlYW4pID0+IHZvaWQ7IG9uTG9nb3V0OiAoKSA9PiB2b2lkOyBvbk9wZW5HbG9zc2FyeTogKHRlcm0/OiBzdHJpbmcpID0+IHZvaWQgfSkge1xyXG4gIGNvbnN0IHNlY3Rpb25OYW1lcyA9IFtcIkFjY291bnRcIiwgXCJCb2R5IHByb2ZpbGVcIiwgXCJUcmFpbmluZ1wiLCBcIkhlYWx0aCAmIHNhZmV0eVwiLCBcIk5vdGlmaWNhdGlvbnNcIiwgXCJQcml2YWN5ICYgZGF0YVwiLCBcIkhlbHBcIl0gYXMgY29uc3Q7XHJcbiAgdHlwZSBTZWN0aW9uTmFtZSA9IHR5cGVvZiBzZWN0aW9uTmFtZXNbbnVtYmVyXTtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShzdG9yZS51c2VyKTtcclxuICBjb25zdCBbY2hhbGxlbmdlLCBzZXRDaGFsbGVuZ2VdID0gdXNlU3RhdGUoc3RvcmUuY2hhbGxlbmdlKTtcclxuICBjb25zdCBbcHJlZmVyZW5jZXMsIHNldFByZWZlcmVuY2VzXSA9IHVzZVN0YXRlKHN0b3JlLnByZWZlcmVuY2VzKTtcclxuICBjb25zdCBbZWRpdGluZywgc2V0RWRpdGluZ10gPSB1c2VTdGF0ZTxTZWN0aW9uTmFtZSB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtleHBhbmRlZCwgc2V0RXhwYW5kZWRdID0gdXNlU3RhdGU8U2VjdGlvbk5hbWU+KFwiQWNjb3VudFwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZHMsIHNldFBhc3N3b3Jkc10gPSB1c2VTdGF0ZSh7IGN1cnJlbnQ6IFwiXCIsIG5leHQ6IFwiXCIsIGNvbmZpcm06IFwiXCIgfSk7XHJcbiAgY29uc3QgW3Nob3dSZXN0YXJ0LCBzZXRTaG93UmVzdGFydF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2RlbGV0ZVRleHQsIHNldERlbGV0ZVRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dEZWxldGUsIHNldFNob3dEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGF2YXRhcklucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xyXG4gIGNvbnN0IFtkdXJhdGlvbkNob2ljZSwgc2V0RHVyYXRpb25DaG9pY2VdID0gdXNlU3RhdGUoWzE1LCAzMCwgNDUsIDYwXS5pbmNsdWRlcyhjaGFsbGVuZ2Uuc2Vzc2lvbk1pbnV0ZXMpID8gU3RyaW5nKGNoYWxsZW5nZS5zZXNzaW9uTWludXRlcykgOiBcImN1c3RvbVwiKTtcclxuICBjb25zdCBbY3VzdG9tRHVyYXRpb24sIHNldEN1c3RvbUR1cmF0aW9uXSA9IHVzZVN0YXRlKFsxNSwgMzAsIDQ1LCA2MF0uaW5jbHVkZXMoY2hhbGxlbmdlLnNlc3Npb25NaW51dGVzKSA/IFwiXCIgOiBTdHJpbmcoY2hhbGxlbmdlLnNlc3Npb25NaW51dGVzKSk7XHJcbiAgY29uc3QgY2hhbGxlbmdlRGF5ID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oY2hhbGxlbmdlLmxlbmd0aCwgTWF0aC5mbG9vcigoRGF0ZS5ub3coKSAtIG5ldyBEYXRlKGAke2NoYWxsZW5nZS5zdGFydERhdGV9VDEyOjAwOjAwYCkuZ2V0VGltZSgpKSAvIDg2XzQwMF8wMDApICsgMSkpO1xyXG4gIGNvbnN0IGluaXRpYWxzID0gdXNlci51c2VybmFtZS5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsIDIpLm1hcCgocGFydCkgPT4gcGFydFswXSkuam9pbihcIlwiKS50b1VwcGVyQ2FzZSgpO1xyXG4gIGNvbnN0IHBhc3N3b3JkUnVsZXMgPSBbXHJcbiAgICBbXCJBdCBsZWFzdCA4IGNoYXJhY3RlcnNcIiwgcGFzc3dvcmRzLm5leHQubGVuZ3RoID49IDhdLFxyXG4gICAgW1wiT25lIHVwcGVyY2FzZSBsZXR0ZXJcIiwgL1tBLVpdLy50ZXN0KHBhc3N3b3Jkcy5uZXh0KV0sXHJcbiAgICBbXCJPbmUgbG93ZXJjYXNlIGxldHRlclwiLCAvW2Etel0vLnRlc3QocGFzc3dvcmRzLm5leHQpXSxcclxuICAgIFtcIk9uZSBudW1iZXJcIiwgL1xcZC8udGVzdChwYXNzd29yZHMubmV4dCldLFxyXG4gIF0gYXMgY29uc3Q7XHJcbiAgY29uc3QgY2FuY2VsID0gKCkgPT4ge1xyXG4gICAgc2V0VXNlcihzdG9yZS51c2VyKTtcclxuICAgIHNldENoYWxsZW5nZShzdG9yZS5jaGFsbGVuZ2UpO1xyXG4gICAgc2V0UHJlZmVyZW5jZXMoc3RvcmUucHJlZmVyZW5jZXMpO1xyXG4gICAgc2V0UGFzc3dvcmRzKHsgY3VycmVudDogXCJcIiwgbmV4dDogXCJcIiwgY29uZmlybTogXCJcIiB9KTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgc2V0RWRpdGluZyhudWxsKTtcclxuICB9O1xyXG4gIGNvbnN0IHNhdmUgPSBhc3luYyAoc2VjdGlvbjogU2VjdGlvbk5hbWUpID0+IHtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgaWYgKHNlY3Rpb24gPT09IFwiQWNjb3VudFwiKSB7XHJcbiAgICAgIGlmICghdXNlci51c2VybmFtZS50cmltKCkgfHwgIS9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QodXNlci5lbWFpbCkpIHJldHVybiBzZXRFcnJvcihcIkVudGVyIGEgbmFtZSBhbmQgdmFsaWQgZW1haWwuXCIpO1xyXG4gICAgICBpZiAocGFzc3dvcmRzLmN1cnJlbnQgfHwgcGFzc3dvcmRzLm5leHQgfHwgcGFzc3dvcmRzLmNvbmZpcm0pIHtcclxuICAgICAgICBpZiAoIXBhc3N3b3Jkcy5jdXJyZW50KSByZXR1cm4gc2V0RXJyb3IoXCJFbnRlciB5b3VyIGN1cnJlbnQgcGFzc3dvcmQuXCIpO1xyXG4gICAgICAgIGlmICghcGFzc3dvcmRSdWxlcy5ldmVyeSgocnVsZSkgPT4gcnVsZVsxXSkpIHJldHVybiBzZXRFcnJvcihcIllvdXIgbmV3IHBhc3N3b3JkIGRvZXMgbm90IG1lZXQgYWxsIHRoZSBydWxlcy5cIik7XHJcbiAgICAgICAgaWYgKHBhc3N3b3Jkcy5uZXh0ICE9PSBwYXNzd29yZHMuY29uZmlybSkgcmV0dXJuIHNldEVycm9yKFwiTmV3IHBhc3N3b3JkcyBkbyBub3QgbWF0Y2guXCIpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoc2VjdGlvbiA9PT0gXCJCb2R5IHByb2ZpbGVcIikge1xyXG4gICAgICBjb25zdCBhZ2VWYWx1ZSA9IE51bWJlcih1c2VyLmFnZSk7XHJcbiAgICAgIGNvbnN0IGhlaWdodENtID0gcGFyc2VIZWlnaHRDbSh1c2VyLmhlaWdodCwgdXNlci51bml0U3lzdGVtKTtcclxuICAgICAgY29uc3Qgd2VpZ2h0S2cgPSBwYXJzZVdlaWdodEtnKHVzZXIud2VpZ2h0LCB1c2VyLnVuaXRTeXN0ZW0pO1xyXG4gICAgICBjb25zdCB0YXJnZXRLZyA9IHVzZXIudGFyZ2V0V2VpZ2h0ID8gcGFyc2VXZWlnaHRLZyh1c2VyLnRhcmdldFdlaWdodCwgdXNlci51bml0U3lzdGVtKSA6IDA7XHJcbiAgICAgIGlmICghYWdlVmFsdWUgfHwgYWdlVmFsdWUgPCAxMCB8fCBhZ2VWYWx1ZSA+IDEwMCkgcmV0dXJuIHNldEVycm9yKFwiQWdlIG11c3QgYmUgYmV0d2VlbiAxMCBhbmQgMTAwLlwiKTtcclxuICAgICAgaWYgKCFoZWlnaHRDbSB8fCBoZWlnaHRDbSA8IDEwMCB8fCBoZWlnaHRDbSA+IDI1MCkgcmV0dXJuIHNldEVycm9yKGBIZWlnaHQgbXVzdCBiZSBiZXR3ZWVuICR7dXNlci51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCIxMDDigJMyNTAgY21cIiA6IFwiYXBwcm94aW1hdGVseSAzIGZ0IDMgaW7igJM4IGZ0IDIgaW5cIn0uYCk7XHJcbiAgICAgIGlmICghd2VpZ2h0S2cgfHwgd2VpZ2h0S2cgPCAyNSB8fCB3ZWlnaHRLZyA+IDMwMCB8fCAodGFyZ2V0S2cgJiYgKHRhcmdldEtnIDwgMjUgfHwgdGFyZ2V0S2cgPiAzMDApKSkgcmV0dXJuIHNldEVycm9yKGBXZWlnaHQgbXVzdCBiZSBiZXR3ZWVuICR7dXNlci51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCIyNeKAkzMwMCBrZ1wiIDogXCI1NeKAkzY2MSBsYlwifS5gKTtcclxuICAgICAgaWYgKCF1c2VyLnNvbWF0b3R5cGUgfHwgIXVzZXIuZ29hbCB8fCAhdXNlci5leHBlcmllbmNlIHx8ICF1c2VyLmFjdGl2aXR5TGV2ZWwpIHJldHVybiBzZXRFcnJvcihcIkNvbXBsZXRlIGVhY2ggYm9keSBwcm9maWxlIHNlbGVjdGlvbi5cIik7XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5zYXZlT25ib2FyZGluZyh7XHJcbiAgICAgICAgICBuYW1lOiB1c2VyLnVzZXJuYW1lLFxyXG4gICAgICAgICAgYWdlOiB1c2VyLmFnZSxcclxuICAgICAgICAgIGhlaWdodDogdXNlci5oZWlnaHQsXHJcbiAgICAgICAgICBjdXJyZW50V2VpZ2h0OiB1c2VyLndlaWdodCxcclxuICAgICAgICAgIHRhcmdldFdlaWdodDogdXNlci50YXJnZXRXZWlnaHQsXHJcbiAgICAgICAgICB1bml0U3lzdGVtOiB1c2VyLnVuaXRTeXN0ZW0sXHJcbiAgICAgICAgICBzb21hdG90eXBlOiB1c2VyLnNvbWF0b3R5cGUsXHJcbiAgICAgICAgICBnb2FsOiB1c2VyLmdvYWwsXHJcbiAgICAgICAgICBleHBlcmllbmNlOiB1c2VyLmV4cGVyaWVuY2UsXHJcbiAgICAgICAgICBhY3Rpdml0eTogdXNlci5hY3Rpdml0eUxldmVsLFxyXG4gICAgICAgICAgd29ya291dERheXM6IFN0cmluZyhjaGFsbGVuZ2UuZGF5c1BlcldlZWspLFxyXG4gICAgICAgICAgc2Vzc2lvbkxlbmd0aDogU3RyaW5nKGNoYWxsZW5nZS5zZXNzaW9uTWludXRlcyksXHJcbiAgICAgICAgICBmb2N1c0FyZWE6IFwiR2VuZXJhbCBGaXRuZXNzXCIsXHJcbiAgICAgICAgICBtb2RlOiBcIlN0YW5kYXJkXCIsXHJcbiAgICAgICAgICBlcXVpcG1lbnQ6IHVzZXIuZXF1aXBtZW50LFxyXG4gICAgICAgICAgY2hhbGxlbmdlRGF5czogY2hhbGxlbmdlLmxlbmd0aCBhcyA2MCB8IDkwLFxyXG4gICAgICAgICAgaGFzQ29uZGl0aW9uOiB1c2VyLmluanVyeUZsYWcsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc3luYyBib2R5IHByb2ZpbGUgd2l0aCBiYWNrZW5kOlwiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoc2VjdGlvbiA9PT0gXCJUcmFpbmluZ1wiKSB7XHJcbiAgICAgIGNvbnN0IG1pbnV0ZXMgPSBkdXJhdGlvbkNob2ljZSA9PT0gXCJjdXN0b21cIiA/IE51bWJlcihjdXN0b21EdXJhdGlvbikgOiBOdW1iZXIoZHVyYXRpb25DaG9pY2UpO1xyXG4gICAgICBpZiAoY2hhbGxlbmdlLmRheXNQZXJXZWVrIDwgMiB8fCBjaGFsbGVuZ2UuZGF5c1BlcldlZWsgPiA2IHx8IG1pbnV0ZXMgPCA1IHx8IG1pbnV0ZXMgPiAxODApIHJldHVybiBzZXRFcnJvcihcIkNob29zZSAy4oCTNiB3b3Jrb3V0IGRheXMgYW5kIGEgc2Vzc2lvbiBkdXJhdGlvbiBmcm9tIDXigJMxODAgbWludXRlcy5cIik7XHJcbiAgICAgIHNldENoYWxsZW5nZSh7IC4uLmNoYWxsZW5nZSwgc2Vzc2lvbk1pbnV0ZXM6IG1pbnV0ZXMgfSk7XHJcbiAgICAgIFxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5zYXZlT25ib2FyZGluZyh7XHJcbiAgICAgICAgICBuYW1lOiB1c2VyLnVzZXJuYW1lLFxyXG4gICAgICAgICAgYWdlOiB1c2VyLmFnZSxcclxuICAgICAgICAgIGhlaWdodDogdXNlci5oZWlnaHQsXHJcbiAgICAgICAgICBjdXJyZW50V2VpZ2h0OiB1c2VyLndlaWdodCxcclxuICAgICAgICAgIHRhcmdldFdlaWdodDogdXNlci50YXJnZXRXZWlnaHQsXHJcbiAgICAgICAgICB1bml0U3lzdGVtOiB1c2VyLnVuaXRTeXN0ZW0sXHJcbiAgICAgICAgICBzb21hdG90eXBlOiB1c2VyLnNvbWF0b3R5cGUsXHJcbiAgICAgICAgICBnb2FsOiB1c2VyLmdvYWwsXHJcbiAgICAgICAgICBleHBlcmllbmNlOiB1c2VyLmV4cGVyaWVuY2UsXHJcbiAgICAgICAgICBhY3Rpdml0eTogdXNlci5hY3Rpdml0eUxldmVsLFxyXG4gICAgICAgICAgd29ya291dERheXM6IFN0cmluZyhjaGFsbGVuZ2UuZGF5c1BlcldlZWspLFxyXG4gICAgICAgICAgc2Vzc2lvbkxlbmd0aDogU3RyaW5nKG1pbnV0ZXMpLFxyXG4gICAgICAgICAgZm9jdXNBcmVhOiBcIkdlbmVyYWwgRml0bmVzc1wiLFxyXG4gICAgICAgICAgbW9kZTogXCJTdGFuZGFyZFwiLFxyXG4gICAgICAgICAgZXF1aXBtZW50OiB1c2VyLmVxdWlwbWVudCxcclxuICAgICAgICAgIGNoYWxsZW5nZURheXM6IGNoYWxsZW5nZS5sZW5ndGggYXMgNjAgfCA5MCxcclxuICAgICAgICAgIGhhc0NvbmRpdGlvbjogdXNlci5pbmp1cnlGbGFnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHN5bmMgdHJhaW5pbmcgcHJlZmVyZW5jZXMgd2l0aCBiYWNrZW5kOlwiLCBlcnIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoIXVwZGF0ZSh7IC4uLnN0b3JlLCB1c2VyLCBjaGFsbGVuZ2U6IHsgLi4uY2hhbGxlbmdlLCBzZXNzaW9uTWludXRlczogbWludXRlcyB9LCBwcmVmZXJlbmNlcyB9KSkgcmV0dXJuO1xyXG4gICAgfSBlbHNlIGlmICghdXBkYXRlKHsgLi4uc3RvcmUsIHVzZXIsIGNoYWxsZW5nZSwgcHJlZmVyZW5jZXMgfSkpIHJldHVybjtcclxuICAgIHNldFBhc3N3b3Jkcyh7IGN1cnJlbnQ6IFwiXCIsIG5leHQ6IFwiXCIsIGNvbmZpcm06IFwiXCIgfSk7XHJcbiAgICBzZXRFZGl0aW5nKG51bGwpO1xyXG4gICAgdG9hc3QoYCR7c2VjdGlvbn0gc2F2ZWQuYCk7XHJcbiAgfTtcclxuICBjb25zdCBzZWN0aW9uQWN0aW9ucyA9IChzZWN0aW9uOiBTZWN0aW9uTmFtZSkgPT4gZWRpdGluZyA9PT0gc2VjdGlvblxyXG4gICAgPyA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtc2VjdGlvbi1hY3Rpb25zXCI+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXtjYW5jZWx9PkNhbmNlbDwvQnV0dG9uPjxCdXR0b24gb25DbGljaz17KCkgPT4gc2F2ZShzZWN0aW9uKX0+U2F2ZTwvQnV0dG9uPjwvZGl2PlxyXG4gICAgOiA8YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtZWRpdFwiIG9uQ2xpY2s9eygpID0+IHsgc2V0RXJyb3IoXCJcIik7IHNldEVkaXRpbmcoc2VjdGlvbik7IH19PkVkaXQ8L2J1dHRvbj47XHJcbiAgY29uc3Qgc2VsZWN0U2VjdGlvbiA9IChzZWN0aW9uOiBTZWN0aW9uTmFtZSkgPT4ge1xyXG4gICAgc2V0RXhwYW5kZWQoc2VjdGlvbik7XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgcHJvZmlsZS0ke3NlY3Rpb24udG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtel0rL2csIFwiLVwiKX1gKT8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiwgYmxvY2s6IFwic3RhcnRcIiB9KTtcclxuICB9O1xyXG4gIGNvbnN0IGNob29zZUF2YXRhciA9IChmaWxlPzogRmlsZSkgPT4ge1xyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcclxuICAgIGlmICghW1wiaW1hZ2UvanBlZ1wiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL3dlYnBcIl0uaW5jbHVkZXMoZmlsZS50eXBlKSkgcmV0dXJuIHNldEVycm9yKFwiQ2hvb3NlIGEgSlBHLCBQTkcsIG9yIFdlYlAgaW1hZ2UuXCIpO1xyXG4gICAgaWYgKGZpbGUuc2l6ZSA+IDUgKiAxMDI0ICogMTAyNCkgcmV0dXJuIHNldEVycm9yKFwiQ2hvb3NlIGFuIGltYWdlIHNtYWxsZXIgdGhhbiA1IE1CLlwiKTtcclxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xyXG4gICAgICBjb25zdCBpbWFnZSA9IG5ldyBJbWFnZSgpO1xyXG4gICAgICBpbWFnZS5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcclxuICAgICAgICBjb25zdCBzY2FsZSA9IE1hdGgubWluKDEsIDgwMCAvIE1hdGgubWF4KGltYWdlLndpZHRoLCBpbWFnZS5oZWlnaHQpKTtcclxuICAgICAgICBjYW52YXMud2lkdGggPSBNYXRoLm1heCgxLCBNYXRoLnJvdW5kKGltYWdlLndpZHRoICogc2NhbGUpKTtcclxuICAgICAgICBjYW52YXMuaGVpZ2h0ID0gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChpbWFnZS5oZWlnaHQgKiBzY2FsZSkpO1xyXG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBjYW52YXMuZ2V0Q29udGV4dChcIjJkXCIpO1xyXG4gICAgICAgIGlmICghY29udGV4dCkgcmV0dXJuIHNldEVycm9yKFwiV2UgY291bGRuJ3QgcHJlcGFyZSB0aGF0IHBob3RvLlwiKTtcclxuICAgICAgICBjb250ZXh0LmRyYXdJbWFnZShpbWFnZSwgMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcclxuICAgICAgICBjb25zdCBhdmF0YXIgPSBjYW52YXMudG9EYXRhVVJMKFwiaW1hZ2Uvd2VicFwiLCAuODIpO1xyXG4gICAgICAgIGNvbnN0IG5leHRVc2VyID0geyAuLi51c2VyLCBhdmF0YXIgfTtcclxuICAgICAgICBzZXRVc2VyKG5leHRVc2VyKTtcclxuICAgICAgICBpZiAodXBkYXRlKHsgLi4uc3RvcmUsIHVzZXI6IG5leHRVc2VyIH0pKSB0b2FzdChcIlByb2ZpbGUgcGhvdG8gdXBkYXRlZC5cIik7XHJcbiAgICAgIH07XHJcbiAgICAgIGltYWdlLnNyYyA9IFN0cmluZyhyZWFkZXIucmVzdWx0KTtcclxuICAgIH07XHJcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuICB9O1xyXG4gIGNvbnN0IHJlc3RhcnRDaGFsbGVuZ2UgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBmcmVzaCA9IGNyZWF0ZUZpdG5lc3NTdG9yZSh7XHJcbiAgICAgIG5hbWU6IHVzZXIudXNlcm5hbWUsIGVtYWlsOiB1c2VyLmVtYWlsLCBhdmF0YXJVcmw6IHVzZXIuYXZhdGFyLCBhZ2U6IHVzZXIuYWdlLCBoZWlnaHQ6IHVzZXIuaGVpZ2h0LCB3ZWlnaHQ6IHVzZXIud2VpZ2h0LCB0YXJnZXRXZWlnaHQ6IHVzZXIudGFyZ2V0V2VpZ2h0LFxyXG4gICAgICBzb21hdG90eXBlOiB1c2VyLnNvbWF0b3R5cGUsIGdvYWw6IHVzZXIuZ29hbCwgZXhwZXJpZW5jZTogdXNlci5leHBlcmllbmNlLCBhY3Rpdml0eTogdXNlci5hY3Rpdml0eUxldmVsLCB1bml0U3lzdGVtOiB1c2VyLnVuaXRTeXN0ZW0sXHJcbiAgICAgIGF2YWlsYWJsZUVxdWlwbWVudDogdXNlci5lcXVpcG1lbnQsIGhhc0NvbmRpdGlvbjogdXNlci5pbmp1cnlGbGFnLCBjaGFsbGVuZ2VEYXlzOiBjaGFsbGVuZ2UubGVuZ3RoLCB3b3Jrb3V0RGF5czogY2hhbGxlbmdlLmRheXNQZXJXZWVrLFxyXG4gICAgICBzZXNzaW9uTWludXRlczogY2hhbGxlbmdlLnNlc3Npb25NaW51dGVzLCBjaGFsbGVuZ2VTdGFydERhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmVzdGFydGVkID0geyAuLi5mcmVzaCwgdXNlcjogeyAuLi5mcmVzaC51c2VyLCAuLi51c2VyIH0sIHByZWZlcmVuY2VzLCB3ZWlnaHRzOiBzdG9yZS53ZWlnaHRzLCBwaG90b3M6IHN0b3JlLnBob3RvcyB9O1xyXG4gICAgaWYgKHVwZGF0ZShyZXN0YXJ0ZWQpKSB7XHJcbiAgICAgIHNldENoYWxsZW5nZShyZXN0YXJ0ZWQuY2hhbGxlbmdlKTtcclxuICAgICAgc2V0U2hvd1Jlc3RhcnQoZmFsc2UpO1xyXG4gICAgICB0b2FzdChcIkNoYWxsZW5nZSByZXN0YXJ0ZWQgYXQgRGF5IDEuIFdlIGtlcHQgeW91ciB3ZWlnaHRzIGFuZCBwaG90b3MuXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgZG93bmxvYWREYXRhID0gKCkgPT4ge1xyXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtKU09OLnN0cmluZ2lmeShzdG9yZSwgbnVsbCwgMildLCB7IHR5cGU6IFwiYXBwbGljYXRpb24vanNvblwiIH0pO1xyXG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcclxuICAgIGxpbmsuaHJlZiA9IHVybDtcclxuICAgIGxpbmsuZG93bmxvYWQgPSBcInNvZmVyZml0LWRhdGEuanNvblwiO1xyXG4gICAgbGluay5jbGljaygpO1xyXG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xyXG4gICAgdG9hc3QoXCJZb3VyIGRhdGEgZXhwb3J0IGlzIHJlYWR5LlwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGhlYWx0aHlQYWNlID0gQm9vbGVhbih1c2VyLndlaWdodCAmJiB1c2VyLnRhcmdldFdlaWdodCkgJiYgKHBhcnNlV2VpZ2h0S2codXNlci53ZWlnaHQsIHVzZXIudW5pdFN5c3RlbSkgLSBwYXJzZVdlaWdodEtnKHVzZXIudGFyZ2V0V2VpZ2h0LCB1c2VyLnVuaXRTeXN0ZW0pKSAvIChjaGFsbGVuZ2UubGVuZ3RoIC8gNykgPiAxO1xyXG4gIGNvbnN0IGNhcmRDbGFzcyA9IChzZWN0aW9uOiBTZWN0aW9uTmFtZSkgPT4gYHByb2ZpbGUtc2VjdGlvbi1jYXJkICR7ZXhwYW5kZWQgPT09IHNlY3Rpb24gPyBcIm1vYmlsZS1leHBhbmRlZFwiIDogXCJcIn1gO1xyXG5cclxuICByZXR1cm4gPD48UGFnZUhlYWRlciBleWVicm93PVwiWU9VUiBBQ0NPVU5UXCIgdGl0bGU9XCJQcm9maWxlXCIgLz5cclxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInByb2ZpbGUtaGVhZGVyLWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLXdyYXBcIj48YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLWxhcmdlXCIgb25DbGljaz17KCkgPT4gYXZhdGFySW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX0gYXJpYS1sYWJlbD1cIkNoYW5nZSBwaG90b1wiPnt1c2VyLmF2YXRhciA/IDxpbWcgc3JjPXt1c2VyLmF2YXRhcn0gYWx0PVwiXCIgLz4gOiBpbml0aWFsc308L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtYXZhdGFyLWNhbWVyYVwiIG9uQ2xpY2s9eygpID0+IGF2YXRhcklucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9IGFyaWEtbGFiZWw9XCJDaGFuZ2UgcGhvdG9cIj48SWNvbiBuYW1lPVwiY2FtZXJhXCIgLz48c3BhbiByb2xlPVwidG9vbHRpcFwiPkNoYW5nZSBwaG90bzwvc3Bhbj48L2J1dHRvbj48aW5wdXQgcmVmPXthdmF0YXJJbnB1dFJlZn0gY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXItaW5wdXRcIiB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5qcGcsLmpwZWcsLnBuZywud2VicCxpbWFnZS9qcGVnLGltYWdlL3BuZyxpbWFnZS93ZWJwXCIgb25DaGFuZ2U9eyhldmVudCkgPT4gY2hvb3NlQXZhdGFyKGV2ZW50LnRhcmdldC5maWxlcz8uWzBdKX0gLz48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtaGVhZGVyLWNvcHlcIj48aDI+e3VzZXIudXNlcm5hbWV9PC9oMj48cD57dXNlci5lbWFpbCB8fCBcIkFkZCB5b3VyIGVtYWlsXCJ9PC9wPjxzcGFuPk1lbWJlciBzaW5jZSB7cHJldHR5RGF0ZSh1c2VyLm1lbWJlclNpbmNlKX08L3NwYW4+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWhlYWRlci1hY3Rpb25zXCI+PHN0cm9uZz5EYXkge2NoYWxsZW5nZURheX0gLyB7Y2hhbGxlbmdlLmxlbmd0aH08L3N0cm9uZz48YnV0dG9uIG9uQ2xpY2s9e29uTG9nb3V0fT48SWNvbiBuYW1lPVwibG9nb3V0XCIgLz5Mb2cgb3V0PC9idXR0b24+PC9kaXY+PC9hcnRpY2xlPlxyXG4gICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cInByb2ZpbGUtZ2xvYmFsLWVycm9yIGlubGluZS12YWxpZGF0aW9uXCI+e2Vycm9yfTwvcD59XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtbGF5b3V0XCI+XHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwicHJvZmlsZS1zdWJuYXZcIiBhcmlhLWxhYmVsPVwiUHJvZmlsZSBzZWN0aW9uc1wiPntzZWN0aW9uTmFtZXMubWFwKChzZWN0aW9uKSA9PiA8YnV0dG9uIGNsYXNzTmFtZT17ZXhwYW5kZWQgPT09IHNlY3Rpb24gPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtzZWN0aW9ufSBvbkNsaWNrPXsoKSA9PiBzZWxlY3RTZWN0aW9uKHNlY3Rpb24pfT57c2VjdGlvbn08SWNvbiBuYW1lPVwiYXJyb3dcIiAvPjwvYnV0dG9uPil9PC9uYXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uc1wiPlxyXG4gICAgICAgIDxhcnRpY2xlIGlkPVwicHJvZmlsZS1hY2NvdW50XCIgY2xhc3NOYW1lPXtjYXJkQ2xhc3MoXCJBY2NvdW50XCIpfT48aGVhZGVyPjxidXR0b24gY2xhc3NOYW1lPVwicHJvZmlsZS1tb2JpbGUtdG9nZ2xlXCIgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWQoXCJBY2NvdW50XCIpfT48c3Bhbj48c21hbGw+QUNDT1VOVDwvc21hbGw+PGgyPlNpZ24taW4gZGV0YWlsczwvaDI+PC9zcGFuPjxpPntleHBhbmRlZCA9PT0gXCJBY2NvdW50XCIgPyBcIuKIklwiIDogXCIrXCJ9PC9pPjwvYnV0dG9uPntzZWN0aW9uQWN0aW9ucyhcIkFjY291bnRcIil9PC9oZWFkZXI+PGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXNlY3Rpb24tYm9keVwiPjxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1maWVsZC1ncmlkXCI+PGxhYmVsPk5hbWU8aW5wdXQgZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiQWNjb3VudFwifSB2YWx1ZT17dXNlci51c2VybmFtZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIHVzZXJuYW1lOiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48bGFiZWw+RW1haWw8aW5wdXQgZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiQWNjb3VudFwifSB0eXBlPVwiZW1haWxcIiB2YWx1ZT17dXNlci5lbWFpbH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGVtYWlsOiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48L2Rpdj57ZWRpdGluZyA9PT0gXCJBY2NvdW50XCIgJiYgPGRpdiBjbGFzc05hbWU9XCJwYXNzd29yZC1lZGl0XCI+PGgzPkNoYW5nZSBwYXNzd29yZDwvaDM+PGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWZpZWxkLWdyaWRcIj48bGFiZWw+Q3VycmVudCBwYXNzd29yZDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiB2YWx1ZT17cGFzc3dvcmRzLmN1cnJlbnR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3Jkcyh7IC4uLnBhc3N3b3JkcywgY3VycmVudDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPjwvbGFiZWw+PGxhYmVsPk5ldyBwYXNzd29yZDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiB2YWx1ZT17cGFzc3dvcmRzLm5leHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3Jkcyh7IC4uLnBhc3N3b3JkcywgbmV4dDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPjwvbGFiZWw+PGxhYmVsPkNvbmZpcm0gbmV3IHBhc3N3b3JkPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIHZhbHVlPXtwYXNzd29yZHMuY29uZmlybX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UGFzc3dvcmRzKHsgLi4ucGFzc3dvcmRzLCBjb25maXJtOiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48L2Rpdj48dWw+e3Bhc3N3b3JkUnVsZXMubWFwKChbcnVsZSwgbWV0XSkgPT4gPGxpIGNsYXNzTmFtZT17bWV0ID8gXCJtZXRcIiA6IFwiXCJ9IGtleT17cnVsZX0+PEljb24gbmFtZT17bWV0ID8gXCJjaGVja1wiIDogXCJjbG9zZVwifSAvPntydWxlfTwvbGk+KX08L3VsPjwvZGl2Pn08L2Rpdj48L2FydGljbGU+XHJcblxyXG4gICAgICAgIDxhcnRpY2xlIGlkPVwicHJvZmlsZS1ib2R5LXByb2ZpbGVcIiBjbGFzc05hbWU9e2NhcmRDbGFzcyhcIkJvZHkgcHJvZmlsZVwiKX0+PGhlYWRlcj48YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtbW9iaWxlLXRvZ2dsZVwiIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkKFwiQm9keSBwcm9maWxlXCIpfT48c3Bhbj48c21hbGw+Qk9EWSBQUk9GSUxFPC9zbWFsbD48aDI+WW91ciBiYXNlbGluZTwvaDI+PC9zcGFuPjxpPntleHBhbmRlZCA9PT0gXCJCb2R5IHByb2ZpbGVcIiA/IFwi4oiSXCIgOiBcIitcIn08L2k+PC9idXR0b24+e3NlY3Rpb25BY3Rpb25zKFwiQm9keSBwcm9maWxlXCIpfTwvaGVhZGVyPjxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uLWJvZHlcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1jaG9pY2UtZ3JvdXBcIj48c3Bhbj5Vbml0czwvc3Bhbj48ZGl2PjxidXR0b24gZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiQm9keSBwcm9maWxlXCJ9IGNsYXNzTmFtZT17dXNlci51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldFVzZXIoeyAuLi51c2VyLCB1bml0U3lzdGVtOiBcIm1ldHJpY1wiIH0pfT5NZXRyaWM8L2J1dHRvbj48YnV0dG9uIGRpc2FibGVkPXtlZGl0aW5nICE9PSBcIkJvZHkgcHJvZmlsZVwifSBjbGFzc05hbWU9e3VzZXIudW5pdFN5c3RlbSA9PT0gXCJpbXBlcmlhbFwiID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldFVzZXIoeyAuLi51c2VyLCB1bml0U3lzdGVtOiBcImltcGVyaWFsXCIgfSl9PkltcGVyaWFsPC9idXR0b24+PC9kaXY+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtZmllbGQtZ3JpZCBmb3VyXCI+PGxhYmVsPkFnZTxpbnB1dCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gdHlwZT1cIm51bWJlclwiIHZhbHVlPXt1c2VyLmFnZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGFnZTogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPjwvbGFiZWw+PGxhYmVsPkhlaWdodCAoe3VzZXIudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwiY21cIiA6IFwiZnQgLyBpblwifSk8aW5wdXQgZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiQm9keSBwcm9maWxlXCJ9IHR5cGU9e3VzZXIudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwibnVtYmVyXCIgOiBcInRleHRcIn0gcGxhY2Vob2xkZXI9e3VzZXIudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwiMTc1XCIgOiBcIjUgZnQgOCBpblwifSB2YWx1ZT17dXNlci5oZWlnaHR9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFVzZXIoeyAuLi51c2VyLCBoZWlnaHQ6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0gLz48L2xhYmVsPjxsYWJlbD5DdXJyZW50IHdlaWdodCAoe3VzZXIudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwia2dcIiA6IFwibGJcIn0pPGlucHV0IGRpc2FibGVkPXtlZGl0aW5nICE9PSBcIkJvZHkgcHJvZmlsZVwifSB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e3VzZXIud2VpZ2h0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRVc2VyKHsgLi4udXNlciwgd2VpZ2h0OiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48bGFiZWw+VGFyZ2V0IHdlaWdodDxpbnB1dCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gdHlwZT1cIm51bWJlclwiIHZhbHVlPXt1c2VyLnRhcmdldFdlaWdodH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIHRhcmdldFdlaWdodDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPjwvbGFiZWw+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvbWF0b3R5cGUtbGFiZWxcIj48c3Bhbj5Tb21hdG90eXBlPC9zcGFuPjxidXR0b24gb25DbGljaz17KCkgPT4gb25PcGVuR2xvc3NhcnkoXCJTb21hdG90eXBlXCIpfSBhcmlhLWxhYmVsPVwiT3BlbiBzb21hdG90eXBlIGdsb3NzYXJ5XCI+4pOYPC9idXR0b24+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXNvbWF0b3R5cGVzXCI+e1tbXCJFY3RvbW9ycGhcIiwgXCJOYXR1cmFsbHkgbGVhbmVyIGZyYW1lXCJdLCBbXCJNZXNvbW9ycGhcIiwgXCJOYXR1cmFsbHkgYXRobGV0aWMgZnJhbWVcIl0sIFtcIkVuZG9tb3JwaFwiLCBcIk5hdHVyYWxseSBicm9hZGVyIGZyYW1lXCJdLCBbXCJOb3QgU3VyZVwiLCBcIlVzZSBteSBvdGhlciBkZXRhaWxzXCJdXS5tYXAoKFtuYW1lLCBjb3B5XSkgPT4gPGJ1dHRvbiBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gY2xhc3NOYW1lPXt1c2VyLnNvbWF0b3R5cGUgPT09IG5hbWUgPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtuYW1lfSBvbkNsaWNrPXsoKSA9PiBzZXRVc2VyKHsgLi4udXNlciwgc29tYXRvdHlwZTogbmFtZSB9KX0+PHN0cm9uZz57bmFtZX08L3N0cm9uZz48c21hbGw+e2NvcHl9PC9zbWFsbD48L2J1dHRvbj4pfTwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWZpZWxkLWdyaWQgdGhyZWVcIj48bGFiZWw+UHJpbWFyeSBnb2FsPHNlbGVjdCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gdmFsdWU9e3VzZXIuZ29hbH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGdvYWw6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0+PG9wdGlvbiB2YWx1ZT1cIlwiPkNob29zZSBhIGdvYWw8L29wdGlvbj48b3B0aW9uPkxvc2UgRmF0ICYgR2V0IExlYW48L29wdGlvbj48b3B0aW9uPkJ1aWxkIE11c2NsZSAmIFN0cmVuZ3RoPC9vcHRpb24+PG9wdGlvbj5Cb2R5IFJlY29tcG9zaXRpb248L29wdGlvbj48L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5FeHBlcmllbmNlIGxldmVsPHNlbGVjdCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gdmFsdWU9e3VzZXIuZXhwZXJpZW5jZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGV4cGVyaWVuY2U6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0+PG9wdGlvbiB2YWx1ZT1cIlwiPkNob29zZSBleHBlcmllbmNlPC9vcHRpb24+PG9wdGlvbj5TdGFydGluZyBPdXQ8L29wdGlvbj48b3B0aW9uPlNvbWUgRXhwZXJpZW5jZTwvb3B0aW9uPjxvcHRpb24+Q29uc2lzdGVudDwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPkFjdGl2aXR5IGxldmVsPHNlbGVjdCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJCb2R5IHByb2ZpbGVcIn0gdmFsdWU9e3VzZXIuYWN0aXZpdHlMZXZlbH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGFjdGl2aXR5TGV2ZWw6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0+PG9wdGlvbiB2YWx1ZT1cIlwiPkNob29zZSBhY3Rpdml0eTwvb3B0aW9uPjxvcHRpb24+U2VkZW50YXJ5PC9vcHRpb24+PG9wdGlvbj5Tb21ldGltZXMgQWN0aXZlPC9vcHRpb24+PG9wdGlvbj5Nb2RlcmF0ZWx5IEFjdGl2ZTwvb3B0aW9uPjxvcHRpb24+VmVyeSBBY3RpdmU8L29wdGlvbj48L3NlbGVjdD48L2xhYmVsPjwvZGl2PntoZWFsdGh5UGFjZSAmJiA8cCBjbGFzc05hbWU9XCJnZW50bGUtbm90ZVwiPlRoYXQgdGFyZ2V0IG1heSBjYWxsIGZvciBhIGZhc3RlciBwYWNlLiBHcmFkdWFsLCBzdXN0YWluYWJsZSBjaGFuZ2VzIGFyZSBlYXNpZXIgdG8gbWFpbnRhaW47IHlvdXIgcGxhbiB3aWxsIHN0YXkgYmFsYW5jZWQuPC9wPn1cclxuICAgICAgICA8L2Rpdj48L2FydGljbGU+XHJcblxyXG4gICAgICAgIDxhcnRpY2xlIGlkPVwicHJvZmlsZS10cmFpbmluZ1wiIGNsYXNzTmFtZT17Y2FyZENsYXNzKFwiVHJhaW5pbmdcIil9PjxoZWFkZXI+PGJ1dHRvbiBjbGFzc05hbWU9XCJwcm9maWxlLW1vYmlsZS10b2dnbGVcIiBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZChcIlRyYWluaW5nXCIpfT48c3Bhbj48c21hbGw+VFJBSU5JTkc8L3NtYWxsPjxoMj5QbGFuIHByZWZlcmVuY2VzPC9oMj48L3NwYW4+PGk+e2V4cGFuZGVkID09PSBcIlRyYWluaW5nXCIgPyBcIuKIklwiIDogXCIrXCJ9PC9pPjwvYnV0dG9uPntzZWN0aW9uQWN0aW9ucyhcIlRyYWluaW5nXCIpfTwvaGVhZGVyPjxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uLWJvZHlcIj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtZmllbGQtZ3JpZCB0aHJlZVwiPjxsYWJlbD5FcXVpcG1lbnQ8c2VsZWN0IGRpc2FibGVkPXtlZGl0aW5nICE9PSBcIlRyYWluaW5nXCJ9IHZhbHVlPXt1c2VyLmVxdWlwbWVudH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGVxdWlwbWVudDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfT48b3B0aW9uPkJvZHl3ZWlnaHQgLyBIb21lIE9ubHk8L29wdGlvbj48b3B0aW9uPkR1bWJiZWxscyAmIEJhbmRzPC9vcHRpb24+PG9wdGlvbj5GdWxsIEd5bSBBY2Nlc3M8L29wdGlvbj48L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5Xb3Jrb3V0IGRheXMgcGVyIHdlZWs8aW5wdXQgZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiVHJhaW5pbmdcIn0gdHlwZT1cIm51bWJlclwiIG1pbj1cIjJcIiBtYXg9XCI2XCIgdmFsdWU9e2NoYWxsZW5nZS5kYXlzUGVyV2Vla30gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q2hhbGxlbmdlKHsgLi4uY2hhbGxlbmdlLCBkYXlzUGVyV2VlazogTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSkgfSl9IC8+PC9sYWJlbD48bGFiZWw+U2Vzc2lvbiBkdXJhdGlvbjxzZWxlY3QgZGlzYWJsZWQ9e2VkaXRpbmcgIT09IFwiVHJhaW5pbmdcIn0gdmFsdWU9e2R1cmF0aW9uQ2hvaWNlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREdXJhdGlvbkNob2ljZShldmVudC50YXJnZXQudmFsdWUpfT48b3B0aW9uIHZhbHVlPVwiMTVcIj4xNSBtaW51dGVzPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIjMwXCI+MzAgbWludXRlczwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCI0NVwiPjQ1IG1pbnV0ZXM8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwiNjBcIj42MCBtaW51dGVzPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cImN1c3RvbVwiPkN1c3RvbS4uLjwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+e2R1cmF0aW9uQ2hvaWNlID09PSBcImN1c3RvbVwiICYmIDxsYWJlbD5DdXN0b20gbWludXRlczxpbnB1dCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJUcmFpbmluZ1wifSB0eXBlPVwibnVtYmVyXCIgbWluPVwiNVwiIG1heD1cIjE4MFwiIHZhbHVlPXtjdXN0b21EdXJhdGlvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q3VzdG9tRHVyYXRpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2xhYmVsPn08bGFiZWw+Q2hhbGxlbmdlIGxlbmd0aDxpbnB1dCBkaXNhYmxlZCB2YWx1ZT17YCR7Y2hhbGxlbmdlLmxlbmd0aH0gZGF5c2B9IC8+PC9sYWJlbD48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImRhbmdlci1yb3dcIj48ZGl2PjxzdHJvbmc+UmVzdGFydCBjaGFsbGVuZ2U8L3N0cm9uZz48c3Bhbj5SZXR1cm4gdGhlIHBsYW4gYW5kIGNhbGVuZGFyIHRvIERheSAxLjwvc3Bhbj48L2Rpdj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dSZXN0YXJ0KHRydWUpfT5SZXN0YXJ0IGNoYWxsZW5nZTwvYnV0dG9uPjwvZGl2PjwvZGl2PjwvYXJ0aWNsZT5cclxuXHJcbiAgICAgICAgPGFydGljbGUgaWQ9XCJwcm9maWxlLWhlYWx0aC1zYWZldHlcIiBjbGFzc05hbWU9e2NhcmRDbGFzcyhcIkhlYWx0aCAmIHNhZmV0eVwiKX0+PGhlYWRlcj48YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtbW9iaWxlLXRvZ2dsZVwiIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkKFwiSGVhbHRoICYgc2FmZXR5XCIpfT48c3Bhbj48c21hbGw+SEVBTFRIICYgU0FGRVRZPC9zbWFsbD48aDI+RXhlcmNpc2UgcHJlZmVyZW5jZXM8L2gyPjwvc3Bhbj48aT57ZXhwYW5kZWQgPT09IFwiSGVhbHRoICYgc2FmZXR5XCIgPyBcIuKIklwiIDogXCIrXCJ9PC9pPjwvYnV0dG9uPntzZWN0aW9uQWN0aW9ucyhcIkhlYWx0aCAmIHNhZmV0eVwiKX08L2hlYWRlcj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtc2VjdGlvbi1ib2R5XCI+PEN1c3RvbUNoZWNrYm94IGNsYXNzTmFtZT1cInByb2ZpbGUtY2hlY2sgY2hlY2tib3gtbGVhZGluZ1wiIGRpc2FibGVkPXtlZGl0aW5nICE9PSBcIkhlYWx0aCAmIHNhZmV0eVwifSBjaGVja2VkPXt1c2VyLmluanVyeUZsYWd9IG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4gc2V0VXNlcih7IC4uLnVzZXIsIGluanVyeUZsYWc6IGNoZWNrZWQgfSl9PjxzcGFuPjxzdHJvbmc+SSBoYXZlIGFuIGluanVyeSBvciBoZWFsdGggY29uZGl0aW9uPC9zdHJvbmc+PHNtYWxsPldoZW4gb24sIGxvd2VyLWltcGFjdCBleGVyY2lzZXMgYXJlIGZhdm9yZWQuPC9zbWFsbD48L3NwYW4+PC9DdXN0b21DaGVja2JveD48cCBjbGFzc05hbWU9XCJzYWZldHktZGlzY2xhaW1lclwiPlNvZmVyRml0IG9mZmVycyBnZW5lcmFsIGZpdG5lc3MgZ3VpZGFuY2UsIG5vdCBtZWRpY2FsIGFkdmljZS4gQ2hlY2sgd2l0aCBhIGRvY3RvciBiZWZvcmUgc3RhcnRpbmcgaWYgeW91IGhhdmUgYSBoZWFsdGggY29uZGl0aW9uLjwvcD48L2Rpdj48L2FydGljbGU+XHJcblxyXG4gICAgICAgIDxhcnRpY2xlIGlkPVwicHJvZmlsZS1ub3RpZmljYXRpb25zXCIgY2xhc3NOYW1lPXtjYXJkQ2xhc3MoXCJOb3RpZmljYXRpb25zXCIpfT48aGVhZGVyPjxidXR0b24gY2xhc3NOYW1lPVwicHJvZmlsZS1tb2JpbGUtdG9nZ2xlXCIgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWQoXCJOb3RpZmljYXRpb25zXCIpfT48c3Bhbj48c21hbGw+Tk9USUZJQ0FUSU9OUzwvc21hbGw+PGgyPlN0YXkgb24gdHJhY2s8L2gyPjwvc3Bhbj48aT57ZXhwYW5kZWQgPT09IFwiTm90aWZpY2F0aW9uc1wiID8gXCLiiJJcIiA6IFwiK1wifTwvaT48L2J1dHRvbj57c2VjdGlvbkFjdGlvbnMoXCJOb3RpZmljYXRpb25zXCIpfTwvaGVhZGVyPjxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1zZWN0aW9uLWJvZHlcIj48ZGl2IGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1saXN0XCI+PEN1c3RvbUNoZWNrYm94IGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1vcHRpb25cIiBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJOb3RpZmljYXRpb25zXCJ9IGNoZWNrZWQ9e3ByZWZlcmVuY2VzLndvcmtvdXRSZW1pbmRlcnN9IG9uQ2hhbmdlPXsoY2hlY2tlZCkgPT4gc2V0UHJlZmVyZW5jZXMoeyAuLi5wcmVmZXJlbmNlcywgd29ya291dFJlbWluZGVyczogY2hlY2tlZCB9KX0+PHNwYW4+PHN0cm9uZz5Xb3Jrb3V0IHJlbWluZGVyczwvc3Ryb25nPjxzbWFsbD5BIHJlbWluZGVyIG9uIHBsYW5uZWQgd29ya291dCBkYXlzLjwvc21hbGw+PC9zcGFuPjwvQ3VzdG9tQ2hlY2tib3g+e3ByZWZlcmVuY2VzLndvcmtvdXRSZW1pbmRlcnMgJiYgPGxhYmVsIGNsYXNzTmFtZT1cInJlbWluZGVyLXRpbWVcIj48c3Bhbj5SZW1pbmRlciB0aW1lPC9zcGFuPjxpbnB1dCBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJOb3RpZmljYXRpb25zXCJ9IHR5cGU9XCJ0aW1lXCIgdmFsdWU9e3ByZWZlcmVuY2VzLnJlbWluZGVyVGltZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UHJlZmVyZW5jZXMoeyAuLi5wcmVmZXJlbmNlcywgcmVtaW5kZXJUaW1lOiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD59PEN1c3RvbUNoZWNrYm94IGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1vcHRpb25cIiBkaXNhYmxlZD17ZWRpdGluZyAhPT0gXCJOb3RpZmljYXRpb25zXCJ9IGNoZWNrZWQ9e3ByZWZlcmVuY2VzLnN0cmVha1JlbWluZGVyc30gb25DaGFuZ2U9eyhjaGVja2VkKSA9PiBzZXRQcmVmZXJlbmNlcyh7IC4uLnByZWZlcmVuY2VzLCBzdHJlYWtSZW1pbmRlcnM6IGNoZWNrZWQgfSl9PjxzcGFuPjxzdHJvbmc+U3RyZWFrIHJlbWluZGVyczwvc3Ryb25nPjxzbWFsbD5BIGdlbnRsZSBwcm9tcHQgd2hlbiB5b3VyIHN0cmVhayBpcyBhY3RpdmUuPC9zbWFsbD48L3NwYW4+PC9DdXN0b21DaGVja2JveD48Q3VzdG9tQ2hlY2tib3ggY2xhc3NOYW1lPVwibm90aWZpY2F0aW9uLW9wdGlvblwiIGRpc2FibGVkPXtlZGl0aW5nICE9PSBcIk5vdGlmaWNhdGlvbnNcIn0gY2hlY2tlZD17cHJlZmVyZW5jZXMud2Vla2x5U3VtbWFyeX0gb25DaGFuZ2U9eyhjaGVja2VkKSA9PiBzZXRQcmVmZXJlbmNlcyh7IC4uLnByZWZlcmVuY2VzLCB3ZWVrbHlTdW1tYXJ5OiBjaGVja2VkIH0pfT48c3Bhbj48c3Ryb25nPldlZWtseSBwcm9ncmVzcyBzdW1tYXJpZXM8L3N0cm9uZz48c21hbGw+QSBzaG9ydCByZWNhcCBvZiB5b3VyIHRyYWluaW5nIHdlZWsuPC9zbWFsbD48L3NwYW4+PC9DdXN0b21DaGVja2JveD48L2Rpdj48L2Rpdj48L2FydGljbGU+XHJcblxyXG4gICAgICAgIDxhcnRpY2xlIGlkPVwicHJvZmlsZS1wcml2YWN5LWRhdGFcIiBjbGFzc05hbWU9e2NhcmRDbGFzcyhcIlByaXZhY3kgJiBkYXRhXCIpfT48aGVhZGVyPjxidXR0b24gY2xhc3NOYW1lPVwicHJvZmlsZS1tb2JpbGUtdG9nZ2xlXCIgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWQoXCJQcml2YWN5ICYgZGF0YVwiKX0+PHNwYW4+PHNtYWxsPlBSSVZBQ1kgJiBEQVRBPC9zbWFsbD48aDI+WW91ciBpbmZvcm1hdGlvbjwvaDI+PC9zcGFuPjxpPntleHBhbmRlZCA9PT0gXCJQcml2YWN5ICYgZGF0YVwiID8gXCLiiJJcIiA6IFwiK1wifTwvaT48L2J1dHRvbj48L2hlYWRlcj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtc2VjdGlvbi1ib2R5XCI+PGRpdiBjbGFzc05hbWU9XCJwcml2YWN5LXN0YXRlbWVudFwiPjxJY29uIG5hbWU9XCJjYW1lcmFcIiAvPjxkaXY+PHN0cm9uZz5Zb3VyIHByb2dyZXNzIHBob3RvcyBhcmUgcHJpdmF0ZTwvc3Ryb25nPjxzcGFuPlRoZXkgYXJlIHN0b3JlZCB3aXRoIHlvdXIgbG9jYWwgcHJvZmlsZSBhbmQgb25seSB2aXNpYmxlIHRvIHlvdS48L3NwYW4+PC9kaXY+PC9kaXY+PGJ1dHRvbiBjbGFzc05hbWU9XCJwcm9maWxlLXJvdy1hY3Rpb25cIiBvbkNsaWNrPXtkb3dubG9hZERhdGF9PjxzcGFuPjxzdHJvbmc+RG93bmxvYWQgbXkgZGF0YTwvc3Ryb25nPjxzbWFsbD5FeHBvcnQgeW91ciBwcm9maWxlIGFuZCBwcm9ncmVzcyBhcyBKU09OLjwvc21hbGw+PC9zcGFuPjxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PC9idXR0b24+PGRpdiBjbGFzc05hbWU9XCJkYW5nZXItem9uZVwiPjxzdHJvbmc+RGVsZXRlIG15IGFjY291bnQ8L3N0cm9uZz48cD5UaGlzIHJlbW92ZXMgeW91ciBwcm9maWxlIGFuZCBhbGwgbG9jYWxseSBzYXZlZCBwcm9ncmVzcy48L3A+e3Nob3dEZWxldGUgPyA8ZGl2PjxsYWJlbD5UeXBlIERFTEVURSB0byBjb25maXJtPGlucHV0IHZhbHVlPXtkZWxldGVUZXh0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREZWxldGVUZXh0KGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9sYWJlbD48QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGRpc2FibGVkPXtkZWxldGVUZXh0ICE9PSBcIkRFTEVURVwifSBvbkNsaWNrPXtvbkxvZ291dH0+RGVsZXRlIG15IGFjY291bnQ8L0J1dHRvbj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0RlbGV0ZShmYWxzZSk7IHNldERlbGV0ZVRleHQoXCJcIik7IH19PkNhbmNlbDwvYnV0dG9uPjwvZGl2PiA6IDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0RlbGV0ZSh0cnVlKX0+RGVsZXRlIG15IGFjY291bnQ8L2J1dHRvbj59PC9kaXY+PC9kaXY+PC9hcnRpY2xlPlxyXG5cclxuICAgICAgICA8YXJ0aWNsZSBpZD1cInByb2ZpbGUtaGVscFwiIGNsYXNzTmFtZT17Y2FyZENsYXNzKFwiSGVscFwiKX0+PGhlYWRlcj48YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtbW9iaWxlLXRvZ2dsZVwiIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkKFwiSGVscFwiKX0+PHNwYW4+PHNtYWxsPkhFTFA8L3NtYWxsPjxoMj5SZXNvdXJjZXM8L2gyPjwvc3Bhbj48aT57ZXhwYW5kZWQgPT09IFwiSGVscFwiID8gXCLiiJJcIiA6IFwiK1wifTwvaT48L2J1dHRvbj48L2hlYWRlcj48ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtc2VjdGlvbi1ib2R5IHByb2ZpbGUtaGVscC1saW5rc1wiPjxidXR0b24gb25DbGljaz17KCkgPT4gb25PcGVuR2xvc3NhcnkoKX0+PHNwYW4+PHN0cm9uZz5HbG9zc2FyeTwvc3Ryb25nPjxzbWFsbD5QbGFpbi1sYW5ndWFnZSBmaXRuZXNzIHRlcm1zLjwvc21hbGw+PC9zcGFuPjxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PC9idXR0b24+PGEgaHJlZj1cIm1haWx0bzpmZWVkYmFja0Bzb2ZlcmZpdC5leGFtcGxlXCI+PHNwYW4+PHN0cm9uZz5TZW5kIGZlZWRiYWNrPC9zdHJvbmc+PHNtYWxsPlRlbGwgdXMgd2hhdCB3b3VsZCBtYWtlIFNvZmVyRml0IGJldHRlci48L3NtYWxsPjwvc3Bhbj48SWNvbiBuYW1lPVwiYXJyb3dcIiAvPjwvYT48ZGl2PjxzcGFuPjxzdHJvbmc+QWJvdXQgU29mZXJGaXQ8L3N0cm9uZz48c21hbGw+QWRhcHRpdmUgZml0bmVzcyBwbGFubmluZyBmb3Igc3VzdGFpbmFibGUgcm91dGluZXMuPC9zbWFsbD48L3NwYW4+PGI+VmVyc2lvbiAxLjA8L2I+PC9kaXY+PC9kaXY+PC9hcnRpY2xlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAge3Nob3dSZXN0YXJ0ICYmIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtbW9kYWwtYmFja2Ryb3BcIj48ZGl2IGNsYXNzTmFtZT1cImVuZC1kaWFsb2dcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48c3BhbiBjbGFzc05hbWU9XCJkYXNoLXN0YXQtaWNvblwiPjxJY29uIG5hbWU9XCJjYWxlbmRhclwiIC8+PC9zcGFuPjxoMj5SZXN0YXJ0IGNoYWxsZW5nZT88L2gyPjxwPllvdXIgd29ya291dCBwbGFuLCBzZXNzaW9ucywgYmFkZ2VzLCBhbmQgY2FsZW5kYXIgd2lsbCByZXNldCB0byBEYXkgMS4gU2F2ZWQgd2VpZ2h0cyBhbmQgcHJvZ3Jlc3MgcGhvdG9zIHdpbGwgYmUga2VwdC48L3A+PEJ1dHRvbiBvbkNsaWNrPXtyZXN0YXJ0Q2hhbGxlbmdlfT5SZXN0YXJ0IGF0IERheSAxPC9CdXR0b24+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UmVzdGFydChmYWxzZSl9PkNhbmNlbDwvQnV0dG9uPjwvZGl2PjwvZGl2Pn1cclxuICA8Lz47XHJcbn0iXX0=