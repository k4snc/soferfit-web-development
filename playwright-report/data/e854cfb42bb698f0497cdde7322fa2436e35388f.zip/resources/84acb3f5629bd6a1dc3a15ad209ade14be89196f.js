import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/EmptyState.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/frontend/components/Icon.tsx";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/EmptyState.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function EmptyState({ title, copy }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "member-empty",
		children: [
			/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 46
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 40
			}, this),
			/* @__PURE__ */ _jsxDEV("h3", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 74
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: copy }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 90
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/EmptyState.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/EmptyState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/EmptyState.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/EmptyState.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZOzs7QUFFckIsT0FBTyxTQUFTLFdBQVcsRUFBRSxPQUFPLFFBQXlDO0NBQzNFLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUE4Qix3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztZQUFPOzs7OztHQUFDLHdCQUFDLE1BQUQsWUFBSyxNQUFVOzs7OztHQUFDLHdCQUFDLEtBQUQsWUFBSSxLQUFROzs7OztFQUFNOzs7Ozs7QUFDM0ciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRW1wdHlTdGF0ZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuL0ljb25cIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBFbXB0eVN0YXRlKHsgdGl0bGUsIGNvcHkgfTogeyB0aXRsZTogc3RyaW5nOyBjb3B5OiBzdHJpbmcgfSkge1xyXG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIm1lbWJlci1lbXB0eVwiPjxzcGFuPjxJY29uIG5hbWU9XCJzcGFya1wiIC8+PC9zcGFuPjxoMz57dGl0bGV9PC9oMz48cD57Y29weX08L3A+PC9kaXY+O1xyXG59XHJcbiJdfQ==