import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/WorkoutsPage.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { EmptyState } from "/src/frontend/components/EmptyState.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { PageHeader } from "/src/frontend/components/PageHeader.tsx";
import { dateKey, prettyDate } from "/src/frontend/lib/format.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/WorkoutsPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function WorkoutsPage({ store, update, navigate, toast }) {
	_s();
	const [tab, setTab] = useState("week");
	const [selectedId, setSelectedId] = useState(null);
	const [openWeek, setOpenWeek] = useState(null);
	const [showMove, setShowMove] = useState(false);
	const [viewWeek, setViewWeek] = useState(null);
	const [settingsTargetId, setSettingsTargetId] = useState(null);
	const [settingsEquipment, setSettingsEquipment] = useState([]);
	const [settingsIntensity, setSettingsIntensity] = useState("Moderate");
	const [settingsLowImpact, setSettingsLowImpact] = useState(false);
	const [settingsScope, setSettingsScope] = useState("one");
	const today = new Date();
	today.setHours(12, 0, 0, 0);
	const todayKey = dateKey(today);
	const challengeStart = new Date(`${store.challenge.startDate}T12:00:00`);
	const challengeDay = Math.max(1, Math.min(store.challenge.length, Math.floor((today.getTime() - challengeStart.getTime()) / 864e5) + 1));
	const currentWeek = Math.max(0, Math.floor((challengeDay - 1) / 7));
	const displayedWeek = viewWeek ?? currentWeek;
	const totalWeeks = Math.ceil(store.challenge.length / 7);
	const selected = store.plan.find((workout) => workout.id === selectedId) ?? null;
	const completedIds = new Set(store.sessions.map((session) => session.workoutId));
	const completedKeys = new Set(store.sessions.map((session) => `${session.workoutId}-${session.date}`));
	const weekStart = new Date(challengeStart);
	weekStart.setDate(challengeStart.getDate() + displayedWeek * 7);
	const weekLength = Math.min(7, store.challenge.length - displayedWeek * 7);
	const weekDays = Array.from({ length: weekLength }, (_, index) => {
		const date = new Date(weekStart);
		date.setDate(weekStart.getDate() + index);
		const key = dateKey(date);
		return {
			date,
			key,
			workout: store.plan.find((item) => item.date === key)
		};
	});
	const weekEnd = weekDays.at(-1)?.date ?? weekStart;
	const todayWorkout = store.plan.find((workout) => workout.date === todayKey) ?? store.plan.filter((workout) => workout.date > todayKey && !workout.optional).sort((left, right) => left.date.localeCompare(right.date))[0] ?? null;
	const weeks = Array.from({ length: Math.ceil(store.challenge.length / 7) }, (_, index) => {
		const startOffset = index * 7;
		const endOffset = startOffset + 6;
		return {
			index,
			workouts: store.plan.filter((workout) => {
				const offset = Math.floor((new Date(`${workout.date}T12:00:00`).getTime() - challengeStart.getTime()) / 864e5);
				return offset >= startOffset && offset <= endOffset;
			})
		};
	});
	const difficulty = selected?.intensity ?? (selected?.name.includes("Recovery") ? "Easy" : "Moderate");
	const defaultEquipment = store.user.equipment.includes("Gym") ? ["Gym machines & barbell"] : store.user.equipment.includes("Dumbbell") ? ["Dumbbells", "Resistance bands"] : ["Bodyweight only"];
	const automaticLowImpact = store.user.injuryFlag || Number(store.user.age) > 0 && Number(store.user.age) < 18 || Number(store.user.age) >= 60;
	const openSettings = (workout) => {
		setSettingsTargetId(workout.id);
		setSettingsEquipment(workout.equipment === "Bodyweight / Home" || workout.equipment.includes("Bodyweight") ? ["Bodyweight only"] : workout.equipment.includes("Gym") ? ["Gym machines & barbell"] : workout.equipment.includes("Dumbbell") ? ["Dumbbells", "Resistance bands"] : defaultEquipment);
		setSettingsIntensity(workout.intensity ?? "Moderate");
		setSettingsLowImpact(workout.lowImpact ?? automaticLowImpact);
		setSettingsScope("one");
	};
	const toggleSettingsEquipment = (item) => {
		setSettingsEquipment((current) => item === "Bodyweight only" ? ["Bodyweight only"] : [...current.filter((value) => value !== "Bodyweight only" && value !== item), ...current.includes(item) ? [] : [item]]);
	};
	const savePlanSettings = () => {
		if (!settingsTargetId || !settingsEquipment.length) return;
		const equipmentLabel = settingsEquipment.length === 1 ? settingsEquipment[0] : settingsEquipment.join(" + ");
		const pools = {
			bodyweight: [
				"Bodyweight squats",
				"Incline push-ups",
				"Glute bridges",
				"Reverse lunges",
				"Mountain climbers",
				"Plank",
				"Bird dog",
				"Step jacks"
			],
			household: [
				"Backpack squats",
				"Incline push-ups",
				"Glute bridges",
				"Reverse lunges",
				"Water bottle rows",
				"Plank",
				"Bird dog",
				"Step jacks"
			],
			dumbbells: [
				"Dumbbell goblet squats",
				"Dumbbell floor press",
				"Dumbbell Romanian deadlifts",
				"Reverse lunges",
				"Dumbbell rows",
				"Plank",
				"Bird dog",
				"Dumbbell push press"
			],
			bands: [
				"Banded squats",
				"Banded chest press",
				"Banded glute bridges",
				"Reverse lunges",
				"Banded rows",
				"Plank",
				"Bird dog",
				"Banded step jacks"
			],
			gym: [
				"Barbell squats",
				"Machine chest press",
				"Cable pull-throughs",
				"Reverse lunges",
				"Seated cable rows",
				"Plank",
				"Bird dog",
				"Rowing intervals"
			]
		};
		const pool = settingsEquipment.includes("Gym machines & barbell") ? pools.gym : settingsEquipment.includes("Dumbbells") ? pools.dumbbells : settingsEquipment.includes("Resistance bands") ? pools.bands : settingsEquipment.includes("Household items (water bottles, backpack)") ? pools.household : pools.bodyweight;
		const prescription = settingsIntensity === "Easy" ? "30s work · 30s rest" : settingsIntensity === "Hard" ? "45s work · 15s rest" : "40s work · 20s rest";
		const plan = store.plan.map((workout) => {
			const applies = settingsScope === "all" ? workout.date >= todayKey : workout.id === settingsTargetId;
			if (!applies) return workout;
			const isRun = workout.name.includes("Walk-Run");
			return {
				...workout,
				equipment: equipmentLabel,
				intensity: settingsIntensity,
				lowImpact: settingsLowImpact,
				sets: settingsIntensity === "Easy" ? 2 : settingsIntensity === "Hard" ? 4 : 3,
				exercises: isRun ? workout.exercises : workout.exercises.map((exercise, index) => ({
					...exercise,
					name: pool[index % pool.length],
					prescription
				}))
			};
		});
		update({
			...store,
			plan
		});
		setSettingsTargetId(null);
		toast(`Workout updated: ${equipmentLabel} · ${settingsIntensity}.`);
	};
	const moveWorkout = (nextDate) => {
		if (!selected || !nextDate) return;
		update({
			...store,
			plan: store.plan.map((workout) => workout.id === selected.id ? {
				...workout,
				date: nextDate
			} : workout)
		});
		setShowMove(false);
		toast(`Workout moved to ${prettyDate(nextDate)}.`);
	};
	const closeDetail = () => {
		setSelectedId(null);
		setShowMove(false);
	};
	const openDetail = (workout) => workout && setSelectedId(workout.id);
	const startWorkout = (workout) => navigate(`/session/${workout.id}`);
	useEffect(() => {
		if (tab !== "week" || displayedWeek !== currentWeek) return;
		const timer = window.setTimeout(() => document.querySelector(".seven-day-strip .day-card.today")?.scrollIntoView({
			behavior: "smooth",
			block: "nearest",
			inline: "center"
		}), 50);
		return () => window.clearTimeout(timer);
	}, [
		tab,
		displayedWeek,
		currentWeek
	]);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(PageHeader, {
			eyebrow: `YOUR PLANS · DAY ${challengeDay}`,
			title: "My workouts"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 115,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "workout-tabs",
			role: "tablist",
			"aria-label": "Workout views",
			children: [
				["week", "This week"],
				["plan", "Full plan"],
				["history", "History"]
			].map(([value, label]) => /* @__PURE__ */ _jsxDEV("button", {
				role: "tab",
				"aria-selected": tab === value,
				className: tab === value ? "active" : "",
				onClick: () => setTab(value),
				children: label
			}, value, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 103
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 5
		}, this),
		tab === "week" && /* @__PURE__ */ _jsxDEV("div", {
			className: "week-view",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "challenge-week-head",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: [
							"Week ",
							displayedWeek + 1,
							" of ",
							totalWeeks,
							" · ",
							weekStart.toLocaleDateString(undefined, {
								month: "short",
								day: "numeric"
							}),
							" - ",
							weekEnd.toLocaleDateString(undefined, {
								month: "short",
								day: "numeric"
							})
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 14
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Day ",
							challengeDay,
							" of ",
							store.challenge.length
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 229
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
							disabled: displayedWeek === 0,
							onClick: () => setViewWeek(Math.max(0, displayedWeek - 1)),
							"aria-label": "Previous challenge week",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 150
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 14
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							disabled: displayedWeek === totalWeeks - 1,
							onClick: () => setViewWeek(Math.min(totalWeeks - 1, displayedWeek + 1)),
							"aria-label": "Next challenge week",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 337
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 179
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "challenge-day-progress",
							children: /* @__PURE__ */ _jsxDEV("i", { style: { width: `${challengeDay / store.challenge.length * 100}%` } }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 49
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "seven-day-strip",
					children: weekDays.map(({ date, key, workout }) => {
						const isToday = key === todayKey;
						const elapsed = date < today;
						const completed = Boolean(workout && (completedKeys.has(`${workout.id}-${key}`) || (elapsed || isToday) && completedIds.has(workout.id)));
						const state = completed ? "done" : isToday ? "today" : elapsed && workout ? "missed" : elapsed ? "elapsed-rest" : workout ? "upcoming" : "rest";
						const status = state === "done" ? "Done" : state === "missed" ? "Missed" : state === "today" ? "Today" : "Rest";
						return /* @__PURE__ */ _jsxDEV("article", {
							className: `day-card ${state}`,
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									className: "day-card-main",
									onClick: () => openDetail(workout),
									disabled: !workout,
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "day-card-date",
											children: [/* @__PURE__ */ _jsxDEV("small", { children: date.toLocaleDateString(undefined, { weekday: "short" }) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 135,
												columnNumber: 47
											}, this), /* @__PURE__ */ _jsxDEV("strong", { children: date.getDate() }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 135,
												columnNumber: 120
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 135,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "day-card-workout",
											children: [/* @__PURE__ */ _jsxDEV("strong", { children: workout?.name || "Recovery day" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 136,
												columnNumber: 50
											}, this), /* @__PURE__ */ _jsxDEV("small", { children: workout ? `${workout.minutes} min` : "Rest & reset" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 136,
												columnNumber: 100
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 136,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: `status-chip ${state}`,
											children: [state === "done" ? /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 76
											}, this) : state === "missed" ? /* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 121
											}, this) : !workout ? /* @__PURE__ */ _jsxDEV(Icon, { name: "moon" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 155
											}, this) : isToday ? /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 188
											}, this) : /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 215
											}, this), status === "Rest" && workout ? "Upcoming" : status]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 137,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 13
								}, this),
								isToday && workout && /* @__PURE__ */ _jsxDEV("button", {
									className: "day-start",
									onClick: () => startWorkout(workout),
									children: "Start workout"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 36
								}, this),
								state === "missed" && workout && /* @__PURE__ */ _jsxDEV("button", {
									className: "reschedule-link",
									onClick: () => {
										openDetail(workout);
										setShowMove(true);
									},
									children: "Reschedule"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 47
								}, this)
							]
						}, key, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 18
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "workout-legend",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "done",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 65
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 45
						}, this), "Done"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 39
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "today",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 128
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 107
						}, this), "Today"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 101
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "upcoming",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 198
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 174
						}, this), "Upcoming"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 168
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "rest",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "moon" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 264
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 244
						}, this), "Rest"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 238
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: "missed",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 327
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 305
						}, this), "Missed"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 299
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "section-title",
					children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "YOUR NEXT SESSION" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 43
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: todayWorkout?.date === todayKey ? "Ready when you are." : "Coming up next" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 75
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 38
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 7
				}, this),
				todayWorkout ? /* @__PURE__ */ _jsxDEV("article", {
					className: "today-detail-card",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: "plan-settings-button dark",
							onClick: () => openSettings(todayWorkout),
							"aria-label": "Plan settings",
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "sliders" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 125
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								role: "tooltip",
								children: "Plan settings"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 148
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "workout-label",
								children: [
									new Date(`${todayWorkout.date}T12:00:00`).toLocaleDateString(undefined, {
										weekday: "short",
										month: "short",
										day: "numeric"
									}).toUpperCase(),
									" · ",
									todayWorkout.minutes,
									" MIN"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 14
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", { children: todayWorkout.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 223
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								todayWorkout.exercises.length,
								" exercises · ",
								/* @__PURE__ */ _jsxDEV("span", { children: todayWorkout.equipment }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 298
								}, this),
								" · ",
								todayWorkout.intensity ?? "Moderate"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 251
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "target-chips",
								children: todayWorkout.targetTags.map((tag) => /* @__PURE__ */ _jsxDEV("i", { children: tag }, tag, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 448
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 380
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "today-detail-actions",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "ghost",
								onClick: () => openDetail(todayWorkout),
								children: "View details"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 47
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => startWorkout(todayWorkout),
								children: ["Start workout ", /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 198
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 133
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 23
				}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
					title: "A clear day to recover",
					copy: "Rest supports your progress. Your next planned workout will appear here."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 150,
					columnNumber: 20
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 120,
			columnNumber: 24
		}, this),
		tab === "plan" && /* @__PURE__ */ _jsxDEV("div", {
			className: "plan-weeks",
			children: weeks.map((week) => {
				const expanded = openWeek === week.index || openWeek === null && week.index === currentWeek;
				const completed = week.workouts.filter((workout) => completedIds.has(workout.id)).length;
				const planned = week.workouts.filter((workout) => !workout.optional).length;
				return /* @__PURE__ */ _jsxDEV("article", {
					className: `plan-week ${week.index > currentWeek ? "future" : ""}`,
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "plan-week-toggle",
						"aria-expanded": expanded,
						onClick: () => setOpenWeek(expanded ? -1 : week.index),
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: ["WEEK ", week.index + 1] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: week.index === currentWeek ? "This week" : `Days ${week.index * 7 + 1}–${Math.min(store.challenge.length, week.index * 7 + 7)}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 55
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							completed,
							"/",
							planned,
							" sessions ",
							/* @__PURE__ */ _jsxDEV("i", { children: expanded ? "−" : "+" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 50
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 11
					}, this), expanded && /* @__PURE__ */ _jsxDEV("div", {
						className: "plan-week-workouts",
						children: week.workouts.length ? week.workouts.map((workout) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => openDetail(workout),
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("small", { children: prettyDate(workout.date) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 182
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: workout.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 223
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 176
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								workout.minutes,
								" min ",
								/* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 289
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 261
							}, this)]
						}, workout.id, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 115
						}, this)) : /* @__PURE__ */ _jsxDEV("p", { children: "Recovery week — no sessions scheduled." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 330
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 24
					}, this)]
				}, week.index, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 16
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 24
		}, this),
		tab === "history" && /* @__PURE__ */ _jsxDEV("div", {
			className: "history-view",
			children: store.sessions.length ? /* @__PURE__ */ _jsxDEV("div", {
				className: "history-list",
				children: store.sessions.slice().reverse().map((session) => {
					const workout = store.plan.find((item) => item.id === session.workoutId);
					return /* @__PURE__ */ _jsxDEV("article", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "dash-stat-icon",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 103
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 70
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: prettyDate(session.date) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 136
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: workout?.name || "Completed workout" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 177
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 131
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: [session.duration, " min"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 235
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Effort ",
							session.effort,
							"/5"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 274
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 230
						}, this)
					] }, `${session.workoutId}-${session.date}`, true, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 16
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 32
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "history-empty",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "history-illustration",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "dumbbell" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 113
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 107
							}, this),
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 144
							}, this),
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 149
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 50
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Your finished workouts will show up here." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 160
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Start today's session to log your first one." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 210
					}, this),
					todayWorkout && /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => startWorkout(todayWorkout),
						children: ["Start workout ", /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 343
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 278
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 19
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 168,
			columnNumber: 27
		}, this),
		selected && /* @__PURE__ */ _jsxDEV("div", {
			className: "workout-drawer-backdrop",
			onMouseDown: closeDetail,
			children: /* @__PURE__ */ _jsxDEV("aside", {
				className: "workout-detail-drawer",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": `${selected.name} details`,
				onMouseDown: (event) => event.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("header", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "drawer-header-actions",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: "plan-settings-button",
								onClick: () => openSettings(selected),
								"aria-label": "Plan settings",
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "sliders" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 163
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									role: "tooltip",
									children: "Plan settings"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 186
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 56
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: "drawer-close",
								onClick: closeDetail,
								"aria-label": "Close workout details",
								children: "×"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 236
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: [
							selected.minutes,
							" MIN · ",
							difficulty.toUpperCase()
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 342
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: selected.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 408
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "target-chips",
							children: [/* @__PURE__ */ _jsxDEV("i", { children: selected.equipment }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 462
							}, this), selected.targetTags.map((tag) => /* @__PURE__ */ _jsxDEV("i", { children: tag }, tag, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 523
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 432
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "drawer-scroll",
						children: [selected.name.includes("Walk-Run") && /* @__PURE__ */ _jsxDEV("div", {
							className: "run-segments",
							children: [/* @__PURE__ */ _jsxDEV("small", { children: "RUN SEGMENTS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 80
							}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Warm-up walk 5:00 · 8 × (jog 1:00 / walk 2:00) · cool-down 5:00" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 107
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 50
						}, this), /* @__PURE__ */ _jsxDEV("ol", {
							className: "detail-exercises",
							children: selected.exercises.map((exercise, index) => /* @__PURE__ */ _jsxDEV("li", { children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "exercise-number",
									children: String(index + 1).padStart(2, "0")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "dumbbell-icon",
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "dumbbell" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 181,
										columnNumber: 122
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 90
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: exercise.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 18
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: [exercise.prescription, selected.lowImpact && /* @__PURE__ */ _jsxDEV("em", { children: "Low-impact" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 103
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 50
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("i", { children: selected.targetTags[index % selected.targetTags.length] }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 137
								}, this)
							] }, `${exercise.name}-${index}`, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 89
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("footer", { children: [
						showMove && /* @__PURE__ */ _jsxDEV("label", {
							className: "move-date",
							children: ["Choose a new day", /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								min: todayKey,
								defaultValue: selected.date,
								onChange: (event) => moveWorkout(event.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 69
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 24
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							onClick: () => setShowMove((current) => !current),
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 91
							}, this), " Move to another day"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 16
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => startWorkout(selected),
							children: ["Start workout ", /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 205
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 144
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "General fitness guidance, not medical advice." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 176,
				columnNumber: 7
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 175,
			columnNumber: 18
		}, this),
		settingsTargetId && /* @__PURE__ */ _jsxDEV("div", {
			className: "plan-settings-backdrop",
			onMouseDown: () => setSettingsTargetId(null),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "plan-settings-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": "Plan settings",
				onMouseDown: (event) => event.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("small", { children: "WORKOUT PREFERENCES" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 271
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Plan settings" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 305
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Tell us what you have and how hard you want to train." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 327
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 266
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSettingsTargetId(null),
						"aria-label": "Close plan settings",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 476
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 393
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 258
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "plan-settings-body",
						children: [
							/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "What equipment do you have for this plan?" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "settings-equipment",
								children: [
									"Bodyweight only",
									"Household items (water bottles, backpack)",
									"Dumbbells",
									"Resistance bands",
									"Gym machines & barbell"
								].map((item) => /* @__PURE__ */ _jsxDEV("button", {
									className: settingsEquipment.includes(item) ? "active" : "",
									onClick: () => toggleSettingsEquipment(item),
									children: [settingsEquipment.includes(item) && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 413
									}, this), item]
								}, item, true, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 250
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 75
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "How intense should it be?" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "intensity-control",
								children: [
									["Easy", "Lower impact, longer rests"],
									["Moderate", "Balanced work and rest"],
									["Hard", "More work, shorter rests"]
								].map(([name, copy]) => /* @__PURE__ */ _jsxDEV("button", {
									className: settingsIntensity === name ? "active" : "",
									onClick: () => setSettingsIntensity(name),
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 364
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: copy }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 387
									}, this)]
								}, name, true, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 247
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 59
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "settings-toggle",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Include low-impact versions" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 48
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Add joint-friendly alternatives where useful." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 92
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 42
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "checkbox",
									checked: settingsLowImpact,
									onChange: (event) => setSettingsLowImpact(event.target.checked)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 159
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 7
							}, this),
							/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Apply to" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "settings-scope",
								children: [/* @__PURE__ */ _jsxDEV("label", { children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "settings-scope",
									checked: settingsScope === "one",
									onChange: () => setSettingsScope("one")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 81
								}, this), "This workout only"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 74
								}, this), /* @__PURE__ */ _jsxDEV("label", { children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "settings-scope",
									checked: settingsScope === "all",
									onChange: () => setSettingsScope("all")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 232
								}, this), "All upcoming workouts"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 225
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 42
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 7
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 515
					}, this),
					/* @__PURE__ */ _jsxDEV("footer", { children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "reset-settings",
						onClick: () => {
							setSettingsEquipment(defaultEquipment);
							setSettingsIntensity("Moderate");
							setSettingsLowImpact(automaticLowImpact);
							setSettingsScope("one");
						},
						children: "Reset to profile defaults"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						onClick: () => setSettingsTargetId(null),
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 254
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						disabled: !settingsEquipment.length,
						onClick: savePlanSettings,
						children: "Save changes"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 335
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 249
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 112
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 192,
			columnNumber: 26
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 114,
		columnNumber: 10
	}, this);
}
_s(WorkoutsPage, "2Mu2qVamcSY/1cwQiQfA3ZnVPEM=");
_c = WorkoutsPage;
var _c;
$RefreshReg$(_c, "WorkoutsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/WorkoutsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/WorkoutsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/WorkoutsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/WorkoutsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsU0FBUyxrQkFBa0I7Ozs7QUFFcEMsT0FBTyxTQUFTLGFBQWEsRUFBRSxPQUFPLFFBQVEsVUFBVSxTQUE2Sjs7Q0FDbk4sTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFzQyxNQUFNO0NBQ2xFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUF3QixJQUFJO0NBQ2hFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7Q0FDNUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBd0IsSUFBSTtDQUM1RSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFtQixDQUFDLENBQUM7Q0FDdkUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBdUMsVUFBVTtDQUNuRyxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQXdCLEtBQUs7Q0FDdkUsTUFBTSxRQUFRLElBQUksS0FBSztDQUN2QixNQUFNLFNBQVMsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUMxQixNQUFNLFdBQVcsUUFBUSxLQUFLO0NBQzlCLE1BQU0saUJBQWlCLElBQUksS0FBSyxHQUFHLE1BQU0sVUFBVSxVQUFVLFVBQVU7Q0FDdkUsTUFBTSxlQUFlLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxNQUFNLFVBQVUsUUFBUSxLQUFLLE9BQU8sTUFBTSxRQUFRLElBQUksZUFBZSxRQUFRLEtBQUssS0FBVSxJQUFJLENBQUMsQ0FBQztDQUM1SSxNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLGVBQWUsS0FBSyxDQUFDLENBQUM7Q0FDbEUsTUFBTSxnQkFBZ0IsWUFBWTtDQUNsQyxNQUFNLGFBQWEsS0FBSyxLQUFLLE1BQU0sVUFBVSxTQUFTLENBQUM7Q0FDdkQsTUFBTSxXQUFXLE1BQU0sS0FBSyxNQUFNLFlBQVksUUFBUSxPQUFPLFVBQVUsS0FBSztDQUM1RSxNQUFNLGVBQWUsSUFBSSxJQUFJLE1BQU0sU0FBUyxLQUFLLFlBQVksUUFBUSxTQUFTLENBQUM7Q0FDL0UsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJLE1BQU0sU0FBUyxLQUFLLFlBQVksR0FBRyxRQUFRLFVBQVUsR0FBRyxRQUFRLE1BQU0sQ0FBQztDQUNyRyxNQUFNLFlBQVksSUFBSSxLQUFLLGNBQWM7Q0FDekMsVUFBVSxRQUFRLGVBQWUsUUFBUSxJQUFJLGdCQUFnQixDQUFDO0NBQzlELE1BQU0sYUFBYSxLQUFLLElBQUksR0FBRyxNQUFNLFVBQVUsU0FBUyxnQkFBZ0IsQ0FBQztDQUN6RSxNQUFNLFdBQVcsTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLElBQUksR0FBRyxVQUFVO0VBQ2hFLE1BQU0sT0FBTyxJQUFJLEtBQUssU0FBUztFQUMvQixLQUFLLFFBQVEsVUFBVSxRQUFRLElBQUksS0FBSztFQUN4QyxNQUFNLE1BQU0sUUFBUSxJQUFJO0VBQ3hCLE9BQU87R0FBRTtHQUFNO0dBQUssU0FBUyxNQUFNLEtBQUssTUFBTSxTQUFTLEtBQUssU0FBUyxHQUFHO0VBQUU7Q0FDNUUsQ0FBQztDQUNELE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRO0NBQ3pDLE1BQU0sZUFBZSxNQUFNLEtBQUssTUFBTSxZQUFZLFFBQVEsU0FBUyxRQUFRLEtBQUssTUFBTSxLQUFLLFFBQVEsWUFBWSxRQUFRLE9BQU8sWUFBWSxDQUFDLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxNQUFNLFVBQVUsS0FBSyxLQUFLLGNBQWMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU07Q0FDOU4sTUFBTSxRQUFRLE1BQU0sS0FBSyxFQUFFLFFBQVEsS0FBSyxLQUFLLE1BQU0sVUFBVSxTQUFTLENBQUMsRUFBRSxJQUFJLEdBQUcsVUFBVTtFQUN4RixNQUFNLGNBQWMsUUFBUTtFQUM1QixNQUFNLFlBQVksY0FBYztFQUNoQyxPQUFPO0dBQ0w7R0FDQSxVQUFVLE1BQU0sS0FBSyxRQUFRLFlBQVk7SUFDdkMsTUFBTSxTQUFTLEtBQUssT0FBTyxJQUFJLEtBQUssR0FBRyxRQUFRLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxJQUFJLGVBQWUsUUFBUSxLQUFLLEtBQVU7SUFDbEgsT0FBTyxVQUFVLGVBQWUsVUFBVTtHQUM1QyxDQUFDO0VBQ0g7Q0FDRixDQUFDO0NBQ0QsTUFBTSxhQUFhLFVBQVUsY0FBYyxVQUFVLEtBQUssU0FBUyxVQUFVLElBQUksU0FBUztDQUMxRixNQUFNLG1CQUFtQixNQUFNLEtBQUssVUFBVSxTQUFTLEtBQUssSUFBSSxDQUFDLHdCQUF3QixJQUFJLE1BQU0sS0FBSyxVQUFVLFNBQVMsVUFBVSxJQUFJLENBQUMsYUFBYSxrQkFBa0IsSUFBSSxDQUFDLGlCQUFpQjtDQUMvTCxNQUFNLHFCQUFxQixNQUFNLEtBQUssY0FBZSxPQUFPLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTyxPQUFPLE1BQU0sS0FBSyxHQUFHLEtBQUs7Q0FDN0ksTUFBTSxnQkFBZ0IsWUFBNEI7RUFDaEQsb0JBQW9CLFFBQVEsRUFBRTtFQUM5QixxQkFBcUIsUUFBUSxjQUFjLHVCQUF1QixRQUFRLFVBQVUsU0FBUyxZQUFZLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLElBQUksQ0FBQyx3QkFBd0IsSUFBSSxRQUFRLFVBQVUsU0FBUyxVQUFVLElBQUksQ0FBQyxhQUFhLGtCQUFrQixJQUFJLGdCQUFnQjtFQUNqUyxxQkFBcUIsUUFBUSxhQUFhLFVBQVU7RUFDcEQscUJBQXFCLFFBQVEsYUFBYSxrQkFBa0I7RUFDNUQsaUJBQWlCLEtBQUs7Q0FDeEI7Q0FDQSxNQUFNLDJCQUEyQixTQUFpQjtFQUNoRCxzQkFBc0IsWUFBWSxTQUFTLG9CQUFvQixDQUFDLGlCQUFpQixJQUFJLENBQUMsR0FBRyxRQUFRLFFBQVEsVUFBVSxVQUFVLHFCQUFxQixVQUFVLElBQUksR0FBRyxHQUFJLFFBQVEsU0FBUyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUM7Q0FDL007Q0FDQSxNQUFNLHlCQUF5QjtFQUM3QixJQUFJLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLFFBQVE7RUFDcEQsTUFBTSxpQkFBaUIsa0JBQWtCLFdBQVcsSUFBSSxrQkFBa0IsS0FBSyxrQkFBa0IsS0FBSyxLQUFLO0VBQzNHLE1BQU0sUUFBUTtHQUNaLFlBQVk7SUFBQztJQUFxQjtJQUFvQjtJQUFpQjtJQUFrQjtJQUFxQjtJQUFTO0lBQVk7R0FBWTtHQUMvSSxXQUFXO0lBQUM7SUFBbUI7SUFBb0I7SUFBaUI7SUFBa0I7SUFBcUI7SUFBUztJQUFZO0dBQVk7R0FDNUksV0FBVztJQUFDO0lBQTBCO0lBQXdCO0lBQStCO0lBQWtCO0lBQWlCO0lBQVM7SUFBWTtHQUFxQjtHQUMxSyxPQUFPO0lBQUM7SUFBaUI7SUFBc0I7SUFBd0I7SUFBa0I7SUFBZTtJQUFTO0lBQVk7R0FBbUI7R0FDaEosS0FBSztJQUFDO0lBQWtCO0lBQXVCO0lBQXVCO0lBQWtCO0lBQXFCO0lBQVM7SUFBWTtHQUFrQjtFQUN0SjtFQUNBLE1BQU0sT0FBTyxrQkFBa0IsU0FBUyx3QkFBd0IsSUFBSSxNQUFNLE1BQU0sa0JBQWtCLFNBQVMsV0FBVyxJQUFJLE1BQU0sWUFBWSxrQkFBa0IsU0FBUyxrQkFBa0IsSUFBSSxNQUFNLFFBQVEsa0JBQWtCLFNBQVMsMkNBQTJDLElBQUksTUFBTSxZQUFZLE1BQU07RUFDN1MsTUFBTSxlQUFlLHNCQUFzQixTQUFTLHdCQUF3QixzQkFBc0IsU0FBUyx3QkFBd0I7RUFDbkksTUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFlBQVk7R0FDdkMsTUFBTSxVQUFVLGtCQUFrQixRQUFRLFFBQVEsUUFBUSxXQUFXLFFBQVEsT0FBTztHQUNwRixJQUFJLENBQUMsU0FBUyxPQUFPO0dBQ3JCLE1BQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxVQUFVO0dBQzlDLE9BQU87SUFDTCxHQUFHO0lBQ0gsV0FBVztJQUNYLFdBQVc7SUFDWCxXQUFXO0lBQ1gsTUFBTSxzQkFBc0IsU0FBUyxJQUFJLHNCQUFzQixTQUFTLElBQUk7SUFDNUUsV0FBVyxRQUFRLFFBQVEsWUFBWSxRQUFRLFVBQVUsS0FBSyxVQUFVLFdBQVc7S0FBRSxHQUFHO0tBQVUsTUFBTSxLQUFLLFFBQVEsS0FBSztLQUFTO0lBQWEsRUFBRTtHQUNwSjtFQUNGLENBQUM7RUFDRCxPQUFPO0dBQUUsR0FBRztHQUFPO0VBQUssQ0FBQztFQUN6QixvQkFBb0IsSUFBSTtFQUN4QixNQUFNLG9CQUFvQixlQUFlLEtBQUssa0JBQWtCLEVBQUU7Q0FDcEU7Q0FDQSxNQUFNLGVBQWUsYUFBcUI7RUFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVO0VBQzVCLE9BQU87R0FBRSxHQUFHO0dBQU8sTUFBTSxNQUFNLEtBQUssS0FBSyxZQUFZLFFBQVEsT0FBTyxTQUFTLEtBQUs7SUFBRSxHQUFHO0lBQVMsTUFBTTtHQUFTLElBQUksT0FBTztFQUFFLENBQUM7RUFDN0gsWUFBWSxLQUFLO0VBQ2pCLE1BQU0sb0JBQW9CLFdBQVcsUUFBUSxFQUFFLEVBQUU7Q0FDbkQ7Q0FDQSxNQUFNLG9CQUFvQjtFQUN4QixjQUFjLElBQUk7RUFDbEIsWUFBWSxLQUFLO0NBQ25CO0NBQ0EsTUFBTSxjQUFjLFlBQTZCLFdBQVcsY0FBYyxRQUFRLEVBQUU7Q0FDcEYsTUFBTSxnQkFBZ0IsWUFBNEIsU0FBUyxZQUFZLFFBQVEsSUFBSTtDQUVuRixnQkFBZ0I7RUFDZCxJQUFJLFFBQVEsVUFBVSxrQkFBa0IsYUFBYTtFQUNyRCxNQUFNLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxjQUFjLGtDQUFrQyxDQUFDLEVBQUUsZUFBZTtHQUFFLFVBQVU7R0FBVSxPQUFPO0dBQVcsUUFBUTtFQUFTLENBQUMsR0FBRyxFQUFFO0VBQ2hMLGFBQWEsT0FBTyxhQUFhLEtBQUs7Q0FDeEMsR0FBRztFQUFDO0VBQUs7RUFBZTtDQUFXLENBQUM7Q0FFcEMsT0FBTztFQUNMLHdCQUFDLFlBQUQ7R0FBWSxTQUFTLG9CQUFvQjtHQUFnQixPQUFNO0VBQWU7Ozs7O0VBQzlFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWUsTUFBSztHQUFVLGNBQVc7YUFDckQ7SUFBQyxDQUFDLFFBQVEsV0FBVztJQUFHLENBQUMsUUFBUSxXQUFXO0lBQUcsQ0FBQyxXQUFXLFNBQVM7R0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sV0FBVyx3QkFBQyxVQUFEO0lBQW9CLE1BQUs7SUFBTSxpQkFBZSxRQUFRO0lBQU8sV0FBVyxRQUFRLFFBQVEsV0FBVztJQUFJLGVBQWUsT0FBTyxLQUFvQztjQUFJO0dBQWMsR0FBdEs7Ozs7VUFBc0ssQ0FBQztFQUNqUjs7Ozs7RUFFSixRQUFRLFVBQVUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQ7T0FBUTtPQUFNLGdCQUFnQjtPQUFFO09BQUs7T0FBVztPQUFJLFVBQVUsbUJBQW1CLFdBQVc7UUFBRSxPQUFPO1FBQVMsS0FBSztPQUFVLENBQUM7T0FBRTtPQUFJLFFBQVEsbUJBQW1CLFdBQVc7UUFBRSxPQUFPO1FBQVMsS0FBSztPQUFVLENBQUM7TUFBVTs7OztnQkFBQyx3QkFBQyxRQUFEO09BQU07T0FBSztPQUFhO09BQUssTUFBTSxVQUFVO01BQWE7Ozs7Y0FBTTs7Ozs7TUFDNVIsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQ7T0FBUSxVQUFVLGtCQUFrQjtPQUFHLGVBQWUsWUFBWSxLQUFLLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDO09BQUcsY0FBVztpQkFBMEIsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7TUFBUzs7OztnQkFBQyx3QkFBQyxVQUFEO09BQVEsVUFBVSxrQkFBa0IsYUFBYTtPQUFHLGVBQWUsWUFBWSxLQUFLLElBQUksYUFBYSxHQUFHLGdCQUFnQixDQUFDLENBQUM7T0FBRyxjQUFXO2lCQUFzQix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztNQUFTOzs7O2NBQU07Ozs7O01BQzNXLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUF5Qix3QkFBQyxLQUFELEVBQUcsT0FBTyxFQUFFLE9BQU8sR0FBRyxlQUFlLE1BQU0sVUFBVSxTQUFTLElBQUksR0FBRyxFQUFJOzs7OztNQUFNOzs7OztLQUNwSDs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixTQUFTLEtBQUssRUFBRSxNQUFNLEtBQUssY0FBYztNQUN4QyxNQUFNLFVBQVUsUUFBUTtNQUN4QixNQUFNLFVBQVUsT0FBTztNQUN2QixNQUFNLFlBQVksUUFBUSxZQUFZLGNBQWMsSUFBSSxHQUFHLFFBQVEsR0FBRyxHQUFHLEtBQUssTUFBTyxXQUFXLFlBQVksYUFBYSxJQUFJLFFBQVEsRUFBRSxFQUFHO01BQzFJLE1BQU0sUUFBUSxZQUFZLFNBQVMsVUFBVSxVQUFVLFdBQVcsVUFBVSxXQUFXLFVBQVUsaUJBQWlCLFVBQVUsYUFBYTtNQUN6SSxNQUFNLFNBQVMsVUFBVSxTQUFTLFNBQVMsVUFBVSxXQUFXLFdBQVcsVUFBVSxVQUFVLFVBQVU7TUFDekcsT0FBTyx3QkFBQyxXQUFEO09BQW1CLFdBQVcsWUFBWTtpQkFBMUM7UUFDTCx3QkFBQyxVQUFEO1NBQVEsV0FBVTtTQUFnQixlQUFlLFdBQVcsT0FBTztTQUFHLFVBQVUsQ0FBQzttQkFBakY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBZ0Msd0JBQUMsU0FBRCxZQUFRLEtBQUssbUJBQW1CLFdBQVcsRUFBRSxTQUFTLFFBQVEsQ0FBQyxFQUFTOzs7O3FCQUFDLHdCQUFDLFVBQUQsWUFBUyxLQUFLLFFBQVEsRUFBVTs7OzttQkFBTzs7Ozs7O1VBQ2hKLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUFtQyx3QkFBQyxVQUFELFlBQVMsU0FBUyxRQUFRLGVBQXVCOzs7O3FCQUFDLHdCQUFDLFNBQUQsWUFBUSxVQUFVLEdBQUcsUUFBUSxRQUFRLFFBQVEsZUFBc0I7Ozs7bUJBQU87Ozs7OztVQUMvSix3QkFBQyxRQUFEO1dBQU0sV0FBVyxlQUFlO3FCQUFoQyxDQUEwQyxVQUFVLFNBQVMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztzQkFBSSxVQUFVLFdBQVcsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztzQkFBSSxDQUFDLFVBQVUsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztzQkFBSSxVQUFVLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7c0JBQUksd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztxQkFBRyxXQUFXLFVBQVUsVUFBVSxhQUFhLE1BQWE7Ozs7OztTQUNsUjs7Ozs7O1FBQ1AsV0FBVyxXQUFXLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQVksZUFBZSxhQUFhLE9BQU87bUJBQUc7UUFBcUI7Ozs7O1FBQy9HLFVBQVUsWUFBWSxXQUFXLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO1NBQWtCLGVBQWU7VUFBRSxXQUFXLE9BQU87VUFBRyxZQUFZLElBQUk7U0FBRzttQkFBRztRQUFrQjs7Ozs7T0FDN0k7U0FSWTs7OzthQVFaO0tBQ1gsQ0FBQztJQUNFOzs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFBZ0Msd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFPLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O01BQUk7Ozs7Z0JBQUMsTUFBVTs7Ozs7TUFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQVEsd0JBQUMsTUFBRCxFQUFNLE1BQUssV0FBWTs7Ozs7TUFBSTs7OztnQkFBQyxPQUFXOzs7OztNQUFDLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBVyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztNQUFJOzs7O2dCQUFDLFVBQWM7Ozs7O01BQUMsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFPLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O01BQUk7Ozs7Z0JBQUMsTUFBVTs7Ozs7TUFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQVMsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7TUFBSTs7OztnQkFBQyxRQUFZOzs7OztLQUFNOzs7Ozs7SUFDMVcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZ0Isd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQsWUFBTyxvQkFBd0I7Ozs7ZUFBQyx3QkFBQyxNQUFELFlBQUssY0FBYyxTQUFTLFdBQVcsd0JBQXdCLGlCQUFxQjs7OzthQUFNOzs7OztJQUFNOzs7OztJQUNuSyxlQUFlLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQ2Qsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBNEIsZUFBZSxhQUFhLFlBQVk7T0FBRyxjQUFXO2lCQUFwRyxDQUFvSCx3QkFBQyxNQUFELEVBQU0sTUFBSyxVQUFXOzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBTSxNQUFLO2tCQUFVO09BQW1COzs7O2VBQVM7Ozs7OztNQUM1TCx3QkFBQyxPQUFEO09BQUssd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQWlDLElBQUksS0FBSyxHQUFHLGFBQWEsS0FBSyxVQUFVLENBQUMsQ0FBQyxtQkFBbUIsV0FBVztVQUFFLFNBQVM7VUFBUyxPQUFPO1VBQVMsS0FBSztTQUFVLENBQUMsQ0FBQyxDQUFDLFlBQVk7U0FBRTtTQUFJLGFBQWE7U0FBUTtRQUFVOzs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUssYUFBYSxLQUFTOzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBSSxhQUFhLFVBQVU7UUFBTztRQUFhLHdCQUFDLFFBQUQsWUFBTyxhQUFhLFVBQWdCOzs7OztRQUFDO1FBQUksYUFBYSxhQUFhO09BQWM7Ozs7O09BQUMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWdCLGFBQWEsV0FBVyxLQUFLLFFBQVEsd0JBQUMsS0FBRCxZQUFjLElBQU8sR0FBYjs7OztlQUFhLENBQUM7T0FBTzs7Ozs7TUFBTTs7Ozs7TUFDMWQsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBc0Msd0JBQUMsUUFBRDtRQUFRLFNBQVE7UUFBUSxlQUFlLFdBQVcsWUFBWTtrQkFBRztPQUFvQjs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQVEsZUFBZSxhQUFhLFlBQVk7a0JBQWhELENBQW1ELGtCQUFjLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7Z0JBQVM7Ozs7O2VBQU07Ozs7OztLQUN4Tjs7Ozs7ZUFBSSx3QkFBQyxZQUFEO0tBQVksT0FBTTtLQUF5QixNQUFLO0lBQTRFOzs7OztHQUN0STs7Ozs7O0VBRUosUUFBUSxVQUFVLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQy9CLE1BQU0sS0FBSyxTQUFTO0lBQ25CLE1BQU0sV0FBVyxhQUFhLEtBQUssU0FBVSxhQUFhLFFBQVEsS0FBSyxVQUFVO0lBQ2pGLE1BQU0sWUFBWSxLQUFLLFNBQVMsUUFBUSxZQUFZLGFBQWEsSUFBSSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDbEYsTUFBTSxVQUFVLEtBQUssU0FBUyxRQUFRLFlBQVksQ0FBQyxRQUFRLFFBQVEsQ0FBQyxDQUFDO0lBQ3JFLE9BQU8sd0JBQUMsV0FBRDtLQUFTLFdBQVcsYUFBYSxLQUFLLFFBQVEsY0FBYyxXQUFXO2VBQXZFLENBQ0wsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBbUIsaUJBQWU7TUFBVSxlQUFlLFlBQVksV0FBVyxDQUFDLElBQUksS0FBSyxLQUFLO2dCQUFuSCxDQUNFLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxTQUFELGFBQU8sU0FBTSxLQUFLLFFBQVEsQ0FBUzs7OztnQkFBQyx3QkFBQyxVQUFELFlBQVMsS0FBSyxVQUFVLGNBQWMsY0FBYyxRQUFRLEtBQUssUUFBUSxJQUFJLEVBQUUsR0FBRyxLQUFLLElBQUksTUFBTSxVQUFVLFFBQVEsS0FBSyxRQUFRLElBQUksQ0FBQyxJQUFZOzs7O2NBQU87Ozs7Z0JBQ2xNLHdCQUFDLFFBQUQ7T0FBTztPQUFVO09BQUU7T0FBUTtPQUFVLHdCQUFDLEtBQUQsWUFBSSxXQUFXLE1BQU0sSUFBTzs7Ozs7TUFBTzs7OztjQUNsRTs7Ozs7ZUFDUCxZQUFZLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFzQixLQUFLLFNBQVMsU0FBUyxLQUFLLFNBQVMsS0FBSyxZQUFZLHdCQUFDLFVBQUQ7T0FBeUIsZUFBZSxXQUFXLE9BQU87aUJBQTFELENBQTZELHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxTQUFELFlBQVEsV0FBVyxRQUFRLElBQUksRUFBUzs7OztpQkFBQyx3QkFBQyxVQUFELFlBQVMsUUFBUSxLQUFhOzs7O2VBQU87Ozs7aUJBQUMsd0JBQUMsUUFBRDtRQUFPLFFBQVE7UUFBUTtRQUFLLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O09BQU87Ozs7ZUFBUztTQUFyTSxRQUFROzs7O2FBQTZMLENBQUMsSUFBSSx3QkFBQyxLQUFELFlBQUcseUNBQXlDOzs7OztLQUFPOzs7O2FBQzNXO09BTmdGLEtBQUs7Ozs7V0FNckY7R0FDWCxDQUFDO0VBQ0U7Ozs7O0VBRUosUUFBUSxhQUFhLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2xDLE1BQU0sU0FBUyxTQUFTLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWdCLE1BQU0sU0FBUyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLFlBQVk7S0FDeEcsTUFBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLFNBQVMsS0FBSyxPQUFPLFFBQVEsU0FBUztLQUN2RSxPQUFPLHdCQUFDLFdBQUQ7TUFBc0Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O01BQU87Ozs7O01BQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQsWUFBUSxXQUFXLFFBQVEsSUFBSSxFQUFTOzs7O2dCQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLFFBQVEsb0JBQXdCOzs7O2NBQU07Ozs7O01BQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsYUFBUyxRQUFRLFVBQVMsTUFBWTs7OztnQkFBQyx3QkFBQyxRQUFEO09BQU07T0FBUSxRQUFRO09BQU87TUFBUTs7OztjQUFNOzs7OztLQUFVLEtBQXpTLEdBQUcsUUFBUSxVQUFVLEdBQUcsUUFBUTs7OztZQUF5UTtJQUNoVSxDQUFDO0dBQU87Ozs7Y0FBSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQStCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQXVCLGVBQVk7Z0JBQWxEO09BQXlELHdCQUFDLFFBQUQsWUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBSyxXQUFZOzs7O2dCQUFPOzs7OztPQUFDLHdCQUFDLEtBQUQsQ0FBSTs7Ozs7T0FBQyx3QkFBQyxLQUFELENBQUk7Ozs7O01BQU07Ozs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSSw0Q0FBNkM7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFHLCtDQUErQzs7Ozs7S0FBRSxnQkFBZ0Isd0JBQUMsUUFBRDtNQUFRLGVBQWUsYUFBYSxZQUFZO2dCQUFoRCxDQUFtRCxrQkFBYyx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O2NBQVM7Ozs7OztJQUFPOzs7Ozs7RUFDaFg7Ozs7O0VBRUosWUFBWSx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUEwQixhQUFhO2FBQ2pFLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO0lBQXdCLE1BQUs7SUFBUyxjQUFXO0lBQU8sY0FBWSxHQUFHLFNBQVMsS0FBSztJQUFXLGNBQWMsVUFBVSxNQUFNLGdCQUFnQjtjQUEvSjtLQUNFLHdCQUFDLFVBQUQ7TUFBUSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUF1Qyx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUF1QixlQUFlLGFBQWEsUUFBUTtRQUFHLGNBQVc7a0JBQTNGLENBQTJHLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFVBQVc7Ozs7a0JBQUMsd0JBQUMsUUFBRDtTQUFNLE1BQUs7bUJBQVU7UUFBbUI7Ozs7Z0JBQVM7Ozs7O2lCQUFDLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQWUsU0FBUztRQUFhLGNBQVc7a0JBQXdCO09BQVM7Ozs7ZUFBTTs7Ozs7O01BQUMsd0JBQUMsU0FBRDtPQUFRLFNBQVM7T0FBUTtPQUFRLFdBQVcsWUFBWTtNQUFTOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLEtBQVM7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBOEIsd0JBQUMsS0FBRCxZQUFJLFNBQVMsVUFBYTs7OztpQkFBRSxTQUFTLFdBQVcsS0FBSyxRQUFRLHdCQUFDLEtBQUQsWUFBYyxJQUFPLEdBQWI7Ozs7Y0FBYSxDQUFDLENBQU87Ozs7OztLQUFTOzs7OztLQUN4aUIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRyxTQUFTLEtBQUssU0FBUyxVQUFVLEtBQUssd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBOEIsd0JBQUMsU0FBRCxZQUFPLGVBQW1COzs7O2lCQUFDLHdCQUFDLEtBQUQsWUFBRyxrRUFBa0U7Ozs7ZUFBTTs7Ozs7Z0JBQzNLLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQixTQUFTLFVBQVUsS0FBSyxVQUFVLFVBQVUsd0JBQUMsTUFBRDtRQUM1RSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUIsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO1FBQVE7Ozs7O1FBQUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWdCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7O1FBQU87Ozs7O1FBQzNJLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsU0FBUyxLQUFhOzs7O2tCQUFDLHdCQUFDLFNBQUQsYUFBUSxTQUFTLGNBQWMsU0FBUyxhQUFhLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7O2dCQUFTOzs7O2dCQUFNOzs7OztRQUFDLHdCQUFDLEtBQUQsWUFBSSxTQUFTLFdBQVcsUUFBUSxTQUFTLFdBQVcsUUFBVzs7Ozs7T0FDekwsS0FIbUYsR0FBRyxTQUFTLEtBQUssR0FBRzs7OztjQUd2RyxDQUFDO01BQU07Ozs7Y0FDUjs7Ozs7O0tBQ0wsd0JBQUMsVUFBRDtNQUNHLFlBQVksd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQTZCLG9CQUFnQix3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFPLEtBQUs7UUFBVSxjQUFjLFNBQVM7UUFBTSxXQUFXLFVBQVUsWUFBWSxNQUFNLE9BQU8sS0FBSztPQUFJOzs7O2VBQVE7Ozs7OztNQUN4TCx3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRDtPQUFRLFNBQVE7T0FBUSxlQUFlLGFBQWEsWUFBWSxDQUFDLE9BQU87aUJBQXhFLENBQTJFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7aUJBQUMsc0JBQTRCOzs7OztnQkFBQyx3QkFBQyxRQUFEO09BQVEsZUFBZSxhQUFhLFFBQVE7aUJBQTVDLENBQStDLGtCQUFjLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7ZUFBUzs7Ozs7Y0FBTTs7Ozs7TUFDcE8sd0JBQUMsS0FBRCxZQUFHLGdEQUFnRDs7Ozs7S0FDN0M7Ozs7O0lBQ0g7Ozs7OztFQUNKOzs7OztFQUNKLG9CQUFvQix3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUF5QixtQkFBbUIsb0JBQW9CLElBQUk7YUFBRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUF1QixNQUFLO0lBQVMsY0FBVztJQUFPLGNBQVc7SUFBZ0IsY0FBYyxVQUFVLE1BQU0sZ0JBQWdCO2NBQS9JO0tBQWtKLHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxPQUFEO01BQUssd0JBQUMsU0FBRCxZQUFPLHNCQUEwQjs7Ozs7TUFBQyx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztNQUFDLHdCQUFDLEtBQUQsWUFBRyx3REFBd0Q7Ozs7O0tBQU07Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsZUFBZSxvQkFBb0IsSUFBSTtNQUFHLGNBQVc7Z0JBQXNCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O0tBQVM7Ozs7YUFBUzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUM1Zix3QkFBQyxZQUFELGFBQVUsd0JBQUMsVUFBRCxZQUFRLDRDQUFpRDs7OztpQkFBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBc0I7U0FBQztTQUFtQjtTQUE2QztTQUFhO1NBQW9CO1FBQXdCLENBQUMsQ0FBQyxLQUFLLFNBQVMsd0JBQUMsVUFBRDtTQUFRLFdBQVcsa0JBQWtCLFNBQVMsSUFBSSxJQUFJLFdBQVc7U0FBZSxlQUFlLHdCQUF3QixJQUFJO21CQUEzSCxDQUErSCxrQkFBa0IsU0FBUyxJQUFJLEtBQUssd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OzttQkFBRyxJQUFhO1dBQTdIOzs7O2VBQTZILENBQUM7T0FBTzs7OztlQUFXOzs7OztPQUM3Yyx3QkFBQyxZQUFELGFBQVUsd0JBQUMsVUFBRCxZQUFRLDRCQUFpQzs7OztpQkFBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBc0I7U0FBQyxDQUFDLFFBQVEsNEJBQTRCO1NBQUcsQ0FBQyxZQUFZLHdCQUF3QjtTQUFHLENBQUMsUUFBUSwwQkFBMEI7UUFBQyxDQUFDLENBQVcsS0FBSyxDQUFDLE1BQU0sVUFBVSx3QkFBQyxVQUFEO1NBQVEsV0FBVyxzQkFBc0IsT0FBTyxXQUFXO1NBQWUsZUFBZSxxQkFBcUIsSUFBSTttQkFBbEgsQ0FBcUgsd0JBQUMsVUFBRCxZQUFTLEtBQWE7Ozs7bUJBQUMsd0JBQUMsU0FBRCxZQUFRLEtBQVk7Ozs7aUJBQVM7V0FBckc7Ozs7ZUFBcUcsQ0FBQztPQUFPOzs7O2VBQVc7Ozs7O09BQzVhLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUFtQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFRLDhCQUFtQzs7OztrQkFBQyx3QkFBQyxTQUFELFlBQU8sZ0RBQW9EOzs7O2dCQUFPOzs7O2tCQUFDLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVcsU0FBUztTQUFtQixXQUFXLFVBQVUscUJBQXFCLE1BQU0sT0FBTyxPQUFPO1FBQUk7Ozs7Z0JBQVE7Ozs7OztPQUNyUix3QkFBQyxZQUFELGFBQVUsd0JBQUMsVUFBRCxZQUFRLFdBQWdCOzs7O2lCQUFDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQWdDLHdCQUFDLFNBQUQsYUFBTyx3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFRLE1BQUs7U0FBaUIsU0FBUyxrQkFBa0I7U0FBTyxnQkFBZ0IsaUJBQWlCLEtBQUs7UUFBSTs7OztrQkFBQyxtQkFBd0I7Ozs7a0JBQUMsd0JBQUMsU0FBRCxhQUFPLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVEsTUFBSztTQUFpQixTQUFTLGtCQUFrQjtTQUFPLGdCQUFnQixpQkFBaUIsS0FBSztRQUFJOzs7O2tCQUFDLHVCQUE0Qjs7OztnQkFBTTs7Ozs7ZUFBVzs7Ozs7TUFDbFk7Ozs7OztLQUFDLHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFpQixlQUFlO09BQUUscUJBQXFCLGdCQUFnQjtPQUFHLHFCQUFxQixVQUFVO09BQUcscUJBQXFCLGtCQUFrQjtPQUFHLGlCQUFpQixLQUFLO01BQUc7Z0JBQUc7S0FBaUM7Ozs7ZUFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBUSxlQUFlLG9CQUFvQixJQUFJO2dCQUFHO0tBQWM7Ozs7ZUFBQyx3QkFBQyxRQUFEO01BQVEsVUFBVSxDQUFDLGtCQUFrQjtNQUFRLFNBQVM7Z0JBQWtCO0tBQW9COzs7O2FBQU07Ozs7YUFBUzs7Ozs7SUFBTTs7Ozs7O0VBQU07Ozs7O0NBQ2pjOzs7OztBQUNKIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIldvcmtvdXRzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b25cIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcclxuaW1wb3J0IHR5cGUgeyBGaXRuZXNzU3RvcmUsIFBsYW5uZWRXb3Jrb3V0IH0gZnJvbSBcIi4uL2ZpdG5lc3NTdG9yZVwiO1xyXG5pbXBvcnQgeyBkYXRlS2V5LCBwcmV0dHlEYXRlIH0gZnJvbSBcIi4uL2xpYi9mb3JtYXRcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBXb3Jrb3V0c1BhZ2UoeyBzdG9yZSwgdXBkYXRlLCBuYXZpZ2F0ZSwgdG9hc3QgfTogeyBzdG9yZTogRml0bmVzc1N0b3JlOyB1cGRhdGU6IChuZXh0OiBGaXRuZXNzU3RvcmUpID0+IHZvaWQ7IG5hdmlnYXRlOiAocGF0aDogc3RyaW5nKSA9PiB2b2lkOyB0b2FzdDogKG1lc3NhZ2U6IHN0cmluZywgZXJyb3I/OiBib29sZWFuKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCBbdGFiLCBzZXRUYWJdID0gdXNlU3RhdGU8XCJ3ZWVrXCIgfCBcInBsYW5cIiB8IFwiaGlzdG9yeVwiPihcIndlZWtcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkSWQsIHNldFNlbGVjdGVkSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW29wZW5XZWVrLCBzZXRPcGVuV2Vla10gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2hvd01vdmUsIHNldFNob3dNb3ZlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdmlld1dlZWssIHNldFZpZXdXZWVrXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtzZXR0aW5nc1RhcmdldElkLCBzZXRTZXR0aW5nc1RhcmdldElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtzZXR0aW5nc0VxdWlwbWVudCwgc2V0U2V0dGluZ3NFcXVpcG1lbnRdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbc2V0dGluZ3NJbnRlbnNpdHksIHNldFNldHRpbmdzSW50ZW5zaXR5XSA9IHVzZVN0YXRlPFwiRWFzeVwiIHwgXCJNb2RlcmF0ZVwiIHwgXCJIYXJkXCI+KFwiTW9kZXJhdGVcIik7XHJcbiAgY29uc3QgW3NldHRpbmdzTG93SW1wYWN0LCBzZXRTZXR0aW5nc0xvd0ltcGFjdF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NldHRpbmdzU2NvcGUsIHNldFNldHRpbmdzU2NvcGVdID0gdXNlU3RhdGU8XCJvbmVcIiB8IFwiYWxsXCI+KFwib25lXCIpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICB0b2RheS5zZXRIb3VycygxMiwgMCwgMCwgMCk7XHJcbiAgY29uc3QgdG9kYXlLZXkgPSBkYXRlS2V5KHRvZGF5KTtcclxuICBjb25zdCBjaGFsbGVuZ2VTdGFydCA9IG5ldyBEYXRlKGAke3N0b3JlLmNoYWxsZW5nZS5zdGFydERhdGV9VDEyOjAwOjAwYCk7XHJcbiAgY29uc3QgY2hhbGxlbmdlRGF5ID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCwgTWF0aC5mbG9vcigodG9kYXkuZ2V0VGltZSgpIC0gY2hhbGxlbmdlU3RhcnQuZ2V0VGltZSgpKSAvIDg2XzQwMF8wMDApICsgMSkpO1xyXG4gIGNvbnN0IGN1cnJlbnRXZWVrID0gTWF0aC5tYXgoMCwgTWF0aC5mbG9vcigoY2hhbGxlbmdlRGF5IC0gMSkgLyA3KSk7XHJcbiAgY29uc3QgZGlzcGxheWVkV2VlayA9IHZpZXdXZWVrID8/IGN1cnJlbnRXZWVrO1xyXG4gIGNvbnN0IHRvdGFsV2Vla3MgPSBNYXRoLmNlaWwoc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDcpO1xyXG4gIGNvbnN0IHNlbGVjdGVkID0gc3RvcmUucGxhbi5maW5kKCh3b3Jrb3V0KSA9PiB3b3Jrb3V0LmlkID09PSBzZWxlY3RlZElkKSA/PyBudWxsO1xyXG4gIGNvbnN0IGNvbXBsZXRlZElkcyA9IG5ldyBTZXQoc3RvcmUuc2Vzc2lvbnMubWFwKChzZXNzaW9uKSA9PiBzZXNzaW9uLndvcmtvdXRJZCkpO1xyXG4gIGNvbnN0IGNvbXBsZXRlZEtleXMgPSBuZXcgU2V0KHN0b3JlLnNlc3Npb25zLm1hcCgoc2Vzc2lvbikgPT4gYCR7c2Vzc2lvbi53b3Jrb3V0SWR9LSR7c2Vzc2lvbi5kYXRlfWApKTtcclxuICBjb25zdCB3ZWVrU3RhcnQgPSBuZXcgRGF0ZShjaGFsbGVuZ2VTdGFydCk7XHJcbiAgd2Vla1N0YXJ0LnNldERhdGUoY2hhbGxlbmdlU3RhcnQuZ2V0RGF0ZSgpICsgZGlzcGxheWVkV2VlayAqIDcpO1xyXG4gIGNvbnN0IHdlZWtMZW5ndGggPSBNYXRoLm1pbig3LCBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoIC0gZGlzcGxheWVkV2VlayAqIDcpO1xyXG4gIGNvbnN0IHdlZWtEYXlzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogd2Vla0xlbmd0aCB9LCAoXywgaW5kZXgpID0+IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh3ZWVrU3RhcnQpO1xyXG4gICAgZGF0ZS5zZXREYXRlKHdlZWtTdGFydC5nZXREYXRlKCkgKyBpbmRleCk7XHJcbiAgICBjb25zdCBrZXkgPSBkYXRlS2V5KGRhdGUpO1xyXG4gICAgcmV0dXJuIHsgZGF0ZSwga2V5LCB3b3Jrb3V0OiBzdG9yZS5wbGFuLmZpbmQoKGl0ZW0pID0+IGl0ZW0uZGF0ZSA9PT0ga2V5KSB9O1xyXG4gIH0pO1xyXG4gIGNvbnN0IHdlZWtFbmQgPSB3ZWVrRGF5cy5hdCgtMSk/LmRhdGUgPz8gd2Vla1N0YXJ0O1xyXG4gIGNvbnN0IHRvZGF5V29ya291dCA9IHN0b3JlLnBsYW4uZmluZCgod29ya291dCkgPT4gd29ya291dC5kYXRlID09PSB0b2RheUtleSkgPz8gc3RvcmUucGxhbi5maWx0ZXIoKHdvcmtvdXQpID0+IHdvcmtvdXQuZGF0ZSA+IHRvZGF5S2V5ICYmICF3b3Jrb3V0Lm9wdGlvbmFsKS5zb3J0KChsZWZ0LCByaWdodCkgPT4gbGVmdC5kYXRlLmxvY2FsZUNvbXBhcmUocmlnaHQuZGF0ZSkpWzBdID8/IG51bGw7XHJcbiAgY29uc3Qgd2Vla3MgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBNYXRoLmNlaWwoc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDcpIH0sIChfLCBpbmRleCkgPT4ge1xyXG4gICAgY29uc3Qgc3RhcnRPZmZzZXQgPSBpbmRleCAqIDc7XHJcbiAgICBjb25zdCBlbmRPZmZzZXQgPSBzdGFydE9mZnNldCArIDY7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBpbmRleCxcclxuICAgICAgd29ya291dHM6IHN0b3JlLnBsYW4uZmlsdGVyKCh3b3Jrb3V0KSA9PiB7XHJcbiAgICAgICAgY29uc3Qgb2Zmc2V0ID0gTWF0aC5mbG9vcigobmV3IERhdGUoYCR7d29ya291dC5kYXRlfVQxMjowMDowMGApLmdldFRpbWUoKSAtIGNoYWxsZW5nZVN0YXJ0LmdldFRpbWUoKSkgLyA4Nl80MDBfMDAwKTtcclxuICAgICAgICByZXR1cm4gb2Zmc2V0ID49IHN0YXJ0T2Zmc2V0ICYmIG9mZnNldCA8PSBlbmRPZmZzZXQ7XHJcbiAgICAgIH0pLFxyXG4gICAgfTtcclxuICB9KTtcclxuICBjb25zdCBkaWZmaWN1bHR5ID0gc2VsZWN0ZWQ/LmludGVuc2l0eSA/PyAoc2VsZWN0ZWQ/Lm5hbWUuaW5jbHVkZXMoXCJSZWNvdmVyeVwiKSA/IFwiRWFzeVwiIDogXCJNb2RlcmF0ZVwiKTtcclxuICBjb25zdCBkZWZhdWx0RXF1aXBtZW50ID0gc3RvcmUudXNlci5lcXVpcG1lbnQuaW5jbHVkZXMoXCJHeW1cIikgPyBbXCJHeW0gbWFjaGluZXMgJiBiYXJiZWxsXCJdIDogc3RvcmUudXNlci5lcXVpcG1lbnQuaW5jbHVkZXMoXCJEdW1iYmVsbFwiKSA/IFtcIkR1bWJiZWxsc1wiLCBcIlJlc2lzdGFuY2UgYmFuZHNcIl0gOiBbXCJCb2R5d2VpZ2h0IG9ubHlcIl07XHJcbiAgY29uc3QgYXV0b21hdGljTG93SW1wYWN0ID0gc3RvcmUudXNlci5pbmp1cnlGbGFnIHx8IChOdW1iZXIoc3RvcmUudXNlci5hZ2UpID4gMCAmJiBOdW1iZXIoc3RvcmUudXNlci5hZ2UpIDwgMTgpIHx8IE51bWJlcihzdG9yZS51c2VyLmFnZSkgPj0gNjA7XHJcbiAgY29uc3Qgb3BlblNldHRpbmdzID0gKHdvcmtvdXQ6IFBsYW5uZWRXb3Jrb3V0KSA9PiB7XHJcbiAgICBzZXRTZXR0aW5nc1RhcmdldElkKHdvcmtvdXQuaWQpO1xyXG4gICAgc2V0U2V0dGluZ3NFcXVpcG1lbnQod29ya291dC5lcXVpcG1lbnQgPT09IFwiQm9keXdlaWdodCAvIEhvbWVcIiB8fCB3b3Jrb3V0LmVxdWlwbWVudC5pbmNsdWRlcyhcIkJvZHl3ZWlnaHRcIikgPyBbXCJCb2R5d2VpZ2h0IG9ubHlcIl0gOiB3b3Jrb3V0LmVxdWlwbWVudC5pbmNsdWRlcyhcIkd5bVwiKSA/IFtcIkd5bSBtYWNoaW5lcyAmIGJhcmJlbGxcIl0gOiB3b3Jrb3V0LmVxdWlwbWVudC5pbmNsdWRlcyhcIkR1bWJiZWxsXCIpID8gW1wiRHVtYmJlbGxzXCIsIFwiUmVzaXN0YW5jZSBiYW5kc1wiXSA6IGRlZmF1bHRFcXVpcG1lbnQpO1xyXG4gICAgc2V0U2V0dGluZ3NJbnRlbnNpdHkod29ya291dC5pbnRlbnNpdHkgPz8gXCJNb2RlcmF0ZVwiKTtcclxuICAgIHNldFNldHRpbmdzTG93SW1wYWN0KHdvcmtvdXQubG93SW1wYWN0ID8/IGF1dG9tYXRpY0xvd0ltcGFjdCk7XHJcbiAgICBzZXRTZXR0aW5nc1Njb3BlKFwib25lXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgdG9nZ2xlU2V0dGluZ3NFcXVpcG1lbnQgPSAoaXRlbTogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRTZXR0aW5nc0VxdWlwbWVudCgoY3VycmVudCkgPT4gaXRlbSA9PT0gXCJCb2R5d2VpZ2h0IG9ubHlcIiA/IFtcIkJvZHl3ZWlnaHQgb25seVwiXSA6IFsuLi5jdXJyZW50LmZpbHRlcigodmFsdWUpID0+IHZhbHVlICE9PSBcIkJvZHl3ZWlnaHQgb25seVwiICYmIHZhbHVlICE9PSBpdGVtKSwgLi4uKGN1cnJlbnQuaW5jbHVkZXMoaXRlbSkgPyBbXSA6IFtpdGVtXSldKTtcclxuICB9O1xyXG4gIGNvbnN0IHNhdmVQbGFuU2V0dGluZ3MgPSAoKSA9PiB7XHJcbiAgICBpZiAoIXNldHRpbmdzVGFyZ2V0SWQgfHwgIXNldHRpbmdzRXF1aXBtZW50Lmxlbmd0aCkgcmV0dXJuO1xyXG4gICAgY29uc3QgZXF1aXBtZW50TGFiZWwgPSBzZXR0aW5nc0VxdWlwbWVudC5sZW5ndGggPT09IDEgPyBzZXR0aW5nc0VxdWlwbWVudFswXSA6IHNldHRpbmdzRXF1aXBtZW50LmpvaW4oXCIgKyBcIik7XHJcbiAgICBjb25zdCBwb29scyA9IHtcclxuICAgICAgYm9keXdlaWdodDogW1wiQm9keXdlaWdodCBzcXVhdHNcIiwgXCJJbmNsaW5lIHB1c2gtdXBzXCIsIFwiR2x1dGUgYnJpZGdlc1wiLCBcIlJldmVyc2UgbHVuZ2VzXCIsIFwiTW91bnRhaW4gY2xpbWJlcnNcIiwgXCJQbGFua1wiLCBcIkJpcmQgZG9nXCIsIFwiU3RlcCBqYWNrc1wiXSxcclxuICAgICAgaG91c2Vob2xkOiBbXCJCYWNrcGFjayBzcXVhdHNcIiwgXCJJbmNsaW5lIHB1c2gtdXBzXCIsIFwiR2x1dGUgYnJpZGdlc1wiLCBcIlJldmVyc2UgbHVuZ2VzXCIsIFwiV2F0ZXIgYm90dGxlIHJvd3NcIiwgXCJQbGFua1wiLCBcIkJpcmQgZG9nXCIsIFwiU3RlcCBqYWNrc1wiXSxcclxuICAgICAgZHVtYmJlbGxzOiBbXCJEdW1iYmVsbCBnb2JsZXQgc3F1YXRzXCIsIFwiRHVtYmJlbGwgZmxvb3IgcHJlc3NcIiwgXCJEdW1iYmVsbCBSb21hbmlhbiBkZWFkbGlmdHNcIiwgXCJSZXZlcnNlIGx1bmdlc1wiLCBcIkR1bWJiZWxsIHJvd3NcIiwgXCJQbGFua1wiLCBcIkJpcmQgZG9nXCIsIFwiRHVtYmJlbGwgcHVzaCBwcmVzc1wiXSxcclxuICAgICAgYmFuZHM6IFtcIkJhbmRlZCBzcXVhdHNcIiwgXCJCYW5kZWQgY2hlc3QgcHJlc3NcIiwgXCJCYW5kZWQgZ2x1dGUgYnJpZGdlc1wiLCBcIlJldmVyc2UgbHVuZ2VzXCIsIFwiQmFuZGVkIHJvd3NcIiwgXCJQbGFua1wiLCBcIkJpcmQgZG9nXCIsIFwiQmFuZGVkIHN0ZXAgamFja3NcIl0sXHJcbiAgICAgIGd5bTogW1wiQmFyYmVsbCBzcXVhdHNcIiwgXCJNYWNoaW5lIGNoZXN0IHByZXNzXCIsIFwiQ2FibGUgcHVsbC10aHJvdWdoc1wiLCBcIlJldmVyc2UgbHVuZ2VzXCIsIFwiU2VhdGVkIGNhYmxlIHJvd3NcIiwgXCJQbGFua1wiLCBcIkJpcmQgZG9nXCIsIFwiUm93aW5nIGludGVydmFsc1wiXSxcclxuICAgIH07XHJcbiAgICBjb25zdCBwb29sID0gc2V0dGluZ3NFcXVpcG1lbnQuaW5jbHVkZXMoXCJHeW0gbWFjaGluZXMgJiBiYXJiZWxsXCIpID8gcG9vbHMuZ3ltIDogc2V0dGluZ3NFcXVpcG1lbnQuaW5jbHVkZXMoXCJEdW1iYmVsbHNcIikgPyBwb29scy5kdW1iYmVsbHMgOiBzZXR0aW5nc0VxdWlwbWVudC5pbmNsdWRlcyhcIlJlc2lzdGFuY2UgYmFuZHNcIikgPyBwb29scy5iYW5kcyA6IHNldHRpbmdzRXF1aXBtZW50LmluY2x1ZGVzKFwiSG91c2Vob2xkIGl0ZW1zICh3YXRlciBib3R0bGVzLCBiYWNrcGFjaylcIikgPyBwb29scy5ob3VzZWhvbGQgOiBwb29scy5ib2R5d2VpZ2h0O1xyXG4gICAgY29uc3QgcHJlc2NyaXB0aW9uID0gc2V0dGluZ3NJbnRlbnNpdHkgPT09IFwiRWFzeVwiID8gXCIzMHMgd29yayDCtyAzMHMgcmVzdFwiIDogc2V0dGluZ3NJbnRlbnNpdHkgPT09IFwiSGFyZFwiID8gXCI0NXMgd29yayDCtyAxNXMgcmVzdFwiIDogXCI0MHMgd29yayDCtyAyMHMgcmVzdFwiO1xyXG4gICAgY29uc3QgcGxhbiA9IHN0b3JlLnBsYW4ubWFwKCh3b3Jrb3V0KSA9PiB7XHJcbiAgICAgIGNvbnN0IGFwcGxpZXMgPSBzZXR0aW5nc1Njb3BlID09PSBcImFsbFwiID8gd29ya291dC5kYXRlID49IHRvZGF5S2V5IDogd29ya291dC5pZCA9PT0gc2V0dGluZ3NUYXJnZXRJZDtcclxuICAgICAgaWYgKCFhcHBsaWVzKSByZXR1cm4gd29ya291dDtcclxuICAgICAgY29uc3QgaXNSdW4gPSB3b3Jrb3V0Lm5hbWUuaW5jbHVkZXMoXCJXYWxrLVJ1blwiKTtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi53b3Jrb3V0LFxyXG4gICAgICAgIGVxdWlwbWVudDogZXF1aXBtZW50TGFiZWwsXHJcbiAgICAgICAgaW50ZW5zaXR5OiBzZXR0aW5nc0ludGVuc2l0eSxcclxuICAgICAgICBsb3dJbXBhY3Q6IHNldHRpbmdzTG93SW1wYWN0LFxyXG4gICAgICAgIHNldHM6IHNldHRpbmdzSW50ZW5zaXR5ID09PSBcIkVhc3lcIiA/IDIgOiBzZXR0aW5nc0ludGVuc2l0eSA9PT0gXCJIYXJkXCIgPyA0IDogMyxcclxuICAgICAgICBleGVyY2lzZXM6IGlzUnVuID8gd29ya291dC5leGVyY2lzZXMgOiB3b3Jrb3V0LmV4ZXJjaXNlcy5tYXAoKGV4ZXJjaXNlLCBpbmRleCkgPT4gKHsgLi4uZXhlcmNpc2UsIG5hbWU6IHBvb2xbaW5kZXggJSBwb29sLmxlbmd0aF0sIHByZXNjcmlwdGlvbiB9KSksXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICAgIHVwZGF0ZSh7IC4uLnN0b3JlLCBwbGFuIH0pO1xyXG4gICAgc2V0U2V0dGluZ3NUYXJnZXRJZChudWxsKTtcclxuICAgIHRvYXN0KGBXb3Jrb3V0IHVwZGF0ZWQ6ICR7ZXF1aXBtZW50TGFiZWx9IMK3ICR7c2V0dGluZ3NJbnRlbnNpdHl9LmApO1xyXG4gIH07XHJcbiAgY29uc3QgbW92ZVdvcmtvdXQgPSAobmV4dERhdGU6IHN0cmluZykgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZCB8fCAhbmV4dERhdGUpIHJldHVybjtcclxuICAgIHVwZGF0ZSh7IC4uLnN0b3JlLCBwbGFuOiBzdG9yZS5wbGFuLm1hcCgod29ya291dCkgPT4gd29ya291dC5pZCA9PT0gc2VsZWN0ZWQuaWQgPyB7IC4uLndvcmtvdXQsIGRhdGU6IG5leHREYXRlIH0gOiB3b3Jrb3V0KSB9KTtcclxuICAgIHNldFNob3dNb3ZlKGZhbHNlKTtcclxuICAgIHRvYXN0KGBXb3Jrb3V0IG1vdmVkIHRvICR7cHJldHR5RGF0ZShuZXh0RGF0ZSl9LmApO1xyXG4gIH07XHJcbiAgY29uc3QgY2xvc2VEZXRhaWwgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZElkKG51bGwpO1xyXG4gICAgc2V0U2hvd01vdmUoZmFsc2UpO1xyXG4gIH07XHJcbiAgY29uc3Qgb3BlbkRldGFpbCA9ICh3b3Jrb3V0PzogUGxhbm5lZFdvcmtvdXQpID0+IHdvcmtvdXQgJiYgc2V0U2VsZWN0ZWRJZCh3b3Jrb3V0LmlkKTtcclxuICBjb25zdCBzdGFydFdvcmtvdXQgPSAod29ya291dDogUGxhbm5lZFdvcmtvdXQpID0+IG5hdmlnYXRlKGAvc2Vzc2lvbi8ke3dvcmtvdXQuaWR9YCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodGFiICE9PSBcIndlZWtcIiB8fCBkaXNwbGF5ZWRXZWVrICE9PSBjdXJyZW50V2VlaykgcmV0dXJuO1xyXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnNldmVuLWRheS1zdHJpcCAuZGF5LWNhcmQudG9kYXlcIik/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIsIGJsb2NrOiBcIm5lYXJlc3RcIiwgaW5saW5lOiBcImNlbnRlclwiIH0pLCA1MCk7XHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgfSwgW3RhYiwgZGlzcGxheWVkV2VlaywgY3VycmVudFdlZWtdKTtcclxuXHJcbiAgcmV0dXJuIDw+XHJcbiAgICA8UGFnZUhlYWRlciBleWVicm93PXtgWU9VUiBQTEFOUyDCtyBEQVkgJHtjaGFsbGVuZ2VEYXl9YH0gdGl0bGU9XCJNeSB3b3Jrb3V0c1wiIC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIndvcmtvdXQtdGFic1wiIHJvbGU9XCJ0YWJsaXN0XCIgYXJpYS1sYWJlbD1cIldvcmtvdXQgdmlld3NcIj5cclxuICAgICAge1tbXCJ3ZWVrXCIsIFwiVGhpcyB3ZWVrXCJdLCBbXCJwbGFuXCIsIFwiRnVsbCBwbGFuXCJdLCBbXCJoaXN0b3J5XCIsIFwiSGlzdG9yeVwiXV0ubWFwKChbdmFsdWUsIGxhYmVsXSkgPT4gPGJ1dHRvbiBrZXk9e3ZhbHVlfSByb2xlPVwidGFiXCIgYXJpYS1zZWxlY3RlZD17dGFiID09PSB2YWx1ZX0gY2xhc3NOYW1lPXt0YWIgPT09IHZhbHVlID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldFRhYih2YWx1ZSBhcyBcIndlZWtcIiB8IFwicGxhblwiIHwgXCJoaXN0b3J5XCIpfT57bGFiZWx9PC9idXR0b24+KX1cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIHt0YWIgPT09IFwid2Vla1wiICYmIDxkaXYgY2xhc3NOYW1lPVwid2Vlay12aWV3XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhbGxlbmdlLXdlZWstaGVhZFwiPlxyXG4gICAgICAgIDxkaXY+PHN0cm9uZz5XZWVrIHtkaXNwbGF5ZWRXZWVrICsgMX0gb2Yge3RvdGFsV2Vla3N9IMK3IHt3ZWVrU3RhcnQudG9Mb2NhbGVEYXRlU3RyaW5nKHVuZGVmaW5lZCwgeyBtb250aDogXCJzaG9ydFwiLCBkYXk6IFwibnVtZXJpY1wiIH0pfSAtIHt3ZWVrRW5kLnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX08L3N0cm9uZz48c3Bhbj5EYXkge2NoYWxsZW5nZURheX0gb2Yge3N0b3JlLmNoYWxsZW5nZS5sZW5ndGh9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgIDxkaXY+PGJ1dHRvbiBkaXNhYmxlZD17ZGlzcGxheWVkV2VlayA9PT0gMH0gb25DbGljaz17KCkgPT4gc2V0Vmlld1dlZWsoTWF0aC5tYXgoMCwgZGlzcGxheWVkV2VlayAtIDEpKX0gYXJpYS1sYWJlbD1cIlByZXZpb3VzIGNoYWxsZW5nZSB3ZWVrXCI+PEljb24gbmFtZT1cImJhY2tcIiAvPjwvYnV0dG9uPjxidXR0b24gZGlzYWJsZWQ9e2Rpc3BsYXllZFdlZWsgPT09IHRvdGFsV2Vla3MgLSAxfSBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3V2VlayhNYXRoLm1pbih0b3RhbFdlZWtzIC0gMSwgZGlzcGxheWVkV2VlayArIDEpKX0gYXJpYS1sYWJlbD1cIk5leHQgY2hhbGxlbmdlIHdlZWtcIj48SWNvbiBuYW1lPVwiYXJyb3dcIiAvPjwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhbGxlbmdlLWRheS1wcm9ncmVzc1wiPjxpIHN0eWxlPXt7IHdpZHRoOiBgJHtjaGFsbGVuZ2VEYXkgLyBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoICogMTAwfSVgIH19IC8+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldmVuLWRheS1zdHJpcFwiPlxyXG4gICAgICAgIHt3ZWVrRGF5cy5tYXAoKHsgZGF0ZSwga2V5LCB3b3Jrb3V0IH0pID0+IHtcclxuICAgICAgICAgIGNvbnN0IGlzVG9kYXkgPSBrZXkgPT09IHRvZGF5S2V5O1xyXG4gICAgICAgICAgY29uc3QgZWxhcHNlZCA9IGRhdGUgPCB0b2RheTtcclxuICAgICAgICAgIGNvbnN0IGNvbXBsZXRlZCA9IEJvb2xlYW4od29ya291dCAmJiAoY29tcGxldGVkS2V5cy5oYXMoYCR7d29ya291dC5pZH0tJHtrZXl9YCkgfHwgKChlbGFwc2VkIHx8IGlzVG9kYXkpICYmIGNvbXBsZXRlZElkcy5oYXMod29ya291dC5pZCkpKSk7XHJcbiAgICAgICAgICBjb25zdCBzdGF0ZSA9IGNvbXBsZXRlZCA/IFwiZG9uZVwiIDogaXNUb2RheSA/IFwidG9kYXlcIiA6IGVsYXBzZWQgJiYgd29ya291dCA/IFwibWlzc2VkXCIgOiBlbGFwc2VkID8gXCJlbGFwc2VkLXJlc3RcIiA6IHdvcmtvdXQgPyBcInVwY29taW5nXCIgOiBcInJlc3RcIjtcclxuICAgICAgICAgIGNvbnN0IHN0YXR1cyA9IHN0YXRlID09PSBcImRvbmVcIiA/IFwiRG9uZVwiIDogc3RhdGUgPT09IFwibWlzc2VkXCIgPyBcIk1pc3NlZFwiIDogc3RhdGUgPT09IFwidG9kYXlcIiA/IFwiVG9kYXlcIiA6IFwiUmVzdFwiO1xyXG4gICAgICAgICAgcmV0dXJuIDxhcnRpY2xlIGtleT17a2V5fSBjbGFzc05hbWU9e2BkYXktY2FyZCAke3N0YXRlfWB9PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRheS1jYXJkLW1haW5cIiBvbkNsaWNrPXsoKSA9PiBvcGVuRGV0YWlsKHdvcmtvdXQpfSBkaXNhYmxlZD17IXdvcmtvdXR9PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRheS1jYXJkLWRhdGVcIj48c21hbGw+e2RhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHVuZGVmaW5lZCwgeyB3ZWVrZGF5OiBcInNob3J0XCIgfSl9PC9zbWFsbD48c3Ryb25nPntkYXRlLmdldERhdGUoKX08L3N0cm9uZz48L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGF5LWNhcmQtd29ya291dFwiPjxzdHJvbmc+e3dvcmtvdXQ/Lm5hbWUgfHwgXCJSZWNvdmVyeSBkYXlcIn08L3N0cm9uZz48c21hbGw+e3dvcmtvdXQgPyBgJHt3b3Jrb3V0Lm1pbnV0ZXN9IG1pbmAgOiBcIlJlc3QgJiByZXNldFwifTwvc21hbGw+PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHN0YXR1cy1jaGlwICR7c3RhdGV9YH0+e3N0YXRlID09PSBcImRvbmVcIiA/IDxJY29uIG5hbWU9XCJjaGVja1wiIC8+IDogc3RhdGUgPT09IFwibWlzc2VkXCIgPyA8SWNvbiBuYW1lPVwiYmFja1wiIC8+IDogIXdvcmtvdXQgPyA8SWNvbiBuYW1lPVwibW9vblwiIC8+IDogaXNUb2RheSA/IDxJY29uIG5hbWU9XCJjYWxlbmRhclwiIC8+IDogPEljb24gbmFtZT1cImFycm93XCIgLz59e3N0YXR1cyA9PT0gXCJSZXN0XCIgJiYgd29ya291dCA/IFwiVXBjb21pbmdcIiA6IHN0YXR1c308L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICB7aXNUb2RheSAmJiB3b3Jrb3V0ICYmIDxidXR0b24gY2xhc3NOYW1lPVwiZGF5LXN0YXJ0XCIgb25DbGljaz17KCkgPT4gc3RhcnRXb3Jrb3V0KHdvcmtvdXQpfT5TdGFydCB3b3Jrb3V0PC9idXR0b24+fVxyXG4gICAgICAgICAgICB7c3RhdGUgPT09IFwibWlzc2VkXCIgJiYgd29ya291dCAmJiA8YnV0dG9uIGNsYXNzTmFtZT1cInJlc2NoZWR1bGUtbGlua1wiIG9uQ2xpY2s9eygpID0+IHsgb3BlbkRldGFpbCh3b3Jrb3V0KTsgc2V0U2hvd01vdmUodHJ1ZSk7IH19PlJlc2NoZWR1bGU8L2J1dHRvbj59XHJcbiAgICAgICAgICA8L2FydGljbGU+O1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3b3Jrb3V0LWxlZ2VuZFwiPjxzcGFuPjxpIGNsYXNzTmFtZT1cImRvbmVcIj48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPjwvaT5Eb25lPC9zcGFuPjxzcGFuPjxpIGNsYXNzTmFtZT1cInRvZGF5XCI+PEljb24gbmFtZT1cImNhbGVuZGFyXCIgLz48L2k+VG9kYXk8L3NwYW4+PHNwYW4+PGkgY2xhc3NOYW1lPVwidXBjb21pbmdcIj48SWNvbiBuYW1lPVwiYXJyb3dcIiAvPjwvaT5VcGNvbWluZzwvc3Bhbj48c3Bhbj48aSBjbGFzc05hbWU9XCJyZXN0XCI+PEljb24gbmFtZT1cIm1vb25cIiAvPjwvaT5SZXN0PC9zcGFuPjxzcGFuPjxpIGNsYXNzTmFtZT1cIm1pc3NlZFwiPjxJY29uIG5hbWU9XCJiYWNrXCIgLz48L2k+TWlzc2VkPC9zcGFuPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj48ZGl2PjxzbWFsbD5ZT1VSIE5FWFQgU0VTU0lPTjwvc21hbGw+PGgyPnt0b2RheVdvcmtvdXQ/LmRhdGUgPT09IHRvZGF5S2V5ID8gXCJSZWFkeSB3aGVuIHlvdSBhcmUuXCIgOiBcIkNvbWluZyB1cCBuZXh0XCJ9PC9oMj48L2Rpdj48L2Rpdj5cclxuICAgICAge3RvZGF5V29ya291dCA/IDxhcnRpY2xlIGNsYXNzTmFtZT1cInRvZGF5LWRldGFpbC1jYXJkXCI+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwbGFuLXNldHRpbmdzLWJ1dHRvbiBkYXJrXCIgb25DbGljaz17KCkgPT4gb3BlblNldHRpbmdzKHRvZGF5V29ya291dCl9IGFyaWEtbGFiZWw9XCJQbGFuIHNldHRpbmdzXCI+PEljb24gbmFtZT1cInNsaWRlcnNcIiAvPjxzcGFuIHJvbGU9XCJ0b29sdGlwXCI+UGxhbiBzZXR0aW5nczwvc3Bhbj48L2J1dHRvbj5cclxuICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cIndvcmtvdXQtbGFiZWxcIj57bmV3IERhdGUoYCR7dG9kYXlXb3Jrb3V0LmRhdGV9VDEyOjAwOjAwYCkudG9Mb2NhbGVEYXRlU3RyaW5nKHVuZGVmaW5lZCwgeyB3ZWVrZGF5OiBcInNob3J0XCIsIG1vbnRoOiBcInNob3J0XCIsIGRheTogXCJudW1lcmljXCIgfSkudG9VcHBlckNhc2UoKX0gwrcge3RvZGF5V29ya291dC5taW51dGVzfSBNSU48L3NwYW4+PGgyPnt0b2RheVdvcmtvdXQubmFtZX08L2gyPjxwPnt0b2RheVdvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aH0gZXhlcmNpc2VzIMK3IDxzcGFuPnt0b2RheVdvcmtvdXQuZXF1aXBtZW50fTwvc3Bhbj4gwrcge3RvZGF5V29ya291dC5pbnRlbnNpdHkgPz8gXCJNb2RlcmF0ZVwifTwvcD48ZGl2IGNsYXNzTmFtZT1cInRhcmdldC1jaGlwc1wiPnt0b2RheVdvcmtvdXQudGFyZ2V0VGFncy5tYXAoKHRhZykgPT4gPGkga2V5PXt0YWd9Pnt0YWd9PC9pPil9PC9kaXY+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b2RheS1kZXRhaWwtYWN0aW9uc1wiPjxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gb3BlbkRldGFpbCh0b2RheVdvcmtvdXQpfT5WaWV3IGRldGFpbHM8L0J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHN0YXJ0V29ya291dCh0b2RheVdvcmtvdXQpfT5TdGFydCB3b3Jrb3V0IDxJY29uIG5hbWU9XCJwbGF5XCIgLz48L0J1dHRvbj48L2Rpdj5cclxuICAgICAgPC9hcnRpY2xlPiA6IDxFbXB0eVN0YXRlIHRpdGxlPVwiQSBjbGVhciBkYXkgdG8gcmVjb3ZlclwiIGNvcHk9XCJSZXN0IHN1cHBvcnRzIHlvdXIgcHJvZ3Jlc3MuIFlvdXIgbmV4dCBwbGFubmVkIHdvcmtvdXQgd2lsbCBhcHBlYXIgaGVyZS5cIiAvPn1cclxuICAgIDwvZGl2Pn1cclxuXHJcbiAgICB7dGFiID09PSBcInBsYW5cIiAmJiA8ZGl2IGNsYXNzTmFtZT1cInBsYW4td2Vla3NcIj5cclxuICAgICAge3dlZWtzLm1hcCgod2VlaykgPT4ge1xyXG4gICAgICAgIGNvbnN0IGV4cGFuZGVkID0gb3BlbldlZWsgPT09IHdlZWsuaW5kZXggfHwgKG9wZW5XZWVrID09PSBudWxsICYmIHdlZWsuaW5kZXggPT09IGN1cnJlbnRXZWVrKTtcclxuICAgICAgICBjb25zdCBjb21wbGV0ZWQgPSB3ZWVrLndvcmtvdXRzLmZpbHRlcigod29ya291dCkgPT4gY29tcGxldGVkSWRzLmhhcyh3b3Jrb3V0LmlkKSkubGVuZ3RoO1xyXG4gICAgICAgIGNvbnN0IHBsYW5uZWQgPSB3ZWVrLndvcmtvdXRzLmZpbHRlcigod29ya291dCkgPT4gIXdvcmtvdXQub3B0aW9uYWwpLmxlbmd0aDtcclxuICAgICAgICByZXR1cm4gPGFydGljbGUgY2xhc3NOYW1lPXtgcGxhbi13ZWVrICR7d2Vlay5pbmRleCA+IGN1cnJlbnRXZWVrID8gXCJmdXR1cmVcIiA6IFwiXCJ9YH0ga2V5PXt3ZWVrLmluZGV4fT5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGxhbi13ZWVrLXRvZ2dsZVwiIGFyaWEtZXhwYW5kZWQ9e2V4cGFuZGVkfSBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuV2VlayhleHBhbmRlZCA/IC0xIDogd2Vlay5pbmRleCl9PlxyXG4gICAgICAgICAgICA8c3Bhbj48c21hbGw+V0VFSyB7d2Vlay5pbmRleCArIDF9PC9zbWFsbD48c3Ryb25nPnt3ZWVrLmluZGV4ID09PSBjdXJyZW50V2VlayA/IFwiVGhpcyB3ZWVrXCIgOiBgRGF5cyAke3dlZWsuaW5kZXggKiA3ICsgMX3igJMke01hdGgubWluKHN0b3JlLmNoYWxsZW5nZS5sZW5ndGgsIHdlZWsuaW5kZXggKiA3ICsgNyl9YH08L3N0cm9uZz48L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuPntjb21wbGV0ZWR9L3twbGFubmVkfSBzZXNzaW9ucyA8aT57ZXhwYW5kZWQgPyBcIuKIklwiIDogXCIrXCJ9PC9pPjwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAge2V4cGFuZGVkICYmIDxkaXYgY2xhc3NOYW1lPVwicGxhbi13ZWVrLXdvcmtvdXRzXCI+e3dlZWsud29ya291dHMubGVuZ3RoID8gd2Vlay53b3Jrb3V0cy5tYXAoKHdvcmtvdXQpID0+IDxidXR0b24ga2V5PXt3b3Jrb3V0LmlkfSBvbkNsaWNrPXsoKSA9PiBvcGVuRGV0YWlsKHdvcmtvdXQpfT48c3Bhbj48c21hbGw+e3ByZXR0eURhdGUod29ya291dC5kYXRlKX08L3NtYWxsPjxzdHJvbmc+e3dvcmtvdXQubmFtZX08L3N0cm9uZz48L3NwYW4+PHNwYW4+e3dvcmtvdXQubWludXRlc30gbWluIDxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PC9zcGFuPjwvYnV0dG9uPikgOiA8cD5SZWNvdmVyeSB3ZWVrIOKAlCBubyBzZXNzaW9ucyBzY2hlZHVsZWQuPC9wPn08L2Rpdj59XHJcbiAgICAgICAgPC9hcnRpY2xlPjtcclxuICAgICAgfSl9XHJcbiAgICA8L2Rpdj59XHJcblxyXG4gICAge3RhYiA9PT0gXCJoaXN0b3J5XCIgJiYgPGRpdiBjbGFzc05hbWU9XCJoaXN0b3J5LXZpZXdcIj5cclxuICAgICAge3N0b3JlLnNlc3Npb25zLmxlbmd0aCA/IDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS1saXN0XCI+e3N0b3JlLnNlc3Npb25zLnNsaWNlKCkucmV2ZXJzZSgpLm1hcCgoc2Vzc2lvbikgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtvdXQgPSBzdG9yZS5wbGFuLmZpbmQoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IHNlc3Npb24ud29ya291dElkKTtcclxuICAgICAgICByZXR1cm4gPGFydGljbGUga2V5PXtgJHtzZXNzaW9uLndvcmtvdXRJZH0tJHtzZXNzaW9uLmRhdGV9YH0+PHNwYW4gY2xhc3NOYW1lPVwiZGFzaC1zdGF0LWljb25cIj48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPjwvc3Bhbj48ZGl2PjxzbWFsbD57cHJldHR5RGF0ZShzZXNzaW9uLmRhdGUpfTwvc21hbGw+PGgzPnt3b3Jrb3V0Py5uYW1lIHx8IFwiQ29tcGxldGVkIHdvcmtvdXRcIn08L2gzPjwvZGl2PjxkaXY+PHN0cm9uZz57c2Vzc2lvbi5kdXJhdGlvbn0gbWluPC9zdHJvbmc+PHNwYW4+RWZmb3J0IHtzZXNzaW9uLmVmZm9ydH0vNTwvc3Bhbj48L2Rpdj48L2FydGljbGU+O1xyXG4gICAgICB9KX08L2Rpdj4gOiA8ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktZW1wdHlcIj48ZGl2IGNsYXNzTmFtZT1cImhpc3RvcnktaWxsdXN0cmF0aW9uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PHNwYW4+PEljb24gbmFtZT1cImR1bWJiZWxsXCIgLz48L3NwYW4+PGkgLz48aSAvPjwvZGl2PjxoMz5Zb3VyIGZpbmlzaGVkIHdvcmtvdXRzIHdpbGwgc2hvdyB1cCBoZXJlLjwvaDM+PHA+U3RhcnQgdG9kYXkncyBzZXNzaW9uIHRvIGxvZyB5b3VyIGZpcnN0IG9uZS48L3A+e3RvZGF5V29ya291dCAmJiA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHN0YXJ0V29ya291dCh0b2RheVdvcmtvdXQpfT5TdGFydCB3b3Jrb3V0IDxJY29uIG5hbWU9XCJwbGF5XCIgLz48L0J1dHRvbj59PC9kaXY+fVxyXG4gICAgPC9kaXY+fVxyXG5cclxuICAgIHtzZWxlY3RlZCAmJiA8ZGl2IGNsYXNzTmFtZT1cIndvcmtvdXQtZHJhd2VyLWJhY2tkcm9wXCIgb25Nb3VzZURvd249e2Nsb3NlRGV0YWlsfT5cclxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cIndvcmtvdXQtZGV0YWlsLWRyYXdlclwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9e2Ake3NlbGVjdGVkLm5hbWV9IGRldGFpbHNgfSBvbk1vdXNlRG93bj17KGV2ZW50KSA9PiBldmVudC5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgPGhlYWRlcj48ZGl2IGNsYXNzTmFtZT1cImRyYXdlci1oZWFkZXItYWN0aW9uc1wiPjxidXR0b24gY2xhc3NOYW1lPVwicGxhbi1zZXR0aW5ncy1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvcGVuU2V0dGluZ3Moc2VsZWN0ZWQpfSBhcmlhLWxhYmVsPVwiUGxhbiBzZXR0aW5nc1wiPjxJY29uIG5hbWU9XCJzbGlkZXJzXCIgLz48c3BhbiByb2xlPVwidG9vbHRpcFwiPlBsYW4gc2V0dGluZ3M8L3NwYW4+PC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9XCJkcmF3ZXItY2xvc2VcIiBvbkNsaWNrPXtjbG9zZURldGFpbH0gYXJpYS1sYWJlbD1cIkNsb3NlIHdvcmtvdXQgZGV0YWlsc1wiPsOXPC9idXR0b24+PC9kaXY+PHNtYWxsPntzZWxlY3RlZC5taW51dGVzfSBNSU4gwrcge2RpZmZpY3VsdHkudG9VcHBlckNhc2UoKX08L3NtYWxsPjxoMj57c2VsZWN0ZWQubmFtZX08L2gyPjxkaXYgY2xhc3NOYW1lPVwidGFyZ2V0LWNoaXBzXCI+PGk+e3NlbGVjdGVkLmVxdWlwbWVudH08L2k+e3NlbGVjdGVkLnRhcmdldFRhZ3MubWFwKCh0YWcpID0+IDxpIGtleT17dGFnfT57dGFnfTwvaT4pfTwvZGl2PjwvaGVhZGVyPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHJhd2VyLXNjcm9sbFwiPlxyXG4gICAgICAgICAge3NlbGVjdGVkLm5hbWUuaW5jbHVkZXMoXCJXYWxrLVJ1blwiKSAmJiA8ZGl2IGNsYXNzTmFtZT1cInJ1bi1zZWdtZW50c1wiPjxzbWFsbD5SVU4gU0VHTUVOVFM8L3NtYWxsPjxwPldhcm0tdXAgd2FsayA1OjAwIMK3IDggw5cgKGpvZyAxOjAwIC8gd2FsayAyOjAwKSDCtyBjb29sLWRvd24gNTowMDwvcD48L2Rpdj59XHJcbiAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwiZGV0YWlsLWV4ZXJjaXNlc1wiPntzZWxlY3RlZC5leGVyY2lzZXMubWFwKChleGVyY2lzZSwgaW5kZXgpID0+IDxsaSBrZXk9e2Ake2V4ZXJjaXNlLm5hbWV9LSR7aW5kZXh9YH0+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4ZXJjaXNlLW51bWJlclwiPntTdHJpbmcoaW5kZXggKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImR1bWJiZWxsLWljb25cIj48SWNvbiBuYW1lPVwiZHVtYmJlbGxcIiAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdj48c3Ryb25nPntleGVyY2lzZS5uYW1lfTwvc3Ryb25nPjxzbWFsbD57ZXhlcmNpc2UucHJlc2NyaXB0aW9ufXtzZWxlY3RlZC5sb3dJbXBhY3QgJiYgPGVtPkxvdy1pbXBhY3Q8L2VtPn08L3NtYWxsPjwvZGl2PjxpPntzZWxlY3RlZC50YXJnZXRUYWdzW2luZGV4ICUgc2VsZWN0ZWQudGFyZ2V0VGFncy5sZW5ndGhdfTwvaT5cclxuICAgICAgICAgIDwvbGk+KX08L29sPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxmb290ZXI+XHJcbiAgICAgICAgICB7c2hvd01vdmUgJiYgPGxhYmVsIGNsYXNzTmFtZT1cIm1vdmUtZGF0ZVwiPkNob29zZSBhIG5ldyBkYXk8aW5wdXQgdHlwZT1cImRhdGVcIiBtaW49e3RvZGF5S2V5fSBkZWZhdWx0VmFsdWU9e3NlbGVjdGVkLmRhdGV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IG1vdmVXb3Jrb3V0KGV2ZW50LnRhcmdldC52YWx1ZSl9IC8+PC9sYWJlbD59XHJcbiAgICAgICAgICA8ZGl2PjxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0U2hvd01vdmUoKGN1cnJlbnQpID0+ICFjdXJyZW50KX0+PEljb24gbmFtZT1cImNhbGVuZGFyXCIgLz4gTW92ZSB0byBhbm90aGVyIGRheTwvQnV0dG9uPjxCdXR0b24gb25DbGljaz17KCkgPT4gc3RhcnRXb3Jrb3V0KHNlbGVjdGVkKX0+U3RhcnQgd29ya291dCA8SWNvbiBuYW1lPVwicGxheVwiIC8+PC9CdXR0b24+PC9kaXY+XHJcbiAgICAgICAgICA8cD5HZW5lcmFsIGZpdG5lc3MgZ3VpZGFuY2UsIG5vdCBtZWRpY2FsIGFkdmljZS48L3A+XHJcbiAgICAgICAgPC9mb290ZXI+XHJcbiAgICAgIDwvYXNpZGU+XHJcbiAgICA8L2Rpdj59XHJcbiAgICB7c2V0dGluZ3NUYXJnZXRJZCAmJiA8ZGl2IGNsYXNzTmFtZT1cInBsYW4tc2V0dGluZ3MtYmFja2Ryb3BcIiBvbk1vdXNlRG93bj17KCkgPT4gc2V0U2V0dGluZ3NUYXJnZXRJZChudWxsKX0+PGRpdiBjbGFzc05hbWU9XCJwbGFuLXNldHRpbmdzLWRpYWxvZ1wiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJQbGFuIHNldHRpbmdzXCIgb25Nb3VzZURvd249eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9PjxoZWFkZXI+PGRpdj48c21hbGw+V09SS09VVCBQUkVGRVJFTkNFUzwvc21hbGw+PGgyPlBsYW4gc2V0dGluZ3M8L2gyPjxwPlRlbGwgdXMgd2hhdCB5b3UgaGF2ZSBhbmQgaG93IGhhcmQgeW91IHdhbnQgdG8gdHJhaW4uPC9wPjwvZGl2PjxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2V0dGluZ3NUYXJnZXRJZChudWxsKX0gYXJpYS1sYWJlbD1cIkNsb3NlIHBsYW4gc2V0dGluZ3NcIj48SWNvbiBuYW1lPVwiY2xvc2VcIiAvPjwvYnV0dG9uPjwvaGVhZGVyPjxkaXYgY2xhc3NOYW1lPVwicGxhbi1zZXR0aW5ncy1ib2R5XCI+XHJcbiAgICAgIDxmaWVsZHNldD48bGVnZW5kPldoYXQgZXF1aXBtZW50IGRvIHlvdSBoYXZlIGZvciB0aGlzIHBsYW4/PC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1lcXVpcG1lbnRcIj57W1wiQm9keXdlaWdodCBvbmx5XCIsIFwiSG91c2Vob2xkIGl0ZW1zICh3YXRlciBib3R0bGVzLCBiYWNrcGFjaylcIiwgXCJEdW1iYmVsbHNcIiwgXCJSZXNpc3RhbmNlIGJhbmRzXCIsIFwiR3ltIG1hY2hpbmVzICYgYmFyYmVsbFwiXS5tYXAoKGl0ZW0pID0+IDxidXR0b24gY2xhc3NOYW1lPXtzZXR0aW5nc0VxdWlwbWVudC5pbmNsdWRlcyhpdGVtKSA/IFwiYWN0aXZlXCIgOiBcIlwifSBrZXk9e2l0ZW19IG9uQ2xpY2s9eygpID0+IHRvZ2dsZVNldHRpbmdzRXF1aXBtZW50KGl0ZW0pfT57c2V0dGluZ3NFcXVpcG1lbnQuaW5jbHVkZXMoaXRlbSkgJiYgPEljb24gbmFtZT1cImNoZWNrXCIgLz59e2l0ZW19PC9idXR0b24+KX08L2Rpdj48L2ZpZWxkc2V0PlxyXG4gICAgICA8ZmllbGRzZXQ+PGxlZ2VuZD5Ib3cgaW50ZW5zZSBzaG91bGQgaXQgYmU/PC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJpbnRlbnNpdHktY29udHJvbFwiPnsoW1tcIkVhc3lcIiwgXCJMb3dlciBpbXBhY3QsIGxvbmdlciByZXN0c1wiXSwgW1wiTW9kZXJhdGVcIiwgXCJCYWxhbmNlZCB3b3JrIGFuZCByZXN0XCJdLCBbXCJIYXJkXCIsIFwiTW9yZSB3b3JrLCBzaG9ydGVyIHJlc3RzXCJdXSBhcyBjb25zdCkubWFwKChbbmFtZSwgY29weV0pID0+IDxidXR0b24gY2xhc3NOYW1lPXtzZXR0aW5nc0ludGVuc2l0eSA9PT0gbmFtZSA/IFwiYWN0aXZlXCIgOiBcIlwifSBrZXk9e25hbWV9IG9uQ2xpY2s9eygpID0+IHNldFNldHRpbmdzSW50ZW5zaXR5KG5hbWUpfT48c3Ryb25nPntuYW1lfTwvc3Ryb25nPjxzbWFsbD57Y29weX08L3NtYWxsPjwvYnV0dG9uPil9PC9kaXY+PC9maWVsZHNldD5cclxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNldHRpbmdzLXRvZ2dsZVwiPjxzcGFuPjxzdHJvbmc+SW5jbHVkZSBsb3ctaW1wYWN0IHZlcnNpb25zPC9zdHJvbmc+PHNtYWxsPkFkZCBqb2ludC1mcmllbmRseSBhbHRlcm5hdGl2ZXMgd2hlcmUgdXNlZnVsLjwvc21hbGw+PC9zcGFuPjxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXtzZXR0aW5nc0xvd0ltcGFjdH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0U2V0dGluZ3NMb3dJbXBhY3QoZXZlbnQudGFyZ2V0LmNoZWNrZWQpfSAvPjwvbGFiZWw+XHJcbiAgICAgIDxmaWVsZHNldD48bGVnZW5kPkFwcGx5IHRvPC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1zY29wZVwiPjxsYWJlbD48aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cInNldHRpbmdzLXNjb3BlXCIgY2hlY2tlZD17c2V0dGluZ3NTY29wZSA9PT0gXCJvbmVcIn0gb25DaGFuZ2U9eygpID0+IHNldFNldHRpbmdzU2NvcGUoXCJvbmVcIil9IC8+VGhpcyB3b3Jrb3V0IG9ubHk8L2xhYmVsPjxsYWJlbD48aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cInNldHRpbmdzLXNjb3BlXCIgY2hlY2tlZD17c2V0dGluZ3NTY29wZSA9PT0gXCJhbGxcIn0gb25DaGFuZ2U9eygpID0+IHNldFNldHRpbmdzU2NvcGUoXCJhbGxcIil9IC8+QWxsIHVwY29taW5nIHdvcmtvdXRzPC9sYWJlbD48L2Rpdj48L2ZpZWxkc2V0PlxyXG4gICAgPC9kaXY+PGZvb3Rlcj48YnV0dG9uIGNsYXNzTmFtZT1cInJlc2V0LXNldHRpbmdzXCIgb25DbGljaz17KCkgPT4geyBzZXRTZXR0aW5nc0VxdWlwbWVudChkZWZhdWx0RXF1aXBtZW50KTsgc2V0U2V0dGluZ3NJbnRlbnNpdHkoXCJNb2RlcmF0ZVwiKTsgc2V0U2V0dGluZ3NMb3dJbXBhY3QoYXV0b21hdGljTG93SW1wYWN0KTsgc2V0U2V0dGluZ3NTY29wZShcIm9uZVwiKTsgfX0+UmVzZXQgdG8gcHJvZmlsZSBkZWZhdWx0czwvYnV0dG9uPjxkaXY+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZXR0aW5nc1RhcmdldElkKG51bGwpfT5DYW5jZWw8L0J1dHRvbj48QnV0dG9uIGRpc2FibGVkPXshc2V0dGluZ3NFcXVpcG1lbnQubGVuZ3RofSBvbkNsaWNrPXtzYXZlUGxhblNldHRpbmdzfT5TYXZlIGNoYW5nZXM8L0J1dHRvbj48L2Rpdj48L2Zvb3Rlcj48L2Rpdj48L2Rpdj59XHJcbiAgPC8+O1xyXG59XHJcbiJdfQ==