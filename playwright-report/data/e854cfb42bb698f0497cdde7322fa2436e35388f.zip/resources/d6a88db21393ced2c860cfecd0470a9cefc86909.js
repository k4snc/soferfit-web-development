export const reviews = [
	{
		initials: "AR",
		name: "Ari R.",
		comment: "The structured challenge and guided session cues kept me consistent without needing a personal trainer."
	},
	{
		initials: "JM",
		name: "Jordan M.",
		comment: "SoferFit gives me structure without making fitness feel complicated. The weekly plan keeps me consistent."
	},
	{
		initials: "SK",
		name: "Sam K.",
		comment: "I love that the workouts meet me at my level. Every session feels focused, clear, and achievable."
	},
	{
		initials: "TN",
		name: "Taylor N.",
		comment: "The 90-day challenge finally made progress feel manageable. I always know what to do next."
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxNQUFNLFVBQVU7Q0FDckI7RUFDRSxVQUFVO0VBQ1YsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsVUFBVTtFQUNWLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQTtFQUNFLFVBQVU7RUFDVixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0E7RUFDRSxVQUFVO0VBQ1YsTUFBTTtFQUNOLFNBQVM7Q0FDWDtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJldmlld3MudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IHJldmlld3MgPSBbXHJcbiAge1xyXG4gICAgaW5pdGlhbHM6IFwiQVJcIixcclxuICAgIG5hbWU6IFwiQXJpIFIuXCIsXHJcbiAgICBjb21tZW50OiBcIlRoZSBzdHJ1Y3R1cmVkIGNoYWxsZW5nZSBhbmQgZ3VpZGVkIHNlc3Npb24gY3VlcyBrZXB0IG1lIGNvbnNpc3RlbnQgd2l0aG91dCBuZWVkaW5nIGEgcGVyc29uYWwgdHJhaW5lci5cIixcclxuICB9LFxyXG4gIHtcclxuICAgIGluaXRpYWxzOiBcIkpNXCIsXHJcbiAgICBuYW1lOiBcIkpvcmRhbiBNLlwiLFxyXG4gICAgY29tbWVudDogXCJTb2ZlckZpdCBnaXZlcyBtZSBzdHJ1Y3R1cmUgd2l0aG91dCBtYWtpbmcgZml0bmVzcyBmZWVsIGNvbXBsaWNhdGVkLiBUaGUgd2Vla2x5IHBsYW4ga2VlcHMgbWUgY29uc2lzdGVudC5cIixcclxuICB9LFxyXG4gIHtcclxuICAgIGluaXRpYWxzOiBcIlNLXCIsXHJcbiAgICBuYW1lOiBcIlNhbSBLLlwiLFxyXG4gICAgY29tbWVudDogXCJJIGxvdmUgdGhhdCB0aGUgd29ya291dHMgbWVldCBtZSBhdCBteSBsZXZlbC4gRXZlcnkgc2Vzc2lvbiBmZWVscyBmb2N1c2VkLCBjbGVhciwgYW5kIGFjaGlldmFibGUuXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpbml0aWFsczogXCJUTlwiLFxyXG4gICAgbmFtZTogXCJUYXlsb3IgTi5cIixcclxuICAgIGNvbW1lbnQ6IFwiVGhlIDkwLWRheSBjaGFsbGVuZ2UgZmluYWxseSBtYWRlIHByb2dyZXNzIGZlZWwgbWFuYWdlYWJsZS4gSSBhbHdheXMga25vdyB3aGF0IHRvIGRvIG5leHQuXCIsXHJcbiAgfSxcclxuXTtcclxuIl19