import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/App.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { GlossaryDrawer } from "/src/frontend/components/GlossaryDrawer.tsx";
import { clearFitnessStore, readFitnessStore, writeFitnessStore } from "/src/frontend/fitnessStore.ts";
import { LoginModal } from "/src/frontend/modals/LoginModal.tsx";
import { SignupModal } from "/src/frontend/modals/SignupModal.tsx";
import { DashboardPage } from "/src/frontend/pages/DashboardPage.tsx";
import { LandingPage } from "/src/frontend/pages/LandingPage.tsx";
import { useExplorer } from "/src/frontend/hooks/useExplorer.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/App.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
function App() {
	_s();
	const explorer = useExplorer();
	const { focusArea, mode, equipment, explorerAge, explorerHeight, explorerWeight } = explorer;
	const [showLogin, setShowLogin] = useState(false);
	const [showSignup, setShowSignup] = useState(false);
	const [showGlossary, setShowGlossary] = useState(false);
	const [glossaryTerm, setGlossaryTerm] = useState();
	const [memberProfile, setMemberProfile] = useState(null);
	const [isSignedIn, setIsSignedIn] = useState(() => Boolean(localStorage.getItem("soferfit-member")));
	const [showProfileMenu, setShowProfileMenu] = useState(false);
	const [path, setPath] = useState(window.location.pathname);
	const [view, setView] = useState(() => window.location.pathname === "/" ? "home" : "dashboard");
	const [appToast, setAppToast] = useState(null);
	const navigate = (nextPath, replace = false) => {
		if (replace) window.history.replaceState({}, "", nextPath);
		else window.history.pushState({}, "", nextPath);
		setPath(nextPath);
		setView(nextPath === "/" ? "home" : "dashboard");
		window.scrollTo({ top: 0 });
	};
	useEffect(() => {
		const onPopState = () => {
			const nextPath = window.location.pathname;
			setPath(nextPath);
			setView(nextPath === "/" ? "home" : "dashboard");
		};
		window.addEventListener("popstate", onPopState);
		return () => window.removeEventListener("popstate", onPopState);
	}, []);
	useEffect(() => {
		if (path !== "/" && !isSignedIn) navigate("/", true);
	}, [isSignedIn, path]);
	useEffect(() => {
		if (!appToast) return;
		const timer = window.setTimeout(() => setAppToast(null), 3200);
		return () => window.clearTimeout(timer);
	}, [appToast]);
	const openGlossary = (term) => {
		setGlossaryTerm(term);
		setShowGlossary(true);
	};
	if (view === "dashboard" && isSignedIn) return /* @__PURE__ */ _jsxDEV(DashboardPage, {
		path,
		navigate,
		profile: memberProfile,
		onHome: () => navigate("/"),
		onLogout: () => {
			setMemberProfile(null);
			setIsSignedIn(false);
			setAppToast("You've been logged out.");
			navigate("/", true);
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 50
	}, this);
	return /* @__PURE__ */ _jsxDEV(LandingPage, {
		isSignedIn,
		memberProfile,
		showProfileMenu,
		setShowProfileMenu,
		setShowLogin,
		setShowSignup,
		setMemberProfile,
		setIsSignedIn,
		setAppToast,
		navigate,
		openGlossary,
		explorer,
		children: [
			/* @__PURE__ */ _jsxDEV(GlossaryDrawer, {
				open: showGlossary,
				initialTerm: glossaryTerm,
				onClose: () => setShowGlossary(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(LoginModal, {
				open: showLogin,
				onClose: () => setShowLogin(false),
				onSignup: () => {
					setShowLogin(false);
					setShowSignup(true);
				},
				onSuccess: () => {
					setShowLogin(false);
					setIsSignedIn(true);
					if (!localStorage.getItem("soferfit-member")) localStorage.setItem("soferfit-member", JSON.stringify({
						id: crypto.randomUUID(),
						email: "member@soferfit.local",
						createdAt: new Date().toISOString()
					}));
					navigate("/dashboard");
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SignupModal, {
				open: showSignup,
				initialAnswers: {
					name: "",
					email: "",
					password: "",
					avatarUrl: "",
					unitSystem: "metric",
					focusArea: focusArea ?? "Full Body",
					mode,
					equipment,
					age: explorerAge,
					height: explorerHeight,
					weight: explorerWeight,
					somatotype: "",
					goal: mode === "Muscle & Strength" ? "Build Muscle & Strength" : mode === "Fat Loss & Cardio" ? "Lose Fat & Get Lean" : "Body Recomposition",
					experience: "",
					activity: "",
					targetWeight: "",
					targetTimeline: "By day 60",
					availableEquipment: equipment === "Gym Equipment" ? "Full Gym Access" : "Bodyweight / Home Only",
					hasCondition: false,
					challengeDays: null,
					workoutDays: null,
					sessionMinutes: null,
					sessionChoice: "",
					customSessionMinutes: "",
					challengeStartDate: ""
				},
				onClose: () => setShowSignup(false),
				onLogin: () => {
					setShowSignup(false);
					setShowLogin(true);
				},
				onOpenGlossary: openGlossary,
				onComplete: (profile) => {
					const completeProfile = {
						...profile,
						challengeStartDate: new Date().toISOString()
					};
					setMemberProfile(completeProfile);
					localStorage.setItem("soferfit-member", JSON.stringify({
						id: crypto.randomUUID(),
						email: profile.email,
						createdAt: new Date().toISOString()
					}));
					clearFitnessStore();
					writeFitnessStore(readFitnessStore(completeProfile));
					setIsSignedIn(true);
					setShowSignup(false);
					navigate("/dashboard");
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			appToast && /* @__PURE__ */ _jsxDEV("div", {
				className: "app-toast",
				role: "status",
				children: appToast
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 20
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
_s(App, "3tpMvS8P/DFkjAUsp9E522hpQoc=", false, function() {
	return [useExplorer];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG1CQUFtQixrQkFBa0IseUJBQXlCO0FBQ3ZFLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXFCO0FBRTlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsbUJBQW1COzs7O0FBRTVCLFNBQVMsTUFBTTs7Q0FDYixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLEVBQUUsV0FBVyxNQUFNLFdBQVcsYUFBYSxnQkFBZ0IsbUJBQW1CO0NBQ3BGLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFpQjtDQUN6RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBK0IsSUFBSTtDQUM3RSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsZUFBZSxRQUFRLGFBQWEsUUFBUSxpQkFBaUIsQ0FBQyxDQUFDO0NBQ25HLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsT0FBTyxTQUFTLFFBQVE7Q0FDekQsTUFBTSxDQUFDLE1BQU0sV0FBVyxlQUFxQyxPQUFPLFNBQVMsYUFBYSxNQUFNLFNBQVMsV0FBVztDQUNwSCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7Q0FFNUQsTUFBTSxZQUFZLFVBQWtCLFVBQVUsVUFBVTtFQUN0RCxJQUFJLFNBQVMsT0FBTyxRQUFRLGFBQWEsQ0FBQyxHQUFHLElBQUksUUFBUTtPQUNwRCxPQUFPLFFBQVEsVUFBVSxDQUFDLEdBQUcsSUFBSSxRQUFRO0VBQzlDLFFBQVEsUUFBUTtFQUNoQixRQUFRLGFBQWEsTUFBTSxTQUFTLFdBQVc7RUFDL0MsT0FBTyxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUM7Q0FDNUI7Q0FFQSxnQkFBZ0I7RUFDZCxNQUFNLG1CQUFtQjtHQUN2QixNQUFNLFdBQVcsT0FBTyxTQUFTO0dBQ2pDLFFBQVEsUUFBUTtHQUNoQixRQUFRLGFBQWEsTUFBTSxTQUFTLFdBQVc7RUFDakQ7RUFDQSxPQUFPLGlCQUFpQixZQUFZLFVBQVU7RUFDOUMsYUFBYSxPQUFPLG9CQUFvQixZQUFZLFVBQVU7Q0FDaEUsR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDZCxJQUFJLFNBQVMsT0FBTyxDQUFDLFlBQVksU0FBUyxLQUFLLElBQUk7Q0FDckQsR0FBRyxDQUFDLFlBQVksSUFBSSxDQUFDO0NBRXJCLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxVQUFVO0VBQ2YsTUFBTSxRQUFRLE9BQU8saUJBQWlCLFlBQVksSUFBSSxHQUFHLElBQUk7RUFDN0QsYUFBYSxPQUFPLGFBQWEsS0FBSztDQUN4QyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBRWIsTUFBTSxnQkFBZ0IsU0FBa0I7RUFDdEMsZ0JBQWdCLElBQUk7RUFDcEIsZ0JBQWdCLElBQUk7Q0FDdEI7Q0FFQSxJQUFJLFNBQVMsZUFBZSxZQUFZLE9BQU8sd0JBQUMsZUFBRDtFQUFxQjtFQUFnQjtFQUFVLFNBQVM7RUFBZSxjQUFjLFNBQVMsR0FBRztFQUFHLGdCQUFnQjtHQUNqSyxpQkFBaUIsSUFBSTtHQUNyQixjQUFjLEtBQUs7R0FDbkIsWUFBWSx5QkFBeUI7R0FDckMsU0FBUyxLQUFLLElBQUk7RUFDcEI7Q0FBSTs7Ozs7Q0FFSixPQUNFLHdCQUFDLGFBQUQ7RUFDYztFQUNHO0VBQ0U7RUFDRztFQUNOO0VBQ0M7RUFDRztFQUNIO0VBQ0Y7RUFDSDtFQUNJO0VBQ0o7WUFaWjtHQWNFLHdCQUFDLGdCQUFEO0lBQWdCLE1BQU07SUFBYyxhQUFhO0lBQWMsZUFBZSxnQkFBZ0IsS0FBSztHQUFJOzs7OztHQUN2Ryx3QkFBQyxZQUFEO0lBQ0UsTUFBTTtJQUNOLGVBQWUsYUFBYSxLQUFLO0lBQ2pDLGdCQUFnQjtLQUNkLGFBQWEsS0FBSztLQUNsQixjQUFjLElBQUk7SUFDcEI7SUFDQSxpQkFBaUI7S0FDZixhQUFhLEtBQUs7S0FDbEIsY0FBYyxJQUFJO0tBQ2xCLElBQUksQ0FBQyxhQUFhLFFBQVEsaUJBQWlCLEdBQUcsYUFBYSxRQUFRLG1CQUFtQixLQUFLLFVBQVU7TUFBRSxJQUFJLE9BQU8sV0FBVztNQUFHLE9BQU87TUFBeUIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7S0FBRSxDQUFDLENBQUM7S0FDdE0sU0FBUyxZQUFZO0lBQ3ZCO0dBQ0Q7Ozs7O0dBQ0Qsd0JBQUMsYUFBRDtJQUNFLE1BQU07SUFDTixnQkFBZ0I7S0FDZCxNQUFNO0tBQ04sT0FBTztLQUNQLFVBQVU7S0FDVixXQUFXO0tBQ1gsWUFBWTtLQUNaLFdBQVcsYUFBYTtLQUN4QjtLQUNBO0tBQ0EsS0FBSztLQUNMLFFBQVE7S0FDUixRQUFRO0tBQ1IsWUFBWTtLQUNaLE1BQU0sU0FBUyxzQkFBc0IsNEJBQTRCLFNBQVMsc0JBQXNCLHdCQUF3QjtLQUN4SCxZQUFZO0tBQ1osVUFBVTtLQUNWLGNBQWM7S0FDZCxnQkFBZ0I7S0FDaEIsb0JBQW9CLGNBQWMsa0JBQWtCLG9CQUFvQjtLQUN4RSxjQUFjO0tBQ2QsZUFBZTtLQUNmLGFBQWE7S0FDYixnQkFBZ0I7S0FDaEIsZUFBZTtLQUNmLHNCQUFzQjtLQUN0QixvQkFBb0I7SUFDdEI7SUFDQSxlQUFlLGNBQWMsS0FBSztJQUNsQyxlQUFlO0tBQ2IsY0FBYyxLQUFLO0tBQ25CLGFBQWEsSUFBSTtJQUNuQjtJQUNBLGdCQUFnQjtJQUNoQixhQUFhLFlBQVk7S0FDdkIsTUFBTSxrQkFBa0I7TUFBRSxHQUFHO01BQVMsb0JBQW9CLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUFFO0tBQ25GLGlCQUFpQixlQUFlO0tBQ2hDLGFBQWEsUUFBUSxtQkFBbUIsS0FBSyxVQUFVO01BQUUsSUFBSSxPQUFPLFdBQVc7TUFBRyxPQUFPLFFBQVE7TUFBTyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUFFLENBQUMsQ0FBQztLQUM5SSxrQkFBa0I7S0FDbEIsa0JBQWtCLGlCQUFpQixlQUFlLENBQUM7S0FDbkQsY0FBYyxJQUFJO0tBQ2xCLGNBQWMsS0FBSztLQUNuQixTQUFTLFlBQVk7SUFDdkI7R0FDRDs7Ozs7R0FDQSxZQUFZLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQVksTUFBSztjQUFVO0dBQWM7Ozs7O0VBQzFEOzs7Ozs7QUFFakI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgR2xvc3NhcnlEcmF3ZXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL0dsb3NzYXJ5RHJhd2VyXCI7XHJcbmltcG9ydCB7IGNsZWFyRml0bmVzc1N0b3JlLCByZWFkRml0bmVzc1N0b3JlLCB3cml0ZUZpdG5lc3NTdG9yZSB9IGZyb20gXCIuL2ZpdG5lc3NTdG9yZVwiO1xyXG5pbXBvcnQgeyBMb2dpbk1vZGFsIH0gZnJvbSBcIi4vbW9kYWxzL0xvZ2luTW9kYWxcIjtcclxuaW1wb3J0IHsgU2lnbnVwTW9kYWwgfSBmcm9tIFwiLi9tb2RhbHMvU2lnbnVwTW9kYWxcIjtcclxuaW1wb3J0IHsgRGFzaGJvYXJkUGFnZSB9IGZyb20gXCIuL3BhZ2VzL0Rhc2hib2FyZFBhZ2VcIjtcclxuaW1wb3J0IHR5cGUgeyBTaWdudXBBbnN3ZXJzIH0gZnJvbSBcIi4vdHlwZXNcIjtcclxuaW1wb3J0IHsgTGFuZGluZ1BhZ2UgfSBmcm9tIFwiLi9wYWdlcy9MYW5kaW5nUGFnZVwiO1xyXG5pbXBvcnQgeyB1c2VFeHBsb3JlciB9IGZyb20gXCIuL2hvb2tzL3VzZUV4cGxvcmVyXCI7XHJcblxyXG5mdW5jdGlvbiBBcHAoKSB7XHJcbiAgY29uc3QgZXhwbG9yZXIgPSB1c2VFeHBsb3JlcigpO1xyXG4gIGNvbnN0IHsgZm9jdXNBcmVhLCBtb2RlLCBlcXVpcG1lbnQsIGV4cGxvcmVyQWdlLCBleHBsb3JlckhlaWdodCwgZXhwbG9yZXJXZWlnaHQgfSA9IGV4cGxvcmVyO1xyXG4gIGNvbnN0IFtzaG93TG9naW4sIHNldFNob3dMb2dpbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dTaWdudXAsIHNldFNob3dTaWdudXBdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93R2xvc3NhcnksIHNldFNob3dHbG9zc2FyeV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2dsb3NzYXJ5VGVybSwgc2V0R2xvc3NhcnlUZXJtXSA9IHVzZVN0YXRlPHN0cmluZz4oKTtcclxuICBjb25zdCBbbWVtYmVyUHJvZmlsZSwgc2V0TWVtYmVyUHJvZmlsZV0gPSB1c2VTdGF0ZTxTaWdudXBBbnN3ZXJzIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2lzU2lnbmVkSW4sIHNldElzU2lnbmVkSW5dID0gdXNlU3RhdGUoKCkgPT4gQm9vbGVhbihsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNvZmVyZml0LW1lbWJlclwiKSkpO1xyXG4gIGNvbnN0IFtzaG93UHJvZmlsZU1lbnUsIHNldFNob3dQcm9maWxlTWVudV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BhdGgsIHNldFBhdGhdID0gdXNlU3RhdGUod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKTtcclxuICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZTxcImhvbWVcIiB8IFwiZGFzaGJvYXJkXCI+KCgpID0+IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvXCIgPyBcImhvbWVcIiA6IFwiZGFzaGJvYXJkXCIpO1xyXG4gIGNvbnN0IFthcHBUb2FzdCwgc2V0QXBwVG9hc3RdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IG5hdmlnYXRlID0gKG5leHRQYXRoOiBzdHJpbmcsIHJlcGxhY2UgPSBmYWxzZSkgPT4ge1xyXG4gICAgaWYgKHJlcGxhY2UpIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSh7fSwgXCJcIiwgbmV4dFBhdGgpO1xyXG4gICAgZWxzZSB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIFwiXCIsIG5leHRQYXRoKTtcclxuICAgIHNldFBhdGgobmV4dFBhdGgpO1xyXG4gICAgc2V0VmlldyhuZXh0UGF0aCA9PT0gXCIvXCIgPyBcImhvbWVcIiA6IFwiZGFzaGJvYXJkXCIpO1xyXG4gICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwIH0pO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBvblBvcFN0YXRlID0gKCkgPT4ge1xyXG4gICAgICBjb25zdCBuZXh0UGF0aCA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZTtcclxuICAgICAgc2V0UGF0aChuZXh0UGF0aCk7XHJcbiAgICAgIHNldFZpZXcobmV4dFBhdGggPT09IFwiL1wiID8gXCJob21lXCIgOiBcImRhc2hib2FyZFwiKTtcclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIG9uUG9wU3RhdGUpO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgb25Qb3BTdGF0ZSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHBhdGggIT09IFwiL1wiICYmICFpc1NpZ25lZEluKSBuYXZpZ2F0ZShcIi9cIiwgdHJ1ZSk7XHJcbiAgfSwgW2lzU2lnbmVkSW4sIHBhdGhdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghYXBwVG9hc3QpIHJldHVybjtcclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0QXBwVG9hc3QobnVsbCksIDMyMDApO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xyXG4gIH0sIFthcHBUb2FzdF0pO1xyXG5cclxuICBjb25zdCBvcGVuR2xvc3NhcnkgPSAodGVybT86IHN0cmluZykgPT4ge1xyXG4gICAgc2V0R2xvc3NhcnlUZXJtKHRlcm0pO1xyXG4gICAgc2V0U2hvd0dsb3NzYXJ5KHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGlmICh2aWV3ID09PSBcImRhc2hib2FyZFwiICYmIGlzU2lnbmVkSW4pIHJldHVybiA8RGFzaGJvYXJkUGFnZSBwYXRoPXtwYXRofSBuYXZpZ2F0ZT17bmF2aWdhdGV9IHByb2ZpbGU9e21lbWJlclByb2ZpbGV9IG9uSG9tZT17KCkgPT4gbmF2aWdhdGUoXCIvXCIpfSBvbkxvZ291dD17KCkgPT4ge1xyXG4gICAgc2V0TWVtYmVyUHJvZmlsZShudWxsKTtcclxuICAgIHNldElzU2lnbmVkSW4oZmFsc2UpO1xyXG4gICAgc2V0QXBwVG9hc3QoXCJZb3UndmUgYmVlbiBsb2dnZWQgb3V0LlwiKTtcclxuICAgIG5hdmlnYXRlKFwiL1wiLCB0cnVlKTtcclxuICB9fSAvPjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxMYW5kaW5nUGFnZVxyXG4gICAgICBpc1NpZ25lZEluPXtpc1NpZ25lZElufVxyXG4gICAgICBtZW1iZXJQcm9maWxlPXttZW1iZXJQcm9maWxlfVxyXG4gICAgICBzaG93UHJvZmlsZU1lbnU9e3Nob3dQcm9maWxlTWVudX1cclxuICAgICAgc2V0U2hvd1Byb2ZpbGVNZW51PXtzZXRTaG93UHJvZmlsZU1lbnV9XHJcbiAgICAgIHNldFNob3dMb2dpbj17c2V0U2hvd0xvZ2lufVxyXG4gICAgICBzZXRTaG93U2lnbnVwPXtzZXRTaG93U2lnbnVwfVxyXG4gICAgICBzZXRNZW1iZXJQcm9maWxlPXtzZXRNZW1iZXJQcm9maWxlfVxyXG4gICAgICBzZXRJc1NpZ25lZEluPXtzZXRJc1NpZ25lZElufVxyXG4gICAgICBzZXRBcHBUb2FzdD17c2V0QXBwVG9hc3R9XHJcbiAgICAgIG5hdmlnYXRlPXtuYXZpZ2F0ZX1cclxuICAgICAgb3Blbkdsb3NzYXJ5PXtvcGVuR2xvc3Nhcnl9XHJcbiAgICAgIGV4cGxvcmVyPXtleHBsb3Jlcn1cclxuICAgID5cclxuICAgICAgPEdsb3NzYXJ5RHJhd2VyIG9wZW49e3Nob3dHbG9zc2FyeX0gaW5pdGlhbFRlcm09e2dsb3NzYXJ5VGVybX0gb25DbG9zZT17KCkgPT4gc2V0U2hvd0dsb3NzYXJ5KGZhbHNlKX0gLz5cclxuICAgICAgPExvZ2luTW9kYWxcclxuICAgICAgICBvcGVuPXtzaG93TG9naW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd0xvZ2luKGZhbHNlKX1cclxuICAgICAgICBvblNpZ251cD17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd0xvZ2luKGZhbHNlKTtcclxuICAgICAgICAgIHNldFNob3dTaWdudXAodHJ1ZSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBvblN1Y2Nlc3M9eygpID0+IHtcclxuICAgICAgICAgIHNldFNob3dMb2dpbihmYWxzZSk7XHJcbiAgICAgICAgICBzZXRJc1NpZ25lZEluKHRydWUpO1xyXG4gICAgICAgICAgaWYgKCFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNvZmVyZml0LW1lbWJlclwiKSkgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzb2ZlcmZpdC1tZW1iZXJcIiwgSlNPTi5zdHJpbmdpZnkoeyBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSwgZW1haWw6IFwibWVtYmVyQHNvZmVyZml0LmxvY2FsXCIsIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pKTtcclxuICAgICAgICAgIG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiKTtcclxuICAgICAgICB9fVxyXG4gICAgICAvPlxyXG4gICAgICA8U2lnbnVwTW9kYWxcclxuICAgICAgICBvcGVuPXtzaG93U2lnbnVwfVxyXG4gICAgICAgIGluaXRpYWxBbnN3ZXJzPXt7XHJcbiAgICAgICAgICBuYW1lOiBcIlwiLFxyXG4gICAgICAgICAgZW1haWw6IFwiXCIsXHJcbiAgICAgICAgICBwYXNzd29yZDogXCJcIixcclxuICAgICAgICAgIGF2YXRhclVybDogXCJcIixcclxuICAgICAgICAgIHVuaXRTeXN0ZW06IFwibWV0cmljXCIsXHJcbiAgICAgICAgICBmb2N1c0FyZWE6IGZvY3VzQXJlYSA/PyBcIkZ1bGwgQm9keVwiLFxyXG4gICAgICAgICAgbW9kZSxcclxuICAgICAgICAgIGVxdWlwbWVudCxcclxuICAgICAgICAgIGFnZTogZXhwbG9yZXJBZ2UsXHJcbiAgICAgICAgICBoZWlnaHQ6IGV4cGxvcmVySGVpZ2h0LFxyXG4gICAgICAgICAgd2VpZ2h0OiBleHBsb3JlcldlaWdodCxcclxuICAgICAgICAgIHNvbWF0b3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBnb2FsOiBtb2RlID09PSBcIk11c2NsZSAmIFN0cmVuZ3RoXCIgPyBcIkJ1aWxkIE11c2NsZSAmIFN0cmVuZ3RoXCIgOiBtb2RlID09PSBcIkZhdCBMb3NzICYgQ2FyZGlvXCIgPyBcIkxvc2UgRmF0ICYgR2V0IExlYW5cIiA6IFwiQm9keSBSZWNvbXBvc2l0aW9uXCIsXHJcbiAgICAgICAgICBleHBlcmllbmNlOiBcIlwiLFxyXG4gICAgICAgICAgYWN0aXZpdHk6IFwiXCIsXHJcbiAgICAgICAgICB0YXJnZXRXZWlnaHQ6IFwiXCIsXHJcbiAgICAgICAgICB0YXJnZXRUaW1lbGluZTogXCJCeSBkYXkgNjBcIixcclxuICAgICAgICAgIGF2YWlsYWJsZUVxdWlwbWVudDogZXF1aXBtZW50ID09PSBcIkd5bSBFcXVpcG1lbnRcIiA/IFwiRnVsbCBHeW0gQWNjZXNzXCIgOiBcIkJvZHl3ZWlnaHQgLyBIb21lIE9ubHlcIixcclxuICAgICAgICAgIGhhc0NvbmRpdGlvbjogZmFsc2UsXHJcbiAgICAgICAgICBjaGFsbGVuZ2VEYXlzOiBudWxsLFxyXG4gICAgICAgICAgd29ya291dERheXM6IG51bGwsXHJcbiAgICAgICAgICBzZXNzaW9uTWludXRlczogbnVsbCxcclxuICAgICAgICAgIHNlc3Npb25DaG9pY2U6IFwiXCIsXHJcbiAgICAgICAgICBjdXN0b21TZXNzaW9uTWludXRlczogXCJcIixcclxuICAgICAgICAgIGNoYWxsZW5nZVN0YXJ0RGF0ZTogXCJcIixcclxuICAgICAgICB9fVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dTaWdudXAoZmFsc2UpfVxyXG4gICAgICAgIG9uTG9naW49eygpID0+IHtcclxuICAgICAgICAgIHNldFNob3dTaWdudXAoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0U2hvd0xvZ2luKHRydWUpO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgb25PcGVuR2xvc3Nhcnk9e29wZW5HbG9zc2FyeX1cclxuICAgICAgICBvbkNvbXBsZXRlPXsocHJvZmlsZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY29tcGxldGVQcm9maWxlID0geyAuLi5wcm9maWxlLCBjaGFsbGVuZ2VTdGFydERhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9O1xyXG4gICAgICAgICAgc2V0TWVtYmVyUHJvZmlsZShjb21wbGV0ZVByb2ZpbGUpO1xyXG4gICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzb2ZlcmZpdC1tZW1iZXJcIiwgSlNPTi5zdHJpbmdpZnkoeyBpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSwgZW1haWw6IHByb2ZpbGUuZW1haWwsIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0pKTtcclxuICAgICAgICAgIGNsZWFyRml0bmVzc1N0b3JlKCk7XHJcbiAgICAgICAgICB3cml0ZUZpdG5lc3NTdG9yZShyZWFkRml0bmVzc1N0b3JlKGNvbXBsZXRlUHJvZmlsZSkpO1xyXG4gICAgICAgICAgc2V0SXNTaWduZWRJbih0cnVlKTtcclxuICAgICAgICAgIHNldFNob3dTaWdudXAoZmFsc2UpO1xyXG4gICAgICAgICAgbmF2aWdhdGUoXCIvZGFzaGJvYXJkXCIpO1xyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICAgIHthcHBUb2FzdCAmJiA8ZGl2IGNsYXNzTmFtZT1cImFwcC10b2FzdFwiIHJvbGU9XCJzdGF0dXNcIj57YXBwVG9hc3R9PC9kaXY+fVxyXG4gICAgPC9MYW5kaW5nUGFnZT5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdfQ==