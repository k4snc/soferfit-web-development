import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/session/SessionPlayer.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { dateKey } from "/src/frontend/lib/format.ts";
import { api } from "/src/frontend/services/api.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/session/SessionPlayer.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function SessionPlayer({ workout, store, update, navigate, toast }) {
	_s();
	const isRunning = workout.name.includes("Walk-Run") || workout.targetTags.includes("Run");
	const [screen, setScreen] = useState("ready");
	const [countdown, setCountdown] = useState(3);
	const [exerciseIndex, setExerciseIndex] = useState(0);
	const [setIndex, setSetIndex] = useState(0);
	const [phase, setPhase] = useState("work");
	const [remaining, setRemaining] = useState(40);
	const [elapsed, setElapsed] = useState(0);
	const [paused, setPaused] = useState(false);
	const [reps, setReps] = useState(0);
	const [cueIndex, setCueIndex] = useState(0);
	const [muted, setMuted] = useState(false);
	const [showEnd, setShowEnd] = useState(false);
	const [showSettings, setShowSettings] = useState(false);
	const [effort, setEffort] = useState(3);
	const [note, setNote] = useState("");
	const [distance, setDistance] = useState("");
	const [sound, setSound] = useState(true);
	const [voice, setVoice] = useState(false);
	const [vibration, setVibration] = useState(true);
	const [wakeScreen, setWakeScreen] = useState(true);
	const [demoSpeed, setDemoSpeed] = useState(false);
	const [indoor, setIndoor] = useState(false);
	const [sessionSwaps, setSessionSwaps] = useState({});
	const equipmentItems = isRunning ? [
		"Comfortable shoes",
		"Water bottle",
		"Safe route or clear indoor space"
	] : [
		workout.equipment,
		"Clear floor space",
		"Water nearby"
	];
	const [equipmentReady, setEquipmentReady] = useState(() => equipmentItems.map(() => false));
	const [runIndex, setRunIndex] = useState(0);
	const wakeLock = useRef(null);
	const runningSegments = useMemo(() => [
		{
			label: "WALK",
			name: "Warm-up walk",
			duration: 300
		},
		...Array.from({ length: 16 }, (_, index) => ({
			label: index % 2 === 0 ? "JOG" : "WALK",
			name: index % 2 === 0 ? "Easy jog" : "Recovery walk",
			duration: index % 2 === 0 ? 60 : 120
		})),
		{
			label: "WALK",
			name: "Cool-down walk",
			duration: 300
		}
	], []);
	const currentExercise = workout.exercises[exerciseIndex];
	const displayName = sessionSwaps[exerciseIndex] || currentExercise?.name || workout.name;
	const isTimed = workout.name.includes("HIIT") || /plank|hold|climber|jump|high knees/i.test(displayName);
	const totalSets = workout.sets ?? (isTimed ? 4 : 3);
	const phaseLabel = isRunning ? runningSegments[runIndex].label : phase === "rest" ? "REST" : "WORK";
	const formatTime = (seconds) => `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
	const cues = /push/i.test(displayName) ? [
		"Keep your core tight",
		"Breathe out as you push",
		"Keep a long line from head to heel"
	] : /squat|lunge/i.test(displayName) ? [
		"Soft knees on landing",
		"Press the floor away",
		"Keep your chest comfortably lifted"
	] : [
		"Move with control",
		"Keep breathing steadily",
		"Choose a pace you can sustain"
	];
	const beep = (double = false) => {
		if (!sound || muted) return;
		try {
			const AudioContextClass = window.AudioContext || window.webkitAudioContext;
			if (!AudioContextClass) return;
			const context = new AudioContextClass();
			[0, ...double ? [.14] : []].forEach((delay) => {
				const oscillator = context.createOscillator();
				const gain = context.createGain();
				oscillator.frequency.value = double ? 720 : 620;
				gain.gain.setValueAtTime(.08, context.currentTime + delay);
				gain.gain.exponentialRampToValueAtTime(.001, context.currentTime + delay + .09);
				oscillator.connect(gain).connect(context.destination);
				oscillator.start(context.currentTime + delay);
				oscillator.stop(context.currentTime + delay + .1);
			});
		} catch {}
	};
	const announce = (message) => {
		if (!voice || muted || !("speechSynthesis" in window)) return;
		window.speechSynthesis.cancel();
		window.speechSynthesis.speak(new SpeechSynthesisUtterance(message));
	};
	const signalChange = (message) => {
		beep(true);
		announce(message);
		if (vibration && "vibrate" in navigator) navigator.vibrate([
			80,
			50,
			80
		]);
	};
	const finishWorkout = () => {
		setPaused(true);
		setScreen("complete");
	};
	const advanceExercise = (direction = 1) => {
		const next = exerciseIndex + direction;
		if (next < 0) return;
		if (next >= workout.exercises.length) return finishWorkout();
		setExerciseIndex(next);
		setSetIndex(0);
		setPhase("work");
		setRemaining(40);
		setReps(0);
		signalChange(`Next exercise, ${sessionSwaps[next] || workout.exercises[next].name}`);
	};
	const finishRest = () => {
		if (setIndex + 1 < totalSets) {
			setSetIndex((value) => value + 1);
			setPhase("work");
			setRemaining(40);
			setReps(0);
			signalChange("Work");
		} else {
			advanceExercise();
		}
	};
	const finishWork = () => {
		setPhase("rest");
		setRemaining(20);
		signalChange("Rest");
	};
	const finishRunSegment = () => {
		if (runIndex + 1 >= runningSegments.length) return finishWorkout();
		const next = runIndex + 1;
		setRunIndex(next);
		setRemaining(runningSegments[next].duration);
		signalChange(`${runningSegments[next].label === "JOG" ? "Jog" : "Walk"} now`);
	};
	const moveRunSegment = (direction) => {
		const next = Math.max(0, Math.min(runningSegments.length - 1, runIndex + direction));
		setRunIndex(next);
		setRemaining(runningSegments[next].duration);
	};
	const saveSession = async (partial = false, destination = "/dashboard") => {
		const completedExercises = workout.exercises.slice(0, Math.min(workout.exercises.length, exerciseIndex + (partial ? 1 : workout.exercises.length))).map((exercise, index) => sessionSwaps[index] || exercise.name);
		const existing = store.sessions.some((session) => session.workoutId === workout.id && session.date === dateKey(new Date()));
		const sessionPayload = {
			workoutId: workout.id,
			date: dateKey(new Date()),
			duration: Math.max(1, Math.round(elapsed / 60)),
			exercisesDone: completedExercises,
			effort,
			note,
			distance: distance ? Number(distance) : undefined,
			isCompleted: !partial
		};
		// 1. Post live session log to Django backend
		try {
			if (api.postSession) {
				await api.postSession(sessionPayload);
			}
		} catch (error) {
			console.error("Backend failed to save workout session:", error);
		}
		// 2. Update local state store & metrics
		if (!existing) {
			const sessions = [...store.sessions, sessionPayload];
			const completionDates = new Set(sessions.map((session) => session.date));
			let currentStreak = 0;
			const cursor = new Date();
			while (completionDates.has(dateKey(cursor))) {
				currentStreak += 1;
				cursor.setDate(cursor.getDate() - 1);
			}
			const challengeDay = Math.max(1, Math.floor((Date.now() - new Date(`${store.challenge.startDate}T12:00:00`).getTime()) / 864e5) + 1);
			const badges = store.badges.map((badge) => {
				const requirements = {
					"streak-3": currentStreak >= 3,
					"streak-7": currentStreak >= 7,
					"streak-14": currentStreak >= 14,
					"streak-30": currentStreak >= 30,
					"workout-1": sessions.length >= 1,
					"workout-10": sessions.length >= 10,
					"workout-25": sessions.length >= 25,
					"workout-50": sessions.length >= 50,
					"week-1": sessions.length >= store.challenge.daysPerWeek,
					halfway: challengeDay >= store.challenge.length / 2,
					finish: challengeDay >= store.challenge.length
				};
				const unlock = requirements[badge.id] ?? badge.unlocked;
				return unlock && !badge.unlocked ? {
					...badge,
					unlocked: true,
					date: dateKey(new Date())
				} : badge;
			});
			update({
				...store,
				sessions,
				badges
			});
		}
		toast(partial ? "Partial session saved." : "Workout saved. Your progress is updated.");
		navigate(destination);
	};
	useEffect(() => {
		if (screen !== "countdown") return;
		if (countdown <= 0) {
			signalChange(isRunning ? "Start walking" : "Begin");
			setScreen("active");
			setRemaining(isRunning ? runningSegments[0].duration : 40);
			return;
		}
		beep();
		const timer = window.setTimeout(() => setCountdown((value) => value - 1), demoSpeed ? 100 : 1e3);
		return () => window.clearTimeout(timer);
	}, [
		screen,
		countdown,
		demoSpeed
	]);
	useEffect(() => {
		if (screen !== "active" || paused) return;
		const timer = window.setInterval(() => {
			setElapsed((value) => value + 1);
			if (isRunning || phase === "rest" || isTimed) setRemaining((value) => Math.max(0, value - 1));
		}, demoSpeed ? 100 : 1e3);
		return () => window.clearInterval(timer);
	}, [
		screen,
		paused,
		demoSpeed,
		isRunning,
		isTimed,
		phase
	]);
	useEffect(() => {
		if (screen !== "active" || paused) return;
		if (remaining > 0 && remaining <= 3) beep();
		if (remaining !== 0) return;
		if (isRunning) finishRunSegment();
		else if (phase === "rest") finishRest();
		else if (isTimed) finishWork();
	}, [
		remaining,
		screen,
		paused
	]);
	useEffect(() => {
		if (screen !== "active") return;
		const timer = window.setInterval(() => setCueIndex((value) => value + 1), demoSpeed ? 1500 : 15e3);
		return () => window.clearInterval(timer);
	}, [
		screen,
		demoSpeed,
		exerciseIndex
	]);
	useEffect(() => {
		const onKeyDown = (event) => {
			if (showSettings) return;
			if (event.key === "Escape") setShowEnd(true);
			if (screen !== "active") return;
			if (event.code === "Space") {
				event.preventDefault();
				setPaused((value) => !value);
			}
			if (event.key === "ArrowRight") isRunning ? finishRunSegment() : advanceExercise();
			if (event.key === "ArrowLeft" && !isRunning) advanceExercise(-1);
		};
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, [
		screen,
		showSettings,
		isRunning,
		exerciseIndex,
		runIndex
	]);
	useEffect(() => {
		const manageWakeLock = async () => {
			const wakeNavigator = navigator;
			if (wakeScreen && screen === "active" && wakeNavigator.wakeLock) {
				try {
					wakeLock.current = await wakeNavigator.wakeLock.request("screen");
				} catch {
					wakeLock.current = null;
				}
			} else if (wakeLock.current) {
				await wakeLock.current.release();
				wakeLock.current = null;
			}
		};
		void manageWakeLock();
		return () => {
			if (wakeLock.current) void wakeLock.current.release();
		};
	}, [wakeScreen, screen]);
	const settingsButton = /* @__PURE__ */ _jsxDEV("button", {
		className: "player-icon-button",
		onClick: () => setShowSettings(true),
		"aria-label": "Session settings",
		children: /* @__PURE__ */ _jsxDEV(Icon, { name: "gear" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 255,
			columnNumber: 133
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 255,
		columnNumber: 26
	}, this);
	const settingsSheet = showSettings && /* @__PURE__ */ _jsxDEV("div", {
		className: "player-modal-backdrop",
		onMouseDown: () => setShowSettings(false),
		children: /* @__PURE__ */ _jsxDEV("aside", {
			className: "settings-sheet",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Session settings",
			onMouseDown: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "SESSION PREFERENCES" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 281
			}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Settings" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 315
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 276
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "player-icon-button",
				onClick: () => setShowSettings(false),
				"aria-label": "Close settings",
				children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 444
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 338
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 268
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "setting-list",
				children: [
					[
						"Sound beeps",
						sound,
						setSound
					],
					[
						"Voice cues",
						voice,
						setVoice
					],
					[
						"Vibration on mobile",
						vibration,
						setVibration
					],
					[
						"Keep screen awake",
						wakeScreen,
						setWakeScreen
					],
					[
						"Demo speed 10×",
						demoSpeed,
						setDemoSpeed
					]
				].map(([label, checked, setter]) => /* @__PURE__ */ _jsxDEV("label", { children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: String(label) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 286
				}, this), label === "Demo speed 10×" && /* @__PURE__ */ _jsxDEV("small", { children: "For presentations" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 349
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 280
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					type: "checkbox",
					checked: Boolean(checked),
					onChange: (event) => setter(event.target.checked)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 389
				}, this)] }, String(label), true, {
					fileName: _jsxFileName,
					lineNumber: 257,
					columnNumber: 253
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 256,
				columnNumber: 483
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 256,
			columnNumber: 123
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 256,
		columnNumber: 41
	}, this);
	if (screen === "ready" || screen === "countdown") return /* @__PURE__ */ _jsxDEV("main", {
		className: "session-player ready-screen",
		children: [
			/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("button", {
				className: "player-icon-button",
				onClick: () => navigate("/workouts"),
				"aria-label": "Close session",
				children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 261,
					columnNumber: 117
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 261,
				columnNumber: 13
			}, this), settingsButton] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 261,
				columnNumber: 5
			}, this),
			screen === "countdown" ? /* @__PURE__ */ _jsxDEV("section", {
				className: "start-countdown",
				"aria-live": "assertive",
				children: [
					/* @__PURE__ */ _jsxDEV("small", { children: "GET READY" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 90
					}, this),
					/* @__PURE__ */ _jsxDEV("strong", { children: countdown || "GO" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 114
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: workout.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 150
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 262,
				columnNumber: 31
			}, this) : /* @__PURE__ */ _jsxDEV("section", {
				className: "ready-content",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "ready-heading",
						children: [
							/* @__PURE__ */ _jsxDEV("small", { children: [
								workout.minutes,
								" MIN · ",
								workout.exercises.length,
								" EXERCISES"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 38
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: workout.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 113
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Check your setup, then begin when you feel ready." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 136
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "ready-grid",
						children: [/* @__PURE__ */ _jsxDEV("ol", { children: workout.exercises.map((exercise, index) => /* @__PURE__ */ _jsxDEV("li", { children: [
							/* @__PURE__ */ _jsxDEV("span", { children: String(index + 1).padStart(2, "0") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 107
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: exercise.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 156
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: exercise.prescription }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 188
							}, this)
						] }, exercise.name, true, {
							fileName: _jsxFileName,
							lineNumber: 264,
							columnNumber: 83
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 264,
							columnNumber: 35
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "equipment-checklist",
							children: [/* @__PURE__ */ _jsxDEV("small", { children: "EQUIPMENT CHECK" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 275
							}, this), equipmentItems.map((item, index) => /* @__PURE__ */ _jsxDEV("button", {
								className: equipmentReady[index] ? "checked" : "",
								onClick: () => setEquipmentReady((current) => current.map((value, itemIndex) => itemIndex === index ? !value : value)),
								children: [/* @__PURE__ */ _jsxDEV("span", { children: equipmentReady[index] && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 564
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 532
								}, this), item]
							}, item, true, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 342
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 264,
							columnNumber: 238
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "safety-line",
						children: "Stop if you feel dizzy, sharp pain, or chest pain. This is general fitness guidance, not medical advice."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => {
							setCountdown(3);
							setScreen("countdown");
						},
						children: ["Begin ", /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 82
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 262,
				columnNumber: 184
			}, this),
			settingsSheet
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 260,
		columnNumber: 60
	}, this);
	if (screen === "complete") {
		const projectedCount = store.sessions.some((session) => session.workoutId === workout.id && session.date === dateKey(new Date())) ? store.sessions.length : store.sessions.length + 1;
		const completionDates = new Set([...store.sessions.map((session) => session.date), dateKey(new Date())]);
		let completionStreak = 0;
		const streakCursor = new Date();
		while (completionDates.has(dateKey(streakCursor))) {
			completionStreak += 1;
			streakCursor.setDate(streakCursor.getDate() - 1);
		}
		const completionRequirements = {
			"streak-3": completionStreak >= 3,
			"streak-7": completionStreak >= 7,
			"streak-14": completionStreak >= 14,
			"streak-30": completionStreak >= 30,
			"workout-1": projectedCount >= 1,
			"workout-10": projectedCount >= 10,
			"workout-25": projectedCount >= 25,
			"workout-50": projectedCount >= 50
		};
		const earnedBadge = store.badges.find((badge) => !badge.unlocked && completionRequirements[badge.id]);
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "session-player complete-screen",
			children: [
				/* @__PURE__ */ _jsxDEV("header", { children: settingsButton }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 291,
					columnNumber: 61
				}, this),
				/* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "completion-mark",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 137
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 103
					}, this),
					/* @__PURE__ */ _jsxDEV("small", { children: ["DAY ", Math.max(1, Math.floor((Date.now() - new Date(`${store.challenge.startDate}T12:00:00`).getTime()) / 864e5) + 1)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 165
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: "Workout complete" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 302
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Great job showing up today." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 327
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "completion-stats",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: formatTime(elapsed) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 46
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Total time" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 84
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 41
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: isRunning ? runIndex + 1 : Math.min(workout.exercises.length, exerciseIndex + 1) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 118
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isRunning ? "Intervals" : "Exercises" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 217
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 113
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: isRunning ? "—" : exerciseIndex * totalSets + setIndex + 1 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 280
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sets" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 357
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 275
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "earned-banner",
						children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "star" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 38
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: earnedBadge ? `${earnedBadge.name} badge unlocked` : "Your streak is growing" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 63
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Streak: ",
							completionStreak,
							" ",
							completionStreak === 1 ? "day" : "days"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 159
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 58
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 293,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "effort-rating",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: "How did that feel?" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 38
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
							["Easy", 2],
							["Just right", 3],
							["Hard", 5]
						].map(([label, value]) => /* @__PURE__ */ _jsxDEV("button", {
							className: effort === value ? "active" : "",
							onClick: () => setEffort(Number(value)),
							children: label
						}, String(label), false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 149
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 73
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 294,
						columnNumber: 7
					}, this),
					isRunning && /* @__PURE__ */ _jsxDEV("label", {
						className: "completion-field",
						children: ["Distance (km) · optional", /* @__PURE__ */ _jsxDEV("input", {
							type: "number",
							min: "0",
							step: ".1",
							value: distance,
							onChange: (event) => setDistance(event.target.value),
							placeholder: "0.0"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 81
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 295,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "completion-field",
						children: ["Add a note · optional", /* @__PURE__ */ _jsxDEV("textarea", {
							value: note,
							onChange: (event) => setNote(event.target.value),
							placeholder: "How did the session feel?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 296,
							columnNumber: 64
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 296,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "completion-actions",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => saveSession(false),
							children: "Save and back to dashboard"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 43
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							onClick: () => saveSession(false, "/progress"),
							children: "Log my weight"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 121
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 297,
						columnNumber: 7
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 291,
					columnNumber: 94
				}, this),
				settingsSheet
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 291,
			columnNumber: 12
		}, this);
	}
	const totalRunDuration = runningSegments.reduce((sum, segment) => sum + segment.duration, 0);
	const runRemaining = runningSegments.slice(runIndex + 1).reduce((sum, segment) => sum + segment.duration, 0) + remaining;
	const progress = isRunning ? (totalRunDuration - runRemaining) / totalRunDuration * 100 : (exerciseIndex + (phase === "rest" ? .8 : .25)) / workout.exercises.length * 100;
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "session-player active-player",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "active-topbar",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: "player-icon-button",
						onClick: () => setShowEnd(true),
						"aria-label": "End workout",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 305,
							columnNumber: 136
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 39
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: workout.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 171
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: isRunning ? `Segment ${runIndex + 1} of ${runningSegments.length}` : `Exercise ${exerciseIndex + 1} of ${workout.exercises.length}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 202
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 166
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "elapsed-time",
						children: formatTime(elapsed)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 354
					}, this),
					settingsButton,
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overall-progress",
						children: /* @__PURE__ */ _jsxDEV("i", { style: { width: `${Math.max(2, progress)}%` } }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 305,
							columnNumber: 463
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 429
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "active-content",
				children: [
					isRunning ? /* @__PURE__ */ _jsxDEV("div", {
						className: "running-phase",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: `phase-label ${phaseLabel.toLowerCase()}`,
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: phaseLabel === "JOG" ? "bolt" : "walk" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 68
								}, this), phaseLabel]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: `timer-ring ${phaseLabel.toLowerCase()}`,
								children: [/* @__PURE__ */ _jsxDEV("strong", { children: formatTime(remaining) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 67
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: runningSegments[runIndex].name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 107
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 309,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", { children: runIndex === 0 ? "Warm-up" : runIndex === runningSegments.length - 1 ? "Cool-down" : `Interval ${Math.ceil(runIndex / 2)} of 8` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: phaseLabel === "JOG" ? "Easy pace. You should be able to hold a conversation." : "Brisk walk, let your breathing settle." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 147
							}, this),
							remaining <= 3 && runIndex < runningSegments.length - 1 && /* @__PURE__ */ _jsxDEV("div", {
								className: "transition-callout",
								children: [
									runningSegments[runIndex + 1].label === "JOG" ? "Jog" : "Walk",
									" in ",
									remaining
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 69
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: `indoor-toggle ${indoor ? "active" : ""}`,
								onClick: () => setIndoor((value) => !value),
								children: [/* @__PURE__ */ _jsxDEV("span", { children: indoor && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 133
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 116
								}, this), "No space or hot weather? March or jog in place."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("small", {
								className: "outdoor-tip",
								children: "In warm weather, go early morning or evening and bring water."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 313,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "run-times",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Total elapsed ", /* @__PURE__ */ _jsxDEV("strong", { children: formatTime(elapsed) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 56
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 36
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Remaining ", /* @__PURE__ */ _jsxDEV("strong", { children: formatTime(runRemaining) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 117
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 101
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "segment-timeline",
								children: runningSegments.map((segment, index) => /* @__PURE__ */ _jsxDEV("i", {
									className: index === runIndex ? "current" : index < runIndex ? "done" : "",
									title: segment.name
								}, index, false, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 84
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 9
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 307,
						columnNumber: 20
					}, this) : phase === "rest" ? /* @__PURE__ */ _jsxDEV("div", {
						className: "rest-phase",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "timer-ring rest",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "phase-label rest",
										children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "timer" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 317,
											columnNumber: 76
										}, this), "REST"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 42
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: remaining }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 107
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "seconds" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 135
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "breathing-copy",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: "Breathe in... breathe out..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 49
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "Sip some water" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 94
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 318,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rest-actions",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setRemaining((value) => value + 15),
									children: "+15s"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 319,
									columnNumber: 39
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: finishRest,
									children: "Skip rest"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 319,
									columnNumber: 112
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "next-up-card",
								children: [
									/* @__PURE__ */ _jsxDEV("small", { children: "NEXT UP" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 320,
										columnNumber: 39
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: setIndex + 1 < totalSets ? displayName : workout.exercises[exerciseIndex + 1]?.name || "Finish strong" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 320,
										columnNumber: 61
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: setIndex + 1 < totalSets ? `Set ${setIndex + 2} of ${totalSets}` : workout.exercises[exerciseIndex + 1]?.prescription }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 320,
										columnNumber: 182
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 9
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 35
					}, this) : isTimed ? /* @__PURE__ */ _jsxDEV("div", {
						className: "timed-phase",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "timer-ring work",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "phase-label work",
										children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 76
										}, this), "WORK"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 42
									}, this),
									/* @__PURE__ */ _jsxDEV("strong", { children: remaining }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 106
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "seconds" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 134
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: displayName }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								"Round ",
								setIndex + 1,
								" of ",
								totalSets
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 31
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 26
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "reps-phase",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "exercise-illustration",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "dumbbell" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 48
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "phase-label work",
								children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 112
								}, this), "WORK"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 78
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", { children: displayName }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 142
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								"Set ",
								setIndex + 1,
								" of ",
								totalSets,
								" · ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "12 reps" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 203
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 164
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rep-counter",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: reps }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 38
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setReps((value) => value + 1),
									"aria-label": "Add repetition",
									children: "+"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 57
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: finishWork,
								children: "Done set"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 155
							}, this),
							/* @__PURE__ */ _jsxDEV("ul", { children: [
								/* @__PURE__ */ _jsxDEV("li", { children: "Brace your core before each rep" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Move through a comfortable range" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 53
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Exhale through the effort" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 94
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "next-up-chip",
								children: ["Next up: ", setIndex + 1 < totalSets ? `Rest, then set ${setIndex + 2}` : workout.exercises[exerciseIndex + 1]?.name || "Cool down"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 9
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 324,
						columnNumber: 16
					}, this),
					!isRunning && phase === "work" && /* @__PURE__ */ _jsxDEV("div", {
						className: "session-options",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSessionSwaps({
								...sessionSwaps,
								[exerciseIndex]: `Easier ${currentExercise.name.toLowerCase()}`
							}),
							children: "Easier option"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 75
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSessionSwaps({
								...sessionSwaps,
								[exerciseIndex]: `Low-impact ${currentExercise.name.toLowerCase()}`
							}),
							children: "Low-impact option"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 223
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 330,
						columnNumber: 42
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cue-banner",
						children: [/* @__PURE__ */ _jsxDEV("small", { children: "CUE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 331,
							columnNumber: 72
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: isRunning ? phaseLabel === "JOG" ? "Relax your shoulders and find your rhythm" : "Let your breathing settle" : cues[cueIndex % cues.length] }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 331,
							columnNumber: 90
						}, this)]
					}, `${exerciseIndex}-${cueIndex}`, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 306,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "player-controls",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => isRunning ? moveRunSegment(-1) : advanceExercise(-1),
						children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "back" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 118
						}, this), "Previous"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 41
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "pause-button",
						onClick: () => setPaused((value) => !value),
						children: [paused ? /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 243
						}, this) : /* @__PURE__ */ _jsxDEV(Icon, { name: "pause" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 266
						}, this), paused ? "Resume" : "Pause"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 155
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => isRunning ? finishRunSegment() : advanceExercise(),
						children: ["Skip", /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 405
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 326
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: muted ? "muted" : "",
						onClick: () => setMuted((value) => !value),
						"aria-label": muted ? "Unmute session" : "Mute session",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "volume" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 575
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 435
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 333,
				columnNumber: 5
			}, this),
			showEnd && /* @__PURE__ */ _jsxDEV("div", {
				className: "player-modal-backdrop",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "end-dialog",
					role: "dialog",
					"aria-modal": "true",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "dash-stat-icon",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "timer" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 149
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 116
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "End workout?" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 177
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "You can keep going, save what you completed, or discard this session." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 198
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => setShowEnd(false),
							children: "Keep going"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 274
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							onClick: () => saveSession(true),
							children: "Save partial session"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 335
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "discard-action",
							onClick: () => navigate("/workouts"),
							children: "Discard"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 422
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 334,
					columnNumber: 56
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 334,
				columnNumber: 17
			}, this),
			settingsSheet
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 304,
		columnNumber: 10
	}, this);
}
_s(SessionPlayer, "HcVqXG6NFCMZc+wIwsgQZqseFm4=");
_c = SessionPlayer;
var _c;
$RefreshReg$(_c, "SessionPlayer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/session/SessionPlayer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/session/SessionPlayer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/session/SessionPlayer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/session/SessionPlayer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsUUFBUSxnQkFBZ0I7QUFDckQsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWTtBQUVyQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxXQUFXOzs7O0FBRXBCLE9BQU8sU0FBUyxjQUFjLEVBQUUsU0FBUyxPQUFPLFFBQVEsVUFBVSxTQUFxSzs7Q0FHck8sTUFBTSxZQUFZLFFBQVEsS0FBSyxTQUFTLFVBQVUsS0FBSyxRQUFRLFdBQVcsU0FBUyxLQUFLO0NBQ3hGLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBdUIsT0FBTztDQUMxRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDO0NBQzVDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUM7Q0FDcEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FDMUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFnQixNQUFNO0NBQ2hELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLENBQUM7Q0FDeEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUM7Q0FDbEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FDMUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEtBQUs7Q0FDeEMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsQ0FBQztDQUN0QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTtDQUN2QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsS0FBSztDQUN4QyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FDakQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUMsQ0FBQyxDQUFDO0NBQzNFLE1BQU0saUJBQWlCLFlBQVk7RUFBQztFQUFxQjtFQUFnQjtDQUFrQyxJQUFJO0VBQUMsUUFBUTtFQUFXO0VBQXFCO0NBQWM7Q0FDdEssTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsZUFBZSxlQUFlLFVBQVUsS0FBSyxDQUFDO0NBQzFGLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDO0NBQzFDLE1BQU0sV0FBVyxPQUFnRCxJQUFJO0NBQ3JFLE1BQU0sa0JBQWtCLGNBQWM7RUFDcEM7R0FBRSxPQUFPO0dBQVEsTUFBTTtHQUFnQixVQUFVO0VBQUk7RUFDckQsR0FBRyxNQUFNLEtBQUssRUFBRSxRQUFRLEdBQUcsSUFBSSxHQUFHLFdBQVc7R0FBRSxPQUFPLFFBQVEsTUFBTSxJQUFJLFFBQVE7R0FBUSxNQUFNLFFBQVEsTUFBTSxJQUFJLGFBQWE7R0FBaUIsVUFBVSxRQUFRLE1BQU0sSUFBSSxLQUFLO0VBQUksRUFBRTtFQUNyTDtHQUFFLE9BQU87R0FBUSxNQUFNO0dBQWtCLFVBQVU7RUFBSTtDQUN6RCxHQUFHLENBQUMsQ0FBQztDQUNMLE1BQU0sa0JBQWtCLFFBQVEsVUFBVTtDQUMxQyxNQUFNLGNBQWMsYUFBYSxrQkFBa0IsaUJBQWlCLFFBQVEsUUFBUTtDQUNwRixNQUFNLFVBQVUsUUFBUSxLQUFLLFNBQVMsTUFBTSxLQUFLLHNDQUFzQyxLQUFLLFdBQVc7Q0FDdkcsTUFBTSxZQUFZLFFBQVEsU0FBUyxVQUFVLElBQUk7Q0FDakQsTUFBTSxhQUFhLFlBQVksZ0JBQWdCLFNBQVMsQ0FBQyxRQUFRLFVBQVUsU0FBUyxTQUFTO0NBQzdGLE1BQU0sY0FBYyxZQUFvQixHQUFHLEtBQUssTUFBTSxVQUFVLEVBQUUsRUFBRSxHQUFHLE9BQU8sVUFBVSxFQUFFLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUMzRyxNQUFNLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFDakM7RUFBQztFQUF3QjtFQUEyQjtDQUFvQyxJQUN4RixlQUFlLEtBQUssV0FBVyxJQUM3QjtFQUFDO0VBQXlCO0VBQXdCO0NBQW9DLElBQ3RGO0VBQUM7RUFBcUI7RUFBMkI7Q0FBK0I7Q0FFdEYsTUFBTSxRQUFRLFNBQVMsVUFBVTtFQUMvQixJQUFJLENBQUMsU0FBUyxPQUFPO0VBQ3JCLElBQUk7R0FDRixNQUFNLG9CQUFvQixPQUFPLGdCQUFpQixPQUF3RTtHQUMxSCxJQUFJLENBQUMsbUJBQW1CO0dBQ3hCLE1BQU0sVUFBVSxJQUFJLGtCQUFrQjtHQUN0QyxDQUFDLEdBQUcsR0FBSSxTQUFTLENBQUMsR0FBSSxJQUFJLENBQUMsQ0FBRSxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hELE1BQU0sYUFBYSxRQUFRLGlCQUFpQjtJQUM1QyxNQUFNLE9BQU8sUUFBUSxXQUFXO0lBQ2hDLFdBQVcsVUFBVSxRQUFRLFNBQVMsTUFBTTtJQUM1QyxLQUFLLEtBQUssZUFBZSxLQUFLLFFBQVEsY0FBYyxLQUFLO0lBQ3pELEtBQUssS0FBSyw2QkFBNkIsTUFBTSxRQUFRLGNBQWMsUUFBUSxHQUFHO0lBQzlFLFdBQVcsUUFBUSxJQUFJLENBQUMsQ0FBQyxRQUFRLFFBQVEsV0FBVztJQUNwRCxXQUFXLE1BQU0sUUFBUSxjQUFjLEtBQUs7SUFDNUMsV0FBVyxLQUFLLFFBQVEsY0FBYyxRQUFRLEVBQUU7R0FDbEQsQ0FBQztFQUNILFFBQVEsQ0FFUjtDQUNGO0NBQ0EsTUFBTSxZQUFZLFlBQW9CO0VBQ3BDLElBQUksQ0FBQyxTQUFTLFNBQVMsRUFBRSxxQkFBcUIsU0FBUztFQUN2RCxPQUFPLGdCQUFnQixPQUFPO0VBQzlCLE9BQU8sZ0JBQWdCLE1BQU0sSUFBSSx5QkFBeUIsT0FBTyxDQUFDO0NBQ3BFO0NBQ0EsTUFBTSxnQkFBZ0IsWUFBb0I7RUFDeEMsS0FBSyxJQUFJO0VBQ1QsU0FBUyxPQUFPO0VBQ2hCLElBQUksYUFBYSxhQUFhLFdBQVcsVUFBVSxRQUFRO0dBQUM7R0FBSTtHQUFJO0VBQUUsQ0FBQztDQUN6RTtDQUNBLE1BQU0sc0JBQXNCO0VBQzFCLFVBQVUsSUFBSTtFQUNkLFVBQVUsVUFBVTtDQUN0QjtDQUNBLE1BQU0sbUJBQW1CLFlBQVksTUFBTTtFQUN6QyxNQUFNLE9BQU8sZ0JBQWdCO0VBQzdCLElBQUksT0FBTyxHQUFHO0VBQ2QsSUFBSSxRQUFRLFFBQVEsVUFBVSxRQUFRLE9BQU8sY0FBYztFQUMzRCxpQkFBaUIsSUFBSTtFQUNyQixZQUFZLENBQUM7RUFDYixTQUFTLE1BQU07RUFDZixhQUFhLEVBQUU7RUFDZixRQUFRLENBQUM7RUFDVCxhQUFhLGtCQUFrQixhQUFhLFNBQVMsUUFBUSxVQUFVLEtBQUssQ0FBQyxNQUFNO0NBQ3JGO0NBQ0EsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxXQUFXLElBQUksV0FBVztHQUM1QixhQUFhLFVBQVUsUUFBUSxDQUFDO0dBQ2hDLFNBQVMsTUFBTTtHQUNmLGFBQWEsRUFBRTtHQUNmLFFBQVEsQ0FBQztHQUNULGFBQWEsTUFBTTtFQUNyQixPQUFPO0dBQ0wsZ0JBQWdCO0VBQ2xCO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQjtFQUN2QixTQUFTLE1BQU07RUFDZixhQUFhLEVBQUU7RUFDZixhQUFhLE1BQU07Q0FDckI7Q0FDQSxNQUFNLHlCQUF5QjtFQUM3QixJQUFJLFdBQVcsS0FBSyxnQkFBZ0IsUUFBUSxPQUFPLGNBQWM7RUFDakUsTUFBTSxPQUFPLFdBQVc7RUFDeEIsWUFBWSxJQUFJO0VBQ2hCLGFBQWEsZ0JBQWdCLEtBQUssQ0FBQyxRQUFRO0VBQzNDLGFBQWEsR0FBRyxnQkFBZ0IsS0FBSyxDQUFDLFVBQVUsUUFBUSxRQUFRLE9BQU8sS0FBSztDQUM5RTtDQUNBLE1BQU0sa0JBQWtCLGNBQXNCO0VBQzVDLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksZ0JBQWdCLFNBQVMsR0FBRyxXQUFXLFNBQVMsQ0FBQztFQUNuRixZQUFZLElBQUk7RUFDaEIsYUFBYSxnQkFBZ0IsS0FBSyxDQUFDLFFBQVE7Q0FDN0M7Q0FFQSxNQUFNLGNBQWMsT0FBTyxVQUFVLE9BQU8sY0FBYyxpQkFBaUI7RUFDekUsTUFBTSxxQkFBcUIsUUFBUSxVQUFVLE1BQU0sR0FBRyxLQUFLLElBQUksUUFBUSxVQUFVLFFBQVEsaUJBQWlCLFVBQVUsSUFBSSxRQUFRLFVBQVUsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsVUFBVSxhQUFhLFVBQVUsU0FBUyxJQUFJO0VBQ2pOLE1BQU0sV0FBVyxNQUFNLFNBQVMsTUFBTSxZQUFZLFFBQVEsY0FBYyxRQUFRLE1BQU0sUUFBUSxTQUFTLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQztFQUUxSCxNQUFNLGlCQUFpQjtHQUNyQixXQUFXLFFBQVE7R0FDbkIsTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDO0dBQ3hCLFVBQVUsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLFVBQVUsRUFBRSxDQUFDO0dBQzlDLGVBQWU7R0FDZjtHQUNBO0dBQ0EsVUFBVSxXQUFXLE9BQU8sUUFBUSxJQUFJO0dBQ3hDLGFBQWEsQ0FBQztFQUNoQjs7RUFHQSxJQUFJO0dBQ0YsSUFBSSxJQUFJLGFBQWE7SUFDbkIsTUFBTSxJQUFJLFlBQVksY0FBYztHQUN0QztFQUNGLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSwyQ0FBMkMsS0FBSztFQUNoRTs7RUFHQSxJQUFJLENBQUMsVUFBVTtHQUNiLE1BQU0sV0FBVyxDQUFDLEdBQUcsTUFBTSxVQUFVLGNBQWM7R0FDbkQsTUFBTSxrQkFBa0IsSUFBSSxJQUFJLFNBQVMsS0FBSyxZQUFZLFFBQVEsSUFBSSxDQUFDO0dBQ3ZFLElBQUksZ0JBQWdCO0dBQ3BCLE1BQU0sU0FBUyxJQUFJLEtBQUs7R0FDeEIsT0FBTyxnQkFBZ0IsSUFBSSxRQUFRLE1BQU0sQ0FBQyxHQUFHO0lBQzNDLGlCQUFpQjtJQUNqQixPQUFPLFFBQVEsT0FBTyxRQUFRLElBQUksQ0FBQztHQUNyQztHQUNBLE1BQU0sZUFBZSxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEdBQUcsTUFBTSxVQUFVLFVBQVUsVUFBVSxDQUFDLENBQUMsUUFBUSxLQUFLLEtBQVUsSUFBSSxDQUFDO0dBQ3hJLE1BQU0sU0FBUyxNQUFNLE9BQU8sS0FBSyxVQUFVO0lBQ3pDLE1BQU0sZUFBd0M7S0FDNUMsWUFBWSxpQkFBaUI7S0FDN0IsWUFBWSxpQkFBaUI7S0FDN0IsYUFBYSxpQkFBaUI7S0FDOUIsYUFBYSxpQkFBaUI7S0FDOUIsYUFBYSxTQUFTLFVBQVU7S0FDaEMsY0FBYyxTQUFTLFVBQVU7S0FDakMsY0FBYyxTQUFTLFVBQVU7S0FDakMsY0FBYyxTQUFTLFVBQVU7S0FDakMsVUFBVSxTQUFTLFVBQVUsTUFBTSxVQUFVO0tBQzdDLFNBQVMsZ0JBQWdCLE1BQU0sVUFBVSxTQUFTO0tBQ2xELFFBQVEsZ0JBQWdCLE1BQU0sVUFBVTtJQUMxQztJQUNBLE1BQU0sU0FBUyxhQUFhLE1BQU0sT0FBTyxNQUFNO0lBQy9DLE9BQU8sVUFBVSxDQUFDLE1BQU0sV0FBVztLQUFFLEdBQUc7S0FBTyxVQUFVO0tBQU0sTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDO0lBQUUsSUFBSTtHQUMvRixDQUFDO0dBQ0QsT0FBTztJQUFFLEdBQUc7SUFBTztJQUFVO0dBQU8sQ0FBQztFQUN2QztFQUNBLE1BQU0sVUFBVSwyQkFBMkIsMENBQTBDO0VBQ3JGLFNBQVMsV0FBVztDQUN0QjtDQUVBLGdCQUFnQjtFQUNkLElBQUksV0FBVyxhQUFhO0VBQzVCLElBQUksYUFBYSxHQUFHO0dBQ2xCLGFBQWEsWUFBWSxrQkFBa0IsT0FBTztHQUNsRCxVQUFVLFFBQVE7R0FDbEIsYUFBYSxZQUFZLGdCQUFnQixFQUFFLENBQUMsV0FBVyxFQUFFO0dBQ3pEO0VBQ0Y7RUFDQSxLQUFLO0VBQ0wsTUFBTSxRQUFRLE9BQU8saUJBQWlCLGNBQWMsVUFBVSxRQUFRLENBQUMsR0FBRyxZQUFZLE1BQU0sR0FBSTtFQUNoRyxhQUFhLE9BQU8sYUFBYSxLQUFLO0NBQ3hDLEdBQUc7RUFBQztFQUFRO0VBQVc7Q0FBUyxDQUFDO0NBRWpDLGdCQUFnQjtFQUNkLElBQUksV0FBVyxZQUFZLFFBQVE7RUFDbkMsTUFBTSxRQUFRLE9BQU8sa0JBQWtCO0dBQ3JDLFlBQVksVUFBVSxRQUFRLENBQUM7R0FDL0IsSUFBSSxhQUFhLFVBQVUsVUFBVSxTQUFTLGNBQWMsVUFBVSxLQUFLLElBQUksR0FBRyxRQUFRLENBQUMsQ0FBQztFQUM5RixHQUFHLFlBQVksTUFBTSxHQUFJO0VBQ3pCLGFBQWEsT0FBTyxjQUFjLEtBQUs7Q0FDekMsR0FBRztFQUFDO0VBQVE7RUFBUTtFQUFXO0VBQVc7RUFBUztDQUFLLENBQUM7Q0FFekQsZ0JBQWdCO0VBQ2QsSUFBSSxXQUFXLFlBQVksUUFBUTtFQUNuQyxJQUFJLFlBQVksS0FBSyxhQUFhLEdBQUcsS0FBSztFQUMxQyxJQUFJLGNBQWMsR0FBRztFQUNyQixJQUFJLFdBQVcsaUJBQWlCO09BQzNCLElBQUksVUFBVSxRQUFRLFdBQVc7T0FDakMsSUFBSSxTQUFTLFdBQVc7Q0FDL0IsR0FBRztFQUFDO0VBQVc7RUFBUTtDQUFNLENBQUM7Q0FFOUIsZ0JBQWdCO0VBQ2QsSUFBSSxXQUFXLFVBQVU7RUFDekIsTUFBTSxRQUFRLE9BQU8sa0JBQWtCLGFBQWEsVUFBVSxRQUFRLENBQUMsR0FBRyxZQUFZLE9BQU8sSUFBSztFQUNsRyxhQUFhLE9BQU8sY0FBYyxLQUFLO0NBQ3pDLEdBQUc7RUFBQztFQUFRO0VBQVc7Q0FBYSxDQUFDO0NBRXJDLGdCQUFnQjtFQUNkLE1BQU0sYUFBYSxVQUF5QjtHQUMxQyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxNQUFNLFFBQVEsVUFBVSxXQUFXLElBQUk7R0FDM0MsSUFBSSxXQUFXLFVBQVU7R0FDekIsSUFBSSxNQUFNLFNBQVMsU0FBUztJQUMxQixNQUFNLGVBQWU7SUFDckIsV0FBVyxVQUFVLENBQUMsS0FBSztHQUM3QjtHQUNBLElBQUksTUFBTSxRQUFRLGNBQWMsWUFBWSxpQkFBaUIsSUFBSSxnQkFBZ0I7R0FDakYsSUFBSSxNQUFNLFFBQVEsZUFBZSxDQUFDLFdBQVcsZ0JBQWdCLENBQUMsQ0FBQztFQUNqRTtFQUNBLE9BQU8saUJBQWlCLFdBQVcsU0FBUztFQUM1QyxhQUFhLE9BQU8sb0JBQW9CLFdBQVcsU0FBUztDQUM5RCxHQUFHO0VBQUM7RUFBUTtFQUFjO0VBQVc7RUFBZTtDQUFRLENBQUM7Q0FFN0QsZ0JBQWdCO0VBQ2QsTUFBTSxpQkFBaUIsWUFBWTtHQUNqQyxNQUFNLGdCQUFnQjtHQUN0QixJQUFJLGNBQWMsV0FBVyxZQUFZLGNBQWMsVUFBVTtJQUMvRCxJQUFJO0tBQUUsU0FBUyxVQUFVLE1BQU0sY0FBYyxTQUFTLFFBQVEsUUFBUTtJQUFHLFFBQVE7S0FBRSxTQUFTLFVBQVU7SUFBTTtHQUM5RyxPQUFPLElBQUksU0FBUyxTQUFTO0lBQzNCLE1BQU0sU0FBUyxRQUFRLFFBQVE7SUFDL0IsU0FBUyxVQUFVO0dBQ3JCO0VBQ0Y7RUFDQSxLQUFLLGVBQWU7RUFDcEIsYUFBYTtHQUFFLElBQUksU0FBUyxTQUFTLEtBQUssU0FBUyxRQUFRLFFBQVE7RUFBRztDQUN4RSxHQUFHLENBQUMsWUFBWSxNQUFNLENBQUM7Q0FFdkIsTUFBTSxpQkFBaUIsd0JBQUMsVUFBRDtFQUFRLFdBQVU7RUFBcUIsZUFBZSxnQkFBZ0IsSUFBSTtFQUFHLGNBQVc7WUFBbUIsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7Q0FBUzs7Ozs7Q0FDOUosTUFBTSxnQkFBZ0IsZ0JBQWdCLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQXdCLG1CQUFtQixnQkFBZ0IsS0FBSztZQUFHLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO0dBQWlCLE1BQUs7R0FBUyxjQUFXO0dBQU8sY0FBVztHQUFtQixjQUFjLFVBQVUsTUFBTSxnQkFBZ0I7YUFBOUksQ0FBaUosd0JBQUMsVUFBRCxhQUFRLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sc0JBQTBCOzs7O2FBQUMsd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7V0FBTTs7OzthQUFDLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQXFCLGVBQWUsZ0JBQWdCLEtBQUs7SUFBRyxjQUFXO2NBQWlCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O0dBQVM7Ozs7V0FBUzs7OzthQUFDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQzVlO0tBQUM7TUFBQztNQUFlO01BQU87S0FBUTtLQUFHO01BQUM7TUFBYztNQUFPO0tBQVE7S0FBRztNQUFDO01BQXVCO01BQVc7S0FBWTtLQUFHO01BQUM7TUFBcUI7TUFBWTtLQUFhO0tBQUc7TUFBQztNQUFrQjtNQUFXO0tBQVk7SUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sU0FBUyxZQUFZLHdCQUFDLFNBQUQsYUFBMkIsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUyxPQUFPLEtBQUssRUFBVTs7OztjQUFFLFVBQVUsb0JBQW9CLHdCQUFDLFNBQUQsWUFBTyxvQkFBd0I7Ozs7WUFBUTs7OztjQUFDLHdCQUFDLFNBQUQ7S0FBTyxNQUFLO0tBQVcsU0FBUyxRQUFRLE9BQU87S0FBRyxXQUFXLFVBQVcsT0FBeUQsTUFBTSxPQUFPLE9BQU87SUFBSTs7OztZQUFRLEtBQTdSLE9BQU8sS0FBSzs7OztXQUFpUixDQUFDO0dBQy9oQjs7OztXQUFROzs7Ozs7Q0FBTTs7Ozs7Q0FFbkIsSUFBSSxXQUFXLFdBQVcsV0FBVyxhQUFhLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDdkQsd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQXFCLGVBQWUsU0FBUyxXQUFXO0lBQUcsY0FBVztjQUFnQix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztHQUFTOzs7O2FBQUUsY0FBdUI7Ozs7O0dBQ3JLLFdBQVcsY0FBYyx3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUFrQixhQUFVO2NBQS9DO0tBQTJELHdCQUFDLFNBQUQsWUFBTyxZQUFnQjs7Ozs7S0FBQyx3QkFBQyxVQUFELFlBQVMsYUFBYSxLQUFhOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBSSxRQUFRLEtBQVE7Ozs7O0lBQVU7Ozs7O2NBQUksd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FDakwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBK0Isd0JBQUMsU0FBRDtRQUFRLFFBQVE7UUFBUTtRQUFRLFFBQVEsVUFBVTtRQUFPO09BQWlCOzs7OztPQUFDLHdCQUFDLE1BQUQsWUFBSyxRQUFRLEtBQVM7Ozs7O09BQUMsd0JBQUMsS0FBRCxZQUFHLG9EQUFvRDs7Ozs7TUFBTTs7Ozs7O0tBQzlMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTRCLHdCQUFDLE1BQUQsWUFBSyxRQUFRLFVBQVUsS0FBSyxVQUFVLFVBQVUsd0JBQUMsTUFBRDtPQUF3Qix3QkFBQyxRQUFELFlBQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQVE7Ozs7O09BQUMsd0JBQUMsVUFBRCxZQUFTLFNBQVMsS0FBYTs7Ozs7T0FBQyx3QkFBQyxTQUFELFlBQVEsU0FBUyxhQUFvQjs7Ozs7TUFBSyxLQUExSSxTQUFTOzs7O2FBQWlJLENBQUMsRUFBTTs7OztnQkFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFxQyx3QkFBQyxTQUFELFlBQU8sa0JBQXNCOzs7O2lCQUFFLGVBQWUsS0FBSyxNQUFNLFVBQVUsd0JBQUMsVUFBRDtRQUFRLFdBQVcsZUFBZSxTQUFTLFlBQVk7UUFBZSxlQUFlLG1CQUFtQixZQUFZLFFBQVEsS0FBSyxPQUFPLGNBQWMsY0FBYyxRQUFRLENBQUMsUUFBUSxLQUFLLENBQUM7a0JBQTNMLENBQThMLHdCQUFDLFFBQUQsWUFBTyxlQUFlLFVBQVUsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztpQkFBUTs7OztrQkFBRSxJQUFhO1VBQXpNOzs7O2NBQXlNLENBQUMsQ0FBTzs7Ozs7Y0FBTTs7Ozs7O0tBQ3RtQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYztLQUEyRzs7Ozs7S0FDdEksd0JBQUMsUUFBRDtNQUFRLGVBQWU7T0FBRSxhQUFhLENBQUM7T0FBRyxVQUFVLFdBQVc7TUFBRztnQkFBbEUsQ0FBcUUsVUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O2NBQVM7Ozs7OztJQUNoRzs7Ozs7O0dBQ1I7RUFDRzs7Ozs7O0NBRU4sSUFBSSxXQUFXLFlBQVk7RUFDekIsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLE1BQU0sWUFBWSxRQUFRLGNBQWMsUUFBUSxNQUFNLFFBQVEsU0FBUyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsSUFBSSxNQUFNLFNBQVMsU0FBUyxNQUFNLFNBQVMsU0FBUztFQUNwTCxNQUFNLGtCQUFrQixJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sU0FBUyxLQUFLLFlBQVksUUFBUSxJQUFJLEdBQUcsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7RUFDdkcsSUFBSSxtQkFBbUI7RUFDdkIsTUFBTSxlQUFlLElBQUksS0FBSztFQUM5QixPQUFPLGdCQUFnQixJQUFJLFFBQVEsWUFBWSxDQUFDLEdBQUc7R0FDakQsb0JBQW9CO0dBQ3BCLGFBQWEsUUFBUSxhQUFhLFFBQVEsSUFBSSxDQUFDO0VBQ2pEO0VBQ0EsTUFBTSx5QkFBa0Q7R0FDdEQsWUFBWSxvQkFBb0I7R0FDaEMsWUFBWSxvQkFBb0I7R0FDaEMsYUFBYSxvQkFBb0I7R0FDakMsYUFBYSxvQkFBb0I7R0FDakMsYUFBYSxrQkFBa0I7R0FDL0IsY0FBYyxrQkFBa0I7R0FDaEMsY0FBYyxrQkFBa0I7R0FDaEMsY0FBYyxrQkFBa0I7RUFDbEM7RUFDQSxNQUFNLGNBQWMsTUFBTSxPQUFPLE1BQU0sVUFBVSxDQUFDLE1BQU0sWUFBWSx1QkFBdUIsTUFBTSxHQUFHO0VBQ3BHLE9BQU8sd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEI7SUFBaUQsd0JBQUMsVUFBRCxZQUFTLGVBQXVCOzs7OztJQUFDLHdCQUFDLFdBQUQ7S0FBUyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBa0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7S0FBTzs7Ozs7S0FBQyx3QkFBQyxTQUFELGFBQU8sUUFBSyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEdBQUcsTUFBTSxVQUFVLFVBQVUsVUFBVSxDQUFDLENBQUMsUUFBUSxLQUFLLEtBQVUsSUFBSSxDQUFDLENBQVM7Ozs7O0tBQUMsd0JBQUMsTUFBRCxZQUFJLG1CQUFvQjs7Ozs7S0FBQyx3QkFBQyxLQUFELFlBQUcsOEJBQThCOzs7OztLQUNqVyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUFrQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFTLFdBQVcsT0FBTyxFQUFVOzs7O2lCQUFDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztlQUFNOzs7OztPQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsWUFBWSxXQUFXLElBQUksS0FBSyxJQUFJLFFBQVEsVUFBVSxRQUFRLGdCQUFnQixDQUFDLEVBQVU7Ozs7aUJBQUMsd0JBQUMsUUFBRCxZQUFPLFlBQVksY0FBYyxZQUFrQjs7OztlQUFNOzs7OztPQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsWUFBWSxNQUFNLGdCQUFnQixZQUFZLFdBQVcsRUFBVTs7OztpQkFBQyx3QkFBQyxRQUFELFlBQU0sT0FBVTs7OztlQUFNOzs7OztNQUFNOzs7Ozs7S0FDMVgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBK0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7OztnQkFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFTLGNBQWMsR0FBRyxZQUFZLEtBQUssbUJBQW1CLHlCQUFpQzs7OztnQkFBQyx3QkFBQyxRQUFEO09BQU07T0FBUztPQUFpQjtPQUFFLHFCQUFxQixJQUFJLFFBQVE7TUFBYTs7OztjQUFNOzs7O2NBQU07Ozs7OztLQUNwUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUErQix3QkFBQyxVQUFELFlBQVEscUJBQTBCOzs7O2dCQUFDLHdCQUFDLE9BQUQsWUFBTTtPQUFDLENBQUMsUUFBUSxDQUFDO09BQUcsQ0FBQyxjQUFjLENBQUM7T0FBRyxDQUFDLFFBQVEsQ0FBQztNQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxXQUFXLHdCQUFDLFVBQUQ7T0FBNEIsV0FBVyxXQUFXLFFBQVEsV0FBVztPQUFJLGVBQWUsVUFBVSxPQUFPLEtBQUssQ0FBQztpQkFBSTtNQUFjLEdBQXBILE9BQU8sS0FBSzs7OzthQUF3RyxDQUFDLEVBQU87Ozs7Y0FBTTs7Ozs7O0tBQzVSLGFBQWEsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQW9DLDRCQUF3Qix3QkFBQyxTQUFEO09BQU8sTUFBSztPQUFTLEtBQUk7T0FBSSxNQUFLO09BQUssT0FBTztPQUFVLFdBQVcsVUFBVSxZQUFZLE1BQU0sT0FBTyxLQUFLO09BQUcsYUFBWTtNQUFPOzs7O2NBQVE7Ozs7OztLQUNuTix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FBb0MseUJBQXFCLHdCQUFDLFlBQUQ7T0FBVSxPQUFPO09BQU0sV0FBVyxVQUFVLFFBQVEsTUFBTSxPQUFPLEtBQUs7T0FBRyxhQUFZO01BQTZCOzs7O2NBQVE7Ozs7OztLQUNuTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUFvQyx3QkFBQyxRQUFEO09BQVEsZUFBZSxZQUFZLEtBQUs7aUJBQUc7TUFBa0M7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFRLFNBQVE7T0FBUSxlQUFlLFlBQVksT0FBTyxXQUFXO2lCQUFHO01BQXFCOzs7O2NBQU07Ozs7OztJQUM5TTs7Ozs7SUFBRTtHQUFvQjs7Ozs7O0NBQ2pDO0NBRUEsTUFBTSxtQkFBbUIsZ0JBQWdCLFFBQVEsS0FBSyxZQUFZLE1BQU0sUUFBUSxVQUFVLENBQUM7Q0FDM0YsTUFBTSxlQUFlLGdCQUFnQixNQUFNLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFlBQVksTUFBTSxRQUFRLFVBQVUsQ0FBQyxJQUFJO0NBQy9HLE1BQU0sV0FBVyxhQUFjLG1CQUFtQixnQkFBZ0IsbUJBQW9CLE9BQVEsaUJBQWlCLFVBQVUsU0FBUyxLQUFLLFFBQVEsUUFBUSxVQUFVLFNBQVU7Q0FDM0ssT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNMLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCO0tBQWtDLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQXFCLGVBQWUsV0FBVyxJQUFJO01BQUcsY0FBVztnQkFBYyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztLQUFTOzs7OztLQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFELFlBQVMsUUFBUSxLQUFhOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFPLFlBQVksV0FBVyxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsV0FBVyxZQUFZLGdCQUFnQixFQUFFLE1BQU0sUUFBUSxVQUFVLFNBQWU7Ozs7YUFBTTs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBZ0IsV0FBVyxPQUFPO0tBQVE7Ozs7O0tBQUU7S0FBZSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBbUIsd0JBQUMsS0FBRCxFQUFHLE9BQU8sRUFBRSxPQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsUUFBUSxFQUFFLEdBQUcsRUFBSTs7Ozs7S0FBTTs7Ozs7SUFBUzs7Ozs7O0dBQzVnQix3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUNHLFlBQVksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDWCx3QkFBQyxPQUFEO1FBQUssV0FBVyxlQUFlLFdBQVcsWUFBWTtrQkFBdEQsQ0FBMkQsd0JBQUMsTUFBRCxFQUFNLE1BQU0sZUFBZSxRQUFRLFNBQVMsT0FBUzs7OztrQkFBRSxVQUFnQjs7Ozs7O09BQ2xJLHdCQUFDLE9BQUQ7UUFBSyxXQUFXLGNBQWMsV0FBVyxZQUFZO2tCQUFyRCxDQUEwRCx3QkFBQyxVQUFELFlBQVMsV0FBVyxTQUFTLEVBQVU7Ozs7a0JBQUMsd0JBQUMsUUFBRCxZQUFPLGdCQUFnQixTQUFTLENBQUMsS0FBVzs7OztnQkFBTTs7Ozs7O09BQ3BKLHdCQUFDLE1BQUQsWUFBSyxhQUFhLElBQUksWUFBWSxhQUFhLGdCQUFnQixTQUFTLElBQUksY0FBYyxZQUFZLEtBQUssS0FBSyxXQUFXLENBQUMsRUFBRSxPQUFXOzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBSSxlQUFlLFFBQVEsMERBQTBELHlDQUE0Qzs7Ozs7T0FDMVEsYUFBYSxLQUFLLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFxQyxnQkFBZ0IsV0FBVyxFQUFFLENBQUMsVUFBVSxRQUFRLFFBQVE7U0FBTztTQUFLO1FBQWU7Ozs7OztPQUNwTCx3QkFBQyxVQUFEO1FBQVEsV0FBVyxpQkFBaUIsU0FBUyxXQUFXO1FBQU0sZUFBZSxXQUFXLFVBQVUsQ0FBQyxLQUFLO2tCQUF4RyxDQUEyRyx3QkFBQyxRQUFELFlBQU8sVUFBVSx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O2lCQUFROzs7O2tCQUFDLGlEQUF1RDs7Ozs7O09BQ2hOLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFjO09BQW9FOzs7OztPQUNuRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUEyQix3QkFBQyxRQUFELGFBQU0sa0JBQWMsd0JBQUMsVUFBRCxZQUFTLFdBQVcsT0FBTyxFQUFVOzs7O2dCQUFPOzs7O2tCQUFDLHdCQUFDLFFBQUQsYUFBTSxjQUFVLHdCQUFDLFVBQUQsWUFBUyxXQUFXLFlBQVksRUFBVTs7OztnQkFBTzs7OztnQkFBTTs7Ozs7O09BQ25LLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFvQixnQkFBZ0IsS0FBSyxTQUFTLFVBQVUsd0JBQUMsS0FBRDtTQUFlLFdBQVcsVUFBVSxXQUFXLFlBQVksUUFBUSxXQUFXLFNBQVM7U0FBSSxPQUFPLFFBQVE7UUFBTyxHQUF6Rzs7OztlQUF5RyxDQUFDO09BQU87Ozs7O01BQ2pNOzs7OztnQkFBSSxVQUFVLFNBQVMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDMUIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBaUMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBa0Msd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztvQkFBQyxNQUFTOzs7Ozs7U0FBQyx3QkFBQyxVQUFELFlBQVMsVUFBa0I7Ozs7O1NBQUMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7O1FBQU07Ozs7OztPQUN2Six3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFnQyx3QkFBQyxRQUFELENBQU87Ozs7O1NBQUMsd0JBQUMsVUFBRCxZQUFRLCtCQUFvQzs7Ozs7U0FBQyx3QkFBQyxTQUFELFlBQU8saUJBQXFCOzs7OztRQUFNOzs7Ozs7T0FDdkgsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBOEIsd0JBQUMsVUFBRDtTQUFRLGVBQWUsY0FBYyxVQUFVLFFBQVEsRUFBRTttQkFBRztRQUFZOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxTQUFTO21CQUFZO1FBQWlCOzs7O2dCQUFNOzs7Ozs7T0FDM0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBOEIsd0JBQUMsU0FBRCxZQUFPLFVBQWM7Ozs7O1NBQUMsd0JBQUMsVUFBRCxZQUFTLFdBQVcsSUFBSSxZQUFZLGNBQWMsUUFBUSxVQUFVLGdCQUFnQixFQUFFLEVBQUUsUUFBUSxnQkFBd0I7Ozs7O1NBQUMsd0JBQUMsUUFBRCxZQUFPLFdBQVcsSUFBSSxZQUFZLE9BQU8sV0FBVyxFQUFFLE1BQU0sY0FBYyxRQUFRLFVBQVUsZ0JBQWdCLEVBQUUsRUFBRSxhQUFtQjs7Ozs7UUFBTTs7Ozs7O01BQ25UOzs7OztnQkFBSSxVQUFVLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ2pCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQWlDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQWtDLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7b0JBQUMsTUFBUzs7Ozs7O1NBQUMsd0JBQUMsVUFBRCxZQUFTLFVBQWtCOzs7OztTQUFDLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7OztRQUFNOzs7Ozs7T0FDdEosd0JBQUMsTUFBRCxZQUFLLFlBQWdCOzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBRztRQUFPLFdBQVc7UUFBRTtRQUFLO09BQWE7Ozs7O01BQzVEOzs7OztnQkFBSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF3Qix3QkFBQyxNQUFELEVBQU0sTUFBSyxXQUFZOzs7OztPQUFNOzs7OztPQUFDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQWtDLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7a0JBQUMsTUFBUzs7Ozs7O09BQUMsd0JBQUMsTUFBRCxZQUFLLFlBQWdCOzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBRztRQUFLLFdBQVc7UUFBRTtRQUFLO1FBQVU7UUFBRyx3QkFBQyxVQUFELFlBQVEsVUFBZTs7Ozs7T0FBSTs7Ozs7T0FDN04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBNkIsd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7a0JBQUMsd0JBQUMsVUFBRDtTQUFRLGVBQWUsU0FBUyxVQUFVLFFBQVEsQ0FBQztTQUFHLGNBQVc7bUJBQWlCO1FBQVM7Ozs7Z0JBQU07Ozs7OztPQUFDLHdCQUFDLFFBQUQ7UUFBUSxTQUFTO2tCQUFZO09BQWdCOzs7OztPQUMvTCx3QkFBQyxNQUFEO1FBQUksd0JBQUMsTUFBRCxZQUFJLGtDQUFtQzs7Ozs7UUFBQyx3QkFBQyxNQUFELFlBQUksbUNBQW9DOzs7OztRQUFDLHdCQUFDLE1BQUQsWUFBSSw0QkFBNkI7Ozs7O09BQUs7Ozs7O09BQzNILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQThCLGFBQVUsV0FBVyxJQUFJLFlBQVksa0JBQWtCLFdBQVcsTUFBTSxRQUFRLFVBQVUsZ0JBQWdCLEVBQUUsRUFBRSxRQUFRLFdBQWlCOzs7Ozs7TUFDbEs7Ozs7OztLQUNKLENBQUMsYUFBYSxVQUFVLFVBQVUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBaUMsd0JBQUMsVUFBRDtPQUFRLGVBQWUsZ0JBQWdCO1FBQUUsR0FBRztTQUFlLGdCQUFnQixVQUFVLGdCQUFnQixLQUFLLFlBQVk7T0FBSSxDQUFDO2lCQUFHO01BQXFCOzs7O2dCQUFDLHdCQUFDLFVBQUQ7T0FBUSxlQUFlLGdCQUFnQjtRQUFFLEdBQUc7U0FBZSxnQkFBZ0IsY0FBYyxnQkFBZ0IsS0FBSyxZQUFZO09BQUksQ0FBQztpQkFBRztNQUF5Qjs7OztjQUFNOzs7Ozs7S0FDelgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBaUUsd0JBQUMsU0FBRCxZQUFPLE1BQVU7Ozs7Z0JBQUMsd0JBQUMsVUFBRCxZQUFTLFlBQWEsZUFBZSxRQUFRLDhDQUE4Qyw4QkFBK0IsS0FBSyxXQUFXLEtBQUssUUFBZ0I7Ozs7Y0FBTTtRQUF2TixHQUFHLGNBQWMsR0FBRzs7OztZQUFtTTtJQUNqUDs7Ozs7O0dBQ1Qsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEI7S0FBb0Msd0JBQUMsVUFBRDtNQUFRLGVBQWUsWUFBWSxlQUFlLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixDQUFDLENBQUM7Z0JBQTFFLENBQTZFLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7Z0JBQUMsVUFBZ0I7Ozs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQWUsZUFBZSxXQUFXLFVBQVUsQ0FBQyxLQUFLO2dCQUEzRSxDQUErRSxTQUFTLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7aUJBQUksd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztnQkFBRyxTQUFTLFdBQVcsT0FBZ0I7Ozs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLFlBQVksaUJBQWlCLElBQUksZ0JBQWdCO2dCQUF4RSxDQUEyRSxRQUFJLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7Y0FBUzs7Ozs7O0tBQUMsd0JBQUMsVUFBRDtNQUFRLFdBQVcsUUFBUSxVQUFVO01BQUksZUFBZSxVQUFVLFVBQVUsQ0FBQyxLQUFLO01BQUcsY0FBWSxRQUFRLG1CQUFtQjtnQkFBZ0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7Ozs7S0FBUzs7Ozs7SUFBUzs7Ozs7O0dBQ2htQixXQUFXLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQXdCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWEsTUFBSztLQUFTLGNBQVc7ZUFBckQ7TUFBNEQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O01BQU87Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7OztNQUFDLHdCQUFDLEtBQUQsWUFBRyx3RUFBd0U7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFRLGVBQWUsV0FBVyxLQUFLO2lCQUFHO01BQWtCOzs7OztNQUFDLHdCQUFDLFFBQUQ7T0FBUSxTQUFRO09BQVEsZUFBZSxZQUFZLElBQUk7aUJBQUc7TUFBNEI7Ozs7O01BQUMsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBaUIsZUFBZSxTQUFTLFdBQVc7aUJBQUc7TUFBZTs7Ozs7S0FBTTs7Ozs7O0dBQU07Ozs7O0dBQ3BnQjtFQUNHOzs7Ozs7QUFDUiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXNzaW9uUGxheWVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9JY29uXCI7XHJcbmltcG9ydCB0eXBlIHsgRml0bmVzc1N0b3JlLCBQbGFubmVkV29ya291dCB9IGZyb20gXCIuLi9maXRuZXNzU3RvcmVcIjtcclxuaW1wb3J0IHsgZGF0ZUtleSB9IGZyb20gXCIuLi9saWIvZm9ybWF0XCI7XHJcbmltcG9ydCB7IGFwaSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hcGlcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTZXNzaW9uUGxheWVyKHsgd29ya291dCwgc3RvcmUsIHVwZGF0ZSwgbmF2aWdhdGUsIHRvYXN0IH06IHsgd29ya291dDogUGxhbm5lZFdvcmtvdXQ7IHN0b3JlOiBGaXRuZXNzU3RvcmU7IHVwZGF0ZTogKG5leHQ6IEZpdG5lc3NTdG9yZSkgPT4gdm9pZDsgbmF2aWdhdGU6IChwYXRoOiBzdHJpbmcpID0+IHZvaWQ7IHRvYXN0OiAobWVzc2FnZTogc3RyaW5nKSA9PiB2b2lkIH0pIHtcclxuICB0eXBlIFBsYXllclNjcmVlbiA9IFwicmVhZHlcIiB8IFwiY291bnRkb3duXCIgfCBcImFjdGl2ZVwiIHwgXCJjb21wbGV0ZVwiO1xyXG4gIHR5cGUgUGhhc2UgPSBcIndvcmtcIiB8IFwicmVzdFwiO1xyXG4gIGNvbnN0IGlzUnVubmluZyA9IHdvcmtvdXQubmFtZS5pbmNsdWRlcyhcIldhbGstUnVuXCIpIHx8IHdvcmtvdXQudGFyZ2V0VGFncy5pbmNsdWRlcyhcIlJ1blwiKTtcclxuICBjb25zdCBbc2NyZWVuLCBzZXRTY3JlZW5dID0gdXNlU3RhdGU8UGxheWVyU2NyZWVuPihcInJlYWR5XCIpO1xyXG4gIGNvbnN0IFtjb3VudGRvd24sIHNldENvdW50ZG93bl0gPSB1c2VTdGF0ZSgzKTtcclxuICBjb25zdCBbZXhlcmNpc2VJbmRleCwgc2V0RXhlcmNpc2VJbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2V0SW5kZXgsIHNldFNldEluZGV4XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtwaGFzZSwgc2V0UGhhc2VdID0gdXNlU3RhdGU8UGhhc2U+KFwid29ya1wiKTtcclxuICBjb25zdCBbcmVtYWluaW5nLCBzZXRSZW1haW5pbmddID0gdXNlU3RhdGUoNDApO1xyXG4gIGNvbnN0IFtlbGFwc2VkLCBzZXRFbGFwc2VkXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtwYXVzZWQsIHNldFBhdXNlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlcHMsIHNldFJlcHNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2N1ZUluZGV4LCBzZXRDdWVJbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbXV0ZWQsIHNldE11dGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0VuZCwgc2V0U2hvd0VuZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dTZXR0aW5ncywgc2V0U2hvd1NldHRpbmdzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWZmb3J0LCBzZXRFZmZvcnRdID0gdXNlU3RhdGUoMyk7XHJcbiAgY29uc3QgW25vdGUsIHNldE5vdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Rpc3RhbmNlLCBzZXREaXN0YW5jZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc291bmQsIHNldFNvdW5kXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFt2b2ljZSwgc2V0Vm9pY2VdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt2aWJyYXRpb24sIHNldFZpYnJhdGlvbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbd2FrZVNjcmVlbiwgc2V0V2FrZVNjcmVlbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZGVtb1NwZWVkLCBzZXREZW1vU3BlZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpbmRvb3IsIHNldEluZG9vcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nlc3Npb25Td2Fwcywgc2V0U2Vzc2lvblN3YXBzXSA9IHVzZVN0YXRlPFJlY29yZDxudW1iZXIsIHN0cmluZz4+KHt9KTtcclxuICBjb25zdCBlcXVpcG1lbnRJdGVtcyA9IGlzUnVubmluZyA/IFtcIkNvbWZvcnRhYmxlIHNob2VzXCIsIFwiV2F0ZXIgYm90dGxlXCIsIFwiU2FmZSByb3V0ZSBvciBjbGVhciBpbmRvb3Igc3BhY2VcIl0gOiBbd29ya291dC5lcXVpcG1lbnQsIFwiQ2xlYXIgZmxvb3Igc3BhY2VcIiwgXCJXYXRlciBuZWFyYnlcIl07XHJcbiAgY29uc3QgW2VxdWlwbWVudFJlYWR5LCBzZXRFcXVpcG1lbnRSZWFkeV0gPSB1c2VTdGF0ZSgoKSA9PiBlcXVpcG1lbnRJdGVtcy5tYXAoKCkgPT4gZmFsc2UpKTtcclxuICBjb25zdCBbcnVuSW5kZXgsIHNldFJ1bkluZGV4XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IHdha2VMb2NrID0gdXNlUmVmPHsgcmVsZWFzZTogKCkgPT4gUHJvbWlzZTx2b2lkPiB9IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgcnVubmluZ1NlZ21lbnRzID0gdXNlTWVtbygoKSA9PiBbXHJcbiAgICB7IGxhYmVsOiBcIldBTEtcIiwgbmFtZTogXCJXYXJtLXVwIHdhbGtcIiwgZHVyYXRpb246IDMwMCB9LFxyXG4gICAgLi4uQXJyYXkuZnJvbSh7IGxlbmd0aDogMTYgfSwgKF8sIGluZGV4KSA9PiAoeyBsYWJlbDogaW5kZXggJSAyID09PSAwID8gXCJKT0dcIiA6IFwiV0FMS1wiLCBuYW1lOiBpbmRleCAlIDIgPT09IDAgPyBcIkVhc3kgam9nXCIgOiBcIlJlY292ZXJ5IHdhbGtcIiwgZHVyYXRpb246IGluZGV4ICUgMiA9PT0gMCA/IDYwIDogMTIwIH0pKSxcclxuICAgIHsgbGFiZWw6IFwiV0FMS1wiLCBuYW1lOiBcIkNvb2wtZG93biB3YWxrXCIsIGR1cmF0aW9uOiAzMDAgfSxcclxuICBdLCBbXSk7XHJcbiAgY29uc3QgY3VycmVudEV4ZXJjaXNlID0gd29ya291dC5leGVyY2lzZXNbZXhlcmNpc2VJbmRleF07XHJcbiAgY29uc3QgZGlzcGxheU5hbWUgPSBzZXNzaW9uU3dhcHNbZXhlcmNpc2VJbmRleF0gfHwgY3VycmVudEV4ZXJjaXNlPy5uYW1lIHx8IHdvcmtvdXQubmFtZTtcclxuICBjb25zdCBpc1RpbWVkID0gd29ya291dC5uYW1lLmluY2x1ZGVzKFwiSElJVFwiKSB8fCAvcGxhbmt8aG9sZHxjbGltYmVyfGp1bXB8aGlnaCBrbmVlcy9pLnRlc3QoZGlzcGxheU5hbWUpO1xyXG4gIGNvbnN0IHRvdGFsU2V0cyA9IHdvcmtvdXQuc2V0cyA/PyAoaXNUaW1lZCA/IDQgOiAzKTtcclxuICBjb25zdCBwaGFzZUxhYmVsID0gaXNSdW5uaW5nID8gcnVubmluZ1NlZ21lbnRzW3J1bkluZGV4XS5sYWJlbCA6IHBoYXNlID09PSBcInJlc3RcIiA/IFwiUkVTVFwiIDogXCJXT1JLXCI7XHJcbiAgY29uc3QgZm9ybWF0VGltZSA9IChzZWNvbmRzOiBudW1iZXIpID0+IGAke01hdGguZmxvb3Ioc2Vjb25kcyAvIDYwKX06JHtTdHJpbmcoc2Vjb25kcyAlIDYwKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICBjb25zdCBjdWVzID0gL3B1c2gvaS50ZXN0KGRpc3BsYXlOYW1lKVxyXG4gICAgPyBbXCJLZWVwIHlvdXIgY29yZSB0aWdodFwiLCBcIkJyZWF0aGUgb3V0IGFzIHlvdSBwdXNoXCIsIFwiS2VlcCBhIGxvbmcgbGluZSBmcm9tIGhlYWQgdG8gaGVlbFwiXVxyXG4gICAgOiAvc3F1YXR8bHVuZ2UvaS50ZXN0KGRpc3BsYXlOYW1lKVxyXG4gICAgICA/IFtcIlNvZnQga25lZXMgb24gbGFuZGluZ1wiLCBcIlByZXNzIHRoZSBmbG9vciBhd2F5XCIsIFwiS2VlcCB5b3VyIGNoZXN0IGNvbWZvcnRhYmx5IGxpZnRlZFwiXVxyXG4gICAgICA6IFtcIk1vdmUgd2l0aCBjb250cm9sXCIsIFwiS2VlcCBicmVhdGhpbmcgc3RlYWRpbHlcIiwgXCJDaG9vc2UgYSBwYWNlIHlvdSBjYW4gc3VzdGFpblwiXTtcclxuXHJcbiAgY29uc3QgYmVlcCA9IChkb3VibGUgPSBmYWxzZSkgPT4ge1xyXG4gICAgaWYgKCFzb3VuZCB8fCBtdXRlZCkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgQXVkaW9Db250ZXh0Q2xhc3MgPSB3aW5kb3cuQXVkaW9Db250ZXh0IHx8ICh3aW5kb3cgYXMgdHlwZW9mIHdpbmRvdyAmIHsgd2Via2l0QXVkaW9Db250ZXh0PzogdHlwZW9mIEF1ZGlvQ29udGV4dCB9KS53ZWJraXRBdWRpb0NvbnRleHQ7XHJcbiAgICAgIGlmICghQXVkaW9Db250ZXh0Q2xhc3MpIHJldHVybjtcclxuICAgICAgY29uc3QgY29udGV4dCA9IG5ldyBBdWRpb0NvbnRleHRDbGFzcygpO1xyXG4gICAgICBbMCwgLi4uKGRvdWJsZSA/IFswLjE0XSA6IFtdKV0uZm9yRWFjaCgoZGVsYXkpID0+IHtcclxuICAgICAgICBjb25zdCBvc2NpbGxhdG9yID0gY29udGV4dC5jcmVhdGVPc2NpbGxhdG9yKCk7XHJcbiAgICAgICAgY29uc3QgZ2FpbiA9IGNvbnRleHQuY3JlYXRlR2FpbigpO1xyXG4gICAgICAgIG9zY2lsbGF0b3IuZnJlcXVlbmN5LnZhbHVlID0gZG91YmxlID8gNzIwIDogNjIwO1xyXG4gICAgICAgIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSguMDgsIGNvbnRleHQuY3VycmVudFRpbWUgKyBkZWxheSk7XHJcbiAgICAgICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoLjAwMSwgY29udGV4dC5jdXJyZW50VGltZSArIGRlbGF5ICsgLjA5KTtcclxuICAgICAgICBvc2NpbGxhdG9yLmNvbm5lY3QoZ2FpbikuY29ubmVjdChjb250ZXh0LmRlc3RpbmF0aW9uKTtcclxuICAgICAgICBvc2NpbGxhdG9yLnN0YXJ0KGNvbnRleHQuY3VycmVudFRpbWUgKyBkZWxheSk7XHJcbiAgICAgICAgb3NjaWxsYXRvci5zdG9wKGNvbnRleHQuY3VycmVudFRpbWUgKyBkZWxheSArIC4xKTtcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gU291bmQgaXMgYW4gZW5oYW5jZW1lbnRcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGFubm91bmNlID0gKG1lc3NhZ2U6IHN0cmluZykgPT4ge1xyXG4gICAgaWYgKCF2b2ljZSB8fCBtdXRlZCB8fCAhKFwic3BlZWNoU3ludGhlc2lzXCIgaW4gd2luZG93KSkgcmV0dXJuO1xyXG4gICAgd2luZG93LnNwZWVjaFN5bnRoZXNpcy5jYW5jZWwoKTtcclxuICAgIHdpbmRvdy5zcGVlY2hTeW50aGVzaXMuc3BlYWsobmV3IFNwZWVjaFN5bnRoZXNpc1V0dGVyYW5jZShtZXNzYWdlKSk7XHJcbiAgfTtcclxuICBjb25zdCBzaWduYWxDaGFuZ2UgPSAobWVzc2FnZTogc3RyaW5nKSA9PiB7XHJcbiAgICBiZWVwKHRydWUpO1xyXG4gICAgYW5ub3VuY2UobWVzc2FnZSk7XHJcbiAgICBpZiAodmlicmF0aW9uICYmIFwidmlicmF0ZVwiIGluIG5hdmlnYXRvcikgbmF2aWdhdG9yLnZpYnJhdGUoWzgwLCA1MCwgODBdKTtcclxuICB9O1xyXG4gIGNvbnN0IGZpbmlzaFdvcmtvdXQgPSAoKSA9PiB7XHJcbiAgICBzZXRQYXVzZWQodHJ1ZSk7XHJcbiAgICBzZXRTY3JlZW4oXCJjb21wbGV0ZVwiKTtcclxuICB9O1xyXG4gIGNvbnN0IGFkdmFuY2VFeGVyY2lzZSA9IChkaXJlY3Rpb24gPSAxKSA9PiB7XHJcbiAgICBjb25zdCBuZXh0ID0gZXhlcmNpc2VJbmRleCArIGRpcmVjdGlvbjtcclxuICAgIGlmIChuZXh0IDwgMCkgcmV0dXJuO1xyXG4gICAgaWYgKG5leHQgPj0gd29ya291dC5leGVyY2lzZXMubGVuZ3RoKSByZXR1cm4gZmluaXNoV29ya291dCgpO1xyXG4gICAgc2V0RXhlcmNpc2VJbmRleChuZXh0KTtcclxuICAgIHNldFNldEluZGV4KDApO1xyXG4gICAgc2V0UGhhc2UoXCJ3b3JrXCIpO1xyXG4gICAgc2V0UmVtYWluaW5nKDQwKTtcclxuICAgIHNldFJlcHMoMCk7XHJcbiAgICBzaWduYWxDaGFuZ2UoYE5leHQgZXhlcmNpc2UsICR7c2Vzc2lvblN3YXBzW25leHRdIHx8IHdvcmtvdXQuZXhlcmNpc2VzW25leHRdLm5hbWV9YCk7XHJcbiAgfTtcclxuICBjb25zdCBmaW5pc2hSZXN0ID0gKCkgPT4ge1xyXG4gICAgaWYgKHNldEluZGV4ICsgMSA8IHRvdGFsU2V0cykge1xyXG4gICAgICBzZXRTZXRJbmRleCgodmFsdWUpID0+IHZhbHVlICsgMSk7XHJcbiAgICAgIHNldFBoYXNlKFwid29ya1wiKTtcclxuICAgICAgc2V0UmVtYWluaW5nKDQwKTtcclxuICAgICAgc2V0UmVwcygwKTtcclxuICAgICAgc2lnbmFsQ2hhbmdlKFwiV29ya1wiKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGFkdmFuY2VFeGVyY2lzZSgpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgZmluaXNoV29yayA9ICgpID0+IHtcclxuICAgIHNldFBoYXNlKFwicmVzdFwiKTtcclxuICAgIHNldFJlbWFpbmluZygyMCk7XHJcbiAgICBzaWduYWxDaGFuZ2UoXCJSZXN0XCIpO1xyXG4gIH07XHJcbiAgY29uc3QgZmluaXNoUnVuU2VnbWVudCA9ICgpID0+IHtcclxuICAgIGlmIChydW5JbmRleCArIDEgPj0gcnVubmluZ1NlZ21lbnRzLmxlbmd0aCkgcmV0dXJuIGZpbmlzaFdvcmtvdXQoKTtcclxuICAgIGNvbnN0IG5leHQgPSBydW5JbmRleCArIDE7XHJcbiAgICBzZXRSdW5JbmRleChuZXh0KTtcclxuICAgIHNldFJlbWFpbmluZyhydW5uaW5nU2VnbWVudHNbbmV4dF0uZHVyYXRpb24pO1xyXG4gICAgc2lnbmFsQ2hhbmdlKGAke3J1bm5pbmdTZWdtZW50c1tuZXh0XS5sYWJlbCA9PT0gXCJKT0dcIiA/IFwiSm9nXCIgOiBcIldhbGtcIn0gbm93YCk7XHJcbiAgfTtcclxuICBjb25zdCBtb3ZlUnVuU2VnbWVudCA9IChkaXJlY3Rpb246IG51bWJlcikgPT4ge1xyXG4gICAgY29uc3QgbmV4dCA9IE1hdGgubWF4KDAsIE1hdGgubWluKHJ1bm5pbmdTZWdtZW50cy5sZW5ndGggLSAxLCBydW5JbmRleCArIGRpcmVjdGlvbikpO1xyXG4gICAgc2V0UnVuSW5kZXgobmV4dCk7XHJcbiAgICBzZXRSZW1haW5pbmcocnVubmluZ1NlZ21lbnRzW25leHRdLmR1cmF0aW9uKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzYXZlU2Vzc2lvbiA9IGFzeW5jIChwYXJ0aWFsID0gZmFsc2UsIGRlc3RpbmF0aW9uID0gXCIvZGFzaGJvYXJkXCIpID0+IHtcclxuICAgIGNvbnN0IGNvbXBsZXRlZEV4ZXJjaXNlcyA9IHdvcmtvdXQuZXhlcmNpc2VzLnNsaWNlKDAsIE1hdGgubWluKHdvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aCwgZXhlcmNpc2VJbmRleCArIChwYXJ0aWFsID8gMSA6IHdvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aCkpKS5tYXAoKGV4ZXJjaXNlLCBpbmRleCkgPT4gc2Vzc2lvblN3YXBzW2luZGV4XSB8fCBleGVyY2lzZS5uYW1lKTtcclxuICAgIGNvbnN0IGV4aXN0aW5nID0gc3RvcmUuc2Vzc2lvbnMuc29tZSgoc2Vzc2lvbikgPT4gc2Vzc2lvbi53b3Jrb3V0SWQgPT09IHdvcmtvdXQuaWQgJiYgc2Vzc2lvbi5kYXRlID09PSBkYXRlS2V5KG5ldyBEYXRlKCkpKTtcclxuICAgIFxyXG4gICAgY29uc3Qgc2Vzc2lvblBheWxvYWQgPSB7XHJcbiAgICAgIHdvcmtvdXRJZDogd29ya291dC5pZCxcclxuICAgICAgZGF0ZTogZGF0ZUtleShuZXcgRGF0ZSgpKSxcclxuICAgICAgZHVyYXRpb246IE1hdGgubWF4KDEsIE1hdGgucm91bmQoZWxhcHNlZCAvIDYwKSksXHJcbiAgICAgIGV4ZXJjaXNlc0RvbmU6IGNvbXBsZXRlZEV4ZXJjaXNlcyxcclxuICAgICAgZWZmb3J0LFxyXG4gICAgICBub3RlLFxyXG4gICAgICBkaXN0YW5jZTogZGlzdGFuY2UgPyBOdW1iZXIoZGlzdGFuY2UpIDogdW5kZWZpbmVkLFxyXG4gICAgICBpc0NvbXBsZXRlZDogIXBhcnRpYWwsXHJcbiAgICB9O1xyXG5cclxuICAgIC8vIDEuIFBvc3QgbGl2ZSBzZXNzaW9uIGxvZyB0byBEamFuZ28gYmFja2VuZFxyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGFwaS5wb3N0U2Vzc2lvbikge1xyXG4gICAgICAgIGF3YWl0IGFwaS5wb3N0U2Vzc2lvbihzZXNzaW9uUGF5bG9hZCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJCYWNrZW5kIGZhaWxlZCB0byBzYXZlIHdvcmtvdXQgc2Vzc2lvbjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIDIuIFVwZGF0ZSBsb2NhbCBzdGF0ZSBzdG9yZSAmIG1ldHJpY3NcclxuICAgIGlmICghZXhpc3RpbmcpIHtcclxuICAgICAgY29uc3Qgc2Vzc2lvbnMgPSBbLi4uc3RvcmUuc2Vzc2lvbnMsIHNlc3Npb25QYXlsb2FkXTtcclxuICAgICAgY29uc3QgY29tcGxldGlvbkRhdGVzID0gbmV3IFNldChzZXNzaW9ucy5tYXAoKHNlc3Npb24pID0+IHNlc3Npb24uZGF0ZSkpO1xyXG4gICAgICBsZXQgY3VycmVudFN0cmVhayA9IDA7XHJcbiAgICAgIGNvbnN0IGN1cnNvciA9IG5ldyBEYXRlKCk7XHJcbiAgICAgIHdoaWxlIChjb21wbGV0aW9uRGF0ZXMuaGFzKGRhdGVLZXkoY3Vyc29yKSkpIHtcclxuICAgICAgICBjdXJyZW50U3RyZWFrICs9IDE7XHJcbiAgICAgICAgY3Vyc29yLnNldERhdGUoY3Vyc29yLmdldERhdGUoKSAtIDEpO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IGNoYWxsZW5nZURheSA9IE1hdGgubWF4KDEsIE1hdGguZmxvb3IoKERhdGUubm93KCkgLSBuZXcgRGF0ZShgJHtzdG9yZS5jaGFsbGVuZ2Uuc3RhcnREYXRlfVQxMjowMDowMGApLmdldFRpbWUoKSkgLyA4Nl80MDBfMDAwKSArIDEpO1xyXG4gICAgICBjb25zdCBiYWRnZXMgPSBzdG9yZS5iYWRnZXMubWFwKChiYWRnZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlcXVpcmVtZW50czogUmVjb3JkPHN0cmluZywgYm9vbGVhbj4gPSB7XHJcbiAgICAgICAgICBcInN0cmVhay0zXCI6IGN1cnJlbnRTdHJlYWsgPj0gMyxcclxuICAgICAgICAgIFwic3RyZWFrLTdcIjogY3VycmVudFN0cmVhayA+PSA3LFxyXG4gICAgICAgICAgXCJzdHJlYWstMTRcIjogY3VycmVudFN0cmVhayA+PSAxNCxcclxuICAgICAgICAgIFwic3RyZWFrLTMwXCI6IGN1cnJlbnRTdHJlYWsgPj0gMzAsXHJcbiAgICAgICAgICBcIndvcmtvdXQtMVwiOiBzZXNzaW9ucy5sZW5ndGggPj0gMSxcclxuICAgICAgICAgIFwid29ya291dC0xMFwiOiBzZXNzaW9ucy5sZW5ndGggPj0gMTAsXHJcbiAgICAgICAgICBcIndvcmtvdXQtMjVcIjogc2Vzc2lvbnMubGVuZ3RoID49IDI1LFxyXG4gICAgICAgICAgXCJ3b3Jrb3V0LTUwXCI6IHNlc3Npb25zLmxlbmd0aCA+PSA1MCxcclxuICAgICAgICAgIFwid2Vlay0xXCI6IHNlc3Npb25zLmxlbmd0aCA+PSBzdG9yZS5jaGFsbGVuZ2UuZGF5c1BlcldlZWssXHJcbiAgICAgICAgICBoYWxmd2F5OiBjaGFsbGVuZ2VEYXkgPj0gc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDIsXHJcbiAgICAgICAgICBmaW5pc2g6IGNoYWxsZW5nZURheSA+PSBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgdW5sb2NrID0gcmVxdWlyZW1lbnRzW2JhZGdlLmlkXSA/PyBiYWRnZS51bmxvY2tlZDtcclxuICAgICAgICByZXR1cm4gdW5sb2NrICYmICFiYWRnZS51bmxvY2tlZCA/IHsgLi4uYmFkZ2UsIHVubG9ja2VkOiB0cnVlLCBkYXRlOiBkYXRlS2V5KG5ldyBEYXRlKCkpIH0gOiBiYWRnZTtcclxuICAgICAgfSk7XHJcbiAgICAgIHVwZGF0ZSh7IC4uLnN0b3JlLCBzZXNzaW9ucywgYmFkZ2VzIH0pO1xyXG4gICAgfVxyXG4gICAgdG9hc3QocGFydGlhbCA/IFwiUGFydGlhbCBzZXNzaW9uIHNhdmVkLlwiIDogXCJXb3Jrb3V0IHNhdmVkLiBZb3VyIHByb2dyZXNzIGlzIHVwZGF0ZWQuXCIpO1xyXG4gICAgbmF2aWdhdGUoZGVzdGluYXRpb24pO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2NyZWVuICE9PSBcImNvdW50ZG93blwiKSByZXR1cm47XHJcbiAgICBpZiAoY291bnRkb3duIDw9IDApIHtcclxuICAgICAgc2lnbmFsQ2hhbmdlKGlzUnVubmluZyA/IFwiU3RhcnQgd2Fsa2luZ1wiIDogXCJCZWdpblwiKTtcclxuICAgICAgc2V0U2NyZWVuKFwiYWN0aXZlXCIpO1xyXG4gICAgICBzZXRSZW1haW5pbmcoaXNSdW5uaW5nID8gcnVubmluZ1NlZ21lbnRzWzBdLmR1cmF0aW9uIDogNDApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBiZWVwKCk7XHJcbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldENvdW50ZG93bigodmFsdWUpID0+IHZhbHVlIC0gMSksIGRlbW9TcGVlZCA/IDEwMCA6IDEwMDApO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xyXG4gIH0sIFtzY3JlZW4sIGNvdW50ZG93biwgZGVtb1NwZWVkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2NyZWVuICE9PSBcImFjdGl2ZVwiIHx8IHBhdXNlZCkgcmV0dXJuO1xyXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICBzZXRFbGFwc2VkKCh2YWx1ZSkgPT4gdmFsdWUgKyAxKTtcclxuICAgICAgaWYgKGlzUnVubmluZyB8fCBwaGFzZSA9PT0gXCJyZXN0XCIgfHwgaXNUaW1lZCkgc2V0UmVtYWluaW5nKCh2YWx1ZSkgPT4gTWF0aC5tYXgoMCwgdmFsdWUgLSAxKSk7XHJcbiAgICB9LCBkZW1vU3BlZWQgPyAxMDAgOiAxMDAwKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcik7XHJcbiAgfSwgW3NjcmVlbiwgcGF1c2VkLCBkZW1vU3BlZWQsIGlzUnVubmluZywgaXNUaW1lZCwgcGhhc2VdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzY3JlZW4gIT09IFwiYWN0aXZlXCIgfHwgcGF1c2VkKSByZXR1cm47XHJcbiAgICBpZiAocmVtYWluaW5nID4gMCAmJiByZW1haW5pbmcgPD0gMykgYmVlcCgpO1xyXG4gICAgaWYgKHJlbWFpbmluZyAhPT0gMCkgcmV0dXJuO1xyXG4gICAgaWYgKGlzUnVubmluZykgZmluaXNoUnVuU2VnbWVudCgpO1xyXG4gICAgZWxzZSBpZiAocGhhc2UgPT09IFwicmVzdFwiKSBmaW5pc2hSZXN0KCk7XHJcbiAgICBlbHNlIGlmIChpc1RpbWVkKSBmaW5pc2hXb3JrKCk7XHJcbiAgfSwgW3JlbWFpbmluZywgc2NyZWVuLCBwYXVzZWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzY3JlZW4gIT09IFwiYWN0aXZlXCIpIHJldHVybjtcclxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHNldEN1ZUluZGV4KCh2YWx1ZSkgPT4gdmFsdWUgKyAxKSwgZGVtb1NwZWVkID8gMTUwMCA6IDE1MDAwKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcik7XHJcbiAgfSwgW3NjcmVlbiwgZGVtb1NwZWVkLCBleGVyY2lzZUluZGV4XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBvbktleURvd24gPSAoZXZlbnQ6IEtleWJvYXJkRXZlbnQpID0+IHtcclxuICAgICAgaWYgKHNob3dTZXR0aW5ncykgcmV0dXJuO1xyXG4gICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkVzY2FwZVwiKSBzZXRTaG93RW5kKHRydWUpO1xyXG4gICAgICBpZiAoc2NyZWVuICE9PSBcImFjdGl2ZVwiKSByZXR1cm47XHJcbiAgICAgIGlmIChldmVudC5jb2RlID09PSBcIlNwYWNlXCIpIHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIHNldFBhdXNlZCgodmFsdWUpID0+ICF2YWx1ZSk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJBcnJvd1JpZ2h0XCIpIGlzUnVubmluZyA/IGZpbmlzaFJ1blNlZ21lbnQoKSA6IGFkdmFuY2VFeGVyY2lzZSgpO1xyXG4gICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkFycm93TGVmdFwiICYmICFpc1J1bm5pbmcpIGFkdmFuY2VFeGVyY2lzZSgtMSk7XHJcbiAgICB9O1xyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93bik7XHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93bik7XHJcbiAgfSwgW3NjcmVlbiwgc2hvd1NldHRpbmdzLCBpc1J1bm5pbmcsIGV4ZXJjaXNlSW5kZXgsIHJ1bkluZGV4XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBtYW5hZ2VXYWtlTG9jayA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3Qgd2FrZU5hdmlnYXRvciA9IG5hdmlnYXRvciBhcyBOYXZpZ2F0b3IgJiB7IHdha2VMb2NrPzogeyByZXF1ZXN0OiAodHlwZTogXCJzY3JlZW5cIikgPT4gUHJvbWlzZTx7IHJlbGVhc2U6ICgpID0+IFByb21pc2U8dm9pZD4gfT4gfSB9O1xyXG4gICAgICBpZiAod2FrZVNjcmVlbiAmJiBzY3JlZW4gPT09IFwiYWN0aXZlXCIgJiYgd2FrZU5hdmlnYXRvci53YWtlTG9jaykge1xyXG4gICAgICAgIHRyeSB7IHdha2VMb2NrLmN1cnJlbnQgPSBhd2FpdCB3YWtlTmF2aWdhdG9yLndha2VMb2NrLnJlcXVlc3QoXCJzY3JlZW5cIik7IH0gY2F0Y2ggeyB3YWtlTG9jay5jdXJyZW50ID0gbnVsbDsgfVxyXG4gICAgICB9IGVsc2UgaWYgKHdha2VMb2NrLmN1cnJlbnQpIHtcclxuICAgICAgICBhd2FpdCB3YWtlTG9jay5jdXJyZW50LnJlbGVhc2UoKTtcclxuICAgICAgICB3YWtlTG9jay5jdXJyZW50ID0gbnVsbDtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIHZvaWQgbWFuYWdlV2FrZUxvY2soKTtcclxuICAgIHJldHVybiAoKSA9PiB7IGlmICh3YWtlTG9jay5jdXJyZW50KSB2b2lkIHdha2VMb2NrLmN1cnJlbnQucmVsZWFzZSgpOyB9O1xyXG4gIH0sIFt3YWtlU2NyZWVuLCBzY3JlZW5dKTtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3NCdXR0b24gPSA8YnV0dG9uIGNsYXNzTmFtZT1cInBsYXllci1pY29uLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dTZXR0aW5ncyh0cnVlKX0gYXJpYS1sYWJlbD1cIlNlc3Npb24gc2V0dGluZ3NcIj48SWNvbiBuYW1lPVwiZ2VhclwiIC8+PC9idXR0b24+O1xyXG4gIGNvbnN0IHNldHRpbmdzU2hlZXQgPSBzaG93U2V0dGluZ3MgJiYgPGRpdiBjbGFzc05hbWU9XCJwbGF5ZXItbW9kYWwtYmFja2Ryb3BcIiBvbk1vdXNlRG93bj17KCkgPT4gc2V0U2hvd1NldHRpbmdzKGZhbHNlKX0+PGFzaWRlIGNsYXNzTmFtZT1cInNldHRpbmdzLXNoZWV0XCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIlNlc3Npb24gc2V0dGluZ3NcIiBvbk1vdXNlRG93bj17KGV2ZW50KSA9PiBldmVudC5zdG9wUHJvcGFnYXRpb24oKX0+PGhlYWRlcj48ZGl2PjxzbWFsbD5TRVNTSU9OIFBSRUZFUkVOQ0VTPC9zbWFsbD48aDI+U2V0dGluZ3M8L2gyPjwvZGl2PjxidXR0b24gY2xhc3NOYW1lPVwicGxheWVyLWljb24tYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1NldHRpbmdzKGZhbHNlKX0gYXJpYS1sYWJlbD1cIkNsb3NlIHNldHRpbmdzXCI+PEljb24gbmFtZT1cImNsb3NlXCIgLz48L2J1dHRvbj48L2hlYWRlcj48ZGl2IGNsYXNzTmFtZT1cInNldHRpbmctbGlzdFwiPlxyXG4gICAge1tbXCJTb3VuZCBiZWVwc1wiLCBzb3VuZCwgc2V0U291bmRdLCBbXCJWb2ljZSBjdWVzXCIsIHZvaWNlLCBzZXRWb2ljZV0sIFtcIlZpYnJhdGlvbiBvbiBtb2JpbGVcIiwgdmlicmF0aW9uLCBzZXRWaWJyYXRpb25dLCBbXCJLZWVwIHNjcmVlbiBhd2FrZVwiLCB3YWtlU2NyZWVuLCBzZXRXYWtlU2NyZWVuXSwgW1wiRGVtbyBzcGVlZCAxMMOXXCIsIGRlbW9TcGVlZCwgc2V0RGVtb1NwZWVkXV0ubWFwKChbbGFiZWwsIGNoZWNrZWQsIHNldHRlcl0pID0+IDxsYWJlbCBrZXk9e1N0cmluZyhsYWJlbCl9PjxzcGFuPjxzdHJvbmc+e1N0cmluZyhsYWJlbCl9PC9zdHJvbmc+e2xhYmVsID09PSBcIkRlbW8gc3BlZWQgMTDDl1wiICYmIDxzbWFsbD5Gb3IgcHJlc2VudGF0aW9uczwvc21hbGw+fTwvc3Bhbj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17Qm9vbGVhbihjaGVja2VkKX0gb25DaGFuZ2U9eyhldmVudCkgPT4gKHNldHRlciBhcyBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxib29sZWFuPj4pKGV2ZW50LnRhcmdldC5jaGVja2VkKX0gLz48L2xhYmVsPil9XHJcbiAgPC9kaXY+PC9hc2lkZT48L2Rpdj47XHJcblxyXG4gIGlmIChzY3JlZW4gPT09IFwicmVhZHlcIiB8fCBzY3JlZW4gPT09IFwiY291bnRkb3duXCIpIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJzZXNzaW9uLXBsYXllciByZWFkeS1zY3JlZW5cIj5cclxuICAgIDxoZWFkZXI+PGJ1dHRvbiBjbGFzc05hbWU9XCJwbGF5ZXItaWNvbi1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi93b3Jrb3V0c1wiKX0gYXJpYS1sYWJlbD1cIkNsb3NlIHNlc3Npb25cIj48SWNvbiBuYW1lPVwiY2xvc2VcIiAvPjwvYnV0dG9uPntzZXR0aW5nc0J1dHRvbn08L2hlYWRlcj5cclxuICAgIHtzY3JlZW4gPT09IFwiY291bnRkb3duXCIgPyA8c2VjdGlvbiBjbGFzc05hbWU9XCJzdGFydC1jb3VudGRvd25cIiBhcmlhLWxpdmU9XCJhc3NlcnRpdmVcIj48c21hbGw+R0VUIFJFQURZPC9zbWFsbD48c3Ryb25nPntjb3VudGRvd24gfHwgXCJHT1wifTwvc3Ryb25nPjxwPnt3b3Jrb3V0Lm5hbWV9PC9wPjwvc2VjdGlvbj4gOiA8c2VjdGlvbiBjbGFzc05hbWU9XCJyZWFkeS1jb250ZW50XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZHktaGVhZGluZ1wiPjxzbWFsbD57d29ya291dC5taW51dGVzfSBNSU4gwrcge3dvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aH0gRVhFUkNJU0VTPC9zbWFsbD48aDE+e3dvcmtvdXQubmFtZX08L2gxPjxwPkNoZWNrIHlvdXIgc2V0dXAsIHRoZW4gYmVnaW4gd2hlbiB5b3UgZmVlbCByZWFkeS48L3A+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZHktZ3JpZFwiPjxvbD57d29ya291dC5leGVyY2lzZXMubWFwKChleGVyY2lzZSwgaW5kZXgpID0+IDxsaSBrZXk9e2V4ZXJjaXNlLm5hbWV9PjxzcGFuPntTdHJpbmcoaW5kZXggKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9PC9zcGFuPjxzdHJvbmc+e2V4ZXJjaXNlLm5hbWV9PC9zdHJvbmc+PHNtYWxsPntleGVyY2lzZS5wcmVzY3JpcHRpb259PC9zbWFsbD48L2xpPil9PC9vbD48ZGl2IGNsYXNzTmFtZT1cImVxdWlwbWVudC1jaGVja2xpc3RcIj48c21hbGw+RVFVSVBNRU5UIENIRUNLPC9zbWFsbD57ZXF1aXBtZW50SXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4gPGJ1dHRvbiBjbGFzc05hbWU9e2VxdWlwbWVudFJlYWR5W2luZGV4XSA/IFwiY2hlY2tlZFwiIDogXCJcIn0ga2V5PXtpdGVtfSBvbkNsaWNrPXsoKSA9PiBzZXRFcXVpcG1lbnRSZWFkeSgoY3VycmVudCkgPT4gY3VycmVudC5tYXAoKHZhbHVlLCBpdGVtSW5kZXgpID0+IGl0ZW1JbmRleCA9PT0gaW5kZXggPyAhdmFsdWUgOiB2YWx1ZSkpfT48c3Bhbj57ZXF1aXBtZW50UmVhZHlbaW5kZXhdICYmIDxJY29uIG5hbWU9XCJjaGVja1wiIC8+fTwvc3Bhbj57aXRlbX08L2J1dHRvbj4pfTwvZGl2PjwvZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJzYWZldHktbGluZVwiPlN0b3AgaWYgeW91IGZlZWwgZGl6enksIHNoYXJwIHBhaW4sIG9yIGNoZXN0IHBhaW4uIFRoaXMgaXMgZ2VuZXJhbCBmaXRuZXNzIGd1aWRhbmNlLCBub3QgbWVkaWNhbCBhZHZpY2UuPC9wPlxyXG4gICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHsgc2V0Q291bnRkb3duKDMpOyBzZXRTY3JlZW4oXCJjb3VudGRvd25cIik7IH19PkJlZ2luIDxJY29uIG5hbWU9XCJwbGF5XCIgLz48L0J1dHRvbj5cclxuICAgIDwvc2VjdGlvbj59XHJcbiAgICB7c2V0dGluZ3NTaGVldH1cclxuICA8L21haW4+O1xyXG5cclxuICBpZiAoc2NyZWVuID09PSBcImNvbXBsZXRlXCIpIHtcclxuICAgIGNvbnN0IHByb2plY3RlZENvdW50ID0gc3RvcmUuc2Vzc2lvbnMuc29tZSgoc2Vzc2lvbikgPT4gc2Vzc2lvbi53b3Jrb3V0SWQgPT09IHdvcmtvdXQuaWQgJiYgc2Vzc2lvbi5kYXRlID09PSBkYXRlS2V5KG5ldyBEYXRlKCkpKSA/IHN0b3JlLnNlc3Npb25zLmxlbmd0aCA6IHN0b3JlLnNlc3Npb25zLmxlbmd0aCArIDE7XHJcbiAgICBjb25zdCBjb21wbGV0aW9uRGF0ZXMgPSBuZXcgU2V0KFsuLi5zdG9yZS5zZXNzaW9ucy5tYXAoKHNlc3Npb24pID0+IHNlc3Npb24uZGF0ZSksIGRhdGVLZXkobmV3IERhdGUoKSldKTtcclxuICAgIGxldCBjb21wbGV0aW9uU3RyZWFrID0gMDtcclxuICAgIGNvbnN0IHN0cmVha0N1cnNvciA9IG5ldyBEYXRlKCk7XHJcbiAgICB3aGlsZSAoY29tcGxldGlvbkRhdGVzLmhhcyhkYXRlS2V5KHN0cmVha0N1cnNvcikpKSB7XHJcbiAgICAgIGNvbXBsZXRpb25TdHJlYWsgKz0gMTtcclxuICAgICAgc3RyZWFrQ3Vyc29yLnNldERhdGUoc3RyZWFrQ3Vyc29yLmdldERhdGUoKSAtIDEpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY29tcGxldGlvblJlcXVpcmVtZW50czogUmVjb3JkPHN0cmluZywgYm9vbGVhbj4gPSB7XHJcbiAgICAgIFwic3RyZWFrLTNcIjogY29tcGxldGlvblN0cmVhayA+PSAzLFxyXG4gICAgICBcInN0cmVhay03XCI6IGNvbXBsZXRpb25TdHJlYWsgPj0gNyxcclxuICAgICAgXCJzdHJlYWstMTRcIjogY29tcGxldGlvblN0cmVhayA+PSAxNCxcclxuICAgICAgXCJzdHJlYWstMzBcIjogY29tcGxldGlvblN0cmVhayA+PSAzMCxcclxuICAgICAgXCJ3b3Jrb3V0LTFcIjogcHJvamVjdGVkQ291bnQgPj0gMSxcclxuICAgICAgXCJ3b3Jrb3V0LTEwXCI6IHByb2plY3RlZENvdW50ID49IDEwLFxyXG4gICAgICBcIndvcmtvdXQtMjVcIjogcHJvamVjdGVkQ291bnQgPj0gMjUsXHJcbiAgICAgIFwid29ya291dC01MFwiOiBwcm9qZWN0ZWRDb3VudCA+PSA1MCxcclxuICAgIH07XHJcbiAgICBjb25zdCBlYXJuZWRCYWRnZSA9IHN0b3JlLmJhZGdlcy5maW5kKChiYWRnZSkgPT4gIWJhZGdlLnVubG9ja2VkICYmIGNvbXBsZXRpb25SZXF1aXJlbWVudHNbYmFkZ2UuaWRdKTtcclxuICAgIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJzZXNzaW9uLXBsYXllciBjb21wbGV0ZS1zY3JlZW5cIj48aGVhZGVyPntzZXR0aW5nc0J1dHRvbn08L2hlYWRlcj48c2VjdGlvbj48c3BhbiBjbGFzc05hbWU9XCJjb21wbGV0aW9uLW1hcmtcIj48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPjwvc3Bhbj48c21hbGw+REFZIHtNYXRoLm1heCgxLCBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gbmV3IERhdGUoYCR7c3RvcmUuY2hhbGxlbmdlLnN0YXJ0RGF0ZX1UMTI6MDA6MDBgKS5nZXRUaW1lKCkpIC8gODZfNDAwXzAwMCkgKyAxKX08L3NtYWxsPjxoMT5Xb3Jrb3V0IGNvbXBsZXRlPC9oMT48cD5HcmVhdCBqb2Igc2hvd2luZyB1cCB0b2RheS48L3A+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGxldGlvbi1zdGF0c1wiPjxkaXY+PHN0cm9uZz57Zm9ybWF0VGltZShlbGFwc2VkKX08L3N0cm9uZz48c3Bhbj5Ub3RhbCB0aW1lPC9zcGFuPjwvZGl2PjxkaXY+PHN0cm9uZz57aXNSdW5uaW5nID8gcnVuSW5kZXggKyAxIDogTWF0aC5taW4od29ya291dC5leGVyY2lzZXMubGVuZ3RoLCBleGVyY2lzZUluZGV4ICsgMSl9PC9zdHJvbmc+PHNwYW4+e2lzUnVubmluZyA/IFwiSW50ZXJ2YWxzXCIgOiBcIkV4ZXJjaXNlc1wifTwvc3Bhbj48L2Rpdj48ZGl2PjxzdHJvbmc+e2lzUnVubmluZyA/IFwi4oCUXCIgOiBleGVyY2lzZUluZGV4ICogdG90YWxTZXRzICsgc2V0SW5kZXggKyAxfTwvc3Ryb25nPjxzcGFuPlNldHM8L3NwYW4+PC9kaXY+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWFybmVkLWJhbm5lclwiPjxJY29uIG5hbWU9XCJzdGFyXCIgLz48ZGl2PjxzdHJvbmc+e2Vhcm5lZEJhZGdlID8gYCR7ZWFybmVkQmFkZ2UubmFtZX0gYmFkZ2UgdW5sb2NrZWRgIDogXCJZb3VyIHN0cmVhayBpcyBncm93aW5nXCJ9PC9zdHJvbmc+PHNwYW4+U3RyZWFrOiB7Y29tcGxldGlvblN0cmVha30ge2NvbXBsZXRpb25TdHJlYWsgPT09IDEgPyBcImRheVwiIDogXCJkYXlzXCJ9PC9zcGFuPjwvZGl2PjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImVmZm9ydC1yYXRpbmdcIj48c3Ryb25nPkhvdyBkaWQgdGhhdCBmZWVsPzwvc3Ryb25nPjxkaXY+e1tbXCJFYXN5XCIsIDJdLCBbXCJKdXN0IHJpZ2h0XCIsIDNdLCBbXCJIYXJkXCIsIDVdXS5tYXAoKFtsYWJlbCwgdmFsdWVdKSA9PiA8YnV0dG9uIGtleT17U3RyaW5nKGxhYmVsKX0gY2xhc3NOYW1lPXtlZmZvcnQgPT09IHZhbHVlID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldEVmZm9ydChOdW1iZXIodmFsdWUpKX0+e2xhYmVsfTwvYnV0dG9uPil9PC9kaXY+PC9kaXY+XHJcbiAgICAgIHtpc1J1bm5pbmcgJiYgPGxhYmVsIGNsYXNzTmFtZT1cImNvbXBsZXRpb24tZmllbGRcIj5EaXN0YW5jZSAoa20pIMK3IG9wdGlvbmFsPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwXCIgc3RlcD1cIi4xXCIgdmFsdWU9e2Rpc3RhbmNlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREaXN0YW5jZShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjAuMFwiIC8+PC9sYWJlbD59XHJcbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjb21wbGV0aW9uLWZpZWxkXCI+QWRkIGEgbm90ZSDCtyBvcHRpb25hbDx0ZXh0YXJlYSB2YWx1ZT17bm90ZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Tm90ZShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkhvdyBkaWQgdGhlIHNlc3Npb24gZmVlbD9cIiAvPjwvbGFiZWw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGxldGlvbi1hY3Rpb25zXCI+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzYXZlU2Vzc2lvbihmYWxzZSl9PlNhdmUgYW5kIGJhY2sgdG8gZGFzaGJvYXJkPC9CdXR0b24+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzYXZlU2Vzc2lvbihmYWxzZSwgXCIvcHJvZ3Jlc3NcIil9PkxvZyBteSB3ZWlnaHQ8L0J1dHRvbj48L2Rpdj5cclxuICAgIDwvc2VjdGlvbj57c2V0dGluZ3NTaGVldH08L21haW4+O1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdG90YWxSdW5EdXJhdGlvbiA9IHJ1bm5pbmdTZWdtZW50cy5yZWR1Y2UoKHN1bSwgc2VnbWVudCkgPT4gc3VtICsgc2VnbWVudC5kdXJhdGlvbiwgMCk7XHJcbiAgY29uc3QgcnVuUmVtYWluaW5nID0gcnVubmluZ1NlZ21lbnRzLnNsaWNlKHJ1bkluZGV4ICsgMSkucmVkdWNlKChzdW0sIHNlZ21lbnQpID0+IHN1bSArIHNlZ21lbnQuZHVyYXRpb24sIDApICsgcmVtYWluaW5nO1xyXG4gIGNvbnN0IHByb2dyZXNzID0gaXNSdW5uaW5nID8gKCh0b3RhbFJ1bkR1cmF0aW9uIC0gcnVuUmVtYWluaW5nKSAvIHRvdGFsUnVuRHVyYXRpb24pICogMTAwIDogKChleGVyY2lzZUluZGV4ICsgKHBoYXNlID09PSBcInJlc3RcIiA/IC44IDogLjI1KSkgLyB3b3Jrb3V0LmV4ZXJjaXNlcy5sZW5ndGgpICogMTAwO1xyXG4gIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJzZXNzaW9uLXBsYXllciBhY3RpdmUtcGxheWVyXCI+XHJcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImFjdGl2ZS10b3BiYXJcIj48YnV0dG9uIGNsYXNzTmFtZT1cInBsYXllci1pY29uLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dFbmQodHJ1ZSl9IGFyaWEtbGFiZWw9XCJFbmQgd29ya291dFwiPjxJY29uIG5hbWU9XCJjbG9zZVwiIC8+PC9idXR0b24+PGRpdj48c3Ryb25nPnt3b3Jrb3V0Lm5hbWV9PC9zdHJvbmc+PHNwYW4+e2lzUnVubmluZyA/IGBTZWdtZW50ICR7cnVuSW5kZXggKyAxfSBvZiAke3J1bm5pbmdTZWdtZW50cy5sZW5ndGh9YCA6IGBFeGVyY2lzZSAke2V4ZXJjaXNlSW5kZXggKyAxfSBvZiAke3dvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aH1gfTwvc3Bhbj48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJlbGFwc2VkLXRpbWVcIj57Zm9ybWF0VGltZShlbGFwc2VkKX08L3NwYW4+e3NldHRpbmdzQnV0dG9ufTxkaXYgY2xhc3NOYW1lPVwib3ZlcmFsbC1wcm9ncmVzc1wiPjxpIHN0eWxlPXt7IHdpZHRoOiBgJHtNYXRoLm1heCgyLCBwcm9ncmVzcyl9JWAgfX0gLz48L2Rpdj48L2hlYWRlcj5cclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImFjdGl2ZS1jb250ZW50XCI+XHJcbiAgICAgIHtpc1J1bm5pbmcgPyA8ZGl2IGNsYXNzTmFtZT1cInJ1bm5pbmctcGhhc2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHBoYXNlLWxhYmVsICR7cGhhc2VMYWJlbC50b0xvd2VyQ2FzZSgpfWB9PjxJY29uIG5hbWU9e3BoYXNlTGFiZWwgPT09IFwiSk9HXCIgPyBcImJvbHRcIiA6IFwid2Fsa1wifSAvPntwaGFzZUxhYmVsfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGltZXItcmluZyAke3BoYXNlTGFiZWwudG9Mb3dlckNhc2UoKX1gfT48c3Ryb25nPntmb3JtYXRUaW1lKHJlbWFpbmluZyl9PC9zdHJvbmc+PHNwYW4+e3J1bm5pbmdTZWdtZW50c1tydW5JbmRleF0ubmFtZX08L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGgyPntydW5JbmRleCA9PT0gMCA/IFwiV2FybS11cFwiIDogcnVuSW5kZXggPT09IHJ1bm5pbmdTZWdtZW50cy5sZW5ndGggLSAxID8gXCJDb29sLWRvd25cIiA6IGBJbnRlcnZhbCAke01hdGguY2VpbChydW5JbmRleCAvIDIpfSBvZiA4YH08L2gyPjxwPntwaGFzZUxhYmVsID09PSBcIkpPR1wiID8gXCJFYXN5IHBhY2UuIFlvdSBzaG91bGQgYmUgYWJsZSB0byBob2xkIGEgY29udmVyc2F0aW9uLlwiIDogXCJCcmlzayB3YWxrLCBsZXQgeW91ciBicmVhdGhpbmcgc2V0dGxlLlwifTwvcD5cclxuICAgICAgICB7cmVtYWluaW5nIDw9IDMgJiYgcnVuSW5kZXggPCBydW5uaW5nU2VnbWVudHMubGVuZ3RoIC0gMSAmJiA8ZGl2IGNsYXNzTmFtZT1cInRyYW5zaXRpb24tY2FsbG91dFwiPntydW5uaW5nU2VnbWVudHNbcnVuSW5kZXggKyAxXS5sYWJlbCA9PT0gXCJKT0dcIiA/IFwiSm9nXCIgOiBcIldhbGtcIn0gaW4ge3JlbWFpbmluZ308L2Rpdj59XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e2BpbmRvb3ItdG9nZ2xlICR7aW5kb29yID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH0gb25DbGljaz17KCkgPT4gc2V0SW5kb29yKCh2YWx1ZSkgPT4gIXZhbHVlKX0+PHNwYW4+e2luZG9vciAmJiA8SWNvbiBuYW1lPVwiY2hlY2tcIiAvPn08L3NwYW4+Tm8gc3BhY2Ugb3IgaG90IHdlYXRoZXI/IE1hcmNoIG9yIGpvZyBpbiBwbGFjZS48L2J1dHRvbj5cclxuICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwib3V0ZG9vci10aXBcIj5JbiB3YXJtIHdlYXRoZXIsIGdvIGVhcmx5IG1vcm5pbmcgb3IgZXZlbmluZyBhbmQgYnJpbmcgd2F0ZXIuPC9zbWFsbD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJ1bi10aW1lc1wiPjxzcGFuPlRvdGFsIGVsYXBzZWQgPHN0cm9uZz57Zm9ybWF0VGltZShlbGFwc2VkKX08L3N0cm9uZz48L3NwYW4+PHNwYW4+UmVtYWluaW5nIDxzdHJvbmc+e2Zvcm1hdFRpbWUocnVuUmVtYWluaW5nKX08L3N0cm9uZz48L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWdtZW50LXRpbWVsaW5lXCI+e3J1bm5pbmdTZWdtZW50cy5tYXAoKHNlZ21lbnQsIGluZGV4KSA9PiA8aSBrZXk9e2luZGV4fSBjbGFzc05hbWU9e2luZGV4ID09PSBydW5JbmRleCA/IFwiY3VycmVudFwiIDogaW5kZXggPCBydW5JbmRleCA/IFwiZG9uZVwiIDogXCJcIn0gdGl0bGU9e3NlZ21lbnQubmFtZX0gLz4pfTwvZGl2PlxyXG4gICAgICA8L2Rpdj4gOiBwaGFzZSA9PT0gXCJyZXN0XCIgPyA8ZGl2IGNsYXNzTmFtZT1cInJlc3QtcGhhc2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWVyLXJpbmcgcmVzdFwiPjxkaXYgY2xhc3NOYW1lPVwicGhhc2UtbGFiZWwgcmVzdFwiPjxJY29uIG5hbWU9XCJ0aW1lclwiIC8+UkVTVDwvZGl2PjxzdHJvbmc+e3JlbWFpbmluZ308L3N0cm9uZz48c3Bhbj5zZWNvbmRzPC9zcGFuPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJlYXRoaW5nLWNvcHlcIj48c3BhbiAvPjxzdHJvbmc+QnJlYXRoZSBpbi4uLiBicmVhdGhlIG91dC4uLjwvc3Ryb25nPjxzbWFsbD5TaXAgc29tZSB3YXRlcjwvc21hbGw+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXN0LWFjdGlvbnNcIj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFJlbWFpbmluZygodmFsdWUpID0+IHZhbHVlICsgMTUpfT4rMTVzPC9idXR0b24+PGJ1dHRvbiBvbkNsaWNrPXtmaW5pc2hSZXN0fT5Ta2lwIHJlc3Q8L2J1dHRvbj48L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5leHQtdXAtY2FyZFwiPjxzbWFsbD5ORVhUIFVQPC9zbWFsbD48c3Ryb25nPntzZXRJbmRleCArIDEgPCB0b3RhbFNldHMgPyBkaXNwbGF5TmFtZSA6IHdvcmtvdXQuZXhlcmNpc2VzW2V4ZXJjaXNlSW5kZXggKyAxXT8ubmFtZSB8fCBcIkZpbmlzaCBzdHJvbmdcIn08L3N0cm9uZz48c3Bhbj57c2V0SW5kZXggKyAxIDwgdG90YWxTZXRzID8gYFNldCAke3NldEluZGV4ICsgMn0gb2YgJHt0b3RhbFNldHN9YCA6IHdvcmtvdXQuZXhlcmNpc2VzW2V4ZXJjaXNlSW5kZXggKyAxXT8ucHJlc2NyaXB0aW9ufTwvc3Bhbj48L2Rpdj5cclxuICAgICAgPC9kaXY+IDogaXNUaW1lZCA/IDxkaXYgY2xhc3NOYW1lPVwidGltZWQtcGhhc2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWVyLXJpbmcgd29ya1wiPjxkaXYgY2xhc3NOYW1lPVwicGhhc2UtbGFiZWwgd29ya1wiPjxJY29uIG5hbWU9XCJib2x0XCIgLz5XT1JLPC9kaXY+PHN0cm9uZz57cmVtYWluaW5nfTwvc3Ryb25nPjxzcGFuPnNlY29uZHM8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGgxPntkaXNwbGF5TmFtZX08L2gxPjxwPlJvdW5kIHtzZXRJbmRleCArIDF9IG9mIHt0b3RhbFNldHN9PC9wPlxyXG4gICAgICA8L2Rpdj4gOiA8ZGl2IGNsYXNzTmFtZT1cInJlcHMtcGhhc2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4ZXJjaXNlLWlsbHVzdHJhdGlvblwiPjxJY29uIG5hbWU9XCJkdW1iYmVsbFwiIC8+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJwaGFzZS1sYWJlbCB3b3JrXCI+PEljb24gbmFtZT1cImJvbHRcIiAvPldPUks8L2Rpdj48aDE+e2Rpc3BsYXlOYW1lfTwvaDE+PHA+U2V0IHtzZXRJbmRleCArIDF9IG9mIHt0b3RhbFNldHN9IMK3IDxzdHJvbmc+MTIgcmVwczwvc3Ryb25nPjwvcD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcC1jb3VudGVyXCI+PHNwYW4+e3JlcHN9PC9zcGFuPjxidXR0b24gb25DbGljaz17KCkgPT4gc2V0UmVwcygodmFsdWUpID0+IHZhbHVlICsgMSl9IGFyaWEtbGFiZWw9XCJBZGQgcmVwZXRpdGlvblwiPis8L2J1dHRvbj48L2Rpdj48QnV0dG9uIG9uQ2xpY2s9e2ZpbmlzaFdvcmt9PkRvbmUgc2V0PC9CdXR0b24+XHJcbiAgICAgICAgPHVsPjxsaT5CcmFjZSB5b3VyIGNvcmUgYmVmb3JlIGVhY2ggcmVwPC9saT48bGk+TW92ZSB0aHJvdWdoIGEgY29tZm9ydGFibGUgcmFuZ2U8L2xpPjxsaT5FeGhhbGUgdGhyb3VnaCB0aGUgZWZmb3J0PC9saT48L3VsPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmV4dC11cC1jaGlwXCI+TmV4dCB1cDoge3NldEluZGV4ICsgMSA8IHRvdGFsU2V0cyA/IGBSZXN0LCB0aGVuIHNldCAke3NldEluZGV4ICsgMn1gIDogd29ya291dC5leGVyY2lzZXNbZXhlcmNpc2VJbmRleCArIDFdPy5uYW1lIHx8IFwiQ29vbCBkb3duXCJ9PC9kaXY+XHJcbiAgICAgIDwvZGl2Pn1cclxuICAgICAgeyFpc1J1bm5pbmcgJiYgcGhhc2UgPT09IFwid29ya1wiICYmIDxkaXYgY2xhc3NOYW1lPVwic2Vzc2lvbi1vcHRpb25zXCI+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTZXNzaW9uU3dhcHMoeyAuLi5zZXNzaW9uU3dhcHMsIFtleGVyY2lzZUluZGV4XTogYEVhc2llciAke2N1cnJlbnRFeGVyY2lzZS5uYW1lLnRvTG93ZXJDYXNlKCl9YCB9KX0+RWFzaWVyIG9wdGlvbjwvYnV0dG9uPjxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2Vzc2lvblN3YXBzKHsgLi4uc2Vzc2lvblN3YXBzLCBbZXhlcmNpc2VJbmRleF06IGBMb3ctaW1wYWN0ICR7Y3VycmVudEV4ZXJjaXNlLm5hbWUudG9Mb3dlckNhc2UoKX1gIH0pfT5Mb3ctaW1wYWN0IG9wdGlvbjwvYnV0dG9uPjwvZGl2Pn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdWUtYmFubmVyXCIga2V5PXtgJHtleGVyY2lzZUluZGV4fS0ke2N1ZUluZGV4fWB9PjxzbWFsbD5DVUU8L3NtYWxsPjxzdHJvbmc+e2lzUnVubmluZyA/IChwaGFzZUxhYmVsID09PSBcIkpPR1wiID8gXCJSZWxheCB5b3VyIHNob3VsZGVycyBhbmQgZmluZCB5b3VyIHJoeXRobVwiIDogXCJMZXQgeW91ciBicmVhdGhpbmcgc2V0dGxlXCIpIDogY3Vlc1tjdWVJbmRleCAlIGN1ZXMubGVuZ3RoXX08L3N0cm9uZz48L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwicGxheWVyLWNvbnRyb2xzXCI+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBpc1J1bm5pbmcgPyBtb3ZlUnVuU2VnbWVudCgtMSkgOiBhZHZhbmNlRXhlcmNpc2UoLTEpfT48SWNvbiBuYW1lPVwiYmFja1wiIC8+UHJldmlvdXM8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cInBhdXNlLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFBhdXNlZCgodmFsdWUpID0+ICF2YWx1ZSl9PntwYXVzZWQgPyA8SWNvbiBuYW1lPVwicGxheVwiIC8+IDogPEljb24gbmFtZT1cInBhdXNlXCIgLz59e3BhdXNlZCA/IFwiUmVzdW1lXCIgOiBcIlBhdXNlXCJ9PC9idXR0b24+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBpc1J1bm5pbmcgPyBmaW5pc2hSdW5TZWdtZW50KCkgOiBhZHZhbmNlRXhlcmNpc2UoKX0+U2tpcDxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PC9idXR0b24+PGJ1dHRvbiBjbGFzc05hbWU9e211dGVkID8gXCJtdXRlZFwiIDogXCJcIn0gb25DbGljaz17KCkgPT4gc2V0TXV0ZWQoKHZhbHVlKSA9PiAhdmFsdWUpfSBhcmlhLWxhYmVsPXttdXRlZCA/IFwiVW5tdXRlIHNlc3Npb25cIiA6IFwiTXV0ZSBzZXNzaW9uXCJ9PjxJY29uIG5hbWU9XCJ2b2x1bWVcIiAvPjwvYnV0dG9uPjwvZm9vdGVyPlxyXG4gICAge3Nob3dFbmQgJiYgPGRpdiBjbGFzc05hbWU9XCJwbGF5ZXItbW9kYWwtYmFja2Ryb3BcIj48ZGl2IGNsYXNzTmFtZT1cImVuZC1kaWFsb2dcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48c3BhbiBjbGFzc05hbWU9XCJkYXNoLXN0YXQtaWNvblwiPjxJY29uIG5hbWU9XCJ0aW1lclwiIC8+PC9zcGFuPjxoMj5FbmQgd29ya291dD88L2gyPjxwPllvdSBjYW4ga2VlcCBnb2luZywgc2F2ZSB3aGF0IHlvdSBjb21wbGV0ZWQsIG9yIGRpc2NhcmQgdGhpcyBzZXNzaW9uLjwvcD48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dFbmQoZmFsc2UpfT5LZWVwIGdvaW5nPC9CdXR0b24+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBzYXZlU2Vzc2lvbih0cnVlKX0+U2F2ZSBwYXJ0aWFsIHNlc3Npb248L0J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImRpc2NhcmQtYWN0aW9uXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvd29ya291dHNcIil9PkRpc2NhcmQ8L2J1dHRvbj48L2Rpdj48L2Rpdj59XHJcbiAgICB7c2V0dGluZ3NTaGVldH1cclxuICA8L21haW4+O1xyXG59Il19