import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/ReviewCarousel.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { reviews } from "/src/frontend/data/reviews.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/ReviewCarousel.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function ReviewCarousel() {
	_s();
	const [activeReview, setActiveReview] = useState(0);
	const [isPaused, setIsPaused] = useState(false);
	const touchStart = useRef(null);
	useEffect(() => {
		if (isPaused) return;
		const interval = window.setInterval(() => {
			setActiveReview((current) => (current + 1) % reviews.length);
		}, 5e3);
		return () => window.clearInterval(interval);
	}, [isPaused]);
	const finishSwipe = (clientX) => {
		if (touchStart.current === null) return;
		const distance = clientX - touchStart.current;
		if (Math.abs(distance) > 45) {
			setActiveReview((current) => distance < 0 ? (current + 1) % reviews.length : (current - 1 + reviews.length) % reviews.length);
		}
		touchStart.current = null;
	};
	const review = reviews[activeReview];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "review-carousel",
		onMouseEnter: () => setIsPaused(true),
		onMouseLeave: () => setIsPaused(false),
		onTouchStart: (event) => {
			touchStart.current = event.touches[0].clientX;
		},
		onTouchEnd: (event) => finishSwipe(event.changedTouches[0].clientX),
		"aria-label": "Member reviews",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "review-slide",
			"aria-live": "polite",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: `review-avatar avatar-${activeReview + 1}`,
				children: review.initials
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "review-content",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "review-meta",
					children: [/* @__PURE__ */ _jsxDEV("strong", { children: review.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "review-stars",
						"aria-label": "5 out of 5 stars",
						children: [
							0,
							1,
							2,
							3,
							4
						].map((star) => /* @__PURE__ */ _jsxDEV(Icon, { name: "star" }, star, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 46
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: review.comment }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "review-dots",
			"aria-label": "Choose a review",
			children: reviews.map((item, index) => /* @__PURE__ */ _jsxDEV("button", {
				className: activeReview === index ? "active" : "",
				onClick: () => setActiveReview(index),
				"aria-label": `Show review ${index + 1}`,
				"aria-current": activeReview === index ? "true" : undefined
			}, item.name, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 5
	}, this);
}
_s(ReviewCarousel, "HkyWK1KsjjjlQL3Ay5BYyZxM1sM=");
_c = ReviewCarousel;
var _c;
$RefreshReg$(_c, "ReviewCarousel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/ReviewCarousel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/ReviewCarousel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/ReviewCarousel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/ReviewCarousel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsWUFBWTtBQUNyQixTQUFTLGVBQWU7Ozs7QUFFeEIsT0FBTyxTQUFTLGlCQUFpQjs7Q0FDL0IsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQztDQUNsRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUM5QyxNQUFNLGFBQWEsT0FBc0IsSUFBSTtDQUU3QyxnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7RUFDZCxNQUFNLFdBQVcsT0FBTyxrQkFBa0I7R0FDeEMsaUJBQWlCLGFBQWEsVUFBVSxLQUFLLFFBQVEsTUFBTTtFQUM3RCxHQUFHLEdBQUk7RUFDUCxhQUFhLE9BQU8sY0FBYyxRQUFRO0NBQzVDLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FFYixNQUFNLGVBQWUsWUFBb0I7RUFDdkMsSUFBSSxXQUFXLFlBQVksTUFBTTtFQUNqQyxNQUFNLFdBQVcsVUFBVSxXQUFXO0VBQ3RDLElBQUksS0FBSyxJQUFJLFFBQVEsSUFBSSxJQUFJO0dBQzNCLGlCQUFpQixZQUNmLFdBQVcsS0FDTixVQUFVLEtBQUssUUFBUSxVQUN2QixVQUFVLElBQUksUUFBUSxVQUFVLFFBQVEsTUFDOUM7RUFDSDtFQUNBLFdBQVcsVUFBVTtDQUN2QjtDQUVBLE1BQU0sU0FBUyxRQUFRO0NBRXZCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVU7RUFDVixvQkFBb0IsWUFBWSxJQUFJO0VBQ3BDLG9CQUFvQixZQUFZLEtBQUs7RUFDckMsZUFBZSxVQUFVO0dBQUUsV0FBVyxVQUFVLE1BQU0sUUFBUSxFQUFFLENBQUM7RUFBUztFQUMxRSxhQUFhLFVBQVUsWUFBWSxNQUFNLGVBQWUsRUFBRSxDQUFDLE9BQU87RUFDbEUsY0FBVztZQU5iLENBUUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBZSxhQUFVO2FBQXhDLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVcsd0JBQXdCLGVBQWU7Y0FBTSxPQUFPO0dBQWU7Ozs7YUFDcEYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFELFlBQVMsT0FBTyxLQUFhOzs7O2VBQzdCLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQWUsY0FBVztnQkFDdkM7T0FBQztPQUFHO09BQUc7T0FBRztPQUFHO01BQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyx3QkFBQyxNQUFELEVBQWlCLE1BQUssT0FBUSxHQUFuQjs7OzthQUFtQixDQUFDO0tBQzFEOzs7O2FBQ0g7Ozs7O2NBQ0wsd0JBQUMsS0FBRCxZQUFJLE9BQU8sUUFBVzs7OztZQUNuQjs7Ozs7V0FDRjs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFjLGNBQVc7YUFDckMsUUFBUSxLQUFLLE1BQU0sVUFDbEIsd0JBQUMsVUFBRDtJQUVFLFdBQVcsaUJBQWlCLFFBQVEsV0FBVztJQUMvQyxlQUFlLGdCQUFnQixLQUFLO0lBQ3BDLGNBQVksZUFBZSxRQUFRO0lBQ25DLGdCQUFjLGlCQUFpQixRQUFRLFNBQVM7R0FDakQsR0FMTSxLQUFLOzs7O1VBS1gsQ0FDRjtFQUNFOzs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJldmlld0Nhcm91c2VsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuL0ljb25cIjtcclxuaW1wb3J0IHsgcmV2aWV3cyB9IGZyb20gXCIuLi9kYXRhL3Jldmlld3NcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZXZpZXdDYXJvdXNlbCgpIHtcclxuICBjb25zdCBbYWN0aXZlUmV2aWV3LCBzZXRBY3RpdmVSZXZpZXddID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2lzUGF1c2VkLCBzZXRJc1BhdXNlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgdG91Y2hTdGFydCA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpc1BhdXNlZCkgcmV0dXJuO1xyXG4gICAgY29uc3QgaW50ZXJ2YWwgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICBzZXRBY3RpdmVSZXZpZXcoKGN1cnJlbnQpID0+IChjdXJyZW50ICsgMSkgJSByZXZpZXdzLmxlbmd0aCk7XHJcbiAgICB9LCA1MDAwKTtcclxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XHJcbiAgfSwgW2lzUGF1c2VkXSk7XHJcblxyXG4gIGNvbnN0IGZpbmlzaFN3aXBlID0gKGNsaWVudFg6IG51bWJlcikgPT4ge1xyXG4gICAgaWYgKHRvdWNoU3RhcnQuY3VycmVudCA9PT0gbnVsbCkgcmV0dXJuO1xyXG4gICAgY29uc3QgZGlzdGFuY2UgPSBjbGllbnRYIC0gdG91Y2hTdGFydC5jdXJyZW50O1xyXG4gICAgaWYgKE1hdGguYWJzKGRpc3RhbmNlKSA+IDQ1KSB7XHJcbiAgICAgIHNldEFjdGl2ZVJldmlldygoY3VycmVudCkgPT4gKFxyXG4gICAgICAgIGRpc3RhbmNlIDwgMFxyXG4gICAgICAgICAgPyAoY3VycmVudCArIDEpICUgcmV2aWV3cy5sZW5ndGhcclxuICAgICAgICAgIDogKGN1cnJlbnQgLSAxICsgcmV2aWV3cy5sZW5ndGgpICUgcmV2aWV3cy5sZW5ndGhcclxuICAgICAgKSk7XHJcbiAgICB9XHJcbiAgICB0b3VjaFN0YXJ0LmN1cnJlbnQgPSBudWxsO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJldmlldyA9IHJldmlld3NbYWN0aXZlUmV2aWV3XTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPVwicmV2aWV3LWNhcm91c2VsXCJcclxuICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRJc1BhdXNlZCh0cnVlKX1cclxuICAgICAgb25Nb3VzZUxlYXZlPXsoKSA9PiBzZXRJc1BhdXNlZChmYWxzZSl9XHJcbiAgICAgIG9uVG91Y2hTdGFydD17KGV2ZW50KSA9PiB7IHRvdWNoU3RhcnQuY3VycmVudCA9IGV2ZW50LnRvdWNoZXNbMF0uY2xpZW50WDsgfX1cclxuICAgICAgb25Ub3VjaEVuZD17KGV2ZW50KSA9PiBmaW5pc2hTd2lwZShldmVudC5jaGFuZ2VkVG91Y2hlc1swXS5jbGllbnRYKX1cclxuICAgICAgYXJpYS1sYWJlbD1cIk1lbWJlciByZXZpZXdzXCJcclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctc2xpZGVcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2ByZXZpZXctYXZhdGFyIGF2YXRhci0ke2FjdGl2ZVJldmlldyArIDF9YH0+e3Jldmlldy5pbml0aWFsc308L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctY29udGVudFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctbWV0YVwiPlxyXG4gICAgICAgICAgICA8c3Ryb25nPntyZXZpZXcubmFtZX08L3N0cm9uZz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmV2aWV3LXN0YXJzXCIgYXJpYS1sYWJlbD1cIjUgb3V0IG9mIDUgc3RhcnNcIj5cclxuICAgICAgICAgICAgICB7WzAsIDEsIDIsIDMsIDRdLm1hcCgoc3RhcikgPT4gPEljb24ga2V5PXtzdGFyfSBuYW1lPVwic3RhclwiIC8+KX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cD57cmV2aWV3LmNvbW1lbnR9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXZpZXctZG90c1wiIGFyaWEtbGFiZWw9XCJDaG9vc2UgYSByZXZpZXdcIj5cclxuICAgICAgICB7cmV2aWV3cy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17aXRlbS5uYW1lfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2FjdGl2ZVJldmlldyA9PT0gaW5kZXggPyBcImFjdGl2ZVwiIDogXCJcIn1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlUmV2aWV3KGluZGV4KX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YFNob3cgcmV2aWV3ICR7aW5kZXggKyAxfWB9XHJcbiAgICAgICAgICAgIGFyaWEtY3VycmVudD17YWN0aXZlUmV2aWV3ID09PSBpbmRleCA/IFwidHJ1ZVwiIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==