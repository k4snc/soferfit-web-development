import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/Icon.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Icon.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function Icon({ name }) {
	const paths = {
		arrow: /* @__PURE__ */ _jsxDEV("path", { d: "M5 12h14M14 7l5 5-5 5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 3,
			columnNumber: 12
		}, this),
		back: /* @__PURE__ */ _jsxDEV("path", { d: "M19 12H5m5-5-5 5 5 5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 11
		}, this),
		play: /* @__PURE__ */ _jsxDEV("path", { d: "m9 7 7 5-7 5V7Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 5,
			columnNumber: 11
		}, this),
		spark: /* @__PURE__ */ _jsxDEV("path", { d: "m12 2 1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 12
		}, this),
		calendar: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("rect", {
			x: "4",
			y: "5",
			width: "16",
			height: "15",
			rx: "2"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 17
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M8 3v4m8-4v4M4 10h16" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 67
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 15
		}, this),
		chart: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M5 19V9m7 10V5m7 14v-7" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 14
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M3 19h18" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 49
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 12
		}, this),
		bolt: /* @__PURE__ */ _jsxDEV("path", { d: "m13 2-8 12h7l-1 8 8-13h-7l1-7Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 11
		}, this),
		check: /* @__PURE__ */ _jsxDEV("path", { d: "m5 12 4 4L19 6" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 12
		}, this),
		star: /* @__PURE__ */ _jsxDEV("path", { d: "m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 11
		}, this),
		eye: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M2.5 12s3.5-5 9.5-5 9.5 5 9.5 5-3.5 5-9.5 5-9.5-5-9.5-5Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 12
		}, this), /* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "12",
			r: "2.5"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 81
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 10
		}, this),
		eyeOff: /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("path", { d: "m3 3 18 18M10.6 7.2A10 10 0 0 1 12 7c6 0 9.5 5 9.5 5a14 14 0 0 1-2.1 2.5M6.4 6.4C3.9 8 2.5 12 2.5 12s3.5 5 9.5 5c1.1 0 2.2-.2 3.1-.5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 15
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 13
		}, this),
		dumbbell: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M7 9v6M4.5 8v8M17 9v6M19.5 8v8M7 12h10" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 17
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M3 10v4m18-4v4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 68
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 15
		}, this),
		camera: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M4 8h3l1.5-2h7L17 8h3v10H4V8Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "13",
			r: "3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 57
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 13
		}, this),
		flame: /* @__PURE__ */ _jsxDEV("path", { d: "M13.5 2.5c.5 4-2.5 5-2 8 1-1 2-2 2.5-3 2.5 2 4 4.2 4 7a6 6 0 0 1-12 0c0-3.4 2-6.2 5.3-9-.2 2 .4 3.1 1.2 3.8.2-2.3.8-4.5 1-6.8Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 12
		}, this),
		clipboard: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("rect", {
			x: "5",
			y: "5",
			width: "14",
			height: "16",
			rx: "2"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 18
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M9 5V3h6v2M9 11h6m-6 4h6" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 68
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 16
		}, this),
		sliders: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("path", { d: "M4 7h10m4 0h2M4 17h2m4 0h10M8 14v6m8-16v6" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 16
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "16",
				cy: "7",
				r: "2"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 70
			}, this),
			/* @__PURE__ */ _jsxDEV("circle", {
				cx: "8",
				cy: "17",
				r: "2"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 101
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 14
		}, this),
		timer: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "13",
			r: "8"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 14
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M12 9v4l3 2M9 2h6m-3 0v3" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 46
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 12
		}, this),
		user: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "8",
			r: "4"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M4 21c.8-4.2 3.5-6 8-6s7.2 1.8 8 6" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 44
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 11
		}, this),
		logout: /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("path", { d: "M10 4H5v16h5M14 8l4 4-4 4m4-4H9" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 15
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 13
		}, this),
		gear: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("circle", {
			cx: "12",
			cy: "12",
			r: "3"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 45
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 11
		}, this),
		close: /* @__PURE__ */ _jsxDEV("path", { d: "m6 6 12 12M18 6 6 18" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 12
		}, this),
		pause: /* @__PURE__ */ _jsxDEV("path", { d: "M9 5v14m6-14v14" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 12
		}, this),
		volume: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M5 10v4h3l4 3V7l-4 3H5Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 15
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M16 9c1.5 1.7 1.5 4.3 0 6m2-8c2.8 2.8 2.8 7.2 0 10" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 51
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 13
		}, this),
		walk: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("circle", {
			cx: "13",
			cy: "4",
			r: "2"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "m10 22 2-7-3-3 2-5 4 3 3 1M6 22l3-6m5-2 3 8" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 44
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 11
		}, this),
		moon: /* @__PURE__ */ _jsxDEV("path", { d: "M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 11
		}, this),
		book: /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("path", { d: "M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22V5.5Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22V5.5Z" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 86
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 11
		}, this)
	};
	return /* @__PURE__ */ _jsxDEV("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: paths[name]
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 10
	}, this);
}
_c = Icon;
var _c;
$RefreshReg$(_c, "Icon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/Icon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Icon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Icon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Icon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsS0FBSyxFQUFFLFFBQTBSO0NBQy9TLE1BQU0sUUFBUTtFQUNaLE9BQU8sd0JBQUMsUUFBRCxFQUFNLEdBQUUsd0JBQXlCOzs7OztFQUN4QyxNQUFNLHdCQUFDLFFBQUQsRUFBTSxHQUFFLHVCQUF3Qjs7Ozs7RUFDdEMsTUFBTSx3QkFBQyxRQUFELEVBQU0sR0FBRSxrQkFBbUI7Ozs7O0VBQ2pDLE9BQU8sd0JBQUMsUUFBRCxFQUFNLEdBQUUsaUVBQWtFOzs7OztFQUNqRixVQUFVLGdEQUFFLHdCQUFDLFFBQUQ7R0FBTSxHQUFFO0dBQUksR0FBRTtHQUFJLE9BQU07R0FBSyxRQUFPO0dBQUssSUFBRztFQUFLOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsdUJBQXdCOzs7O1VBQUc7Ozs7O0VBQ2pHLE9BQU8sZ0RBQUUsd0JBQUMsUUFBRCxFQUFNLEdBQUUseUJBQTBCOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsV0FBWTs7OztVQUFHOzs7OztFQUNuRSxNQUFNLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGlDQUFrQzs7Ozs7RUFDaEQsT0FBTyx3QkFBQyxRQUFELEVBQU0sR0FBRSxpQkFBa0I7Ozs7O0VBQ2pDLE1BQU0sd0JBQUMsUUFBRCxFQUFNLEdBQUUsNkVBQThFOzs7OztFQUM1RixLQUFLLGdEQUFFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDJEQUE0RDs7OztZQUFDLHdCQUFDLFVBQUQ7R0FBUSxJQUFHO0dBQUssSUFBRztHQUFLLEdBQUU7RUFBTzs7OztVQUFHOzs7OztFQUNoSCxRQUFRLCtDQUFFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLHVJQUF3STs7OztXQUFHOzs7OztFQUM3SixVQUFVLGdEQUFFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLHlDQUEwQzs7OztZQUFDLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGlCQUFrQjs7OztVQUFHOzs7OztFQUM1RixRQUFRLGdEQUFFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGdDQUFpQzs7OztZQUFDLHdCQUFDLFVBQUQ7R0FBUSxJQUFHO0dBQUssSUFBRztHQUFLLEdBQUU7RUFBSzs7OztVQUFHOzs7OztFQUN0RixPQUFPLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGlJQUFrSTs7Ozs7RUFDakosV0FBVyxnREFBRSx3QkFBQyxRQUFEO0dBQU0sR0FBRTtHQUFJLEdBQUU7R0FBSSxPQUFNO0dBQUssUUFBTztHQUFLLElBQUc7RUFBSzs7OztZQUFDLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDJCQUE0Qjs7OztVQUFHOzs7OztFQUN0RyxTQUFTO0dBQUUsd0JBQUMsUUFBRCxFQUFNLEdBQUUsNENBQTZDOzs7OztHQUFDLHdCQUFDLFVBQUQ7SUFBUSxJQUFHO0lBQUssSUFBRztJQUFJLEdBQUU7R0FBSzs7Ozs7R0FBQyx3QkFBQyxVQUFEO0lBQVEsSUFBRztJQUFJLElBQUc7SUFBSyxHQUFFO0dBQUs7Ozs7O0VBQUc7Ozs7O0VBQ2pJLE9BQU8sZ0RBQUUsd0JBQUMsVUFBRDtHQUFRLElBQUc7R0FBSyxJQUFHO0dBQUssR0FBRTtFQUFLOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsMkJBQTRCOzs7O1VBQUc7Ozs7O0VBQ2hGLE1BQU0sZ0RBQUUsd0JBQUMsVUFBRDtHQUFRLElBQUc7R0FBSyxJQUFHO0dBQUksR0FBRTtFQUFLOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUscUNBQXNDOzs7O1VBQUc7Ozs7O0VBQ3hGLFFBQVEsK0NBQUUsd0JBQUMsUUFBRCxFQUFNLEdBQUUsa0NBQW1DOzs7O1dBQUc7Ozs7O0VBQ3hELE1BQU0sZ0RBQUUsd0JBQUMsVUFBRDtHQUFRLElBQUc7R0FBSyxJQUFHO0dBQUssR0FBRTtFQUFLOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsNGJBQTZiOzs7O1VBQUc7Ozs7O0VBQ2hmLE9BQU8sd0JBQUMsUUFBRCxFQUFNLEdBQUUsdUJBQXdCOzs7OztFQUN2QyxPQUFPLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGtCQUFtQjs7Ozs7RUFDbEMsUUFBUSxnREFBRSx3QkFBQyxRQUFELEVBQU0sR0FBRSwwQkFBMkI7Ozs7WUFBQyx3QkFBQyxRQUFELEVBQU0sR0FBRSxxREFBc0Q7Ozs7VUFBRzs7Ozs7RUFDL0csTUFBTSxnREFBRSx3QkFBQyxVQUFEO0dBQVEsSUFBRztHQUFLLElBQUc7R0FBSSxHQUFFO0VBQUs7Ozs7WUFBQyx3QkFBQyxRQUFELEVBQU0sR0FBRSw4Q0FBK0M7Ozs7VUFBRzs7Ozs7RUFDakcsTUFBTSx3QkFBQyxRQUFELEVBQU0sR0FBRSxzREFBdUQ7Ozs7O0VBQ3JFLE1BQU0sZ0RBQUUsd0JBQUMsUUFBRCxFQUFNLEdBQUUsK0RBQWdFOzs7O1lBQUMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsa0VBQW1FOzs7O1VBQUc7Ozs7O0NBQ2pLO0NBQ0EsT0FBTyx3QkFBQyxPQUFEO0VBQUssU0FBUTtFQUFZLGVBQVk7WUFBUSxNQUFNO0NBQVc7Ozs7O0FBQ3ZFIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkljb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBJY29uKHsgbmFtZSB9OiB7IG5hbWU6IFwiYXJyb3dcIiB8IFwiYmFja1wiIHwgXCJwbGF5XCIgfCBcInNwYXJrXCIgfCBcImNhbGVuZGFyXCIgfCBcImNoYXJ0XCIgfCBcImJvbHRcIiB8IFwiY2hlY2tcIiB8IFwic3RhclwiIHwgXCJleWVcIiB8IFwiZXllT2ZmXCIgfCBcImR1bWJiZWxsXCIgfCBcImNhbWVyYVwiIHwgXCJmbGFtZVwiIHwgXCJjbGlwYm9hcmRcIiB8IFwic2xpZGVyc1wiIHwgXCJ0aW1lclwiIHwgXCJ1c2VyXCIgfCBcImxvZ291dFwiIHwgXCJnZWFyXCIgfCBcImNsb3NlXCIgfCBcInBhdXNlXCIgfCBcInZvbHVtZVwiIHwgXCJ3YWxrXCIgfCBcIm1vb25cIiB8IFwiYm9va1wiIH0pIHtcclxuICBjb25zdCBwYXRocyA9IHtcclxuICAgIGFycm93OiA8cGF0aCBkPVwiTTUgMTJoMTRNMTQgN2w1IDUtNSA1XCIgLz4sXHJcbiAgICBiYWNrOiA8cGF0aCBkPVwiTTE5IDEySDVtNS01LTUgNSA1IDVcIiAvPixcclxuICAgIHBsYXk6IDxwYXRoIGQ9XCJtOSA3IDcgNS03IDVWN1pcIiAvPixcclxuICAgIHNwYXJrOiA8cGF0aCBkPVwibTEyIDIgMS44IDYuMkwyMCAxMGwtNi4yIDEuOEwxMiAxOGwtMS44LTYuMkw0IDEwbDYuMi0xLjhMMTIgMlpcIiAvPixcclxuICAgIGNhbGVuZGFyOiA8PjxyZWN0IHg9XCI0XCIgeT1cIjVcIiB3aWR0aD1cIjE2XCIgaGVpZ2h0PVwiMTVcIiByeD1cIjJcIiAvPjxwYXRoIGQ9XCJNOCAzdjRtOC00djRNNCAxMGgxNlwiIC8+PC8+LFxyXG4gICAgY2hhcnQ6IDw+PHBhdGggZD1cIk01IDE5VjltNyAxMFY1bTcgMTR2LTdcIiAvPjxwYXRoIGQ9XCJNMyAxOWgxOFwiIC8+PC8+LFxyXG4gICAgYm9sdDogPHBhdGggZD1cIm0xMyAyLTggMTJoN2wtMSA4IDgtMTNoLTdsMS03WlwiIC8+LFxyXG4gICAgY2hlY2s6IDxwYXRoIGQ9XCJtNSAxMiA0IDRMMTkgNlwiIC8+LFxyXG4gICAgc3RhcjogPHBhdGggZD1cIm0xMiAzIDIuOCA1LjcgNi4yLjktNC41IDQuNCAxLjEgNi4yLTUuNi0zLTUuNiAzIDEuMS02LjJMMyA5LjZsNi4yLS45TDEyIDNaXCIgLz4sXHJcbiAgICBleWU6IDw+PHBhdGggZD1cIk0yLjUgMTJzMy41LTUgOS41LTUgOS41IDUgOS41IDUtMy41IDUtOS41IDUtOS41LTUtOS41LTVaXCIgLz48Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjIuNVwiIC8+PC8+LFxyXG4gICAgZXllT2ZmOiA8PjxwYXRoIGQ9XCJtMyAzIDE4IDE4TTEwLjYgNy4yQTEwIDEwIDAgMCAxIDEyIDdjNiAwIDkuNSA1IDkuNSA1YTE0IDE0IDAgMCAxLTIuMSAyLjVNNi40IDYuNEMzLjkgOCAyLjUgMTIgMi41IDEyczMuNSA1IDkuNSA1YzEuMSAwIDIuMi0uMiAzLjEtLjVcIiAvPjwvPixcclxuICAgIGR1bWJiZWxsOiA8PjxwYXRoIGQ9XCJNNyA5djZNNC41IDh2OE0xNyA5djZNMTkuNSA4djhNNyAxMmgxMFwiIC8+PHBhdGggZD1cIk0zIDEwdjRtMTgtNHY0XCIgLz48Lz4sXHJcbiAgICBjYW1lcmE6IDw+PHBhdGggZD1cIk00IDhoM2wxLjUtMmg3TDE3IDhoM3YxMEg0VjhaXCIgLz48Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEzXCIgcj1cIjNcIiAvPjwvPixcclxuICAgIGZsYW1lOiA8cGF0aCBkPVwiTTEzLjUgMi41Yy41IDQtMi41IDUtMiA4IDEtMSAyLTIgMi41LTMgMi41IDIgNCA0LjIgNCA3YTYgNiAwIDAgMS0xMiAwYzAtMy40IDItNi4yIDUuMy05LS4yIDIgLjQgMy4xIDEuMiAzLjguMi0yLjMuOC00LjUgMS02LjhaXCIgLz4sXHJcbiAgICBjbGlwYm9hcmQ6IDw+PHJlY3QgeD1cIjVcIiB5PVwiNVwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxNlwiIHJ4PVwiMlwiIC8+PHBhdGggZD1cIk05IDVWM2g2djJNOSAxMWg2bS02IDRoNlwiIC8+PC8+LFxyXG4gICAgc2xpZGVyczogPD48cGF0aCBkPVwiTTQgN2gxMG00IDBoMk00IDE3aDJtNCAwaDEwTTggMTR2Nm04LTE2djZcIiAvPjxjaXJjbGUgY3g9XCIxNlwiIGN5PVwiN1wiIHI9XCIyXCIgLz48Y2lyY2xlIGN4PVwiOFwiIGN5PVwiMTdcIiByPVwiMlwiIC8+PC8+LFxyXG4gICAgdGltZXI6IDw+PGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxM1wiIHI9XCI4XCIgLz48cGF0aCBkPVwiTTEyIDl2NGwzIDJNOSAyaDZtLTMgMHYzXCIgLz48Lz4sXHJcbiAgICB1c2VyOiA8PjxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiOFwiIHI9XCI0XCIgLz48cGF0aCBkPVwiTTQgMjFjLjgtNC4yIDMuNS02IDgtNnM3LjIgMS44IDggNlwiIC8+PC8+LFxyXG4gICAgbG9nb3V0OiA8PjxwYXRoIGQ9XCJNMTAgNEg1djE2aDVNMTQgOGw0IDQtNCA0bTQtNEg5XCIgLz48Lz4sXHJcbiAgICBnZWFyOiA8PjxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiM1wiIC8+PHBhdGggZD1cIk0xOS40IDE1YTEuNyAxLjcgMCAwIDAgLjMgMS45bC4xLjEtMi44IDIuOC0uMS0uMWExLjcgMS43IDAgMCAwLTEuOS0uMyAxLjcgMS43IDAgMCAwLTEgMS42di4yaC00VjIxYTEuNyAxLjcgMCAwIDAtMS0xLjYgMS43IDEuNyAwIDAgMC0xLjkuM2wtLjEuMUw0LjIgMTdsLjEtLjFhMS43IDEuNyAwIDAgMCAuMy0xLjlBMS43IDEuNyAwIDAgMCAzIDE0SDIuOHYtNEgzYTEuNyAxLjcgMCAwIDAgMS42LTEgMS43IDEuNyAwIDAgMC0uMy0xLjlMNC4yIDcgNyA0LjJsLjEuMWExLjcgMS43IDAgMCAwIDEuOS4zQTEuNyAxLjcgMCAwIDAgMTAgM1YyLjhoNFYzYTEuNyAxLjcgMCAwIDAgMSAxLjYgMS43IDEuNyAwIDAgMCAxLjktLjNsLjEtLjFMMTkuOCA3bC0uMS4xYTEuNyAxLjcgMCAwIDAtLjMgMS45IDEuNyAxLjcgMCAwIDAgMS42IDFoLjJ2NEgyMWExLjcgMS43IDAgMCAwLTEuNiAxWlwiIC8+PC8+LFxyXG4gICAgY2xvc2U6IDxwYXRoIGQ9XCJtNiA2IDEyIDEyTTE4IDYgNiAxOFwiIC8+LFxyXG4gICAgcGF1c2U6IDxwYXRoIGQ9XCJNOSA1djE0bTYtMTR2MTRcIiAvPixcclxuICAgIHZvbHVtZTogPD48cGF0aCBkPVwiTTUgMTB2NGgzbDQgM1Y3bC00IDNINVpcIiAvPjxwYXRoIGQ9XCJNMTYgOWMxLjUgMS43IDEuNSA0LjMgMCA2bTItOGMyLjggMi44IDIuOCA3LjIgMCAxMFwiIC8+PC8+LFxyXG4gICAgd2FsazogPD48Y2lyY2xlIGN4PVwiMTNcIiBjeT1cIjRcIiByPVwiMlwiIC8+PHBhdGggZD1cIm0xMCAyMiAyLTctMy0zIDItNSA0IDMgMyAxTTYgMjJsMy02bTUtMiAzIDhcIiAvPjwvPixcclxuICAgIG1vb246IDxwYXRoIGQ9XCJNMjAgMTUuNUE4LjUgOC41IDAgMCAxIDguNSA0IDguNSA4LjUgMCAxIDAgMjAgMTUuNVpcIiAvPixcclxuICAgIGJvb2s6IDw+PHBhdGggZD1cIk00IDUuNUEzLjUgMy41IDAgMCAxIDcuNSAySDExdjE3SDcuNUEzLjUgMy41IDAgMCAwIDQgMjJWNS41WlwiIC8+PHBhdGggZD1cIk0yMCA1LjVBMy41IDMuNSAwIDAgMCAxNi41IDJIMTN2MTdoMy41QTMuNSAzLjUgMCAwIDEgMjAgMjJWNS41WlwiIC8+PC8+LFxyXG4gIH07XHJcbiAgcmV0dXJuIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPntwYXRoc1tuYW1lXX08L3N2Zz47XHJcbn1cclxuIl19