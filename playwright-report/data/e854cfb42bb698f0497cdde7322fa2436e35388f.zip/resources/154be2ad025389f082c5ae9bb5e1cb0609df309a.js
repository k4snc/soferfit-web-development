import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/LogoMark.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import soferFitLogo from "/src/frontend/assets/soferfit-logo.png?import";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/LogoMark.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function LogoMark() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "brand-mark",
		children: /* @__PURE__ */ _jsxDEV("img", {
			src: soferFitLogo,
			alt: ""
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 39
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = LogoMark;
var _c;
$RefreshReg$(_c, "LogoMark");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/LogoMark.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/LogoMark.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/LogoMark.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/LogoMark.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxrQkFBa0I7OztBQUV6QixPQUFPLFNBQVMsV0FBVztDQUN6QixPQUFPLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWEsd0JBQUMsT0FBRDtHQUFLLEtBQUs7R0FBYyxLQUFJO0VBQUk7Ozs7O0NBQU87Ozs7O0FBQzdFIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxvZ29NYXJrLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc29mZXJGaXRMb2dvIGZyb20gXCIuLi9hc3NldHMvc29mZXJmaXQtbG9nby5wbmdcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2dvTWFyaygpIHtcclxuICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiYnJhbmQtbWFya1wiPjxpbWcgc3JjPXtzb2ZlckZpdExvZ299IGFsdD1cIlwiIC8+PC9zcGFuPjtcclxufVxyXG4iXX0=