import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/OverviewPage.tsx");const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import soferFitLogo from "/src/frontend/assets/soferfit-logo.png?import";
import { Button } from "/src/frontend/components/Button.tsx";
import { EmptyState } from "/src/frontend/components/EmptyState.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { PageHeader } from "/src/frontend/components/PageHeader.tsx";
import { dateKey } from "/src/frontend/lib/format.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/OverviewPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function OverviewPage({ store, navigate }) {
	const today = new Date();
	const todayKey = dateKey(today);
	const challengeStart = new Date(`${store.challenge.startDate}T12:00:00`);
	const challengeDay = Math.max(1, Math.min(store.challenge.length, Math.floor((today.getTime() - challengeStart.getTime()) / 864e5) + 1));
	const nextWorkout = store.plan.filter((workout) => workout.date >= todayKey && !workout.optional).sort((left, right) => left.date.localeCompare(right.date))[0] ?? store.plan[0];
	const workoutToday = nextWorkout?.date === todayKey;
	const activeMinutes = store.sessions.reduce((sum, session) => sum + session.duration, 0);
	const completedDates = new Set(store.sessions.map((session) => session.date));
	let streak = 0;
	const cursor = new Date(today);
	while (completedDates.has(dateKey(cursor))) {
		streak += 1;
		cursor.setDate(cursor.getDate() - 1);
	}
	const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
	const gridStart = new Date(monthStart);
	gridStart.setDate(1 - (monthStart.getDay() + 6) % 7);
	const calendarDays = Array.from({ length: 42 }, (_, index) => {
		const date = new Date(gridStart);
		date.setDate(gridStart.getDate() + index);
		return date;
	});
	const plannedDates = new Set(store.plan.map((workout) => workout.date));
	const firstName = store.user.username.split(/\s+/)[0] || "Member";
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(PageHeader, {
		eyebrow: `DAY ${challengeDay}`,
		title: `Keep your rhythm, ${firstName}.`
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "dash-layout",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "dash-primary",
			children: [nextWorkout ? /* @__PURE__ */ _jsxDEV("article", {
				className: "today-workout",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "today-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "workout-label",
							children: workoutToday ? `TODAY'S WORKOUT · ${nextWorkout.minutes} MIN` : "REST DAY"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: workoutToday ? nextWorkout.name : "Rest day" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: workoutToday ? `${nextWorkout.exercises.length} exercises · ${nextWorkout.equipment} · ${nextWorkout.intensity ?? "Moderate"}` : `Next: ${nextWorkout.name}, ${new Date(`${nextWorkout.date}T12:00:00`).toLocaleDateString(undefined, {
							weekday: "long",
							month: "short",
							day: "numeric"
						})}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 13
						}, this),
						workoutToday && /* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => navigate(`/session/${nextWorkout.id}`),
							children: ["Start workout ", /* @__PURE__ */ _jsxDEV(Icon, { name: "play" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 107
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 30
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "workout-art",
					"aria-hidden": "true",
					style: { "--runner-logo": `url(${soferFitLogo})` }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 24
			}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
				title: "Your first workout is waiting",
				copy: "Visit Generate to create a workout that fits your day."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 22
			}, this), /* @__PURE__ */ _jsxDEV("article", {
				className: "dash-calendar-panel",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "panel-head",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h3", { children: [today.toLocaleDateString(undefined, { month: "long" }), " activity"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 44
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 39
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: streak ? `${streak} day streak` : "Start your streak" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 124
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "full-calendar",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "week days",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "M" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 40
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 54
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "W" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 68
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 82
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "F" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 96
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "S" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 110
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "S" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 124
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "calendar-grid",
							children: calendarDays.map((date) => {
								const key = dateKey(date);
								const completed = completedDates.has(key);
								const isToday = key === todayKey;
								const planned = plannedDates.has(key);
								const className = completed ? "done" : isToday ? "today" : planned ? "upcoming" : "rest";
								return /* @__PURE__ */ _jsxDEV("span", {
									className,
									"aria-label": `${date.toDateString()}, ${completed ? "completed" : isToday ? "today" : planned ? "upcoming" : "rest"}`,
									children: completed ? /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 59,
										columnNumber: 193
									}, this) : date.getDate()
								}, key, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 24
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "calendar-legend",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", { className: "done" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 52
								}, this), "Completed"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 46
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", { className: "upcoming" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 96
								}, this), "Upcoming"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 90
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", { className: "today" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 143
								}, this), "Today"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 137
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", { className: "rest" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 184
								}, this), "Rest"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 178
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "dash-secondary",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "stat-row",
					children: [/* @__PURE__ */ _jsxDEV("article", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "dash-stat-icon",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 53
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 20
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: "CHALLENGE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 84
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: [
							"Day ",
							challengeDay,
							" ",
							/* @__PURE__ */ _jsxDEV("i", { children: ["/ ", store.challenge.length] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 135
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 108
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: [Math.max(0, store.challenge.length - challengeDay), " days remaining"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 177
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("article", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "dash-stat-icon",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 53
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 20
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: "ACTIVE TIME" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 80
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: activeMinutes < 60 ? `${activeMinutes}m` : `${(activeMinutes / 60).toFixed(1)}h` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 106
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: store.sessions.length ? `${store.sessions.length} sessions completed` : "Your first session is ready" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 205
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("article", {
					className: "strength-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "panel-head",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "BADGES" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 44
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: store.badges.some((badge) => badge.unlocked) ? "Your consistency is showing." : "Complete sessions to earn badges." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 65
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 39
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
							store.badges.filter((badge) => badge.unlocked).length,
							"/",
							store.badges.length
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 197
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "badge-grid",
						children: store.badges.map((badge) => /* @__PURE__ */ _jsxDEV("div", {
							className: badge.unlocked ? "unlocked" : "",
							children: [/* @__PURE__ */ _jsxDEV(Icon, { name: badge.unlocked ? "check" : "star" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 133
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: badge.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 182
							}, this)]
						}, badge.id, true, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 68
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("article", {
					className: "encouragement",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: "“Small steps, repeated, become your transformation.”" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 44
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["KEEP YOUR RHYTHM · DAY ", challengeDay] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 103
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 10
	}, this);
}
_c = OverviewPage;
var _c;
$RefreshReg$(_c, "OverviewPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/OverviewPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/OverviewPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/OverviewPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/OverviewPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxrQkFBa0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGtCQUFrQjtBQUUzQixTQUFTLGVBQWU7OztBQUV4QixPQUFPLFNBQVMsYUFBYSxFQUFFLE9BQU8sWUFBdUU7Q0FDM0csTUFBTSxRQUFRLElBQUksS0FBSztDQUN2QixNQUFNLFdBQVcsUUFBUSxLQUFLO0NBQzlCLE1BQU0saUJBQWlCLElBQUksS0FBSyxHQUFHLE1BQU0sVUFBVSxVQUFVLFVBQVU7Q0FDdkUsTUFBTSxlQUFlLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxNQUFNLFVBQVUsUUFBUSxLQUFLLE9BQU8sTUFBTSxRQUFRLElBQUksZUFBZSxRQUFRLEtBQUssS0FBVSxJQUFJLENBQUMsQ0FBQztDQUM1SSxNQUFNLGNBQWMsTUFBTSxLQUFLLFFBQVEsWUFBWSxRQUFRLFFBQVEsWUFBWSxDQUFDLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxNQUFNLFVBQVUsS0FBSyxLQUFLLGNBQWMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sTUFBTSxLQUFLO0NBQzlLLE1BQU0sZUFBZSxhQUFhLFNBQVM7Q0FDM0MsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLFFBQVEsS0FBSyxZQUFZLE1BQU0sUUFBUSxVQUFVLENBQUM7Q0FDdkYsTUFBTSxpQkFBaUIsSUFBSSxJQUFJLE1BQU0sU0FBUyxLQUFLLFlBQVksUUFBUSxJQUFJLENBQUM7Q0FDNUUsSUFBSSxTQUFTO0NBQ2IsTUFBTSxTQUFTLElBQUksS0FBSyxLQUFLO0NBQzdCLE9BQU8sZUFBZSxJQUFJLFFBQVEsTUFBTSxDQUFDLEdBQUc7RUFDMUMsVUFBVTtFQUNWLE9BQU8sUUFBUSxPQUFPLFFBQVEsSUFBSSxDQUFDO0NBQ3JDO0NBQ0EsTUFBTSxhQUFhLElBQUksS0FBSyxNQUFNLFlBQVksR0FBRyxNQUFNLFNBQVMsR0FBRyxDQUFDO0NBQ3BFLE1BQU0sWUFBWSxJQUFJLEtBQUssVUFBVTtDQUNyQyxVQUFVLFFBQVEsS0FBTSxXQUFXLE9BQU8sSUFBSSxLQUFLLENBQUU7Q0FDckQsTUFBTSxlQUFlLE1BQU0sS0FBSyxFQUFFLFFBQVEsR0FBRyxJQUFJLEdBQUcsVUFBVTtFQUM1RCxNQUFNLE9BQU8sSUFBSSxLQUFLLFNBQVM7RUFDL0IsS0FBSyxRQUFRLFVBQVUsUUFBUSxJQUFJLEtBQUs7RUFDeEMsT0FBTztDQUNULENBQUM7Q0FDRCxNQUFNLGVBQWUsSUFBSSxJQUFJLE1BQU0sS0FBSyxLQUFLLFlBQVksUUFBUSxJQUFJLENBQUM7Q0FDdEUsTUFBTSxZQUFZLE1BQU0sS0FBSyxTQUFTLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTTtDQUV6RCxPQUFPLGdEQUNMLHdCQUFDLFlBQUQ7RUFBWSxTQUFTLE9BQU87RUFBZ0IsT0FBTyxxQkFBcUIsVUFBVTtDQUFLOzs7O1dBQ3ZGLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0csY0FBYyx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaUIsZUFBZSxxQkFBcUIsWUFBWSxRQUFRLFFBQVE7TUFBaUI7Ozs7O01BQ2xILHdCQUFDLE1BQUQsWUFBSyxlQUFlLFlBQVksT0FBTyxXQUFlOzs7OztNQUN0RCx3QkFBQyxLQUFELFlBQUksZUFBZSxHQUFHLFlBQVksVUFBVSxPQUFPLGVBQWUsWUFBWSxVQUFVLEtBQUssWUFBWSxhQUFhLGVBQWUsU0FBUyxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBRyxZQUFZLEtBQUssVUFBVSxDQUFDLENBQUMsbUJBQW1CLFdBQVc7T0FBRSxTQUFTO09BQVEsT0FBTztPQUFTLEtBQUs7TUFBVSxDQUFDLElBQU87Ozs7O01BQ25TLGdCQUFnQix3QkFBQyxRQUFEO09BQVEsZUFBZSxTQUFTLFlBQVksWUFBWSxJQUFJO2lCQUE1RCxDQUErRCxrQkFBYyx3QkFBQyxNQUFELEVBQU0sTUFBSyxPQUFROzs7O2VBQVM7Ozs7OztLQUN2SDs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLGVBQVk7S0FBTyxPQUFPLEVBQUUsaUJBQWlCLE9BQU8sYUFBYSxHQUFHO0lBQTJCOzs7O1lBQ3JIOzs7OztjQUFJLHdCQUFDLFlBQUQ7SUFBWSxPQUFNO0lBQWdDLE1BQUs7R0FBMEQ7Ozs7YUFDOUgsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQTRCLHdCQUFDLE9BQUQsWUFBSyx3QkFBQyxNQUFELGFBQUssTUFBTSxtQkFBbUIsV0FBVyxFQUFFLE9BQU8sT0FBTyxDQUFDLEdBQUUsV0FBYTs7OztjQUFNOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFPLFNBQVMsR0FBRyxPQUFPLGVBQWUsb0JBQTBCOzs7O2FBQU07Ozs7O2NBQzFMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUEyQix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7UUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7T0FBTTs7Ozs7O01BQ2xJLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGFBQWEsS0FBSyxTQUFTO1FBQzFCLE1BQU0sTUFBTSxRQUFRLElBQUk7UUFDeEIsTUFBTSxZQUFZLGVBQWUsSUFBSSxHQUFHO1FBQ3hDLE1BQU0sVUFBVSxRQUFRO1FBQ3hCLE1BQU0sVUFBVSxhQUFhLElBQUksR0FBRztRQUNwQyxNQUFNLFlBQVksWUFBWSxTQUFTLFVBQVUsVUFBVSxVQUFVLGFBQWE7UUFDbEYsT0FBTyx3QkFBQyxRQUFEO1NBQTJCO1NBQVcsY0FBWSxHQUFHLEtBQUssYUFBYSxFQUFFLElBQUksWUFBWSxjQUFjLFVBQVUsVUFBVSxVQUFVLGFBQWE7bUJBQVcsWUFBWSx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O29CQUFJLEtBQUssUUFBUTtRQUFRLEdBQTNNOzs7O2VBQTJNO09BQy9OLENBQUM7TUFDRTs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUFpQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRCxFQUFHLFdBQVUsT0FBUTs7OztrQkFBQyxXQUFlOzs7OztRQUFDLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxLQUFELEVBQUcsV0FBVSxXQUFZOzs7O2tCQUFDLFVBQWM7Ozs7O1FBQUMsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQsRUFBRyxXQUFVLFFBQVM7Ozs7a0JBQUMsT0FBVzs7Ozs7UUFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRCxFQUFHLFdBQVUsT0FBUTs7OztrQkFBQyxNQUFVOzs7OztPQUFNOzs7Ozs7S0FDOU07Ozs7O1lBQ0U7Ozs7O1dBQ047Ozs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxXQUFEO01BQVMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7O01BQU87Ozs7O01BQUMsd0JBQUMsU0FBRCxZQUFPLFlBQWdCOzs7OztNQUFDLHdCQUFDLFVBQUQ7T0FBUTtPQUFLO09BQWE7T0FBQyx3QkFBQyxLQUFELGFBQUcsTUFBRyxNQUFNLFVBQVUsTUFBVTs7Ozs7TUFBUzs7Ozs7TUFBQyx3QkFBQyxRQUFELGFBQU8sS0FBSyxJQUFJLEdBQUcsTUFBTSxVQUFVLFNBQVMsWUFBWSxHQUFFLGlCQUFxQjs7Ozs7S0FBVTs7OztlQUMvUCx3QkFBQyxXQUFEO01BQVMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O01BQU87Ozs7O01BQUMsd0JBQUMsU0FBRCxZQUFPLGNBQWtCOzs7OztNQUFDLHdCQUFDLFVBQUQsWUFBUyxnQkFBZ0IsS0FBSyxHQUFHLGNBQWMsS0FBSyxJQUFJLGdCQUFnQixHQUFFLENBQUUsUUFBUSxDQUFDLEVBQUUsR0FBVzs7Ozs7TUFBQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxTQUFTLFNBQVMsR0FBRyxNQUFNLFNBQVMsT0FBTyx1QkFBdUIsOEJBQW9DOzs7OztLQUFVOzs7O2FBQzVUOzs7Ozs7SUFDTCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTRCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sU0FBYTs7OztnQkFBQyx3QkFBQyxNQUFELFlBQUssTUFBTSxPQUFPLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFBSSxpQ0FBaUMsb0NBQXdDOzs7O2NBQU07Ozs7Z0JBQUMsd0JBQUMsVUFBRDtPQUFTLE1BQU0sT0FBTyxRQUFRLFVBQVUsTUFBTSxRQUFRLENBQUMsQ0FBQztPQUFPO09BQUUsTUFBTSxPQUFPO01BQWU7Ozs7Y0FBTTs7Ozs7ZUFDN1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWMsTUFBTSxPQUFPLEtBQUssVUFBVSx3QkFBQyxPQUFEO09BQUssV0FBVyxNQUFNLFdBQVcsYUFBYTtpQkFBOUMsQ0FBaUUsd0JBQUMsTUFBRCxFQUFNLE1BQU0sTUFBTSxXQUFXLFVBQVUsT0FBUzs7OztpQkFBQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxLQUFXOzs7O2VBQU07U0FBekYsTUFBTTs7OzthQUFtRixDQUFDO0tBQU87Ozs7YUFDMU07Ozs7OztJQUNULHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQW1DLHdCQUFDLEtBQUQsWUFBRyx1REFBdUQ7Ozs7ZUFBQyx3QkFBQyxRQUFELGFBQU0sMkJBQXdCLFlBQW1COzs7O2FBQVU7Ozs7OztHQUN0Sjs7Ozs7VUFDRjs7Ozs7U0FDTDs7Ozs7QUFDSiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPdmVydmlld1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzb2ZlckZpdExvZ28gZnJvbSBcIi4uL2Fzc2V0cy9zb2ZlcmZpdC1sb2dvLnBuZ1wiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b25cIjtcclxuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0VtcHR5U3RhdGVcIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCIuLi9jb21wb25lbnRzL1BhZ2VIZWFkZXJcIjtcclxuaW1wb3J0IHR5cGUgeyBGaXRuZXNzU3RvcmUgfSBmcm9tIFwiLi4vZml0bmVzc1N0b3JlXCI7XHJcbmltcG9ydCB7IGRhdGVLZXkgfSBmcm9tIFwiLi4vbGliL2Zvcm1hdFwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE92ZXJ2aWV3UGFnZSh7IHN0b3JlLCBuYXZpZ2F0ZSB9OiB7IHN0b3JlOiBGaXRuZXNzU3RvcmU7IG5hdmlnYXRlOiAocGF0aDogc3RyaW5nKSA9PiB2b2lkIH0pIHtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgdG9kYXlLZXkgPSBkYXRlS2V5KHRvZGF5KTtcclxuICBjb25zdCBjaGFsbGVuZ2VTdGFydCA9IG5ldyBEYXRlKGAke3N0b3JlLmNoYWxsZW5nZS5zdGFydERhdGV9VDEyOjAwOjAwYCk7XHJcbiAgY29uc3QgY2hhbGxlbmdlRGF5ID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCwgTWF0aC5mbG9vcigodG9kYXkuZ2V0VGltZSgpIC0gY2hhbGxlbmdlU3RhcnQuZ2V0VGltZSgpKSAvIDg2XzQwMF8wMDApICsgMSkpO1xyXG4gIGNvbnN0IG5leHRXb3Jrb3V0ID0gc3RvcmUucGxhbi5maWx0ZXIoKHdvcmtvdXQpID0+IHdvcmtvdXQuZGF0ZSA+PSB0b2RheUtleSAmJiAhd29ya291dC5vcHRpb25hbCkuc29ydCgobGVmdCwgcmlnaHQpID0+IGxlZnQuZGF0ZS5sb2NhbGVDb21wYXJlKHJpZ2h0LmRhdGUpKVswXSA/PyBzdG9yZS5wbGFuWzBdO1xyXG4gIGNvbnN0IHdvcmtvdXRUb2RheSA9IG5leHRXb3Jrb3V0Py5kYXRlID09PSB0b2RheUtleTtcclxuICBjb25zdCBhY3RpdmVNaW51dGVzID0gc3RvcmUuc2Vzc2lvbnMucmVkdWNlKChzdW0sIHNlc3Npb24pID0+IHN1bSArIHNlc3Npb24uZHVyYXRpb24sIDApO1xyXG4gIGNvbnN0IGNvbXBsZXRlZERhdGVzID0gbmV3IFNldChzdG9yZS5zZXNzaW9ucy5tYXAoKHNlc3Npb24pID0+IHNlc3Npb24uZGF0ZSkpO1xyXG4gIGxldCBzdHJlYWsgPSAwO1xyXG4gIGNvbnN0IGN1cnNvciA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICB3aGlsZSAoY29tcGxldGVkRGF0ZXMuaGFzKGRhdGVLZXkoY3Vyc29yKSkpIHtcclxuICAgIHN0cmVhayArPSAxO1xyXG4gICAgY3Vyc29yLnNldERhdGUoY3Vyc29yLmdldERhdGUoKSAtIDEpO1xyXG4gIH1cclxuICBjb25zdCBtb250aFN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgY29uc3QgZ3JpZFN0YXJ0ID0gbmV3IERhdGUobW9udGhTdGFydCk7XHJcbiAgZ3JpZFN0YXJ0LnNldERhdGUoMSAtICgobW9udGhTdGFydC5nZXREYXkoKSArIDYpICUgNykpO1xyXG4gIGNvbnN0IGNhbGVuZGFyRGF5cyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IDQyIH0sIChfLCBpbmRleCkgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGdyaWRTdGFydCk7XHJcbiAgICBkYXRlLnNldERhdGUoZ3JpZFN0YXJ0LmdldERhdGUoKSArIGluZGV4KTtcclxuICAgIHJldHVybiBkYXRlO1xyXG4gIH0pO1xyXG4gIGNvbnN0IHBsYW5uZWREYXRlcyA9IG5ldyBTZXQoc3RvcmUucGxhbi5tYXAoKHdvcmtvdXQpID0+IHdvcmtvdXQuZGF0ZSkpO1xyXG4gIGNvbnN0IGZpcnN0TmFtZSA9IHN0b3JlLnVzZXIudXNlcm5hbWUuc3BsaXQoL1xccysvKVswXSB8fCBcIk1lbWJlclwiO1xyXG5cclxuICByZXR1cm4gPD5cclxuICAgIDxQYWdlSGVhZGVyIGV5ZWJyb3c9e2BEQVkgJHtjaGFsbGVuZ2VEYXl9YH0gdGl0bGU9e2BLZWVwIHlvdXIgcmh5dGhtLCAke2ZpcnN0TmFtZX0uYH0gLz5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZGFzaC1sYXlvdXRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoLXByaW1hcnlcIj5cclxuICAgICAgICB7bmV4dFdvcmtvdXQgPyA8YXJ0aWNsZSBjbGFzc05hbWU9XCJ0b2RheS13b3Jrb3V0XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvZGF5LWNvcHlcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwid29ya291dC1sYWJlbFwiPnt3b3Jrb3V0VG9kYXkgPyBgVE9EQVknUyBXT1JLT1VUIMK3ICR7bmV4dFdvcmtvdXQubWludXRlc30gTUlOYCA6IFwiUkVTVCBEQVlcIn08L3NwYW4+XHJcbiAgICAgICAgICAgIDxoMj57d29ya291dFRvZGF5ID8gbmV4dFdvcmtvdXQubmFtZSA6IFwiUmVzdCBkYXlcIn08L2gyPlxyXG4gICAgICAgICAgICA8cD57d29ya291dFRvZGF5ID8gYCR7bmV4dFdvcmtvdXQuZXhlcmNpc2VzLmxlbmd0aH0gZXhlcmNpc2VzIMK3ICR7bmV4dFdvcmtvdXQuZXF1aXBtZW50fSDCtyAke25leHRXb3Jrb3V0LmludGVuc2l0eSA/PyBcIk1vZGVyYXRlXCJ9YCA6IGBOZXh0OiAke25leHRXb3Jrb3V0Lm5hbWV9LCAke25ldyBEYXRlKGAke25leHRXb3Jrb3V0LmRhdGV9VDEyOjAwOjAwYCkudG9Mb2NhbGVEYXRlU3RyaW5nKHVuZGVmaW5lZCwgeyB3ZWVrZGF5OiBcImxvbmdcIiwgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX1gfTwvcD5cclxuICAgICAgICAgICAge3dvcmtvdXRUb2RheSAmJiA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvc2Vzc2lvbi8ke25leHRXb3Jrb3V0LmlkfWApfT5TdGFydCB3b3Jrb3V0IDxJY29uIG5hbWU9XCJwbGF5XCIgLz48L0J1dHRvbj59XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid29ya291dC1hcnRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzdHlsZT17eyBcIi0tcnVubmVyLWxvZ29cIjogYHVybCgke3NvZmVyRml0TG9nb30pYCB9IGFzIFJlYWN0LkNTU1Byb3BlcnRpZXN9IC8+XHJcbiAgICAgICAgPC9hcnRpY2xlPiA6IDxFbXB0eVN0YXRlIHRpdGxlPVwiWW91ciBmaXJzdCB3b3Jrb3V0IGlzIHdhaXRpbmdcIiBjb3B5PVwiVmlzaXQgR2VuZXJhdGUgdG8gY3JlYXRlIGEgd29ya291dCB0aGF0IGZpdHMgeW91ciBkYXkuXCIgLz59XHJcbiAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwiZGFzaC1jYWxlbmRhci1wYW5lbFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbC1oZWFkXCI+PGRpdj48aDM+e3RvZGF5LnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6IFwibG9uZ1wiIH0pfSBhY3Rpdml0eTwvaDM+PC9kaXY+PHNwYW4+e3N0cmVhayA/IGAke3N0cmVha30gZGF5IHN0cmVha2AgOiBcIlN0YXJ0IHlvdXIgc3RyZWFrXCJ9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmdWxsLWNhbGVuZGFyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2VlayBkYXlzXCI+PHNwYW4+TTwvc3Bhbj48c3Bhbj5UPC9zcGFuPjxzcGFuPlc8L3NwYW4+PHNwYW4+VDwvc3Bhbj48c3Bhbj5GPC9zcGFuPjxzcGFuPlM8L3NwYW4+PHNwYW4+Uzwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYWxlbmRhci1ncmlkXCI+XHJcbiAgICAgICAgICAgICAge2NhbGVuZGFyRGF5cy5tYXAoKGRhdGUpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGtleSA9IGRhdGVLZXkoZGF0ZSk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjb21wbGV0ZWQgPSBjb21wbGV0ZWREYXRlcy5oYXMoa2V5KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGlzVG9kYXkgPSBrZXkgPT09IHRvZGF5S2V5O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGxhbm5lZCA9IHBsYW5uZWREYXRlcy5oYXMoa2V5KTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNsYXNzTmFtZSA9IGNvbXBsZXRlZCA/IFwiZG9uZVwiIDogaXNUb2RheSA/IFwidG9kYXlcIiA6IHBsYW5uZWQgPyBcInVwY29taW5nXCIgOiBcInJlc3RcIjtcclxuICAgICAgICAgICAgICAgIHJldHVybiA8c3BhbiBrZXk9e2tleX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IGFyaWEtbGFiZWw9e2Ake2RhdGUudG9EYXRlU3RyaW5nKCl9LCAke2NvbXBsZXRlZCA/IFwiY29tcGxldGVkXCIgOiBpc1RvZGF5ID8gXCJ0b2RheVwiIDogcGxhbm5lZCA/IFwidXBjb21pbmdcIiA6IFwicmVzdFwifWB9Pntjb21wbGV0ZWQgPyA8SWNvbiBuYW1lPVwiY2hlY2tcIiAvPiA6IGRhdGUuZ2V0RGF0ZSgpfTwvc3Bhbj47XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGVuZGFyLWxlZ2VuZFwiPjxzcGFuPjxpIGNsYXNzTmFtZT1cImRvbmVcIiAvPkNvbXBsZXRlZDwvc3Bhbj48c3Bhbj48aSBjbGFzc05hbWU9XCJ1cGNvbWluZ1wiIC8+VXBjb21pbmc8L3NwYW4+PHNwYW4+PGkgY2xhc3NOYW1lPVwidG9kYXlcIiAvPlRvZGF5PC9zcGFuPjxzcGFuPjxpIGNsYXNzTmFtZT1cInJlc3RcIiAvPlJlc3Q8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2gtc2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LXJvd1wiPlxyXG4gICAgICAgICAgPGFydGljbGU+PHNwYW4gY2xhc3NOYW1lPVwiZGFzaC1zdGF0LWljb25cIj48SWNvbiBuYW1lPVwiY2FsZW5kYXJcIiAvPjwvc3Bhbj48c21hbGw+Q0hBTExFTkdFPC9zbWFsbD48c3Ryb25nPkRheSB7Y2hhbGxlbmdlRGF5fSA8aT4vIHtzdG9yZS5jaGFsbGVuZ2UubGVuZ3RofTwvaT48L3N0cm9uZz48c3Bhbj57TWF0aC5tYXgoMCwgc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAtIGNoYWxsZW5nZURheSl9IGRheXMgcmVtYWluaW5nPC9zcGFuPjwvYXJ0aWNsZT5cclxuICAgICAgICAgIDxhcnRpY2xlPjxzcGFuIGNsYXNzTmFtZT1cImRhc2gtc3RhdC1pY29uXCI+PEljb24gbmFtZT1cImJvbHRcIiAvPjwvc3Bhbj48c21hbGw+QUNUSVZFIFRJTUU8L3NtYWxsPjxzdHJvbmc+e2FjdGl2ZU1pbnV0ZXMgPCA2MCA/IGAke2FjdGl2ZU1pbnV0ZXN9bWAgOiBgJHsoYWN0aXZlTWludXRlcyAvIDYwKS50b0ZpeGVkKDEpfWhgfTwvc3Ryb25nPjxzcGFuPntzdG9yZS5zZXNzaW9ucy5sZW5ndGggPyBgJHtzdG9yZS5zZXNzaW9ucy5sZW5ndGh9IHNlc3Npb25zIGNvbXBsZXRlZGAgOiBcIllvdXIgZmlyc3Qgc2Vzc2lvbiBpcyByZWFkeVwifTwvc3Bhbj48L2FydGljbGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwic3RyZW5ndGgtY2FyZFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbC1oZWFkXCI+PGRpdj48c21hbGw+QkFER0VTPC9zbWFsbD48aDM+e3N0b3JlLmJhZGdlcy5zb21lKChiYWRnZSkgPT4gYmFkZ2UudW5sb2NrZWQpID8gXCJZb3VyIGNvbnNpc3RlbmN5IGlzIHNob3dpbmcuXCIgOiBcIkNvbXBsZXRlIHNlc3Npb25zIHRvIGVhcm4gYmFkZ2VzLlwifTwvaDM+PC9kaXY+PHN0cm9uZz57c3RvcmUuYmFkZ2VzLmZpbHRlcigoYmFkZ2UpID0+IGJhZGdlLnVubG9ja2VkKS5sZW5ndGh9L3tzdG9yZS5iYWRnZXMubGVuZ3RofTwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYWRnZS1ncmlkXCI+e3N0b3JlLmJhZGdlcy5tYXAoKGJhZGdlKSA9PiA8ZGl2IGNsYXNzTmFtZT17YmFkZ2UudW5sb2NrZWQgPyBcInVubG9ja2VkXCIgOiBcIlwifSBrZXk9e2JhZGdlLmlkfT48SWNvbiBuYW1lPXtiYWRnZS51bmxvY2tlZCA/IFwiY2hlY2tcIiA6IFwic3RhclwifSAvPjxzcGFuPntiYWRnZS5uYW1lfTwvc3Bhbj48L2Rpdj4pfTwvZGl2PlxyXG4gICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJlbmNvdXJhZ2VtZW50XCI+PHA+4oCcU21hbGwgc3RlcHMsIHJlcGVhdGVkLCBiZWNvbWUgeW91ciB0cmFuc2Zvcm1hdGlvbi7igJ08L3A+PHNwYW4+S0VFUCBZT1VSIFJIWVRITSDCtyBEQVkge2NoYWxsZW5nZURheX08L3NwYW4+PC9hcnRpY2xlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIDwvPjtcclxufVxyXG4iXX0=