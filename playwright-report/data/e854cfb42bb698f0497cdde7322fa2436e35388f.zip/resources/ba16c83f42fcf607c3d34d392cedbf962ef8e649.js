import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/Button.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Button.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function Button({ children, variant = "primary", onClick, className = "", disabled = false }) {
	return /* @__PURE__ */ _jsxDEV("button", {
		className: `button button-${variant} ${className}`,
		onClick,
		disabled,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 10
	}, this);
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/Button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/Button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsT0FBTyxFQUNyQixVQUNBLFVBQVUsV0FDVixTQUNBLFlBQVksSUFDWixXQUFXLFNBT1Y7Q0FDRCxPQUFPLHdCQUFDLFVBQUQ7RUFBUSxXQUFXLGlCQUFpQixRQUFRLEdBQUc7RUFBc0I7RUFBbUI7RUFBVztDQUFpQjs7Ozs7QUFDN0giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQnV0dG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZnVuY3Rpb24gQnV0dG9uKHtcclxuICBjaGlsZHJlbixcclxuICB2YXJpYW50ID0gXCJwcmltYXJ5XCIsXHJcbiAgb25DbGljayxcclxuICBjbGFzc05hbWUgPSBcIlwiLFxyXG4gIGRpc2FibGVkID0gZmFsc2UsXHJcbn06IHtcclxuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xyXG4gIHZhcmlhbnQ/OiBcInByaW1hcnlcIiB8IFwiZ2hvc3RcIiB8IFwiZGFya1wiO1xyXG4gIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xyXG4gIGNsYXNzTmFtZT86IHN0cmluZztcclxuICBkaXNhYmxlZD86IGJvb2xlYW47XHJcbn0pIHtcclxuICByZXR1cm4gPGJ1dHRvbiBjbGFzc05hbWU9e2BidXR0b24gYnV0dG9uLSR7dmFyaWFudH0gJHtjbGFzc05hbWV9YH0gb25DbGljaz17b25DbGlja30gZGlzYWJsZWQ9e2Rpc2FibGVkfT57Y2hpbGRyZW59PC9idXR0b24+O1xyXG59XHJcbiJdfQ==