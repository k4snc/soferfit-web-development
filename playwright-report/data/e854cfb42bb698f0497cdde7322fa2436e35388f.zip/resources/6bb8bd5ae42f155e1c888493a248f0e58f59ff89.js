import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/CustomCheckbox.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Icon } from "/src/frontend/components/Icon.tsx";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/CustomCheckbox.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function CustomCheckbox({ checked, onChange, disabled = false, className = "", children }) {
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		role: "checkbox",
		"aria-checked": checked,
		disabled,
		className: `custom-checkbox ${checked ? "checked" : ""} ${className}`,
		onClick: () => onChange(!checked),
		children: [children && /* @__PURE__ */ _jsxDEV("span", {
			className: "checkbox-copy",
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 210
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "checkbox-mark",
			children: checked && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 304
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 260
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = CustomCheckbox;
var _c;
$RefreshReg$(_c, "CustomCheckbox");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/CustomCheckbox.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/CustomCheckbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/CustomCheckbox.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/CustomCheckbox.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZOzs7QUFFckIsT0FBTyxTQUFTLGVBQWUsRUFBRSxTQUFTLFVBQVUsV0FBVyxPQUFPLFlBQVksSUFBSSxZQUE0STtDQUNoTyxPQUFPLHdCQUFDLFVBQUQ7RUFBUSxNQUFLO0VBQVMsTUFBSztFQUFXLGdCQUFjO0VBQW1CO0VBQVUsV0FBVyxtQkFBbUIsVUFBVSxZQUFZLEdBQUcsR0FBRztFQUFhLGVBQWUsU0FBUyxDQUFDLE9BQU87WUFBeEwsQ0FBNEwsWUFBWSx3QkFBQyxRQUFEO0dBQU0sV0FBVTtHQUFpQjtFQUFlOzs7O1lBQUUsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaUIsV0FBVyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztFQUFROzs7O1VBQVM7Ozs7OztBQUNwViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDdXN0b21DaGVja2JveC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuL0ljb25cIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21DaGVja2JveCh7IGNoZWNrZWQsIG9uQ2hhbmdlLCBkaXNhYmxlZCA9IGZhbHNlLCBjbGFzc05hbWUgPSBcIlwiLCBjaGlsZHJlbiB9OiB7IGNoZWNrZWQ6IGJvb2xlYW47IG9uQ2hhbmdlOiAoY2hlY2tlZDogYm9vbGVhbikgPT4gdm9pZDsgZGlzYWJsZWQ/OiBib29sZWFuOyBjbGFzc05hbWU/OiBzdHJpbmc7IGNoaWxkcmVuPzogUmVhY3QuUmVhY3ROb2RlIH0pIHtcclxuICByZXR1cm4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgcm9sZT1cImNoZWNrYm94XCIgYXJpYS1jaGVja2VkPXtjaGVja2VkfSBkaXNhYmxlZD17ZGlzYWJsZWR9IGNsYXNzTmFtZT17YGN1c3RvbS1jaGVja2JveCAke2NoZWNrZWQgPyBcImNoZWNrZWRcIiA6IFwiXCJ9ICR7Y2xhc3NOYW1lfWB9IG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKCFjaGVja2VkKX0+e2NoaWxkcmVuICYmIDxzcGFuIGNsYXNzTmFtZT1cImNoZWNrYm94LWNvcHlcIj57Y2hpbGRyZW59PC9zcGFuPn08c3BhbiBjbGFzc05hbWU9XCJjaGVja2JveC1tYXJrXCI+e2NoZWNrZWQgJiYgPEljb24gbmFtZT1cImNoZWNrXCIgLz59PC9zcGFuPjwvYnV0dG9uPjtcclxufVxyXG4iXX0=