import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/LandingPage.tsx");const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import welcomeImage from "/src/frontend/assets/welcome-training.png?import";
import { BodyMap } from "/src/frontend/components/BodyMap.tsx";
import { Button } from "/src/frontend/components/Button.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { InfoTip } from "/src/frontend/components/InfoTip.tsx";
import { LogoMark } from "/src/frontend/components/LogoMark.tsx";
import { ReviewCarousel } from "/src/frontend/components/ReviewCarousel.tsx";
import { clearFitnessStore } from "/src/frontend/fitnessStore.ts";
import { api } from "/src/frontend/services/api.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/LandingPage.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function LandingPage({ isSignedIn, memberProfile, showProfileMenu, setShowProfileMenu, setShowLogin, setShowSignup, setMemberProfile, setIsSignedIn, setAppToast, navigate, openGlossary, explorer, children }) {
	const { gender, setGender, orientation, setOrientation, selected, fullBody, mode, equipment, routineState, setRoutineState, loadingMessage, explorerAge, setExplorerAge, explorerHeight, setExplorerHeight, explorerWeight, setExplorerWeight, focusArea, list, metricErrors, selectMuscle, selectFullBody, updateMode, updateEquipment } = explorer;
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "landing-page",
		children: [
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "nav shell",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: "brand",
						onClick: () => window.scrollTo({
							top: 0,
							behavior: "smooth"
						}),
						children: [/* @__PURE__ */ _jsxDEV(LogoMark, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 11
						}, this), "SoferFit"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "nav-links",
						children: [
							/* @__PURE__ */ _jsxDEV("a", {
								href: "#features",
								children: "How it works"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("a", {
								href: "#challenge",
								children: "Challenge"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("a", {
								href: "#explore",
								children: "Explore"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 9
					}, this),
					isSignedIn ? /* @__PURE__ */ _jsxDEV("div", {
						className: "member-menu-wrap",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "member-menu-trigger",
							onClick: () => setShowProfileMenu((current) => !current),
							"aria-expanded": showProfileMenu,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: memberProfile?.avatarUrl ? /* @__PURE__ */ _jsxDEV("img", {
								src: memberProfile.avatarUrl,
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 47
							}, this) : memberProfile?.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "SF" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: memberProfile?.name.split(/\s+/)[0] || "Member" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 11
						}, this), showProfileMenu && /* @__PURE__ */ _jsxDEV("div", {
							className: "member-menu",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => navigate("/dashboard"),
								children: "Dashboard"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 60
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: async () => {
									await api.logout();
									clearFitnessStore();
									setMemberProfile(null);
									setIsSignedIn(false);
									setShowProfileMenu(false);
									setAppToast("You've been logged out.");
								},
								children: "Log out"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 125
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 31
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 23
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "nav-auth",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "login-link",
							onClick: () => setShowLogin(true),
							children: "Log in"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							variant: "dark",
							onClick: () => setShowSignup(true),
							children: "Sign up"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 18
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "hero shell",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "hero-copy",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", { children: [
							"Your body.",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 25
							}, this),
							"Your goals."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Adaptive training tailored to your body type, designed for weight management, and structured 60–90 day challenges." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(ReviewCarousel, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hero-trust-actions",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "trust-row",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "avatars",
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: "J" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 103,
											columnNumber: 40
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "M" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 103,
											columnNumber: 54
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "A" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 103,
											columnNumber: 68
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "rating",
									children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "star" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 39
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "4.9/5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 59
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "hero-actions",
								children: /* @__PURE__ */ _jsxDEV(Button, {
									className: "hero-explore",
									onClick: () => document.querySelector("#explore")?.scrollIntoView({ behavior: "smooth" }),
									children: ["Build Your Routine ", /* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 108,
										columnNumber: 36
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "hero-visual",
					children: [
						/* @__PURE__ */ _jsxDEV("img", {
							className: "welcome-image",
							src: welcomeImage,
							alt: "Athlete training in a green outdoor setting"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "float-card workout-card",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "card-icon",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 41
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "TODAY'S FOCUS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "Upper body + core" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 46
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "float-card progress-card",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "progress-ring",
								children: "32%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "TRACK PROGRESS" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "Visualize accomplishments" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 47
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "float-card plan-card",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "card-icon",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 41
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "SMART PLANNING" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "Adapts to you" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 47
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "float-card coach-card",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "card-icon",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 41
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "GUIDED WORKOUT" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 18
							}, this), /* @__PURE__ */ _jsxDEV("strong", { children: "Cues + rest timer" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 47
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "metric-strip",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "100%" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 14
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "FREE" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 35
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "60–90" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 14
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "DAY CHALLENGE" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 36
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
						className: "metric-ai",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 44
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 14
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "GENERATE WORKOUTS" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 74
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "∞" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 14
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "WAYS TO PROGRESS" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 32
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "features shell",
				id: "features",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading centered",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "eyebrow",
						children: "MORE THAN A WORKOUT WEBSITE"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: [
						"Everything you need to",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 37
						}, this),
						/* @__PURE__ */ _jsxDEV("em", { children: "keep showing up." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 43
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "feature-grid",
					children: [
						/* @__PURE__ */ _jsxDEV("article", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-icon feature-icon-violet",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 70
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 20
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", { children: "AI-made for you" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 97
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Plans are made based on your body type, equipment access, and fat-reduction goals." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 121
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("article", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-icon feature-icon-violet",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 70
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 20
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", { children: "Progress, made visible" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 100
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "A calendar heatmap, active workouts, streaks, and meaningful stats in one view." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 131
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("article", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "feature-icon feature-icon-violet",
								children: /* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 70
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 20
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", { children: "Encouragement" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 96
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Step-by-step guidance, active countdown timers, set/rep counters, and real-time encouragement." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 118
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "challenge",
				id: "challenge",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "shell",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "challenge-copy",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: [
								"One challenge.",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 31
								}, this),
								/* @__PURE__ */ _jsxDEV("em", { children: "Built around you." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 37
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Tell us your starting point, schedule, equipment, and goal. SoferFit shapes every session—and adapts to you." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("ul", { children: [
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 19
								}, this), " Choose a 60 or 90-day roadmap"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 19
								}, this), " Smart recovery and session adjustments"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 19
								}, this), " Encouragement exactly when you need it"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "dashboard-card",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "dash-top",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "GOOD MORNING, KENNETH" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 44
								}, this), /* @__PURE__ */ _jsxDEV("h3", { children: "Keep your rhythm! 🌞" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 80
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 39
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "DAY 24 / 90" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 115
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "calendar",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "calendar-head",
										children: [/* @__PURE__ */ _jsxDEV("strong", { children: "SEPTEMBER" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 46
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "3 week streak 🔥" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 72
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "week days",
										children: [
											/* @__PURE__ */ _jsxDEV("span", { children: "M" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 42
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 56
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "W" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 70
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 84
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "F" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 98
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "S" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 112
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "S" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 126
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 15
									}, this),
									[
										0,
										1,
										2,
										3
									].map((week) => /* @__PURE__ */ _jsxDEV("div", {
										className: "week",
										children: [
											1,
											2,
											3,
											4,
											5,
											6,
											7
										].map((day) => {
											const num = week * 7 + day;
											const dayClass = num <= 23 ? "done" : num === 24 ? "today" : num >= 25 ? "blue-day" : "";
											return /* @__PURE__ */ _jsxDEV("span", {
												className: dayClass,
												children: num
											}, day, false, {
												fileName: _jsxFileName,
												lineNumber: 181,
												columnNumber: 28
											}, this);
										})
									}, week, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 17
									}, this))
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "dash-stats",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "mini-icon",
											children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 48
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 20
										}, this),
										/* @__PURE__ */ _jsxDEV("small", { children: "CHALLENGE" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 79
										}, this),
										/* @__PURE__ */ _jsxDEV("strong", { children: ["Day 24 ", /* @__PURE__ */ _jsxDEV("i", { children: "/ 60" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 118
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 103
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "mini-icon lime",
											children: /* @__PURE__ */ _jsxDEV(Icon, { name: "chart" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 188,
												columnNumber: 53
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 20
										}, this),
										/* @__PURE__ */ _jsxDEV("small", { children: "TARGET PROGRESS" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 81
										}, this),
										/* @__PURE__ */ _jsxDEV("strong", { children: "32%" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 111
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "mini-icon peach",
											children: /* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 189,
												columnNumber: 54
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 189,
											columnNumber: 20
										}, this),
										/* @__PURE__ */ _jsxDEV("small", { children: "ACTIVE TIME" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 189,
											columnNumber: 81
										}, this),
										/* @__PURE__ */ _jsxDEV("strong", { children: "16.4h" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 189,
											columnNumber: 107
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "explorer shell",
				id: "explore",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: [
						"Select Your Focus Area.",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 38
						}, this),
						/* @__PURE__ */ _jsxDEV("em", { children: "Build Your Routine." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 44
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Choose the area you want to tone or target for fat reduction." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 196,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "explorer-grid",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "map-panel",
						children: /* @__PURE__ */ _jsxDEV(BodyMap, {
							gender,
							orientation,
							selected,
							fullBody,
							disabled: routineState !== "idle",
							onSelect: selectMuscle
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "exercise-panel",
						children: [
							routineState === "idle" && /* @__PURE__ */ _jsxDEV("div", {
								className: "routine-state routine-idle",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-state-head",
										children: [/* @__PURE__ */ _jsxDEV("small", { children: "YOUR ROUTINE" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 208,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("h3", { children: focusArea ?? "No focus area selected" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-state-scroll",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "routine-controls",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "control-row focus-orientation-row",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "filter-group",
														children: [/* @__PURE__ */ _jsxDEV("small", { children: "FOCUS AREA" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 215,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "filter-pills",
															children: /* @__PURE__ */ _jsxDEV("button", {
																className: fullBody ? "active" : "",
																onClick: selectFullBody,
																children: "Full Body"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 216,
																columnNumber: 55
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 216,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 214,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "filter-group",
														children: [/* @__PURE__ */ _jsxDEV("small", { children: "ORIENTATION" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 219,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "filter-pills",
															children: ["Front", "Back"].map((item) => /* @__PURE__ */ _jsxDEV("button", {
																className: orientation === item ? "active" : "",
																onClick: () => setOrientation(item),
																children: item
															}, item, false, {
																fileName: _jsxFileName,
																lineNumber: 222,
																columnNumber: 29
															}, this))
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 220,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 218,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 213,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "control-row model-metrics-row",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "filter-group",
														children: [/* @__PURE__ */ _jsxDEV("small", { children: "MODEL" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 229,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "filter-pills",
															children: ["Man", "Woman"].map((item) => /* @__PURE__ */ _jsxDEV("button", {
																className: gender === item ? "active" : "",
																onClick: () => setGender(item),
																children: item
															}, item, false, {
																fileName: _jsxFileName,
																lineNumber: 232,
																columnNumber: 29
															}, this))
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 230,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 228,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "metric-inputs",
														children: [
															/* @__PURE__ */ _jsxDEV("label", { children: [
																"Age",
																/* @__PURE__ */ _jsxDEV("input", {
																	type: "number",
																	min: "10",
																	max: "100",
																	value: explorerAge,
																	onChange: (event) => setExplorerAge(event.target.value),
																	placeholder: "24"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 237,
																	columnNumber: 35
																}, this),
																metricErrors.age && /* @__PURE__ */ _jsxDEV("small", { children: metricErrors.age }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 237,
																	columnNumber: 192
																}, this)
															] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 237,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("label", { children: [
																"Height",
																/* @__PURE__ */ _jsxDEV("input", {
																	type: "number",
																	min: "100",
																	max: "250",
																	value: explorerHeight,
																	onChange: (event) => setExplorerHeight(event.target.value),
																	placeholder: "175 cm"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 238,
																	columnNumber: 38
																}, this),
																metricErrors.height && /* @__PURE__ */ _jsxDEV("small", { children: metricErrors.height }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 238,
																	columnNumber: 209
																}, this)
															] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 238,
																columnNumber: 25
															}, this),
															/* @__PURE__ */ _jsxDEV("label", { children: [
																"Weight",
																/* @__PURE__ */ _jsxDEV("input", {
																	type: "number",
																	min: "25",
																	max: "300",
																	value: explorerWeight,
																	onChange: (event) => setExplorerWeight(event.target.value),
																	placeholder: "70 kg"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 239,
																	columnNumber: 38
																}, this),
																metricErrors.weight && /* @__PURE__ */ _jsxDEV("small", { children: metricErrors.weight }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 239,
																	columnNumber: 207
																}, this)
															] }, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 239,
																columnNumber: 25
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 236,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 227,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "filter-group",
													children: [/* @__PURE__ */ _jsxDEV("small", {
														className: "label-with-info",
														children: ["TRAINING ", /* @__PURE__ */ _jsxDEV(InfoTip, {
															term: "Training",
															definition: "Defines routine intensity and rep schemes.",
															actionLabel: "View Glossary",
															showTerm: false,
															onLearnMore: () => openGlossary("Fat Loss & Cardio")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 243,
															columnNumber: 67
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 243,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "filter-pills",
														children: [
															"Fat Loss & Cardio",
															"HIIT",
															"Muscle & Strength"
														].map((item) => /* @__PURE__ */ _jsxDEV("button", {
															className: mode === item ? "active" : "",
															onClick: () => updateMode(item),
															children: item
														}, item, false, {
															fileName: _jsxFileName,
															lineNumber: 246,
															columnNumber: 27
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 244,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 242,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "filter-group",
													children: [/* @__PURE__ */ _jsxDEV("small", {
														className: "label-with-info",
														children: ["EQUIPMENT ", /* @__PURE__ */ _jsxDEV(InfoTip, {
															term: "Equipment",
															definition: "Choose whether your routine should use only your body weight or common gym equipment.",
															actionLabel: "View Glossary",
															onLearnMore: () => openGlossary("Bodyweight")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 251,
															columnNumber: 68
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 251,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "filter-pills",
														children: [/* @__PURE__ */ _jsxDEV("button", {
															className: equipment === "No Equipment / Bodyweight" ? "active" : "",
															onClick: () => updateEquipment("No Equipment / Bodyweight"),
															children: "Bodyweight / Home"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 253,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															className: equipment === "Gym Equipment" ? "active" : "",
															onClick: () => updateEquipment("Gym Equipment"),
															children: "Gym Equipment"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 254,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 252,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 250,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 212,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 211,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-state-action",
										children: [/* @__PURE__ */ _jsxDEV(Button, {
											disabled: !focusArea || !mode || !equipment,
											onClick: () => setRoutineState("loading"),
											children: "Generate workout routine "
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("small", { children: "AI generation is limited, use wisely." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 259,
										columnNumber: 17
									}, this)
								]
							}, "idle", true, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 15
							}, this),
							routineState === "loading" && /* @__PURE__ */ _jsxDEV("div", {
								className: "routine-state routine-loading",
								"aria-live": "polite",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "loading-copy",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "generation-spinner" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("strong", { children: loadingMessage === 0 ? "Analyzing body focus and target metrics..." : "Balancing rep schemes, equipment, and rest intervals..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 270,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "skeleton-list",
									"aria-hidden": "true",
									children: [
										0,
										1,
										2
									].map((item) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 60
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 71
									}, this), /* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 76
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 65
									}, this)] }, item, true, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 44
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 272,
									columnNumber: 17
								}, this)]
							}, "loading", true, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 15
							}, this),
							routineState === "results" && /* @__PURE__ */ _jsxDEV("div", {
								className: "routine-state routine-results",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-results-head",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h3", { children: "Your Generated Routine" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 24
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: focusArea }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 282,
											columnNumber: 24
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: mode }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 282,
											columnNumber: 48
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 282,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 280,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-state-scroll result-list",
										children: list.map((exercise) => /* @__PURE__ */ _jsxDEV("article", {
											className: "result-card",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "dumbbell-icon",
													children: /* @__PURE__ */ _jsxDEV(Icon, { name: "dumbbell" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 287,
														columnNumber: 55
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 287,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "exercise-name",
													children: [/* @__PURE__ */ _jsxDEV("strong", { children: exercise.name }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 288,
														columnNumber: 55
													}, this), /* @__PURE__ */ _jsxDEV("small", { children: exercise.reps }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 288,
														columnNumber: 87
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 288,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "muscle-tag",
													children: exercise.tag
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 289,
													columnNumber: 23
												}, this)
											]
										}, exercise.name, true, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 284,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "routine-result-action",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "save-routine-banner",
											children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Save this routine and start your 60–90 day transformation challenge!" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 295,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV(Button, {
												onClick: () => setShowSignup(true),
												children: "Create Profile"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 296,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 294,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 293,
										columnNumber: 17
									}, this)
								]
							}, "results", true, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", { children: [/* @__PURE__ */ _jsxDEV("div", { className: "shell footer-divider" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 306,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "shell footer-bottom",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: "© 2026 SoferFit. All rights reserved." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 308,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Legal links",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: "footer-glossary",
							onClick: () => openGlossary(),
							children: " Glossary"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#privacy-policy",
							children: "Privacy Policy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#terms-of-service",
							children: "Terms of Service"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 312,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#cookies",
							children: "Cookies"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 7
			}, this),
			children
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_c = LandingPage;
var _c;
$RefreshReg$(_c, "LandingPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/LandingPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/LandingPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/LandingPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/LandingPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxrQkFBa0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsY0FBYztBQUN2QixTQUFTLFlBQVk7QUFDckIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsV0FBVzs7O0FBb0JwQixPQUFPLFNBQVMsWUFBWSxFQUMxQixZQUNBLGVBQ0EsaUJBQ0Esb0JBQ0EsY0FDQSxlQUNBLGtCQUNBLGVBQ0EsYUFDQSxVQUNBLGNBQ0EsVUFDQSxZQUNtQjtDQUNuQixNQUFNLEVBQ0osUUFDQSxXQUNBLGFBQ0EsZ0JBQ0EsVUFDQSxVQUNBLE1BQ0EsV0FDQSxjQUNBLGlCQUNBLGdCQUNBLGFBQ0EsZ0JBQ0EsZ0JBQ0EsbUJBQ0EsZ0JBQ0EsbUJBQ0EsV0FDQSxNQUNBLGNBQ0EsY0FDQSxnQkFDQSxZQUNBLG9CQUNFO0NBRUosT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFRLGVBQWUsT0FBTyxTQUFTO09BQUUsS0FBSztPQUFHLFVBQVU7TUFBUyxDQUFDO2dCQUF2RixDQUNFLHdCQUFDLFVBQUQsQ0FBVzs7OztnQkFBQyxVQUVOOzs7Ozs7S0FDUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFZO09BQWU7Ozs7O09BQ25DLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFhO09BQVk7Ozs7O09BQ2pDLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFXO09BQVU7Ozs7O01BQzFCOzs7Ozs7S0FDSixhQUFhLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ1osd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBc0IsZUFBZSxvQkFBb0IsWUFBWSxDQUFDLE9BQU87T0FBRyxpQkFBZTtpQkFBakgsQ0FDRSx3QkFBQyxRQUFELFlBQU8sZUFBZSxZQUFZLHdCQUFDLE9BQUQ7UUFBSyxLQUFLLGNBQWM7UUFBVyxLQUFJO09BQUk7Ozs7a0JBQUksZUFBZSxLQUFLLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsWUFBWSxLQUFLLEtBQVc7Ozs7aUJBQzFMLHdCQUFDLFVBQUQsWUFBUyxlQUFlLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxNQUFNLFNBQWlCOzs7O2VBQzNEOzs7OztnQkFDUCxtQkFBbUIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNkIsd0JBQUMsVUFBRDtRQUFRLGVBQWUsU0FBUyxZQUFZO2tCQUFHO09BQWlCOzs7O2lCQUFDLHdCQUFDLFVBQUQ7UUFBUSxTQUFTLFlBQVk7U0FBRSxNQUFNLElBQUksT0FBTztTQUFHLGtCQUFrQjtTQUFHLGlCQUFpQixJQUFJO1NBQUcsY0FBYyxLQUFLO1NBQUcsbUJBQW1CLEtBQUs7U0FBRyxZQUFZLHlCQUF5QjtRQUFHO2tCQUFHO09BQWU7Ozs7ZUFBTTs7Ozs7Y0FDaFU7Ozs7O2dCQUFJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ1Asd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBYSxlQUFlLGFBQWEsSUFBSTtpQkFBRztNQUFjOzs7O2dCQUNoRix3QkFBQyxRQUFEO09BQVEsU0FBUTtPQUFPLGVBQWUsY0FBYyxJQUFJO2lCQUFHO01BQWU7Ozs7Y0FDdkU7Ozs7OztJQUNGOzs7Ozs7R0FFTCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFEO09BQUk7T0FBVSx3QkFBQyxNQUFELENBQUs7Ozs7O09BQUM7TUFBZTs7Ozs7TUFDbkMsd0JBQUMsS0FBRCxZQUFHLHFIQUFxSDs7Ozs7TUFDeEgsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O01BQ2pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUF5Qix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7VUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7VUFBQyx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FBTTs7Ozs7a0JBQ3hFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQXdCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7bUJBQUMsd0JBQUMsVUFBRCxZQUFRLFFBQWE7Ozs7aUJBQU07Ozs7O2dCQUNwRTs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRDtTQUFRLFdBQVU7U0FBZSxlQUFlLFNBQVMsY0FBYyxVQUFVLENBQUMsRUFBRSxlQUFlLEVBQUUsVUFBVSxTQUFTLENBQUM7bUJBQXpILENBQTRILHVCQUN2Ryx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O2lCQUNqQzs7Ozs7O09BQ0w7Ozs7ZUFDRjs7Ozs7O0tBQ0Y7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQWdCLEtBQUs7T0FBYyxLQUFJO01BQStDOzs7OztNQUNyRyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O09BQU87Ozs7aUJBQ3RELHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sZ0JBQW9COzs7O2lCQUFDLHdCQUFDLFVBQUQsWUFBUSxvQkFBeUI7Ozs7ZUFBTTs7OztlQUNyRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZ0I7T0FBUTs7OztpQkFDdkMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQsWUFBTyxpQkFBcUI7Ozs7aUJBQUMsd0JBQUMsVUFBRCxZQUFRLDRCQUFpQzs7OztlQUFNOzs7O2VBQzlFOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O09BQU87Ozs7aUJBQ3ZELHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8saUJBQXFCOzs7O2lCQUFDLHdCQUFDLFVBQUQsWUFBUSxnQkFBcUI7Ozs7ZUFBTTs7OztlQUNsRTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBWSx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztPQUFPOzs7O2lCQUN2RCx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLGlCQUFxQjs7OztpQkFBQyx3QkFBQyxVQUFELFlBQVEsb0JBQXlCOzs7O2VBQU07Ozs7ZUFDdEU7Ozs7OztLQUNGOzs7OztZQUNFOzs7Ozs7R0FFVCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSxPQUFZOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7YUFBTTs7Ozs7S0FDaEQsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSxRQUFhOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzthQUFNOzs7OztLQUMxRCx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRDtNQUFRLFdBQVU7Z0JBQVksd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7S0FBUzs7OztlQUFDLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7YUFBTTs7Ozs7S0FDcEcsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSxJQUFTOzs7O2VBQUMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OzthQUFNOzs7OztJQUN0RDs7Ozs7O0dBRUwsd0JBQUMsV0FBRDtJQUFTLFdBQVU7SUFBaUIsSUFBRztjQUF2QyxDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBVTtLQUFnQzs7OztlQUN6RCx3QkFBQyxNQUFEO01BQUk7TUFBc0Isd0JBQUMsTUFBRCxDQUFLOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7O0tBQUs7Ozs7YUFDMUQ7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFdBQUQ7T0FBUyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBbUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7T0FBTTs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUksa0JBQW1COzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBRyxxRkFBcUY7Ozs7O01BQVU7Ozs7O01BQ2hOLHdCQUFDLFdBQUQ7T0FBUyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBbUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssV0FBWTs7Ozs7T0FBTTs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUkseUJBQTBCOzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBRyxrRkFBa0Y7Ozs7O01BQVU7Ozs7O01BQ3ZOLHdCQUFDLFdBQUQ7T0FBUyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBbUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7T0FBTTs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztPQUFDLHdCQUFDLEtBQUQsWUFBRyxpR0FBaUc7Ozs7O01BQVU7Ozs7O0tBQ3ROOzs7OztZQUNFOzs7Ozs7R0FFVCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtJQUFZLElBQUc7Y0FDaEMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJO1FBQWMsd0JBQUMsTUFBRCxDQUFLOzs7OztRQUFDLHdCQUFDLE1BQUQsWUFBSSxvQkFBcUI7Ozs7O09BQUs7Ozs7O09BQ3RELHdCQUFDLEtBQUQsWUFBRywrR0FBK0c7Ozs7O09BQ2xILHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFELGFBQUksd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztrQkFBQyxnQ0FBa0M7Ozs7O1FBQzNELHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7O2tCQUFDLHlDQUEyQzs7Ozs7UUFDcEUsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7a0JBQUMseUNBQTJDOzs7OztPQUNsRTs7Ozs7TUFDRDs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTBCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8sd0JBQTRCOzs7O2tCQUFDLHdCQUFDLE1BQUQsWUFBSSx1QkFBd0I7Ozs7Z0JBQU07Ozs7a0JBQUMsd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O2dCQUFNOzs7Ozs7T0FDbkksd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUErQix3QkFBQyxVQUFELFlBQVEsWUFBaUI7Ozs7b0JBQUMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztrQkFBTTs7Ozs7O1NBQzNGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQTJCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztVQUFNOzs7Ozs7U0FDakk7VUFBQztVQUFHO1VBQUc7VUFBRztTQUFDLENBQUMsQ0FBQyxLQUFLLFNBQ2pCLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaO1dBQUM7V0FBRztXQUFHO1dBQUc7V0FBRztXQUFHO1dBQUc7VUFBQyxDQUFDLENBQUMsS0FBSyxRQUFRO1dBQ2xDLE1BQU0sTUFBTSxPQUFPLElBQUk7V0FDdkIsTUFBTSxXQUFXLE9BQU8sS0FDcEIsU0FDQSxRQUFRLEtBQ04sVUFDQSxPQUFPLEtBQ0wsYUFDQTtXQUNSLE9BQU8sd0JBQUMsUUFBRDtZQUFnQixXQUFXO3NCQUFXO1dBQVUsR0FBckM7Ozs7a0JBQXFDO1VBQ3pELENBQUM7U0FDRSxHQVpzQjs7OztnQkFZdEIsQ0FDTjtRQUNFOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBWSx3QkFBQyxNQUFELEVBQU0sTUFBSyxXQUFZOzs7OztVQUFPOzs7OztVQUFDLHdCQUFDLFNBQUQsWUFBTyxZQUFnQjs7Ozs7VUFBQyx3QkFBQyxVQUFELGFBQVEsV0FBTyx3QkFBQyxLQUFELFlBQUcsT0FBTzs7OztrQkFBUzs7Ozs7U0FBTTs7Ozs7U0FDaEksd0JBQUMsT0FBRDtVQUFLLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFpQix3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztVQUFPOzs7OztVQUFDLHdCQUFDLFNBQUQsWUFBTyxrQkFBc0I7Ozs7O1VBQUMsd0JBQUMsVUFBRCxZQUFRLE1BQVc7Ozs7O1NBQU07Ozs7O1NBQ3pILHdCQUFDLE9BQUQ7VUFBSyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBa0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssT0FBUTs7Ozs7VUFBTzs7Ozs7VUFBQyx3QkFBQyxTQUFELFlBQU8sY0FBa0I7Ozs7O1VBQUMsd0JBQUMsVUFBRCxZQUFRLFFBQWE7Ozs7O1NBQU07Ozs7O1FBQ3BIOzs7Ozs7TUFDRjs7Ozs7YUFDRjs7Ozs7O0dBQ0U7Ozs7O0dBRVQsd0JBQUMsV0FBRDtJQUFTLFdBQVU7SUFBaUIsSUFBRztjQUF2QyxDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUk7TUFBdUIsd0JBQUMsTUFBRCxDQUFLOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7O0tBQUs7Ozs7ZUFDakUsd0JBQUMsS0FBRCxZQUFHLGdFQUFnRTs7OzthQUNoRTs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRDtPQUFpQjtPQUFxQjtPQUF1QjtPQUFvQjtPQUFVLFVBQVUsaUJBQWlCO09BQVEsVUFBVTtNQUFlOzs7OztLQUNwSjs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0csaUJBQWlCLFVBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFELFlBQU8sZUFBbUI7Ozs7b0JBQzFCLHdCQUFDLE1BQUQsWUFBSyxhQUFhLHlCQUE2Qjs7OztrQkFDNUM7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNFLHdCQUFDLFNBQUQsWUFBTyxhQUFpQjs7Ozt3QkFDeEIsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWUsd0JBQUMsVUFBRDtnQkFBUSxXQUFXLFdBQVcsV0FBVztnQkFBSSxTQUFTOzBCQUFnQjtlQUFpQjs7Ozs7Y0FBTTs7OztzQkFDeEg7Ozs7O3VCQUNMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0Usd0JBQUMsU0FBRCxZQUFPLGNBQWtCOzs7O3dCQUN6Qix3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFDWCxDQUFDLFNBQVMsTUFBTSxDQUFDLENBQW1CLEtBQUssU0FDekMsd0JBQUMsVUFBRDtnQkFBbUIsV0FBVyxnQkFBZ0IsT0FBTyxXQUFXO2dCQUFJLGVBQWUsZUFBZSxJQUFJOzBCQUFJO2VBQWEsR0FBMUc7Ozs7c0JBQTBHLENBQ3hIO2NBQ0U7Ozs7c0JBQ0Y7Ozs7O3FCQUNGOzs7Ozs7WUFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0Usd0JBQUMsU0FBRCxZQUFPLFFBQVk7Ozs7d0JBQ25CLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUNYLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBYyxLQUFLLFNBQ25DLHdCQUFDLFVBQUQ7Z0JBQW1CLFdBQVcsV0FBVyxPQUFPLFdBQVc7Z0JBQUksZUFBZSxVQUFVLElBQUk7MEJBQUk7ZUFBYSxHQUFoRzs7OztzQkFBZ0csQ0FDOUc7Y0FDRTs7OztzQkFDRjs7Ozs7dUJBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWY7ZUFDRSx3QkFBQyxTQUFEO2dCQUFPO2dCQUFHLHdCQUFDLFNBQUQ7aUJBQU8sTUFBSztpQkFBUyxLQUFJO2lCQUFLLEtBQUk7aUJBQU0sT0FBTztpQkFBYSxXQUFXLFVBQVUsZUFBZSxNQUFNLE9BQU8sS0FBSztpQkFBRyxhQUFZO2dCQUFNOzs7OztnQkFBRSxhQUFhLE9BQU8sd0JBQUMsU0FBRCxZQUFRLGFBQWEsSUFBVzs7Ozs7ZUFBUzs7Ozs7ZUFDaE4sd0JBQUMsU0FBRDtnQkFBTztnQkFBTSx3QkFBQyxTQUFEO2lCQUFPLE1BQUs7aUJBQVMsS0FBSTtpQkFBTSxLQUFJO2lCQUFNLE9BQU87aUJBQWdCLFdBQVcsVUFBVSxrQkFBa0IsTUFBTSxPQUFPLEtBQUs7aUJBQUcsYUFBWTtnQkFBVTs7Ozs7Z0JBQUUsYUFBYSxVQUFVLHdCQUFDLFNBQUQsWUFBUSxhQUFhLE9BQWM7Ozs7O2VBQVM7Ozs7O2VBQ3BPLHdCQUFDLFNBQUQ7Z0JBQU87Z0JBQU0sd0JBQUMsU0FBRDtpQkFBTyxNQUFLO2lCQUFTLEtBQUk7aUJBQUssS0FBSTtpQkFBTSxPQUFPO2lCQUFnQixXQUFXLFVBQVUsa0JBQWtCLE1BQU0sT0FBTyxLQUFLO2lCQUFHLGFBQVk7Z0JBQVM7Ozs7O2dCQUFFLGFBQWEsVUFBVSx3QkFBQyxTQUFELFlBQVEsYUFBYSxPQUFjOzs7OztlQUFTOzs7OztjQUMvTjs7Ozs7cUJBQ0Y7Ozs7OztZQUNMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsU0FBRDtjQUFPLFdBQVU7d0JBQWpCLENBQW1DLGFBQVMsd0JBQUMsU0FBRDtlQUFTLE1BQUs7ZUFBVyxZQUFXO2VBQTZDLGFBQVk7ZUFBZ0IsVUFBVTtlQUFPLG1CQUFtQixhQUFhLG1CQUFtQjtjQUFJOzs7O3NCQUFROzs7Ozt1QkFDek8sd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQ1g7ZUFBQztlQUFxQjtlQUFRO2NBQW1CLENBQUMsQ0FBb0IsS0FBSyxTQUMzRSx3QkFBQyxVQUFEO2VBQW1CLFdBQVcsU0FBUyxPQUFPLFdBQVc7ZUFBSSxlQUFlLFdBQVcsSUFBSTt5QkFBSTtjQUFhLEdBQS9GOzs7O3FCQUErRixDQUM3RzthQUNFOzs7O3FCQUNGOzs7Ozs7WUFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFNBQUQ7Y0FBTyxXQUFVO3dCQUFqQixDQUFtQyxjQUFVLHdCQUFDLFNBQUQ7ZUFBUyxNQUFLO2VBQVksWUFBVztlQUF3RixhQUFZO2VBQWdCLG1CQUFtQixhQUFhLFlBQVk7Y0FBSTs7OztzQkFBUTs7Ozs7dUJBQzlQLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0Usd0JBQUMsVUFBRDtlQUFRLFdBQVcsY0FBYyw4QkFBOEIsV0FBVztlQUFJLGVBQWUsZ0JBQWdCLDJCQUEyQjt5QkFBRztjQUF5Qjs7Ozt3QkFDcEssd0JBQUMsVUFBRDtlQUFRLFdBQVcsY0FBYyxrQkFBa0IsV0FBVztlQUFJLGVBQWUsZ0JBQWdCLGVBQWU7eUJBQUc7Y0FBcUI7Ozs7c0JBQ3JJOzs7OztxQkFDRjs7Ozs7O1dBQ0Y7Ozs7OztTQUNGOzs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFRLFVBQVUsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDO1dBQVcsZUFBZSxnQkFBZ0IsU0FBUztxQkFBRztVQUFpQzs7OztvQkFDakksd0JBQUMsU0FBRCxZQUFPLHdDQUE0Qzs7OztrQkFDaEQ7Ozs7OztRQUNGO1VBekQyQzs7OztjQXlEM0M7T0FHTixpQkFBaUIsYUFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBOEMsYUFBVTtrQkFBdkUsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHFCQUFzQjs7OzttQkFDdEMsd0JBQUMsVUFBRCxZQUFTLG1CQUFtQixJQUFJLCtDQUErQywwREFBa0U7Ozs7aUJBQzlJOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFnQixlQUFZO21CQUN4QztVQUFDO1VBQUc7VUFBRztTQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsd0JBQUMsT0FBRCxhQUFnQix3QkFBQyxLQUFELENBQUk7Ozs7bUJBQUMsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLEtBQUQsQ0FBSTs7OzttQkFBQyx3QkFBQyxLQUFELENBQUk7Ozs7aUJBQU87Ozs7aUJBQU0sS0FBdkM7Ozs7Z0JBQXVDLENBQUM7UUFDeEU7Ozs7Z0JBQ0Y7VUFSOEM7Ozs7Y0FROUM7T0FHTixpQkFBaUIsYUFDaEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsWUFBSyx3QkFBQyxNQUFELFlBQUkseUJBQTBCOzs7O21CQUFNOzs7O29CQUN6Qyx3QkFBQyxPQUFELGFBQUssd0JBQUMsUUFBRCxZQUFPLFVBQWdCOzs7O29CQUFDLHdCQUFDLFFBQUQsWUFBTyxLQUFXOzs7O2tCQUFNOzs7O2tCQUNsRDs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osS0FBSyxLQUFLLGFBQ1Qsd0JBQUMsV0FBRDtXQUFTLFdBQVU7cUJBQW5CO1lBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWdCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7O1lBQU87Ozs7O1lBQzlELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUFnQyx3QkFBQyxVQUFELFlBQVMsU0FBUyxLQUFhOzs7O3VCQUFDLHdCQUFDLFNBQUQsWUFBUSxTQUFTLEtBQVk7Ozs7cUJBQU87Ozs7OztZQUNwRyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBYyxTQUFTO1lBQVU7Ozs7O1dBQzFDO2FBSjZCLFNBQVM7Ozs7aUJBSXRDLENBQ1Y7U0FDRTs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFVBQUQsWUFBUSx1RUFBNEU7Ozs7cUJBQ3BGLHdCQUFDLFFBQUQ7WUFBUSxlQUFlLGNBQWMsSUFBSTtzQkFBRztXQUFzQjs7OzttQkFDL0Q7Ozs7OztTQUNGOzs7OztRQUNGO1VBcEI4Qzs7OztjQW9COUM7TUFFSjs7Ozs7YUFDRjs7Ozs7WUFDRTs7Ozs7O0dBRVQsd0JBQUMsVUFBRCxhQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVCQUF3Qjs7OzthQUN2Qyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRCxZQUFHLHdDQUF3Qzs7OztjQUMzQyx3QkFBQyxPQUFEO0tBQUssY0FBVztlQUFoQjtNQUNFLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQWtCLGVBQWUsYUFBYTtpQkFBRztNQUFpQjs7Ozs7TUFDcEYsd0JBQUMsS0FBRDtPQUFHLE1BQUs7aUJBQWtCO01BQWlCOzs7OztNQUMzQyx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBb0I7TUFBbUI7Ozs7O01BQy9DLHdCQUFDLEtBQUQ7T0FBRyxNQUFLO2lCQUFXO01BQVU7Ozs7O0tBQzFCOzs7OztZQUNGOzs7OztXQUNDOzs7OztHQUNQO0VBQ0c7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhbmRpbmdQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IERpc3BhdGNoLCBSZWFjdE5vZGUsIFNldFN0YXRlQWN0aW9uIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB3ZWxjb21lSW1hZ2UgZnJvbSBcIi4uL2Fzc2V0cy93ZWxjb21lLXRyYWluaW5nLnBuZ1wiO1xyXG5pbXBvcnQgeyBCb2R5TWFwIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQm9keU1hcFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9CdXR0b25cIjtcclxuaW1wb3J0IHsgSWNvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0ljb25cIjtcclxuaW1wb3J0IHsgSW5mb1RpcCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0luZm9UaXBcIjtcclxuaW1wb3J0IHsgTG9nb01hcmsgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Mb2dvTWFya1wiO1xyXG5pbXBvcnQgeyBSZXZpZXdDYXJvdXNlbCB9IGZyb20gXCIuLi9jb21wb25lbnRzL1Jldmlld0Nhcm91c2VsXCI7XHJcbmltcG9ydCB7IGNsZWFyRml0bmVzc1N0b3JlIH0gZnJvbSBcIi4uL2ZpdG5lc3NTdG9yZVwiO1xyXG5pbXBvcnQgeyBhcGkgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpXCI7XHJcbmltcG9ydCB0eXBlIHsgR2VuZGVyLCBPcmllbnRhdGlvbiwgU2lnbnVwQW5zd2VycywgVHJhaW5pbmdNb2RlIH0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcbmltcG9ydCB0eXBlIHsgdXNlRXhwbG9yZXIgfSBmcm9tIFwiLi4vaG9va3MvdXNlRXhwbG9yZXJcIjtcclxuXHJcbnR5cGUgTGFuZGluZ1BhZ2VQcm9wcyA9IHtcclxuICBpc1NpZ25lZEluOiBib29sZWFuO1xyXG4gIG1lbWJlclByb2ZpbGU6IFNpZ251cEFuc3dlcnMgfCBudWxsO1xyXG4gIHNob3dQcm9maWxlTWVudTogYm9vbGVhbjtcclxuICBzZXRTaG93UHJvZmlsZU1lbnU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPGJvb2xlYW4+PjtcclxuICBzZXRTaG93TG9naW46IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPGJvb2xlYW4+PjtcclxuICBzZXRTaG93U2lnbnVwOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxib29sZWFuPj47XHJcbiAgc2V0TWVtYmVyUHJvZmlsZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248U2lnbnVwQW5zd2VycyB8IG51bGw+PjtcclxuICBzZXRJc1NpZ25lZEluOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxib29sZWFuPj47XHJcbiAgc2V0QXBwVG9hc3Q6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZyB8IG51bGw+PjtcclxuICBuYXZpZ2F0ZTogKHBhdGg6IHN0cmluZywgcmVwbGFjZT86IGJvb2xlYW4pID0+IHZvaWQ7XHJcbiAgb3Blbkdsb3NzYXJ5OiAodGVybT86IHN0cmluZykgPT4gdm9pZDtcclxuICBleHBsb3JlcjogUmV0dXJuVHlwZTx0eXBlb2YgdXNlRXhwbG9yZXI+O1xyXG4gIGNoaWxkcmVuPzogUmVhY3ROb2RlO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIExhbmRpbmdQYWdlKHtcclxuICBpc1NpZ25lZEluLFxyXG4gIG1lbWJlclByb2ZpbGUsXHJcbiAgc2hvd1Byb2ZpbGVNZW51LFxyXG4gIHNldFNob3dQcm9maWxlTWVudSxcclxuICBzZXRTaG93TG9naW4sXHJcbiAgc2V0U2hvd1NpZ251cCxcclxuICBzZXRNZW1iZXJQcm9maWxlLFxyXG4gIHNldElzU2lnbmVkSW4sXHJcbiAgc2V0QXBwVG9hc3QsXHJcbiAgbmF2aWdhdGUsXHJcbiAgb3Blbkdsb3NzYXJ5LFxyXG4gIGV4cGxvcmVyLFxyXG4gIGNoaWxkcmVuLFxyXG59OiBMYW5kaW5nUGFnZVByb3BzKSB7XHJcbiAgY29uc3Qge1xyXG4gICAgZ2VuZGVyLFxyXG4gICAgc2V0R2VuZGVyLFxyXG4gICAgb3JpZW50YXRpb24sXHJcbiAgICBzZXRPcmllbnRhdGlvbixcclxuICAgIHNlbGVjdGVkLFxyXG4gICAgZnVsbEJvZHksXHJcbiAgICBtb2RlLFxyXG4gICAgZXF1aXBtZW50LFxyXG4gICAgcm91dGluZVN0YXRlLFxyXG4gICAgc2V0Um91dGluZVN0YXRlLFxyXG4gICAgbG9hZGluZ01lc3NhZ2UsXHJcbiAgICBleHBsb3JlckFnZSxcclxuICAgIHNldEV4cGxvcmVyQWdlLFxyXG4gICAgZXhwbG9yZXJIZWlnaHQsXHJcbiAgICBzZXRFeHBsb3JlckhlaWdodCxcclxuICAgIGV4cGxvcmVyV2VpZ2h0LFxyXG4gICAgc2V0RXhwbG9yZXJXZWlnaHQsXHJcbiAgICBmb2N1c0FyZWEsXHJcbiAgICBsaXN0LFxyXG4gICAgbWV0cmljRXJyb3JzLFxyXG4gICAgc2VsZWN0TXVzY2xlLFxyXG4gICAgc2VsZWN0RnVsbEJvZHksXHJcbiAgICB1cGRhdGVNb2RlLFxyXG4gICAgdXBkYXRlRXF1aXBtZW50LFxyXG4gIH0gPSBleHBsb3JlcjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cImxhbmRpbmctcGFnZVwiPlxyXG4gICAgICA8bmF2IGNsYXNzTmFtZT1cIm5hdiBzaGVsbFwiPlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnJhbmRcIiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiBcInNtb290aFwiIH0pfT5cclxuICAgICAgICAgIDxMb2dvTWFyayAvPlxyXG4gICAgICAgICAgU29mZXJGaXRcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdi1saW5rc1wiPlxyXG4gICAgICAgICAgPGEgaHJlZj1cIiNmZWF0dXJlc1wiPkhvdyBpdCB3b3JrczwvYT5cclxuICAgICAgICAgIDxhIGhyZWY9XCIjY2hhbGxlbmdlXCI+Q2hhbGxlbmdlPC9hPlxyXG4gICAgICAgICAgPGEgaHJlZj1cIiNleHBsb3JlXCI+RXhwbG9yZTwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7aXNTaWduZWRJbiA/IDxkaXYgY2xhc3NOYW1lPVwibWVtYmVyLW1lbnUtd3JhcFwiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJtZW1iZXItbWVudS10cmlnZ2VyXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1Byb2ZpbGVNZW51KChjdXJyZW50KSA9PiAhY3VycmVudCl9IGFyaWEtZXhwYW5kZWQ9e3Nob3dQcm9maWxlTWVudX0+XHJcbiAgICAgICAgICAgIDxzcGFuPnttZW1iZXJQcm9maWxlPy5hdmF0YXJVcmwgPyA8aW1nIHNyYz17bWVtYmVyUHJvZmlsZS5hdmF0YXJVcmx9IGFsdD1cIlwiIC8+IDogbWVtYmVyUHJvZmlsZT8ubmFtZS5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsIDIpLm1hcCgocGFydCkgPT4gcGFydFswXSkuam9pbihcIlwiKS50b1VwcGVyQ2FzZSgpIHx8IFwiU0ZcIn08L3NwYW4+XHJcbiAgICAgICAgICAgIDxzdHJvbmc+e21lbWJlclByb2ZpbGU/Lm5hbWUuc3BsaXQoL1xccysvKVswXSB8fCBcIk1lbWJlclwifTwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICB7c2hvd1Byb2ZpbGVNZW51ICYmIDxkaXYgY2xhc3NOYW1lPVwibWVtYmVyLW1lbnVcIj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFwiL2Rhc2hib2FyZFwiKX0+RGFzaGJvYXJkPC9idXR0b24+PGJ1dHRvbiBvbkNsaWNrPXthc3luYyAoKSA9PiB7IGF3YWl0IGFwaS5sb2dvdXQoKTsgY2xlYXJGaXRuZXNzU3RvcmUoKTsgc2V0TWVtYmVyUHJvZmlsZShudWxsKTsgc2V0SXNTaWduZWRJbihmYWxzZSk7IHNldFNob3dQcm9maWxlTWVudShmYWxzZSk7IHNldEFwcFRvYXN0KFwiWW91J3ZlIGJlZW4gbG9nZ2VkIG91dC5cIik7IH19PkxvZyBvdXQ8L2J1dHRvbj48L2Rpdj59XHJcbiAgICAgICAgPC9kaXY+IDogPGRpdiBjbGFzc05hbWU9XCJuYXYtYXV0aFwiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJsb2dpbi1saW5rXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0xvZ2luKHRydWUpfT5Mb2cgaW48L2J1dHRvbj5cclxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImRhcmtcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2lnbnVwKHRydWUpfT5TaWduIHVwPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+fVxyXG4gICAgICA8L25hdj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhlcm8gc2hlbGxcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY29weVwiPlxyXG4gICAgICAgICAgPGgxPllvdXIgYm9keS48YnIgLz5Zb3VyIGdvYWxzLjwvaDE+XHJcbiAgICAgICAgICA8cD5BZGFwdGl2ZSB0cmFpbmluZyB0YWlsb3JlZCB0byB5b3VyIGJvZHkgdHlwZSwgZGVzaWduZWQgZm9yIHdlaWdodCBtYW5hZ2VtZW50LCBhbmQgc3RydWN0dXJlZCA2MOKAkzkwIGRheSBjaGFsbGVuZ2VzLjwvcD5cclxuICAgICAgICAgIDxSZXZpZXdDYXJvdXNlbCAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLXRydXN0LWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cnVzdC1yb3dcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF2YXRhcnNcIj48c3Bhbj5KPC9zcGFuPjxzcGFuPk08L3NwYW4+PHNwYW4+QTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhdGluZ1wiPjxJY29uIG5hbWU9XCJzdGFyXCIgLz48c3Ryb25nPjQuOS81PC9zdHJvbmc+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gY2xhc3NOYW1lPVwiaGVyby1leHBsb3JlXCIgb25DbGljaz17KCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNleHBsb3JlXCIpPy5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pfT5cclxuICAgICAgICAgICAgICAgIEJ1aWxkIFlvdXIgUm91dGluZSA8SWNvbiBuYW1lPVwiYXJyb3dcIiAvPlxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tdmlzdWFsXCI+XHJcbiAgICAgICAgICA8aW1nIGNsYXNzTmFtZT1cIndlbGNvbWUtaW1hZ2VcIiBzcmM9e3dlbGNvbWVJbWFnZX0gYWx0PVwiQXRobGV0ZSB0cmFpbmluZyBpbiBhIGdyZWVuIG91dGRvb3Igc2V0dGluZ1wiIC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsb2F0LWNhcmQgd29ya291dC1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcmQtaWNvblwiPjxJY29uIG5hbWU9XCJib2x0XCIgLz48L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXY+PHNtYWxsPlRPREFZJ1MgRk9DVVM8L3NtYWxsPjxzdHJvbmc+VXBwZXIgYm9keSArIGNvcmU8L3N0cm9uZz48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbG9hdC1jYXJkIHByb2dyZXNzLWNhcmRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9ncmVzcy1yaW5nXCI+MzIlPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+PHNtYWxsPlRSQUNLIFBST0dSRVNTPC9zbWFsbD48c3Ryb25nPlZpc3VhbGl6ZSBhY2NvbXBsaXNobWVudHM8L3N0cm9uZz48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbG9hdC1jYXJkIHBsYW4tY2FyZFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJkLWljb25cIj48SWNvbiBuYW1lPVwic3BhcmtcIiAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdj48c21hbGw+U01BUlQgUExBTk5JTkc8L3NtYWxsPjxzdHJvbmc+QWRhcHRzIHRvIHlvdTwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsb2F0LWNhcmQgY29hY2gtY2FyZFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXJkLWljb25cIj48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdj48c21hbGw+R1VJREVEIFdPUktPVVQ8L3NtYWxsPjxzdHJvbmc+Q3VlcyArIHJlc3QgdGltZXI8L3N0cm9uZz48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1ldHJpYy1zdHJpcFwiPlxyXG4gICAgICAgIDxkaXY+PHN0cm9uZz4xMDAlPC9zdHJvbmc+PHNwYW4+RlJFRTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICA8ZGl2PjxzdHJvbmc+NjDigJM5MDwvc3Ryb25nPjxzcGFuPkRBWSBDSEFMTEVOR0U8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRpdj48c3Ryb25nIGNsYXNzTmFtZT1cIm1ldHJpYy1haVwiPjxJY29uIG5hbWU9XCJzcGFya1wiIC8+PC9zdHJvbmc+PHNwYW4+R0VORVJBVEUgV09SS09VVFM8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRpdj48c3Ryb25nPuKInjwvc3Ryb25nPjxzcGFuPldBWVMgVE8gUFJPR1JFU1M8L3NwYW4+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZmVhdHVyZXMgc2hlbGxcIiBpZD1cImZlYXR1cmVzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRpbmcgY2VudGVyZWRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXllYnJvd1wiPk1PUkUgVEhBTiBBIFdPUktPVVQgV0VCU0lURTwvZGl2PlxyXG4gICAgICAgICAgPGgyPkV2ZXJ5dGhpbmcgeW91IG5lZWQgdG88YnIgLz48ZW0+a2VlcCBzaG93aW5nIHVwLjwvZW0+PC9oMj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtZ3JpZFwiPlxyXG4gICAgICAgICAgPGFydGljbGU+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb24gZmVhdHVyZS1pY29uLXZpb2xldFwiPjxJY29uIG5hbWU9XCJzcGFya1wiIC8+PC9kaXY+PGgzPkFJLW1hZGUgZm9yIHlvdTwvaDM+PHA+UGxhbnMgYXJlIG1hZGUgYmFzZWQgb24geW91ciBib2R5IHR5cGUsIGVxdWlwbWVudCBhY2Nlc3MsIGFuZCBmYXQtcmVkdWN0aW9uIGdvYWxzLjwvcD48L2FydGljbGU+XHJcbiAgICAgICAgICA8YXJ0aWNsZT48ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtaWNvbiBmZWF0dXJlLWljb24tdmlvbGV0XCI+PEljb24gbmFtZT1cImNhbGVuZGFyXCIgLz48L2Rpdj48aDM+UHJvZ3Jlc3MsIG1hZGUgdmlzaWJsZTwvaDM+PHA+QSBjYWxlbmRhciBoZWF0bWFwLCBhY3RpdmUgd29ya291dHMsIHN0cmVha3MsIGFuZCBtZWFuaW5nZnVsIHN0YXRzIGluIG9uZSB2aWV3LjwvcD48L2FydGljbGU+XHJcbiAgICAgICAgICA8YXJ0aWNsZT48ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtaWNvbiBmZWF0dXJlLWljb24tdmlvbGV0XCI+PEljb24gbmFtZT1cImJvbHRcIiAvPjwvZGl2PjxoMz5FbmNvdXJhZ2VtZW50PC9oMz48cD5TdGVwLWJ5LXN0ZXAgZ3VpZGFuY2UsIGFjdGl2ZSBjb3VudGRvd24gdGltZXJzLCBzZXQvcmVwIGNvdW50ZXJzLCBhbmQgcmVhbC10aW1lIGVuY291cmFnZW1lbnQuPC9wPjwvYXJ0aWNsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY2hhbGxlbmdlXCIgaWQ9XCJjaGFsbGVuZ2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNoZWxsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYWxsZW5nZS1jb3B5XCI+XHJcbiAgICAgICAgICAgIDxoMj5PbmUgY2hhbGxlbmdlLjxiciAvPjxlbT5CdWlsdCBhcm91bmQgeW91LjwvZW0+PC9oMj5cclxuICAgICAgICAgICAgPHA+VGVsbCB1cyB5b3VyIHN0YXJ0aW5nIHBvaW50LCBzY2hlZHVsZSwgZXF1aXBtZW50LCBhbmQgZ29hbC4gU29mZXJGaXQgc2hhcGVzIGV2ZXJ5IHNlc3Npb27igJRhbmQgYWRhcHRzIHRvIHlvdS48L3A+XHJcbiAgICAgICAgICAgIDx1bD5cclxuICAgICAgICAgICAgICA8bGk+PEljb24gbmFtZT1cImNoZWNrXCIgLz4gQ2hvb3NlIGEgNjAgb3IgOTAtZGF5IHJvYWRtYXA8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT48SWNvbiBuYW1lPVwiY2hlY2tcIiAvPiBTbWFydCByZWNvdmVyeSBhbmQgc2Vzc2lvbiBhZGp1c3RtZW50czwvbGk+XHJcbiAgICAgICAgICAgICAgPGxpPjxJY29uIG5hbWU9XCJjaGVja1wiIC8+IEVuY291cmFnZW1lbnQgZXhhY3RseSB3aGVuIHlvdSBuZWVkIGl0PC9saT5cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2gtdG9wXCI+PGRpdj48c21hbGw+R09PRCBNT1JOSU5HLCBLRU5ORVRIPC9zbWFsbD48aDM+S2VlcCB5b3VyIHJoeXRobSEg8J+MnjwvaDM+PC9kaXY+PHNwYW4+REFZIDI0IC8gOTA8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FsZW5kYXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGVuZGFyLWhlYWRcIj48c3Ryb25nPlNFUFRFTUJFUjwvc3Ryb25nPjxzcGFuPjMgd2VlayBzdHJlYWsg8J+UpTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndlZWsgZGF5c1wiPjxzcGFuPk08L3NwYW4+PHNwYW4+VDwvc3Bhbj48c3Bhbj5XPC9zcGFuPjxzcGFuPlQ8L3NwYW4+PHNwYW4+Rjwvc3Bhbj48c3Bhbj5TPC9zcGFuPjxzcGFuPlM8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAge1swLCAxLCAyLCAzXS5tYXAoKHdlZWspID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2Vla1wiIGtleT17d2Vla30+XHJcbiAgICAgICAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNSwgNiwgN10ubWFwKChkYXkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBudW0gPSB3ZWVrICogNyArIGRheTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBkYXlDbGFzcyA9IG51bSA8PSAyM1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImRvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBudW0gPT09IDI0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0b2RheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogbnVtID49IDI1XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJsdWUtZGF5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxzcGFuIGtleT17ZGF5fSBjbGFzc05hbWU9e2RheUNsYXNzfT57bnVtfTwvc3Bhbj47XHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2gtc3RhdHNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cIm1pbmktaWNvblwiPjxJY29uIG5hbWU9XCJjYWxlbmRhclwiIC8+PC9zcGFuPjxzbWFsbD5DSEFMTEVOR0U8L3NtYWxsPjxzdHJvbmc+RGF5IDI0IDxpPi8gNjA8L2k+PC9zdHJvbmc+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJtaW5pLWljb24gbGltZVwiPjxJY29uIG5hbWU9XCJjaGFydFwiIC8+PC9zcGFuPjxzbWFsbD5UQVJHRVQgUFJPR1JFU1M8L3NtYWxsPjxzdHJvbmc+MzIlPC9zdHJvbmc+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj48c3BhbiBjbGFzc05hbWU9XCJtaW5pLWljb24gcGVhY2hcIj48SWNvbiBuYW1lPVwiYm9sdFwiIC8+PC9zcGFuPjxzbWFsbD5BQ1RJVkUgVElNRTwvc21hbGw+PHN0cm9uZz4xNi40aDwvc3Ryb25nPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJleHBsb3JlciBzaGVsbFwiIGlkPVwiZXhwbG9yZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+XHJcbiAgICAgICAgICA8aDI+U2VsZWN0IFlvdXIgRm9jdXMgQXJlYS48YnIgLz48ZW0+QnVpbGQgWW91ciBSb3V0aW5lLjwvZW0+PC9oMj5cclxuICAgICAgICAgIDxwPkNob29zZSB0aGUgYXJlYSB5b3Ugd2FudCB0byB0b25lIG9yIHRhcmdldCBmb3IgZmF0IHJlZHVjdGlvbi48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBsb3Jlci1ncmlkXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1wYW5lbFwiPlxyXG4gICAgICAgICAgICA8Qm9keU1hcCBnZW5kZXI9e2dlbmRlcn0gb3JpZW50YXRpb249e29yaWVudGF0aW9ufSBzZWxlY3RlZD17c2VsZWN0ZWR9IGZ1bGxCb2R5PXtmdWxsQm9keX0gZGlzYWJsZWQ9e3JvdXRpbmVTdGF0ZSAhPT0gXCJpZGxlXCJ9IG9uU2VsZWN0PXtzZWxlY3RNdXNjbGV9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhlcmNpc2UtcGFuZWxcIj5cclxuICAgICAgICAgICAge3JvdXRpbmVTdGF0ZSA9PT0gXCJpZGxlXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91dGluZS1zdGF0ZSByb3V0aW5lLWlkbGVcIiBrZXk9XCJpZGxlXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdXRpbmUtc3RhdGUtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c21hbGw+WU9VUiBST1VUSU5FPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgPGgzPntmb2N1c0FyZWEgPz8gXCJObyBmb2N1cyBhcmVhIHNlbGVjdGVkXCJ9PC9oMz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3V0aW5lLXN0YXRlLXNjcm9sbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdXRpbmUtY29udHJvbHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRyb2wtcm93IGZvY3VzLW9yaWVudGF0aW9uLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsPkZPQ1VTIEFSRUE8L3NtYWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1waWxsc1wiPjxidXR0b24gY2xhc3NOYW1lPXtmdWxsQm9keSA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXtzZWxlY3RGdWxsQm9keX0+RnVsbCBCb2R5PC9idXR0b24+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbD5PUklFTlRBVElPTjwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXBpbGxzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhbXCJGcm9udFwiLCBcIkJhY2tcIl0gYXMgT3JpZW50YXRpb25bXSkubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17aXRlbX0gY2xhc3NOYW1lPXtvcmllbnRhdGlvbiA9PT0gaXRlbSA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiBzZXRPcmllbnRhdGlvbihpdGVtKX0+e2l0ZW19PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250cm9sLXJvdyBtb2RlbC1tZXRyaWNzLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsPk1PREVMPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGlsbHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7KFtcIk1hblwiLCBcIldvbWFuXCJdIGFzIEdlbmRlcltdKS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24ga2V5PXtpdGVtfSBjbGFzc05hbWU9e2dlbmRlciA9PT0gaXRlbSA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiBzZXRHZW5kZXIoaXRlbSl9PntpdGVtfTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXRyaWMtaW5wdXRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5BZ2U8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjEwXCIgbWF4PVwiMTAwXCIgdmFsdWU9e2V4cGxvcmVyQWdlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFeHBsb3JlckFnZShldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjI0XCIgLz57bWV0cmljRXJyb3JzLmFnZSAmJiA8c21hbGw+e21ldHJpY0Vycm9ycy5hZ2V9PC9zbWFsbD59PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkhlaWdodDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMTAwXCIgbWF4PVwiMjUwXCIgdmFsdWU9e2V4cGxvcmVySGVpZ2h0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFeHBsb3JlckhlaWdodChldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjE3NSBjbVwiIC8+e21ldHJpY0Vycm9ycy5oZWlnaHQgJiYgPHNtYWxsPnttZXRyaWNFcnJvcnMuaGVpZ2h0fTwvc21hbGw+fTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5XZWlnaHQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjI1XCIgbWF4PVwiMzAwXCIgdmFsdWU9e2V4cGxvcmVyV2VpZ2h0fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFeHBsb3JlcldlaWdodChldmVudC50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIjcwIGtnXCIgLz57bWV0cmljRXJyb3JzLndlaWdodCAmJiA8c21hbGw+e21ldHJpY0Vycm9ycy53ZWlnaHR9PC9zbWFsbD59PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwibGFiZWwtd2l0aC1pbmZvXCI+VFJBSU5JTkcgPEluZm9UaXAgdGVybT1cIlRyYWluaW5nXCIgZGVmaW5pdGlvbj1cIkRlZmluZXMgcm91dGluZSBpbnRlbnNpdHkgYW5kIHJlcCBzY2hlbWVzLlwiIGFjdGlvbkxhYmVsPVwiVmlldyBHbG9zc2FyeVwiIHNob3dUZXJtPXtmYWxzZX0gb25MZWFybk1vcmU9eygpID0+IG9wZW5HbG9zc2FyeShcIkZhdCBMb3NzICYgQ2FyZGlvXCIpfSAvPjwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1waWxsc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KFtcIkZhdCBMb3NzICYgQ2FyZGlvXCIsIFwiSElJVFwiLCBcIk11c2NsZSAmIFN0cmVuZ3RoXCJdIGFzIFRyYWluaW5nTW9kZVtdKS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17aXRlbX0gY2xhc3NOYW1lPXttb2RlID09PSBpdGVtID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHVwZGF0ZU1vZGUoaXRlbSl9PntpdGVtfTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c21hbGwgY2xhc3NOYW1lPVwibGFiZWwtd2l0aC1pbmZvXCI+RVFVSVBNRU5UIDxJbmZvVGlwIHRlcm09XCJFcXVpcG1lbnRcIiBkZWZpbml0aW9uPVwiQ2hvb3NlIHdoZXRoZXIgeW91ciByb3V0aW5lIHNob3VsZCB1c2Ugb25seSB5b3VyIGJvZHkgd2VpZ2h0IG9yIGNvbW1vbiBneW0gZXF1aXBtZW50LlwiIGFjdGlvbkxhYmVsPVwiVmlldyBHbG9zc2FyeVwiIG9uTGVhcm5Nb3JlPXsoKSA9PiBvcGVuR2xvc3NhcnkoXCJCb2R5d2VpZ2h0XCIpfSAvPjwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1waWxsc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17ZXF1aXBtZW50ID09PSBcIk5vIEVxdWlwbWVudCAvIEJvZHl3ZWlnaHRcIiA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiB1cGRhdGVFcXVpcG1lbnQoXCJObyBFcXVpcG1lbnQgLyBCb2R5d2VpZ2h0XCIpfT5Cb2R5d2VpZ2h0IC8gSG9tZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17ZXF1aXBtZW50ID09PSBcIkd5bSBFcXVpcG1lbnRcIiA/IFwiYWN0aXZlXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiB1cGRhdGVFcXVpcG1lbnQoXCJHeW0gRXF1aXBtZW50XCIpfT5HeW0gRXF1aXBtZW50PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91dGluZS1zdGF0ZS1hY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17IWZvY3VzQXJlYSB8fCAhbW9kZSB8fCAhZXF1aXBtZW50fSBvbkNsaWNrPXsoKSA9PiBzZXRSb3V0aW5lU3RhdGUoXCJsb2FkaW5nXCIpfT5HZW5lcmF0ZSB3b3Jrb3V0IHJvdXRpbmUgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxzbWFsbD5BSSBnZW5lcmF0aW9uIGlzIGxpbWl0ZWQsIHVzZSB3aXNlbHkuPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3JvdXRpbmVTdGF0ZSA9PT0gXCJsb2FkaW5nXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91dGluZS1zdGF0ZSByb3V0aW5lLWxvYWRpbmdcIiBrZXk9XCJsb2FkaW5nXCIgYXJpYS1saXZlPVwicG9saXRlXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctY29weVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnZW5lcmF0aW9uLXNwaW5uZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPntsb2FkaW5nTWVzc2FnZSA9PT0gMCA/IFwiQW5hbHl6aW5nIGJvZHkgZm9jdXMgYW5kIHRhcmdldCBtZXRyaWNzLi4uXCIgOiBcIkJhbGFuY2luZyByZXAgc2NoZW1lcywgZXF1aXBtZW50LCBhbmQgcmVzdCBpbnRlcnZhbHMuLi5cIn08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2VsZXRvbi1saXN0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbMCwgMSwgMl0ubWFwKChpdGVtKSA9PiA8ZGl2IGtleT17aXRlbX0+PGkgLz48c3Bhbj48aSAvPjxpIC8+PC9zcGFuPjwvZGl2Pil9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtyb3V0aW5lU3RhdGUgPT09IFwicmVzdWx0c1wiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdXRpbmUtc3RhdGUgcm91dGluZS1yZXN1bHRzXCIga2V5PVwicmVzdWx0c1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3V0aW5lLXJlc3VsdHMtaGVhZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PjxoMz5Zb3VyIEdlbmVyYXRlZCBSb3V0aW5lPC9oMz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj48c3Bhbj57Zm9jdXNBcmVhfTwvc3Bhbj48c3Bhbj57bW9kZX08L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91dGluZS1zdGF0ZS1zY3JvbGwgcmVzdWx0LWxpc3RcIj5cclxuICAgICAgICAgICAgICAgICAge2xpc3QubWFwKChleGVyY2lzZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInJlc3VsdC1jYXJkXCIga2V5PXtleGVyY2lzZS5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImR1bWJiZWxsLWljb25cIj48SWNvbiBuYW1lPVwiZHVtYmJlbGxcIiAvPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4ZXJjaXNlLW5hbWVcIj48c3Ryb25nPntleGVyY2lzZS5uYW1lfTwvc3Ryb25nPjxzbWFsbD57ZXhlcmNpc2UucmVwc308L3NtYWxsPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm11c2NsZS10YWdcIj57ZXhlcmNpc2UudGFnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdXRpbmUtcmVzdWx0LWFjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNhdmUtcm91dGluZS1iYW5uZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlNhdmUgdGhpcyByb3V0aW5lIGFuZCBzdGFydCB5b3VyIDYw4oCTOTAgZGF5IHRyYW5zZm9ybWF0aW9uIGNoYWxsZW5nZSE8L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dTaWdudXAodHJ1ZSl9PkNyZWF0ZSBQcm9maWxlPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPGZvb3Rlcj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNoZWxsIGZvb3Rlci1kaXZpZGVyXCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNoZWxsIGZvb3Rlci1ib3R0b21cIj5cclxuICAgICAgICAgIDxwPsKpIDIwMjYgU29mZXJGaXQuIEFsbCByaWdodHMgcmVzZXJ2ZWQuPC9wPlxyXG4gICAgICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiTGVnYWwgbGlua3NcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJmb290ZXItZ2xvc3NhcnlcIiBvbkNsaWNrPXsoKSA9PiBvcGVuR2xvc3NhcnkoKX0+IEdsb3NzYXJ5PC9idXR0b24+XHJcbiAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJpdmFjeS1wb2xpY3lcIj5Qcml2YWN5IFBvbGljeTwvYT5cclxuICAgICAgICAgICAgPGEgaHJlZj1cIiN0ZXJtcy1vZi1zZXJ2aWNlXCI+VGVybXMgb2YgU2VydmljZTwvYT5cclxuICAgICAgICAgICAgPGEgaHJlZj1cIiNjb29raWVzXCI+Q29va2llczwvYT5cclxuICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Zvb3Rlcj5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuIl19