import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/GeneratePage.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { CustomCheckbox } from "/src/frontend/components/CustomCheckbox.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { PageHeader } from "/src/frontend/components/PageHeader.tsx";
import { dateKey, prettyDate } from "/src/frontend/lib/format.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/GeneratePage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function GeneratePage({ store, update, navigate, toast }) {
	_s();
	const nextMonday = (from = new Date()) => {
		const date = new Date(from);
		date.setHours(12, 0, 0, 0);
		const days = (8 - date.getDay()) % 7 || 7;
		date.setDate(date.getDate() + days);
		return dateKey(date);
	};
	const profileEquipment = store.user.equipment.includes("Gym") ? "Gym Equipment" : store.user.equipment.includes("Dumbbell") ? "Dumbbells & Bands" : "Bodyweight / Home";
	const profileTraining = store.user.goal.includes("Muscle") ? "Muscle & Strength" : "Fat Loss & Cardio";
	const age = Number(store.user.age);
	const automaticLowImpact = store.user.injuryFlag || age > 0 && age < 18 || age >= 60;
	const [generatorState, setGeneratorState] = useState("form");
	const [option, setOption] = useState("single");
	const [reason, setReason] = useState("");
	const [focus, setFocus] = useState("Full Body");
	const [training, setTraining] = useState(profileTraining);
	const [equipment, setEquipment] = useState(profileEquipment);
	const initialDuration = [
		15,
		30,
		45,
		60
	].includes(store.challenge.sessionMinutes) ? String(store.challenge.sessionMinutes) : "custom";
	const [durationChoice, setDurationChoice] = useState(initialDuration);
	const [customDuration, setCustomDuration] = useState(initialDuration === "custom" ? String(store.challenge.sessionMinutes) : "");
	const [effort, setEffort] = useState("Moderate");
	const [lowImpact, setLowImpact] = useState(automaticLowImpact);
	const [loadingMessage, setLoadingMessage] = useState(0);
	const [result, setResult] = useState(null);
	const [scheduleDate, setScheduleDate] = useState(() => store.plan.find((workout) => workout.date >= dateKey(new Date()) && !workout.optional)?.date || dateKey(new Date()));
	const [confirmRegenerate, setConfirmRegenerate] = useState(false);
	const resetDate = /^\d{4}-\d{2}-\d{2}$/.test(store.aiGenerations.resetDate) ? store.aiGenerations.resetDate : nextMonday();
	const resetDue = resetDate <= dateKey(new Date());
	const usedCount = resetDue ? 0 : store.aiGenerations.usedCount;
	const remaining = Math.max(0, 3 - usedCount);
	const duration = durationChoice === "custom" ? Number(customDuration) : Number(durationChoice);
	const valid = Boolean(focus && training && equipment && effort && duration >= 5 && duration <= 180 && (option === "single" || reason));
	useEffect(() => {
		const mondayReset = nextMonday();
		if (resetDue || resetDate !== mondayReset) {
			update({
				...store,
				aiGenerations: {
					usedCount: resetDue ? 0 : usedCount,
					resetDate: mondayReset
				}
			});
		}
	}, []);
	useEffect(() => {
		if (generatorState !== "loading") return;
		setLoadingMessage(0);
		const messageTimer = window.setInterval(() => setLoadingMessage((value) => (value + 1) % 3), 900);
		const resultTimer = window.setTimeout(() => {
			try {
				const exercisePools = {
					"Full Body": [
						"Squat to reach",
						"Incline push-up",
						"Reverse lunge",
						"Glute bridge",
						"Bird dog",
						"Standing knee drive",
						"Dead bug",
						"Marching finisher"
					],
					"Upper Body": [
						"Wall push-up",
						"Bent-over row",
						"Shoulder press",
						"Biceps curl",
						"Triceps extension",
						"Plank shoulder tap",
						"Lateral raise",
						"Chest press"
					],
					"Lower Body": [
						"Tempo squat",
						"Reverse lunge",
						"Glute bridge",
						"Calf raise",
						"Side lunge",
						"Wall sit",
						"Step-up",
						"Dead bug"
					],
					Core: [
						"Dead bug",
						"Bird dog",
						"Forearm plank",
						"Heel taps",
						"Side plank",
						"Bear hold",
						"Standing knee drive",
						"Glute bridge"
					],
					"Cardio / Running": training === "Walk-Run" ? [
						"Warm-up walk",
						"Jog interval",
						"Recovery walk",
						"Jog interval",
						"Recovery walk",
						"Steady finish",
						"Cool-down walk"
					] : [
						"March in place",
						"Step touch",
						"High knees",
						"Skater step",
						"Squat to reach",
						"Mountain climber",
						"Fast feet",
						"Breathing reset"
					]
				};
				const count = duration <= 15 ? 4 : duration <= 30 ? 6 : 8;
				const names = exercisePools[focus].slice(0, count);
				const isRun = focus === "Cardio / Running" && training === "Walk-Run";
				const generated = {
					id: `generated-${Date.now()}`,
					date: scheduleDate,
					name: isRun ? "Fresh Walk-Run Intervals" : `${effort} ${focus} ${training === "HIIT" ? "Circuit" : "Session"}`,
					minutes: duration,
					equipment,
					targetTags: isRun ? ["Cardio", "Run"] : [focus, training],
					exercises: names.map((name, index) => ({
						name: lowImpact && /high knees|mountain climber|fast feet/i.test(name) ? `Low-impact ${name.toLowerCase()}` : name,
						prescription: isRun ? index === 0 || index === names.length - 1 ? "5:00" : index % 2 ? "1:00 jog" : "2:00 walk" : training === "HIIT" ? "40 sec work · 20 sec rest" : effort === "Easy" ? "2 × 10 · 45 sec rest" : effort === "Hard" ? "4 × 12 · 30 sec rest" : "3 × 12 · 40 sec rest"
					}))
				};
				const nextStore = {
					...store,
					aiGenerations: {
						usedCount: usedCount + 1,
						resetDate: nextMonday()
					}
				};
				if (!update(nextStore)) throw new Error("storage");
				setResult(generated);
				setGeneratorState("result");
			} catch {
				setGeneratorState("error");
			}
		}, 2800);
		return () => {
			window.clearInterval(messageTimer);
			window.clearTimeout(resultTimer);
		};
	}, [generatorState]);
	const startGeneration = () => {
		if (!remaining) return;
		setConfirmRegenerate(false);
		setGeneratorState("loading");
	};
	const addToPlan = (saveOnly = false) => {
		if (!result) return;
		const scheduled = {
			...result,
			id: `${result.id}-${saveOnly ? "saved" : "plan"}`,
			date: scheduleDate,
			optional: saveOnly
		};
		const plan = option === "adjust" && !saveOnly ? store.plan.map((workout) => workout.date >= dateKey(new Date()) && !workout.optional ? {
			...scheduled,
			id: workout.id,
			date: workout.date,
			name: workout.name.includes("Recovery") ? workout.name : scheduled.name
		} : workout) : [scheduled, ...store.plan];
		if (!update({
			...store,
			plan
		})) return;
		toast(option === "adjust" && !saveOnly ? "Your remaining challenge plan was re-balanced." : saveOnly ? "Workout saved to My workouts." : `Workout added for ${prettyDate(scheduleDate)}.`);
		navigate("/workouts");
	};
	const discard = () => {
		setResult(null);
		setGeneratorState("form");
	};
	const loadingCopy = [
		"Analyzing your profile...",
		"Balancing reps, rest, and equipment...",
		"Building your routine..."
	];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(PageHeader, { title: "Generate" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 12
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "generate-header",
			children: /* @__PURE__ */ _jsxDEV("span", { children: [remaining, " of 3 generations left this week"] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 38
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("article", {
			className: "generator-shell",
			children: [
				generatorState === "form" && /* @__PURE__ */ _jsxDEV("div", {
					className: "generator-scroll",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "generator-options",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								className: option === "single" ? "selected" : "",
								onClick: () => setOption("single"),
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "generate-choice-icon",
										children: /* @__PURE__ */ _jsxDEV(Icon, { name: "bolt" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 144
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 105
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Single workout" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 176
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "A one-off routine for today or another day." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 207
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 171
									}, this),
									/* @__PURE__ */ _jsxDEV("i", { children: option === "single" && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 298
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 271
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 11
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: option === "adjust" ? "selected" : "",
								onClick: () => setOption("adjust"),
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "generate-choice-icon",
										children: /* @__PURE__ */ _jsxDEV(Icon, { name: "calendar" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 144
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 105
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Adjust my challenge plan" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 180
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Re-balance the workouts in your remaining weeks." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 221
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 175
									}, this),
									/* @__PURE__ */ _jsxDEV("i", { children: option === "adjust" && /* @__PURE__ */ _jsxDEV(Icon, { name: "check" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 317
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 290
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 11
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 9
						}, this),
						option === "adjust" && /* @__PURE__ */ _jsxDEV("div", {
							className: "reason-row",
							children: [/* @__PURE__ */ _jsxDEV("small", { children: "WHAT CHANGED?" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 61
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								"Too hard",
								"Too easy",
								"Schedule changed",
								"New equipment",
								"Plateau"
							].map((item) => /* @__PURE__ */ _jsxDEV("button", {
								className: reason === item ? "active" : "",
								onClick: () => setReason(item),
								children: item
							}, item, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 182
							}, this)) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 89
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 33
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "generator-form",
							children: [
								/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Focus area" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "generator-chips",
									children: [
										"Full Body",
										"Upper Body",
										"Lower Body",
										"Core",
										"Cardio / Running"
									].map((item) => /* @__PURE__ */ _jsxDEV("button", {
										className: focus === item ? "active" : "",
										onClick: () => {
											setFocus(item);
											if (item !== "Cardio / Running" && training === "Walk-Run") setTraining("Fat Loss & Cardio");
										},
										children: item
									}, item, false, {
										fileName: _jsxFileName,
										lineNumber: 127,
										columnNumber: 179
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 48
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: ["Training ", /* @__PURE__ */ _jsxDEV("span", {
									className: "info-tip",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										"aria-label": "About training",
										children: "ⓘ"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 65
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "term-tooltip",
										role: "tooltip",
										children: [
											/* @__PURE__ */ _jsxDEV("strong", { children: "Training style" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 171
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: "This changes the pace, repetitions, work periods, and rest in your routine." }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 202
											}, this),
											/* @__PURE__ */ _jsxDEV("a", {
												href: "/#glossary",
												children: "View glossary"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 290
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 125
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 38
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "generator-chips",
									children: [
										"Fat Loss & Cardio",
										"HIIT",
										"Muscle & Strength",
										...focus === "Cardio / Running" ? ["Walk-Run"] : []
									].map((item) => /* @__PURE__ */ _jsxDEV("button", {
										className: training === item ? "active" : "",
										onClick: () => setTraining(item),
										children: item
									}, item, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 521
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 351
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Equipment" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "generator-chips",
									children: [
										"Bodyweight / Home",
										"Dumbbells & Bands",
										"Gym Equipment"
									].map((item) => /* @__PURE__ */ _jsxDEV("button", {
										className: equipment === item ? "active" : "",
										onClick: () => setEquipment(item),
										children: item
									}, item, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 181
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 47
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "generator-row",
									children: [/* @__PURE__ */ _jsxDEV("label", { children: ["Duration", /* @__PURE__ */ _jsxDEV("select", {
										value: durationChoice,
										onChange: (event) => setDurationChoice(event.target.value),
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "15",
												children: "15 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 130,
												columnNumber: 148
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "30",
												children: "30 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 130,
												columnNumber: 186
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "45",
												children: "45 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 130,
												columnNumber: 224
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "60",
												children: "60 minutes"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 130,
												columnNumber: 262
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "custom",
												children: "Custom..."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 130,
												columnNumber: 300
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 57
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 42
									}, this), durationChoice === "custom" && /* @__PURE__ */ _jsxDEV("label", { children: ["Custom minutes", /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "5",
										max: "180",
										value: customDuration,
										onChange: (event) => setCustomDuration(event.target.value),
										placeholder: "5–180"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 411
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 390
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Effort today" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "generator-chips",
									children: [
										"Easy",
										"Moderate",
										"Hard"
									].map((item) => /* @__PURE__ */ _jsxDEV("button", {
										className: effort === item ? "active" : "",
										onClick: () => setEffort(item),
										children: item
									}, item, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 138
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 50
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 11
								}, this),
								/* @__PURE__ */ _jsxDEV(CustomCheckbox, {
									className: "generator-toggle",
									checked: lowImpact,
									onChange: setLowImpact,
									children: /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Include low-impact options" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 106
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: automaticLowImpact ? "On based on your profile; you can change it here." : "Adds joint-friendly alternatives to the routine." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 149
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 100
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 11
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 37
				}, this),
				generatorState === "loading" && /* @__PURE__ */ _jsxDEV("div", {
					className: "generator-loading",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "emerald-pulse",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 126
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 94
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: loadingCopy[loadingMessage] }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 154
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "generator-skeleton",
							children: [
								0,
								1,
								2
							].map((item) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 277
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 288
							}, this), /* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 293
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 282
							}, this)] }, item, true, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 261
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 200
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 40
				}, this),
				generatorState === "result" && result && /* @__PURE__ */ _jsxDEV("div", {
					className: "generator-result",
					children: [
						/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("small", { children: "YOUR GENERATED ROUTINE" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 22
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", { children: result.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 59
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								result.minutes,
								" min · ",
								result.equipment
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 81
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "target-chips",
							children: result.targetTags.map((tag) => /* @__PURE__ */ _jsxDEV("i", { children: tag }, tag, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 197
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 135
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "generated-exercises",
							children: result.exercises.map((exercise, index) => /* @__PURE__ */ _jsxDEV("article", { children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "dumbbell-icon",
									children: /* @__PURE__ */ _jsxDEV(Icon, { name: "dumbbell" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 164
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 132
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: exercise.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 200
								}, this), /* @__PURE__ */ _jsxDEV("small", { children: exercise.prescription }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 232
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 195
								}, this),
								/* @__PURE__ */ _jsxDEV("i", { children: result.targetTags[index % result.targetTags.length] }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 276
								}, this)
							] }, `${exercise.name}-${index}`, true, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 89
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "why-plan",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 41
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 35
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Why this plan" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 74
							}, this), /* @__PURE__ */ _jsxDEV("ul", { children: [/* @__PURE__ */ _jsxDEV("li", { children: equipment === "Bodyweight / Home" ? "Bodyweight-focused, since that's your selected equipment." : `${equipment} movements match the setup you selected.` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 108
							}, this), /* @__PURE__ */ _jsxDEV("li", { children: lowImpact ? "Low-impact swaps are included so you can adjust as needed." : `${effort} effort keeps today's session aligned with how you feel.` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 271
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 104
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 69
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "generator-guidance",
							children: "AI suggestions are general fitness guidance, not medical advice."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 49
				}, this),
				generatorState === "error" && /* @__PURE__ */ _jsxDEV("div", {
					className: "generator-message",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "spark" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 79
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 73
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Let's try that again." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 107
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "We couldn't generate a new plan. Your current plan is unchanged and no generation was used." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 137
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => setGeneratorState("form"),
							children: "Try again"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 235
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 38
				}, this),
				/* @__PURE__ */ _jsxDEV("footer", {
					className: "generator-actions",
					children: [generatorState === "form" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							onClick: startGeneration,
							disabled: !valid || !remaining,
							children: "Generate routine"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 41
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: "AI generation is limited, use wisely." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 132
						}, this),
						!remaining && /* @__PURE__ */ _jsxDEV("p", {
							className: "limit-message",
							children: [
								"You've used all 3 generations this week. They reset on ",
								prettyDate(resetDate),
								". In the meantime, swap exercises in ",
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => navigate("/workouts"),
									children: "My workouts"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 343
								}, this),
								"."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 199
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 39
					}, this), generatorState === "result" && result && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "schedule-action",
							children: [/* @__PURE__ */ _jsxDEV("label", { children: ["Add to my plan", /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								min: dateKey(new Date()),
								value: scheduleDate,
								onChange: (event) => setScheduleDate(event.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 107
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 86
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => addToPlan(false),
								children: "Add to my plan"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 241
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 53
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "result-actions",
							children: [
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									onClick: () => addToPlan(true),
									children: "Save to My workouts"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 343
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									onClick: () => setConfirmRegenerate(true),
									disabled: !remaining,
									children: "Regenerate"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 427
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: discard,
									children: "Discard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 535
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 311
						}, this),
						confirmRegenerate && /* @__PURE__ */ _jsxDEV("div", {
							className: "regenerate-confirm",
							children: [
								/* @__PURE__ */ _jsxDEV("p", { children: "Regenerating uses another of your weekly generations." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 641
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setConfirmRegenerate(false),
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 701
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									onClick: startGeneration,
									children: "Use 1 generation"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 768
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 605
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 51
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 7
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 5
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 117,
		columnNumber: 10
	}, this);
}
_s(GeneratePage, "FwVkmUoefYUHPD1Ejj/Oojfvy4Q=");
_c = GeneratePage;
var _c;
$RefreshReg$(_c, "GeneratePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/GeneratePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/GeneratePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/GeneratePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/GeneratePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsU0FBUyxrQkFBa0I7Ozs7QUFFcEMsT0FBTyxTQUFTLGFBQWEsRUFBRSxPQUFPLFFBQVEsVUFBVSxTQUFnSzs7Q0FLdE4sTUFBTSxjQUFjLE9BQU8sSUFBSSxLQUFLLE1BQU07RUFDeEMsTUFBTSxPQUFPLElBQUksS0FBSyxJQUFJO0VBQzFCLEtBQUssU0FBUyxJQUFJLEdBQUcsR0FBRyxDQUFDO0VBQ3pCLE1BQU0sUUFBUSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUs7RUFDeEMsS0FBSyxRQUFRLEtBQUssUUFBUSxJQUFJLElBQUk7RUFDbEMsT0FBTyxRQUFRLElBQUk7Q0FDckI7Q0FDQSxNQUFNLG1CQUF1QyxNQUFNLEtBQUssVUFBVSxTQUFTLEtBQUssSUFBSSxrQkFBa0IsTUFBTSxLQUFLLFVBQVUsU0FBUyxVQUFVLElBQUksc0JBQXNCO0NBQ3hLLE1BQU0sa0JBQTRCLE1BQU0sS0FBSyxLQUFLLFNBQVMsUUFBUSxJQUFJLHNCQUFzQjtDQUM3RixNQUFNLE1BQU0sT0FBTyxNQUFNLEtBQUssR0FBRztDQUNqQyxNQUFNLHFCQUFxQixNQUFNLEtBQUssY0FBZSxNQUFNLEtBQUssTUFBTSxNQUFPLE9BQU87Q0FDcEYsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBeUIsTUFBTTtDQUMzRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQThCLFFBQVE7Q0FDbEUsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFnQixXQUFXO0NBQ3JELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBbUIsZUFBZTtDQUNsRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBNkIsZ0JBQWdCO0NBQy9FLE1BQU0sa0JBQWtCO0VBQUM7RUFBSTtFQUFJO0VBQUk7Q0FBRSxDQUFDLENBQUMsU0FBUyxNQUFNLFVBQVUsY0FBYyxJQUFJLE9BQU8sTUFBTSxVQUFVLGNBQWMsSUFBSTtDQUM3SCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLGVBQWU7Q0FDcEUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxvQkFBb0IsV0FBVyxPQUFPLE1BQU0sVUFBVSxjQUFjLElBQUksRUFBRTtDQUMvSCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXVDLFVBQVU7Q0FDN0UsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsa0JBQWtCO0NBQzdELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsQ0FBQztDQUN0RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWdDLElBQUk7Q0FDaEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLGVBQWUsTUFBTSxLQUFLLE1BQU0sWUFBWSxRQUFRLFFBQVEsUUFBUSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxRQUFRLENBQUMsRUFBRSxRQUFRLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQztDQUMxSyxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxZQUFZLHNCQUFzQixLQUFLLE1BQU0sY0FBYyxTQUFTLElBQUksTUFBTSxjQUFjLFlBQVksV0FBVztDQUN6SCxNQUFNLFdBQVcsYUFBYSxRQUFRLElBQUksS0FBSyxDQUFDO0NBQ2hELE1BQU0sWUFBWSxXQUFXLElBQUksTUFBTSxjQUFjO0NBQ3JELE1BQU0sWUFBWSxLQUFLLElBQUksR0FBRyxJQUFJLFNBQVM7Q0FDM0MsTUFBTSxXQUFXLG1CQUFtQixXQUFXLE9BQU8sY0FBYyxJQUFJLE9BQU8sY0FBYztDQUM3RixNQUFNLFFBQVEsUUFBUSxTQUFTLFlBQVksYUFBYSxVQUFVLFlBQVksS0FBSyxZQUFZLFFBQVEsV0FBVyxZQUFZLE9BQU87Q0FFckksZ0JBQWdCO0VBQ2QsTUFBTSxjQUFjLFdBQVc7RUFDL0IsSUFBSSxZQUFZLGNBQWMsYUFBYTtHQUN6QyxPQUFPO0lBQUUsR0FBRztJQUFPLGVBQWU7S0FBRSxXQUFXLFdBQVcsSUFBSTtLQUFXLFdBQVc7SUFBWTtHQUFFLENBQUM7RUFDckc7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUNkLElBQUksbUJBQW1CLFdBQVc7RUFDbEMsa0JBQWtCLENBQUM7RUFDbkIsTUFBTSxlQUFlLE9BQU8sa0JBQWtCLG1CQUFtQixXQUFXLFFBQVEsS0FBSyxDQUFDLEdBQUcsR0FBRztFQUNoRyxNQUFNLGNBQWMsT0FBTyxpQkFBaUI7R0FDMUMsSUFBSTtJQUNGLE1BQU0sZ0JBQXlDO0tBQzdDLGFBQWE7TUFBQztNQUFrQjtNQUFtQjtNQUFpQjtNQUFnQjtNQUFZO01BQXVCO01BQVk7S0FBbUI7S0FDdEosY0FBYztNQUFDO01BQWdCO01BQWlCO01BQWtCO01BQWU7TUFBcUI7TUFBc0I7TUFBaUI7S0FBYTtLQUMxSixjQUFjO01BQUM7TUFBZTtNQUFpQjtNQUFnQjtNQUFjO01BQWM7TUFBWTtNQUFXO0tBQVU7S0FDNUgsTUFBTTtNQUFDO01BQVk7TUFBWTtNQUFpQjtNQUFhO01BQWM7TUFBYTtNQUF1QjtLQUFjO0tBQzdILG9CQUFvQixhQUFhLGFBQWE7TUFBQztNQUFnQjtNQUFnQjtNQUFpQjtNQUFnQjtNQUFpQjtNQUFpQjtLQUFnQixJQUFJO01BQUM7TUFBa0I7TUFBYztNQUFjO01BQWU7TUFBa0I7TUFBb0I7TUFBYTtLQUFpQjtJQUMxUztJQUNBLE1BQU0sUUFBUSxZQUFZLEtBQUssSUFBSSxZQUFZLEtBQUssSUFBSTtJQUN4RCxNQUFNLFFBQVEsY0FBYyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUs7SUFDakQsTUFBTSxRQUFRLFVBQVUsc0JBQXNCLGFBQWE7SUFDM0QsTUFBTSxZQUE0QjtLQUNoQyxJQUFJLGFBQWEsS0FBSyxJQUFJO0tBQzFCLE1BQU07S0FDTixNQUFNLFFBQVEsNkJBQTZCLEdBQUcsT0FBTyxHQUFHLE1BQU0sR0FBRyxhQUFhLFNBQVMsWUFBWTtLQUNuRyxTQUFTO0tBQ1Q7S0FDQSxZQUFZLFFBQVEsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLE9BQU8sUUFBUTtLQUN4RCxXQUFXLE1BQU0sS0FBSyxNQUFNLFdBQVc7TUFDckMsTUFBTSxhQUFhLHlDQUF5QyxLQUFLLElBQUksSUFBSSxjQUFjLEtBQUssWUFBWSxNQUFNO01BQzlHLGNBQWMsUUFBUyxVQUFVLEtBQUssVUFBVSxNQUFNLFNBQVMsSUFBSSxTQUFTLFFBQVEsSUFBSSxhQUFhLGNBQWUsYUFBYSxTQUFTLDhCQUE4QixXQUFXLFNBQVMseUJBQXlCLFdBQVcsU0FBUyx5QkFBeUI7S0FDcFEsRUFBRTtJQUNKO0lBQ0EsTUFBTSxZQUFZO0tBQUUsR0FBRztLQUFPLGVBQWU7TUFBRSxXQUFXLFlBQVk7TUFBRyxXQUFXLFdBQVc7S0FBRTtJQUFFO0lBQ25HLElBQUksQ0FBQyxPQUFPLFNBQVMsR0FBRyxNQUFNLElBQUksTUFBTSxTQUFTO0lBQ2pELFVBQVUsU0FBUztJQUNuQixrQkFBa0IsUUFBUTtHQUM1QixRQUFRO0lBQ04sa0JBQWtCLE9BQU87R0FDM0I7RUFDRixHQUFHLElBQUk7RUFDUCxhQUFhO0dBQ1gsT0FBTyxjQUFjLFlBQVk7R0FDakMsT0FBTyxhQUFhLFdBQVc7RUFDakM7Q0FDRixHQUFHLENBQUMsY0FBYyxDQUFDO0NBRW5CLE1BQU0sd0JBQXdCO0VBQzVCLElBQUksQ0FBQyxXQUFXO0VBQ2hCLHFCQUFxQixLQUFLO0VBQzFCLGtCQUFrQixTQUFTO0NBQzdCO0NBQ0EsTUFBTSxhQUFhLFdBQVcsVUFBVTtFQUN0QyxJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sWUFBWTtHQUFFLEdBQUc7R0FBUSxJQUFJLEdBQUcsT0FBTyxHQUFHLEdBQUcsV0FBVyxVQUFVO0dBQVUsTUFBTTtHQUFjLFVBQVU7RUFBUztFQUN6SCxNQUFNLE9BQU8sV0FBVyxZQUFZLENBQUMsV0FDakMsTUFBTSxLQUFLLEtBQUssWUFBWSxRQUFRLFFBQVEsUUFBUSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxXQUFXO0dBQUUsR0FBRztHQUFXLElBQUksUUFBUTtHQUFJLE1BQU0sUUFBUTtHQUFNLE1BQU0sUUFBUSxLQUFLLFNBQVMsVUFBVSxJQUFJLFFBQVEsT0FBTyxVQUFVO0VBQUssSUFBSSxPQUFPLElBQzlOLENBQUMsV0FBVyxHQUFHLE1BQU0sSUFBSTtFQUM3QixJQUFJLENBQUMsT0FBTztHQUFFLEdBQUc7R0FBTztFQUFLLENBQUMsR0FBRztFQUNqQyxNQUFNLFdBQVcsWUFBWSxDQUFDLFdBQVcsbURBQW1ELFdBQVcsa0NBQWtDLHFCQUFxQixXQUFXLFlBQVksRUFBRSxFQUFFO0VBQ3pMLFNBQVMsV0FBVztDQUN0QjtDQUNBLE1BQU0sZ0JBQWdCO0VBQ3BCLFVBQVUsSUFBSTtFQUNkLGtCQUFrQixNQUFNO0NBQzFCO0NBQ0EsTUFBTSxjQUFjO0VBQUM7RUFBNkI7RUFBMEM7Q0FBMEI7Q0FFdEgsT0FBTztFQUFFLHdCQUFDLFlBQUQsRUFBWSxPQUFNLFdBQVk7Ozs7O0VBQ3JDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWtCLHdCQUFDLFFBQUQsYUFBTyxXQUFVLGtDQUFzQzs7Ozs7RUFBTTs7Ozs7RUFDOUYsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFDRyxtQkFBbUIsVUFBVSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQzVCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUFRLFdBQVcsV0FBVyxXQUFXLGFBQWE7UUFBSSxlQUFlLFVBQVUsUUFBUTtrQkFBM0Y7U0FBOEYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7O1NBQU87Ozs7O1NBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUSxpQkFBc0I7Ozs7bUJBQUMsd0JBQUMsU0FBRCxZQUFPLDhDQUFrRDs7OztpQkFBTTs7Ozs7U0FBQyx3QkFBQyxLQUFELFlBQUksV0FBVyxZQUFZLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7a0JBQUs7Ozs7O1FBQVM7Ozs7O2lCQUNqVSx3QkFBQyxVQUFEO1FBQVEsV0FBVyxXQUFXLFdBQVcsYUFBYTtRQUFJLGVBQWUsVUFBVSxRQUFRO2tCQUEzRjtTQUE4Rix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUIsd0JBQUMsTUFBRCxFQUFNLE1BQUssV0FBWTs7Ozs7U0FBTzs7Ozs7U0FBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFRLDJCQUFnQzs7OzttQkFBQyx3QkFBQyxTQUFELFlBQU8sbURBQXVEOzs7O2lCQUFNOzs7OztTQUFDLHdCQUFDLEtBQUQsWUFBSSxXQUFXLFlBQVksd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztrQkFBSzs7Ozs7UUFBUzs7Ozs7ZUFDalY7Ozs7OztNQUNKLFdBQVcsWUFBWSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE0Qix3QkFBQyxTQUFELFlBQU8sZ0JBQW9COzs7O2lCQUFDLHdCQUFDLE9BQUQsWUFBTTtRQUFDO1FBQVk7UUFBWTtRQUFvQjtRQUFpQjtPQUFTLENBQUMsQ0FBQyxLQUFLLFNBQVMsd0JBQUMsVUFBRDtRQUFRLFdBQVcsV0FBVyxPQUFPLFdBQVc7UUFBZSxlQUFlLFVBQVUsSUFBSTtrQkFBSTtPQUFhLEdBQXBEOzs7O2NBQW9ELENBQUMsRUFBTzs7OztlQUFNOzs7Ozs7TUFDeFMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxZQUFELGFBQVUsd0JBQUMsVUFBRCxZQUFRLGFBQWtCOzs7O2tCQUFDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFvQjtVQUFDO1VBQWE7VUFBYztVQUFjO1VBQVE7U0FBa0IsQ0FBQyxDQUFhLEtBQUssU0FBUyx3QkFBQyxVQUFEO1VBQVEsV0FBVyxVQUFVLE9BQU8sV0FBVztVQUFlLGVBQWU7V0FBRSxTQUFTLElBQUk7V0FBRyxJQUFJLFNBQVMsc0JBQXNCLGFBQWEsWUFBWSxZQUFZLG1CQUFtQjtVQUFHO29CQUFJO1NBQWEsR0FBdEo7Ozs7Z0JBQXNKLENBQUM7UUFBTzs7OztnQkFBVzs7Ozs7UUFDelksd0JBQUMsWUFBRCxhQUFVLHdCQUFDLFVBQUQsYUFBUSxhQUFTLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUEyQix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGNBQVc7b0JBQWlCO1NBQVM7Ozs7bUJBQUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7VUFBZSxNQUFLO29CQUFwQztXQUE4Qyx3QkFBQyxVQUFELFlBQVEsaUJBQXNCOzs7OztXQUFDLHdCQUFDLFFBQUQsWUFBTSw4RUFBaUY7Ozs7O1dBQUMsd0JBQUMsS0FBRDtZQUFHLE1BQUs7c0JBQWE7V0FBZ0I7Ozs7O1VBQU87Ozs7O2lCQUFPOzs7OztnQkFBUzs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0I7VUFBQztVQUFxQjtVQUFRO1VBQXFCLEdBQUksVUFBVSxxQkFBcUIsQ0FBQyxVQUFVLElBQUksQ0FBQztTQUFFLENBQUMsQ0FBZ0IsS0FBSyxTQUFTLHdCQUFDLFVBQUQ7VUFBUSxXQUFXLGFBQWEsT0FBTyxXQUFXO1VBQWUsZUFBZSxZQUFZLElBQUk7b0JBQUk7U0FBYSxHQUF0RDs7OztnQkFBc0QsQ0FBQztRQUFPOzs7O2dCQUFXOzs7OztRQUNsb0Isd0JBQUMsWUFBRCxhQUFVLHdCQUFDLFVBQUQsWUFBUSxZQUFpQjs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0I7VUFBQztVQUFxQjtVQUFxQjtTQUFlLENBQUMsQ0FBMEIsS0FBSyxTQUFTLHdCQUFDLFVBQUQ7VUFBUSxXQUFXLGNBQWMsT0FBTyxXQUFXO1VBQWUsZUFBZSxhQUFhLElBQUk7b0JBQUk7U0FBYSxHQUF2RDs7OztnQkFBdUQsQ0FBQztRQUFPOzs7O2dCQUFXOzs7OztRQUNoVCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUErQix3QkFBQyxTQUFELGFBQU8sWUFBUSx3QkFBQyxVQUFEO1VBQVEsT0FBTztVQUFnQixXQUFXLFVBQVUsa0JBQWtCLE1BQU0sT0FBTyxLQUFLO29CQUF4RjtXQUEyRix3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBSztXQUFrQjs7Ozs7V0FBQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBSztXQUFrQjs7Ozs7V0FBQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBSztXQUFrQjs7Ozs7V0FBQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBSztXQUFrQjs7Ozs7V0FBQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUztXQUFpQjs7Ozs7VUFBUzs7Ozs7aUJBQVE7Ozs7bUJBQUUsbUJBQW1CLFlBQVksd0JBQUMsU0FBRCxhQUFPLGtCQUFjLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQVMsS0FBSTtVQUFJLEtBQUk7VUFBTSxPQUFPO1VBQWdCLFdBQVcsVUFBVSxrQkFBa0IsTUFBTSxPQUFPLEtBQUs7VUFBRyxhQUFZO1NBQVM7Ozs7aUJBQVE7Ozs7aUJBQU87Ozs7OztRQUM5aUIsd0JBQUMsWUFBRCxhQUFVLHdCQUFDLFVBQUQsWUFBUSxlQUFvQjs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0I7VUFBQztVQUFRO1VBQVk7U0FBTSxDQUFDLENBQVcsS0FBSyxTQUFTLHdCQUFDLFVBQUQ7VUFBUSxXQUFXLFdBQVcsT0FBTyxXQUFXO1VBQWUsZUFBZSxVQUFVLElBQUk7b0JBQUk7U0FBYSxHQUFwRDs7OztnQkFBb0QsQ0FBQztRQUFPOzs7O2dCQUFXOzs7OztRQUMvUCx3QkFBQyxnQkFBRDtTQUFnQixXQUFVO1NBQW1CLFNBQVM7U0FBVyxVQUFVO21CQUFjLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsNkJBQWtDOzs7O21CQUFDLHdCQUFDLFNBQUQsWUFBUSxxQkFBcUIsc0RBQXNELG1EQUEwRDs7OztpQkFBTzs7Ozs7UUFBaUI7Ozs7O09BQzVTOzs7Ozs7S0FDRjs7Ozs7O0lBRUosbUJBQW1CLGFBQWEsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBb0IsYUFBVTtlQUE3QztNQUFzRCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZ0Isd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7TUFBTzs7Ozs7TUFBQyx3QkFBQyxVQUFELFlBQVMsWUFBWSxnQkFBd0I7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQXNCO1FBQUM7UUFBRztRQUFHO09BQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyx3QkFBQyxPQUFELGFBQWdCLHdCQUFDLEtBQUQsQ0FBSTs7OztpQkFBQyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsS0FBRCxDQUFJOzs7O2lCQUFDLHdCQUFDLEtBQUQsQ0FBSTs7OztlQUFPOzs7O2VBQU0sS0FBdkM7Ozs7Y0FBdUMsQ0FBQztNQUFPOzs7OztLQUFNOzs7Ozs7SUFFNVQsbUJBQW1CLFlBQVksVUFBVSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ3hDLHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxPQUFEO09BQUssd0JBQUMsU0FBRCxZQUFPLHlCQUE2Qjs7Ozs7T0FBQyx3QkFBQyxNQUFELFlBQUssT0FBTyxLQUFTOzs7OztPQUFDLHdCQUFDLEtBQUQ7UUFBSSxPQUFPO1FBQVE7UUFBUSxPQUFPO09BQWE7Ozs7O01BQU07Ozs7Z0JBQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWdCLE9BQU8sV0FBVyxLQUFLLFFBQVEsd0JBQUMsS0FBRCxZQUFjLElBQU8sR0FBYjs7OztjQUFhLENBQUM7TUFBTzs7OztjQUFTOzs7OztNQUNsTyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBdUIsT0FBTyxVQUFVLEtBQUssVUFBVSxVQUFVLHdCQUFDLFdBQUQ7UUFBMkMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWdCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFdBQVk7Ozs7O1FBQU87Ozs7O1FBQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQsWUFBUyxTQUFTLEtBQWE7Ozs7a0JBQUMsd0JBQUMsU0FBRCxZQUFRLFNBQVMsYUFBb0I7Ozs7Z0JBQU07Ozs7O1FBQUMsd0JBQUMsS0FBRCxZQUFJLE9BQU8sV0FBVyxRQUFRLE9BQU8sV0FBVyxRQUFXOzs7OztPQUFVLEtBQWxQLEdBQUcsU0FBUyxLQUFLLEdBQUc7Ozs7Y0FBOE4sQ0FBQztNQUFPOzs7OztNQUN4Vix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUEwQix3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztnQkFBTzs7OztpQkFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxZQUFRLGdCQUFxQjs7OztpQkFBQyx3QkFBQyxNQUFELGFBQUksd0JBQUMsTUFBRCxZQUFLLGNBQWMsc0JBQXNCLDhEQUE4RCxHQUFHLFVBQVUsMENBQThDOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSyxZQUFZLCtEQUErRCxHQUFHLE9BQU8sMERBQThEOzs7O2VBQUs7Ozs7ZUFBTTs7OztlQUFNOzs7Ozs7TUFDL2Esd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXFCO01BQW1FOzs7OztLQUNsRzs7Ozs7O0lBRUosbUJBQW1CLFdBQVcsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUFtQyx3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7OztlQUFPOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSSx3QkFBeUI7Ozs7O01BQUMsd0JBQUMsS0FBRCxZQUFHLDhGQUE4Rjs7Ozs7TUFBQyx3QkFBQyxRQUFEO09BQVEsZUFBZSxrQkFBa0IsTUFBTTtpQkFBRztNQUFpQjs7Ozs7S0FBTTs7Ozs7O0lBRTdTLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO2VBQWxCLENBQ0csbUJBQW1CLFVBQVU7TUFBRSx3QkFBQyxRQUFEO09BQVEsU0FBUztPQUFpQixVQUFVLENBQUMsU0FBUyxDQUFDO2lCQUFXO01BQXdCOzs7OztNQUFDLHdCQUFDLFNBQUQsWUFBTyx3Q0FBNEM7Ozs7O01BQUUsQ0FBQyxhQUFhLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTZCO1FBQXdELFdBQVcsU0FBUztRQUFFO1FBQXFDLHdCQUFDLFVBQUQ7U0FBUSxlQUFlLFNBQVMsV0FBVzttQkFBRztRQUFtQjs7Ozs7UUFBQztPQUFJOzs7Ozs7S0FBSTs7OztlQUN2WixtQkFBbUIsWUFBWSxVQUFVO01BQUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBaUMsd0JBQUMsU0FBRCxhQUFPLGtCQUFjLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQU8sS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDO1FBQUcsT0FBTztRQUFjLFdBQVcsVUFBVSxnQkFBZ0IsTUFBTSxPQUFPLEtBQUs7T0FBSTs7OztlQUFROzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBUSxlQUFlLFVBQVUsS0FBSztrQkFBRztPQUFzQjs7OztlQUFNOzs7Ozs7TUFBQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUFnQyx3QkFBQyxRQUFEO1NBQVEsU0FBUTtTQUFRLGVBQWUsVUFBVSxJQUFJO21CQUFHO1FBQTJCOzs7OztRQUFDLHdCQUFDLFFBQUQ7U0FBUSxTQUFRO1NBQVEsZUFBZSxxQkFBcUIsSUFBSTtTQUFHLFVBQVUsQ0FBQzttQkFBVztRQUFrQjs7Ozs7UUFBQyx3QkFBQyxVQUFEO1NBQVEsU0FBUzttQkFBUztRQUFlOzs7OztPQUFNOzs7Ozs7TUFBRSxxQkFBcUIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFBb0Msd0JBQUMsS0FBRCxZQUFHLHdEQUF3RDs7Ozs7UUFBQyx3QkFBQyxVQUFEO1NBQVEsZUFBZSxxQkFBcUIsS0FBSzttQkFBRztRQUFjOzs7OztRQUFDLHdCQUFDLFFBQUQ7U0FBUSxTQUFTO21CQUFpQjtRQUF3Qjs7Ozs7T0FBTTs7Ozs7O0tBQUk7Ozs7YUFDcnpCOzs7Ozs7R0FDRDs7Ozs7O0NBQ1Q7Ozs7O0FBQ0oiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2VuZXJhdGVQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCIuLi9jb21wb25lbnRzL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBDdXN0b21DaGVja2JveCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0N1c3RvbUNoZWNrYm94XCI7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9JY29uXCI7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XHJcbmltcG9ydCB0eXBlIHsgRml0bmVzc1N0b3JlLCBQbGFubmVkV29ya291dCB9IGZyb20gXCIuLi9maXRuZXNzU3RvcmVcIjtcclxuaW1wb3J0IHsgZGF0ZUtleSwgcHJldHR5RGF0ZSB9IGZyb20gXCIuLi9saWIvZm9ybWF0XCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gR2VuZXJhdGVQYWdlKHsgc3RvcmUsIHVwZGF0ZSwgbmF2aWdhdGUsIHRvYXN0IH06IHsgc3RvcmU6IEZpdG5lc3NTdG9yZTsgdXBkYXRlOiAobmV4dDogRml0bmVzc1N0b3JlKSA9PiBib29sZWFuOyBuYXZpZ2F0ZTogKHBhdGg6IHN0cmluZykgPT4gdm9pZDsgdG9hc3Q6IChtZXNzYWdlOiBzdHJpbmcsIGVycm9yPzogYm9vbGVhbikgPT4gdm9pZCB9KSB7XHJcbiAgdHlwZSBHZW5lcmF0b3JTdGF0ZSA9IFwiZm9ybVwiIHwgXCJsb2FkaW5nXCIgfCBcInJlc3VsdFwiIHwgXCJlcnJvclwiO1xyXG4gIHR5cGUgRm9jdXMgPSBcIkZ1bGwgQm9keVwiIHwgXCJVcHBlciBCb2R5XCIgfCBcIkxvd2VyIEJvZHlcIiB8IFwiQ29yZVwiIHwgXCJDYXJkaW8gLyBSdW5uaW5nXCI7XHJcbiAgdHlwZSBUcmFpbmluZyA9IFwiRmF0IExvc3MgJiBDYXJkaW9cIiB8IFwiSElJVFwiIHwgXCJNdXNjbGUgJiBTdHJlbmd0aFwiIHwgXCJXYWxrLVJ1blwiO1xyXG4gIHR5cGUgR2VuZXJhdG9yRXF1aXBtZW50ID0gXCJCb2R5d2VpZ2h0IC8gSG9tZVwiIHwgXCJEdW1iYmVsbHMgJiBCYW5kc1wiIHwgXCJHeW0gRXF1aXBtZW50XCI7XHJcbiAgY29uc3QgbmV4dE1vbmRheSA9IChmcm9tID0gbmV3IERhdGUoKSkgPT4ge1xyXG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGZyb20pO1xyXG4gICAgZGF0ZS5zZXRIb3VycygxMiwgMCwgMCwgMCk7XHJcbiAgICBjb25zdCBkYXlzID0gKDggLSBkYXRlLmdldERheSgpKSAlIDcgfHwgNztcclxuICAgIGRhdGUuc2V0RGF0ZShkYXRlLmdldERhdGUoKSArIGRheXMpO1xyXG4gICAgcmV0dXJuIGRhdGVLZXkoZGF0ZSk7XHJcbiAgfTtcclxuICBjb25zdCBwcm9maWxlRXF1aXBtZW50OiBHZW5lcmF0b3JFcXVpcG1lbnQgPSBzdG9yZS51c2VyLmVxdWlwbWVudC5pbmNsdWRlcyhcIkd5bVwiKSA/IFwiR3ltIEVxdWlwbWVudFwiIDogc3RvcmUudXNlci5lcXVpcG1lbnQuaW5jbHVkZXMoXCJEdW1iYmVsbFwiKSA/IFwiRHVtYmJlbGxzICYgQmFuZHNcIiA6IFwiQm9keXdlaWdodCAvIEhvbWVcIjtcclxuICBjb25zdCBwcm9maWxlVHJhaW5pbmc6IFRyYWluaW5nID0gc3RvcmUudXNlci5nb2FsLmluY2x1ZGVzKFwiTXVzY2xlXCIpID8gXCJNdXNjbGUgJiBTdHJlbmd0aFwiIDogXCJGYXQgTG9zcyAmIENhcmRpb1wiO1xyXG4gIGNvbnN0IGFnZSA9IE51bWJlcihzdG9yZS51c2VyLmFnZSk7XHJcbiAgY29uc3QgYXV0b21hdGljTG93SW1wYWN0ID0gc3RvcmUudXNlci5pbmp1cnlGbGFnIHx8IChhZ2UgPiAwICYmIGFnZSA8IDE4KSB8fCBhZ2UgPj0gNjA7XHJcbiAgY29uc3QgW2dlbmVyYXRvclN0YXRlLCBzZXRHZW5lcmF0b3JTdGF0ZV0gPSB1c2VTdGF0ZTxHZW5lcmF0b3JTdGF0ZT4oXCJmb3JtXCIpO1xyXG4gIGNvbnN0IFtvcHRpb24sIHNldE9wdGlvbl0gPSB1c2VTdGF0ZTxcInNpbmdsZVwiIHwgXCJhZGp1c3RcIj4oXCJzaW5nbGVcIik7XHJcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmb2N1cywgc2V0Rm9jdXNdID0gdXNlU3RhdGU8Rm9jdXM+KFwiRnVsbCBCb2R5XCIpO1xyXG4gIGNvbnN0IFt0cmFpbmluZywgc2V0VHJhaW5pbmddID0gdXNlU3RhdGU8VHJhaW5pbmc+KHByb2ZpbGVUcmFpbmluZyk7XHJcbiAgY29uc3QgW2VxdWlwbWVudCwgc2V0RXF1aXBtZW50XSA9IHVzZVN0YXRlPEdlbmVyYXRvckVxdWlwbWVudD4ocHJvZmlsZUVxdWlwbWVudCk7XHJcbiAgY29uc3QgaW5pdGlhbER1cmF0aW9uID0gWzE1LCAzMCwgNDUsIDYwXS5pbmNsdWRlcyhzdG9yZS5jaGFsbGVuZ2Uuc2Vzc2lvbk1pbnV0ZXMpID8gU3RyaW5nKHN0b3JlLmNoYWxsZW5nZS5zZXNzaW9uTWludXRlcykgOiBcImN1c3RvbVwiO1xyXG4gIGNvbnN0IFtkdXJhdGlvbkNob2ljZSwgc2V0RHVyYXRpb25DaG9pY2VdID0gdXNlU3RhdGUoaW5pdGlhbER1cmF0aW9uKTtcclxuICBjb25zdCBbY3VzdG9tRHVyYXRpb24sIHNldEN1c3RvbUR1cmF0aW9uXSA9IHVzZVN0YXRlKGluaXRpYWxEdXJhdGlvbiA9PT0gXCJjdXN0b21cIiA/IFN0cmluZyhzdG9yZS5jaGFsbGVuZ2Uuc2Vzc2lvbk1pbnV0ZXMpIDogXCJcIik7XHJcbiAgY29uc3QgW2VmZm9ydCwgc2V0RWZmb3J0XSA9IHVzZVN0YXRlPFwiRWFzeVwiIHwgXCJNb2RlcmF0ZVwiIHwgXCJIYXJkXCI+KFwiTW9kZXJhdGVcIik7XHJcbiAgY29uc3QgW2xvd0ltcGFjdCwgc2V0TG93SW1wYWN0XSA9IHVzZVN0YXRlKGF1dG9tYXRpY0xvd0ltcGFjdCk7XHJcbiAgY29uc3QgW2xvYWRpbmdNZXNzYWdlLCBzZXRMb2FkaW5nTWVzc2FnZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcmVzdWx0LCBzZXRSZXN1bHRdID0gdXNlU3RhdGU8UGxhbm5lZFdvcmtvdXQgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2NoZWR1bGVEYXRlLCBzZXRTY2hlZHVsZURhdGVdID0gdXNlU3RhdGUoKCkgPT4gc3RvcmUucGxhbi5maW5kKCh3b3Jrb3V0KSA9PiB3b3Jrb3V0LmRhdGUgPj0gZGF0ZUtleShuZXcgRGF0ZSgpKSAmJiAhd29ya291dC5vcHRpb25hbCk/LmRhdGUgfHwgZGF0ZUtleShuZXcgRGF0ZSgpKSk7XHJcbiAgY29uc3QgW2NvbmZpcm1SZWdlbmVyYXRlLCBzZXRDb25maXJtUmVnZW5lcmF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgcmVzZXREYXRlID0gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3Qoc3RvcmUuYWlHZW5lcmF0aW9ucy5yZXNldERhdGUpID8gc3RvcmUuYWlHZW5lcmF0aW9ucy5yZXNldERhdGUgOiBuZXh0TW9uZGF5KCk7XHJcbiAgY29uc3QgcmVzZXREdWUgPSByZXNldERhdGUgPD0gZGF0ZUtleShuZXcgRGF0ZSgpKTtcclxuICBjb25zdCB1c2VkQ291bnQgPSByZXNldER1ZSA/IDAgOiBzdG9yZS5haUdlbmVyYXRpb25zLnVzZWRDb3VudDtcclxuICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCgwLCAzIC0gdXNlZENvdW50KTtcclxuICBjb25zdCBkdXJhdGlvbiA9IGR1cmF0aW9uQ2hvaWNlID09PSBcImN1c3RvbVwiID8gTnVtYmVyKGN1c3RvbUR1cmF0aW9uKSA6IE51bWJlcihkdXJhdGlvbkNob2ljZSk7XHJcbiAgY29uc3QgdmFsaWQgPSBCb29sZWFuKGZvY3VzICYmIHRyYWluaW5nICYmIGVxdWlwbWVudCAmJiBlZmZvcnQgJiYgZHVyYXRpb24gPj0gNSAmJiBkdXJhdGlvbiA8PSAxODAgJiYgKG9wdGlvbiA9PT0gXCJzaW5nbGVcIiB8fCByZWFzb24pKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IG1vbmRheVJlc2V0ID0gbmV4dE1vbmRheSgpO1xyXG4gICAgaWYgKHJlc2V0RHVlIHx8IHJlc2V0RGF0ZSAhPT0gbW9uZGF5UmVzZXQpIHtcclxuICAgICAgdXBkYXRlKHsgLi4uc3RvcmUsIGFpR2VuZXJhdGlvbnM6IHsgdXNlZENvdW50OiByZXNldER1ZSA/IDAgOiB1c2VkQ291bnQsIHJlc2V0RGF0ZTogbW9uZGF5UmVzZXQgfSB9KTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZ2VuZXJhdG9yU3RhdGUgIT09IFwibG9hZGluZ1wiKSByZXR1cm47XHJcbiAgICBzZXRMb2FkaW5nTWVzc2FnZSgwKTtcclxuICAgIGNvbnN0IG1lc3NhZ2VUaW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiBzZXRMb2FkaW5nTWVzc2FnZSgodmFsdWUpID0+ICh2YWx1ZSArIDEpICUgMyksIDkwMCk7XHJcbiAgICBjb25zdCByZXN1bHRUaW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBleGVyY2lzZVBvb2xzOiBSZWNvcmQ8Rm9jdXMsIHN0cmluZ1tdPiA9IHtcclxuICAgICAgICAgIFwiRnVsbCBCb2R5XCI6IFtcIlNxdWF0IHRvIHJlYWNoXCIsIFwiSW5jbGluZSBwdXNoLXVwXCIsIFwiUmV2ZXJzZSBsdW5nZVwiLCBcIkdsdXRlIGJyaWRnZVwiLCBcIkJpcmQgZG9nXCIsIFwiU3RhbmRpbmcga25lZSBkcml2ZVwiLCBcIkRlYWQgYnVnXCIsIFwiTWFyY2hpbmcgZmluaXNoZXJcIl0sXHJcbiAgICAgICAgICBcIlVwcGVyIEJvZHlcIjogW1wiV2FsbCBwdXNoLXVwXCIsIFwiQmVudC1vdmVyIHJvd1wiLCBcIlNob3VsZGVyIHByZXNzXCIsIFwiQmljZXBzIGN1cmxcIiwgXCJUcmljZXBzIGV4dGVuc2lvblwiLCBcIlBsYW5rIHNob3VsZGVyIHRhcFwiLCBcIkxhdGVyYWwgcmFpc2VcIiwgXCJDaGVzdCBwcmVzc1wiXSxcclxuICAgICAgICAgIFwiTG93ZXIgQm9keVwiOiBbXCJUZW1wbyBzcXVhdFwiLCBcIlJldmVyc2UgbHVuZ2VcIiwgXCJHbHV0ZSBicmlkZ2VcIiwgXCJDYWxmIHJhaXNlXCIsIFwiU2lkZSBsdW5nZVwiLCBcIldhbGwgc2l0XCIsIFwiU3RlcC11cFwiLCBcIkRlYWQgYnVnXCJdLFxyXG4gICAgICAgICAgQ29yZTogW1wiRGVhZCBidWdcIiwgXCJCaXJkIGRvZ1wiLCBcIkZvcmVhcm0gcGxhbmtcIiwgXCJIZWVsIHRhcHNcIiwgXCJTaWRlIHBsYW5rXCIsIFwiQmVhciBob2xkXCIsIFwiU3RhbmRpbmcga25lZSBkcml2ZVwiLCBcIkdsdXRlIGJyaWRnZVwiXSxcclxuICAgICAgICAgIFwiQ2FyZGlvIC8gUnVubmluZ1wiOiB0cmFpbmluZyA9PT0gXCJXYWxrLVJ1blwiID8gW1wiV2FybS11cCB3YWxrXCIsIFwiSm9nIGludGVydmFsXCIsIFwiUmVjb3Zlcnkgd2Fsa1wiLCBcIkpvZyBpbnRlcnZhbFwiLCBcIlJlY292ZXJ5IHdhbGtcIiwgXCJTdGVhZHkgZmluaXNoXCIsIFwiQ29vbC1kb3duIHdhbGtcIl0gOiBbXCJNYXJjaCBpbiBwbGFjZVwiLCBcIlN0ZXAgdG91Y2hcIiwgXCJIaWdoIGtuZWVzXCIsIFwiU2thdGVyIHN0ZXBcIiwgXCJTcXVhdCB0byByZWFjaFwiLCBcIk1vdW50YWluIGNsaW1iZXJcIiwgXCJGYXN0IGZlZXRcIiwgXCJCcmVhdGhpbmcgcmVzZXRcIl0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBjb3VudCA9IGR1cmF0aW9uIDw9IDE1ID8gNCA6IGR1cmF0aW9uIDw9IDMwID8gNiA6IDg7XHJcbiAgICAgICAgY29uc3QgbmFtZXMgPSBleGVyY2lzZVBvb2xzW2ZvY3VzXS5zbGljZSgwLCBjb3VudCk7XHJcbiAgICAgICAgY29uc3QgaXNSdW4gPSBmb2N1cyA9PT0gXCJDYXJkaW8gLyBSdW5uaW5nXCIgJiYgdHJhaW5pbmcgPT09IFwiV2Fsay1SdW5cIjtcclxuICAgICAgICBjb25zdCBnZW5lcmF0ZWQ6IFBsYW5uZWRXb3Jrb3V0ID0ge1xyXG4gICAgICAgICAgaWQ6IGBnZW5lcmF0ZWQtJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgICAgICBkYXRlOiBzY2hlZHVsZURhdGUsXHJcbiAgICAgICAgICBuYW1lOiBpc1J1biA/IFwiRnJlc2ggV2Fsay1SdW4gSW50ZXJ2YWxzXCIgOiBgJHtlZmZvcnR9ICR7Zm9jdXN9ICR7dHJhaW5pbmcgPT09IFwiSElJVFwiID8gXCJDaXJjdWl0XCIgOiBcIlNlc3Npb25cIn1gLFxyXG4gICAgICAgICAgbWludXRlczogZHVyYXRpb24sXHJcbiAgICAgICAgICBlcXVpcG1lbnQsXHJcbiAgICAgICAgICB0YXJnZXRUYWdzOiBpc1J1biA/IFtcIkNhcmRpb1wiLCBcIlJ1blwiXSA6IFtmb2N1cywgdHJhaW5pbmddLFxyXG4gICAgICAgICAgZXhlcmNpc2VzOiBuYW1lcy5tYXAoKG5hbWUsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICBuYW1lOiBsb3dJbXBhY3QgJiYgL2hpZ2gga25lZXN8bW91bnRhaW4gY2xpbWJlcnxmYXN0IGZlZXQvaS50ZXN0KG5hbWUpID8gYExvdy1pbXBhY3QgJHtuYW1lLnRvTG93ZXJDYXNlKCl9YCA6IG5hbWUsXHJcbiAgICAgICAgICAgIHByZXNjcmlwdGlvbjogaXNSdW4gPyAoaW5kZXggPT09IDAgfHwgaW5kZXggPT09IG5hbWVzLmxlbmd0aCAtIDEgPyBcIjU6MDBcIiA6IGluZGV4ICUgMiA/IFwiMTowMCBqb2dcIiA6IFwiMjowMCB3YWxrXCIpIDogdHJhaW5pbmcgPT09IFwiSElJVFwiID8gXCI0MCBzZWMgd29yayDCtyAyMCBzZWMgcmVzdFwiIDogZWZmb3J0ID09PSBcIkVhc3lcIiA/IFwiMiDDlyAxMCDCtyA0NSBzZWMgcmVzdFwiIDogZWZmb3J0ID09PSBcIkhhcmRcIiA/IFwiNCDDlyAxMiDCtyAzMCBzZWMgcmVzdFwiIDogXCIzIMOXIDEyIMK3IDQwIHNlYyByZXN0XCIsXHJcbiAgICAgICAgICB9KSksXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBuZXh0U3RvcmUgPSB7IC4uLnN0b3JlLCBhaUdlbmVyYXRpb25zOiB7IHVzZWRDb3VudDogdXNlZENvdW50ICsgMSwgcmVzZXREYXRlOiBuZXh0TW9uZGF5KCkgfSB9O1xyXG4gICAgICAgIGlmICghdXBkYXRlKG5leHRTdG9yZSkpIHRocm93IG5ldyBFcnJvcihcInN0b3JhZ2VcIik7XHJcbiAgICAgICAgc2V0UmVzdWx0KGdlbmVyYXRlZCk7XHJcbiAgICAgICAgc2V0R2VuZXJhdG9yU3RhdGUoXCJyZXN1bHRcIik7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIHNldEdlbmVyYXRvclN0YXRlKFwiZXJyb3JcIik7XHJcbiAgICAgIH1cclxuICAgIH0sIDI4MDApO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LmNsZWFySW50ZXJ2YWwobWVzc2FnZVRpbWVyKTtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dChyZXN1bHRUaW1lcik7XHJcbiAgICB9O1xyXG4gIH0sIFtnZW5lcmF0b3JTdGF0ZV0pO1xyXG5cclxuICBjb25zdCBzdGFydEdlbmVyYXRpb24gPSAoKSA9PiB7XHJcbiAgICBpZiAoIXJlbWFpbmluZykgcmV0dXJuO1xyXG4gICAgc2V0Q29uZmlybVJlZ2VuZXJhdGUoZmFsc2UpO1xyXG4gICAgc2V0R2VuZXJhdG9yU3RhdGUoXCJsb2FkaW5nXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgYWRkVG9QbGFuID0gKHNhdmVPbmx5ID0gZmFsc2UpID0+IHtcclxuICAgIGlmICghcmVzdWx0KSByZXR1cm47XHJcbiAgICBjb25zdCBzY2hlZHVsZWQgPSB7IC4uLnJlc3VsdCwgaWQ6IGAke3Jlc3VsdC5pZH0tJHtzYXZlT25seSA/IFwic2F2ZWRcIiA6IFwicGxhblwifWAsIGRhdGU6IHNjaGVkdWxlRGF0ZSwgb3B0aW9uYWw6IHNhdmVPbmx5IH07XHJcbiAgICBjb25zdCBwbGFuID0gb3B0aW9uID09PSBcImFkanVzdFwiICYmICFzYXZlT25seVxyXG4gICAgICA/IHN0b3JlLnBsYW4ubWFwKCh3b3Jrb3V0KSA9PiB3b3Jrb3V0LmRhdGUgPj0gZGF0ZUtleShuZXcgRGF0ZSgpKSAmJiAhd29ya291dC5vcHRpb25hbCA/IHsgLi4uc2NoZWR1bGVkLCBpZDogd29ya291dC5pZCwgZGF0ZTogd29ya291dC5kYXRlLCBuYW1lOiB3b3Jrb3V0Lm5hbWUuaW5jbHVkZXMoXCJSZWNvdmVyeVwiKSA/IHdvcmtvdXQubmFtZSA6IHNjaGVkdWxlZC5uYW1lIH0gOiB3b3Jrb3V0KVxyXG4gICAgICA6IFtzY2hlZHVsZWQsIC4uLnN0b3JlLnBsYW5dO1xyXG4gICAgaWYgKCF1cGRhdGUoeyAuLi5zdG9yZSwgcGxhbiB9KSkgcmV0dXJuO1xyXG4gICAgdG9hc3Qob3B0aW9uID09PSBcImFkanVzdFwiICYmICFzYXZlT25seSA/IFwiWW91ciByZW1haW5pbmcgY2hhbGxlbmdlIHBsYW4gd2FzIHJlLWJhbGFuY2VkLlwiIDogc2F2ZU9ubHkgPyBcIldvcmtvdXQgc2F2ZWQgdG8gTXkgd29ya291dHMuXCIgOiBgV29ya291dCBhZGRlZCBmb3IgJHtwcmV0dHlEYXRlKHNjaGVkdWxlRGF0ZSl9LmApO1xyXG4gICAgbmF2aWdhdGUoXCIvd29ya291dHNcIik7XHJcbiAgfTtcclxuICBjb25zdCBkaXNjYXJkID0gKCkgPT4ge1xyXG4gICAgc2V0UmVzdWx0KG51bGwpO1xyXG4gICAgc2V0R2VuZXJhdG9yU3RhdGUoXCJmb3JtXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgbG9hZGluZ0NvcHkgPSBbXCJBbmFseXppbmcgeW91ciBwcm9maWxlLi4uXCIsIFwiQmFsYW5jaW5nIHJlcHMsIHJlc3QsIGFuZCBlcXVpcG1lbnQuLi5cIiwgXCJCdWlsZGluZyB5b3VyIHJvdXRpbmUuLi5cIl07XHJcblxyXG4gIHJldHVybiA8PjxQYWdlSGVhZGVyIHRpdGxlPVwiR2VuZXJhdGVcIiAvPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0ZS1oZWFkZXJcIj48c3Bhbj57cmVtYWluaW5nfSBvZiAzIGdlbmVyYXRpb25zIGxlZnQgdGhpcyB3ZWVrPC9zcGFuPjwvZGl2PlxyXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwiZ2VuZXJhdG9yLXNoZWxsXCI+XHJcbiAgICAgIHtnZW5lcmF0b3JTdGF0ZSA9PT0gXCJmb3JtXCIgJiYgPGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0b3Itc2Nyb2xsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0b3Itb3B0aW9uc1wiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e29wdGlvbiA9PT0gXCJzaW5nbGVcIiA/IFwic2VsZWN0ZWRcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldE9wdGlvbihcInNpbmdsZVwiKX0+PHNwYW4gY2xhc3NOYW1lPVwiZ2VuZXJhdGUtY2hvaWNlLWljb25cIj48SWNvbiBuYW1lPVwiYm9sdFwiIC8+PC9zcGFuPjxkaXY+PHN0cm9uZz5TaW5nbGUgd29ya291dDwvc3Ryb25nPjxzbWFsbD5BIG9uZS1vZmYgcm91dGluZSBmb3IgdG9kYXkgb3IgYW5vdGhlciBkYXkuPC9zbWFsbD48L2Rpdj48aT57b3B0aW9uID09PSBcInNpbmdsZVwiICYmIDxJY29uIG5hbWU9XCJjaGVja1wiIC8+fTwvaT48L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtvcHRpb24gPT09IFwiYWRqdXN0XCIgPyBcInNlbGVjdGVkXCIgOiBcIlwifSBvbkNsaWNrPXsoKSA9PiBzZXRPcHRpb24oXCJhZGp1c3RcIil9PjxzcGFuIGNsYXNzTmFtZT1cImdlbmVyYXRlLWNob2ljZS1pY29uXCI+PEljb24gbmFtZT1cImNhbGVuZGFyXCIgLz48L3NwYW4+PGRpdj48c3Ryb25nPkFkanVzdCBteSBjaGFsbGVuZ2UgcGxhbjwvc3Ryb25nPjxzbWFsbD5SZS1iYWxhbmNlIHRoZSB3b3Jrb3V0cyBpbiB5b3VyIHJlbWFpbmluZyB3ZWVrcy48L3NtYWxsPjwvZGl2PjxpPntvcHRpb24gPT09IFwiYWRqdXN0XCIgJiYgPEljb24gbmFtZT1cImNoZWNrXCIgLz59PC9pPjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtvcHRpb24gPT09IFwiYWRqdXN0XCIgJiYgPGRpdiBjbGFzc05hbWU9XCJyZWFzb24tcm93XCI+PHNtYWxsPldIQVQgQ0hBTkdFRD88L3NtYWxsPjxkaXY+e1tcIlRvbyBoYXJkXCIsIFwiVG9vIGVhc3lcIiwgXCJTY2hlZHVsZSBjaGFuZ2VkXCIsIFwiTmV3IGVxdWlwbWVudFwiLCBcIlBsYXRlYXVcIl0ubWFwKChpdGVtKSA9PiA8YnV0dG9uIGNsYXNzTmFtZT17cmVhc29uID09PSBpdGVtID8gXCJhY3RpdmVcIiA6IFwiXCJ9IGtleT17aXRlbX0gb25DbGljaz17KCkgPT4gc2V0UmVhc29uKGl0ZW0pfT57aXRlbX08L2J1dHRvbj4pfTwvZGl2PjwvZGl2Pn1cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdlbmVyYXRvci1mb3JtXCI+XHJcbiAgICAgICAgICA8ZmllbGRzZXQ+PGxlZ2VuZD5Gb2N1cyBhcmVhPC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0b3ItY2hpcHNcIj57KFtcIkZ1bGwgQm9keVwiLCBcIlVwcGVyIEJvZHlcIiwgXCJMb3dlciBCb2R5XCIsIFwiQ29yZVwiLCBcIkNhcmRpbyAvIFJ1bm5pbmdcIl0gYXMgRm9jdXNbXSkubWFwKChpdGVtKSA9PiA8YnV0dG9uIGNsYXNzTmFtZT17Zm9jdXMgPT09IGl0ZW0gPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtpdGVtfSBvbkNsaWNrPXsoKSA9PiB7IHNldEZvY3VzKGl0ZW0pOyBpZiAoaXRlbSAhPT0gXCJDYXJkaW8gLyBSdW5uaW5nXCIgJiYgdHJhaW5pbmcgPT09IFwiV2Fsay1SdW5cIikgc2V0VHJhaW5pbmcoXCJGYXQgTG9zcyAmIENhcmRpb1wiKTsgfX0+e2l0ZW19PC9idXR0b24+KX08L2Rpdj48L2ZpZWxkc2V0PlxyXG4gICAgICAgICAgPGZpZWxkc2V0PjxsZWdlbmQ+VHJhaW5pbmcgPHNwYW4gY2xhc3NOYW1lPVwiaW5mby10aXBcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBhcmlhLWxhYmVsPVwiQWJvdXQgdHJhaW5pbmdcIj7ik5g8L2J1dHRvbj48c3BhbiBjbGFzc05hbWU9XCJ0ZXJtLXRvb2x0aXBcIiByb2xlPVwidG9vbHRpcFwiPjxzdHJvbmc+VHJhaW5pbmcgc3R5bGU8L3N0cm9uZz48c3Bhbj5UaGlzIGNoYW5nZXMgdGhlIHBhY2UsIHJlcGV0aXRpb25zLCB3b3JrIHBlcmlvZHMsIGFuZCByZXN0IGluIHlvdXIgcm91dGluZS48L3NwYW4+PGEgaHJlZj1cIi8jZ2xvc3NhcnlcIj5WaWV3IGdsb3NzYXJ5PC9hPjwvc3Bhbj48L3NwYW4+PC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0b3ItY2hpcHNcIj57KFtcIkZhdCBMb3NzICYgQ2FyZGlvXCIsIFwiSElJVFwiLCBcIk11c2NsZSAmIFN0cmVuZ3RoXCIsIC4uLihmb2N1cyA9PT0gXCJDYXJkaW8gLyBSdW5uaW5nXCIgPyBbXCJXYWxrLVJ1blwiXSA6IFtdKV0gYXMgVHJhaW5pbmdbXSkubWFwKChpdGVtKSA9PiA8YnV0dG9uIGNsYXNzTmFtZT17dHJhaW5pbmcgPT09IGl0ZW0gPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtpdGVtfSBvbkNsaWNrPXsoKSA9PiBzZXRUcmFpbmluZyhpdGVtKX0+e2l0ZW19PC9idXR0b24+KX08L2Rpdj48L2ZpZWxkc2V0PlxyXG4gICAgICAgICAgPGZpZWxkc2V0PjxsZWdlbmQ+RXF1aXBtZW50PC9sZWdlbmQ+PGRpdiBjbGFzc05hbWU9XCJnZW5lcmF0b3ItY2hpcHNcIj57KFtcIkJvZHl3ZWlnaHQgLyBIb21lXCIsIFwiRHVtYmJlbGxzICYgQmFuZHNcIiwgXCJHeW0gRXF1aXBtZW50XCJdIGFzIEdlbmVyYXRvckVxdWlwbWVudFtdKS5tYXAoKGl0ZW0pID0+IDxidXR0b24gY2xhc3NOYW1lPXtlcXVpcG1lbnQgPT09IGl0ZW0gPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtpdGVtfSBvbkNsaWNrPXsoKSA9PiBzZXRFcXVpcG1lbnQoaXRlbSl9PntpdGVtfTwvYnV0dG9uPil9PC9kaXY+PC9maWVsZHNldD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2VuZXJhdG9yLXJvd1wiPjxsYWJlbD5EdXJhdGlvbjxzZWxlY3QgdmFsdWU9e2R1cmF0aW9uQ2hvaWNlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREdXJhdGlvbkNob2ljZShldmVudC50YXJnZXQudmFsdWUpfT48b3B0aW9uIHZhbHVlPVwiMTVcIj4xNSBtaW51dGVzPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIjMwXCI+MzAgbWludXRlczwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCI0NVwiPjQ1IG1pbnV0ZXM8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwiNjBcIj42MCBtaW51dGVzPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cImN1c3RvbVwiPkN1c3RvbS4uLjwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+e2R1cmF0aW9uQ2hvaWNlID09PSBcImN1c3RvbVwiICYmIDxsYWJlbD5DdXN0b20gbWludXRlczxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiNVwiIG1heD1cIjE4MFwiIHZhbHVlPXtjdXN0b21EdXJhdGlvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Q3VzdG9tRHVyYXRpb24oZXZlbnQudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCI14oCTMTgwXCIgLz48L2xhYmVsPn08L2Rpdj5cclxuICAgICAgICAgIDxmaWVsZHNldD48bGVnZW5kPkVmZm9ydCB0b2RheTwvbGVnZW5kPjxkaXYgY2xhc3NOYW1lPVwiZ2VuZXJhdG9yLWNoaXBzXCI+eyhbXCJFYXN5XCIsIFwiTW9kZXJhdGVcIiwgXCJIYXJkXCJdIGFzIGNvbnN0KS5tYXAoKGl0ZW0pID0+IDxidXR0b24gY2xhc3NOYW1lPXtlZmZvcnQgPT09IGl0ZW0gPyBcImFjdGl2ZVwiIDogXCJcIn0ga2V5PXtpdGVtfSBvbkNsaWNrPXsoKSA9PiBzZXRFZmZvcnQoaXRlbSl9PntpdGVtfTwvYnV0dG9uPil9PC9kaXY+PC9maWVsZHNldD5cclxuICAgICAgICAgIDxDdXN0b21DaGVja2JveCBjbGFzc05hbWU9XCJnZW5lcmF0b3ItdG9nZ2xlXCIgY2hlY2tlZD17bG93SW1wYWN0fSBvbkNoYW5nZT17c2V0TG93SW1wYWN0fT48c3Bhbj48c3Ryb25nPkluY2x1ZGUgbG93LWltcGFjdCBvcHRpb25zPC9zdHJvbmc+PHNtYWxsPnthdXRvbWF0aWNMb3dJbXBhY3QgPyBcIk9uIGJhc2VkIG9uIHlvdXIgcHJvZmlsZTsgeW91IGNhbiBjaGFuZ2UgaXQgaGVyZS5cIiA6IFwiQWRkcyBqb2ludC1mcmllbmRseSBhbHRlcm5hdGl2ZXMgdG8gdGhlIHJvdXRpbmUuXCJ9PC9zbWFsbD48L3NwYW4+PC9DdXN0b21DaGVja2JveD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+fVxyXG5cclxuICAgICAge2dlbmVyYXRvclN0YXRlID09PSBcImxvYWRpbmdcIiAmJiA8ZGl2IGNsYXNzTmFtZT1cImdlbmVyYXRvci1sb2FkaW5nXCIgYXJpYS1saXZlPVwicG9saXRlXCI+PHNwYW4gY2xhc3NOYW1lPVwiZW1lcmFsZC1wdWxzZVwiPjxJY29uIG5hbWU9XCJzcGFya1wiIC8+PC9zcGFuPjxzdHJvbmc+e2xvYWRpbmdDb3B5W2xvYWRpbmdNZXNzYWdlXX08L3N0cm9uZz48ZGl2IGNsYXNzTmFtZT1cImdlbmVyYXRvci1za2VsZXRvblwiPntbMCwgMSwgMl0ubWFwKChpdGVtKSA9PiA8ZGl2IGtleT17aXRlbX0+PGkgLz48c3Bhbj48aSAvPjxpIC8+PC9zcGFuPjwvZGl2Pil9PC9kaXY+PC9kaXY+fVxyXG5cclxuICAgICAge2dlbmVyYXRvclN0YXRlID09PSBcInJlc3VsdFwiICYmIHJlc3VsdCAmJiA8ZGl2IGNsYXNzTmFtZT1cImdlbmVyYXRvci1yZXN1bHRcIj5cclxuICAgICAgICA8aGVhZGVyPjxkaXY+PHNtYWxsPllPVVIgR0VORVJBVEVEIFJPVVRJTkU8L3NtYWxsPjxoMj57cmVzdWx0Lm5hbWV9PC9oMj48cD57cmVzdWx0Lm1pbnV0ZXN9IG1pbiDCtyB7cmVzdWx0LmVxdWlwbWVudH08L3A+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJ0YXJnZXQtY2hpcHNcIj57cmVzdWx0LnRhcmdldFRhZ3MubWFwKCh0YWcpID0+IDxpIGtleT17dGFnfT57dGFnfTwvaT4pfTwvZGl2PjwvaGVhZGVyPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2VuZXJhdGVkLWV4ZXJjaXNlc1wiPntyZXN1bHQuZXhlcmNpc2VzLm1hcCgoZXhlcmNpc2UsIGluZGV4KSA9PiA8YXJ0aWNsZSBrZXk9e2Ake2V4ZXJjaXNlLm5hbWV9LSR7aW5kZXh9YH0+PHNwYW4gY2xhc3NOYW1lPVwiZHVtYmJlbGwtaWNvblwiPjxJY29uIG5hbWU9XCJkdW1iYmVsbFwiIC8+PC9zcGFuPjxkaXY+PHN0cm9uZz57ZXhlcmNpc2UubmFtZX08L3N0cm9uZz48c21hbGw+e2V4ZXJjaXNlLnByZXNjcmlwdGlvbn08L3NtYWxsPjwvZGl2PjxpPntyZXN1bHQudGFyZ2V0VGFnc1tpbmRleCAlIHJlc3VsdC50YXJnZXRUYWdzLmxlbmd0aF19PC9pPjwvYXJ0aWNsZT4pfTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2h5LXBsYW5cIj48c3Bhbj48SWNvbiBuYW1lPVwic3BhcmtcIiAvPjwvc3Bhbj48ZGl2PjxzdHJvbmc+V2h5IHRoaXMgcGxhbjwvc3Ryb25nPjx1bD48bGk+e2VxdWlwbWVudCA9PT0gXCJCb2R5d2VpZ2h0IC8gSG9tZVwiID8gXCJCb2R5d2VpZ2h0LWZvY3VzZWQsIHNpbmNlIHRoYXQncyB5b3VyIHNlbGVjdGVkIGVxdWlwbWVudC5cIiA6IGAke2VxdWlwbWVudH0gbW92ZW1lbnRzIG1hdGNoIHRoZSBzZXR1cCB5b3Ugc2VsZWN0ZWQuYH08L2xpPjxsaT57bG93SW1wYWN0ID8gXCJMb3ctaW1wYWN0IHN3YXBzIGFyZSBpbmNsdWRlZCBzbyB5b3UgY2FuIGFkanVzdCBhcyBuZWVkZWQuXCIgOiBgJHtlZmZvcnR9IGVmZm9ydCBrZWVwcyB0b2RheSdzIHNlc3Npb24gYWxpZ25lZCB3aXRoIGhvdyB5b3UgZmVlbC5gfTwvbGk+PC91bD48L2Rpdj48L2Rpdj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJnZW5lcmF0b3ItZ3VpZGFuY2VcIj5BSSBzdWdnZXN0aW9ucyBhcmUgZ2VuZXJhbCBmaXRuZXNzIGd1aWRhbmNlLCBub3QgbWVkaWNhbCBhZHZpY2UuPC9wPlxyXG4gICAgICA8L2Rpdj59XHJcblxyXG4gICAgICB7Z2VuZXJhdG9yU3RhdGUgPT09IFwiZXJyb3JcIiAmJiA8ZGl2IGNsYXNzTmFtZT1cImdlbmVyYXRvci1tZXNzYWdlXCI+PHNwYW4+PEljb24gbmFtZT1cInNwYXJrXCIgLz48L3NwYW4+PGgyPkxldCdzIHRyeSB0aGF0IGFnYWluLjwvaDI+PHA+V2UgY291bGRuJ3QgZ2VuZXJhdGUgYSBuZXcgcGxhbi4gWW91ciBjdXJyZW50IHBsYW4gaXMgdW5jaGFuZ2VkIGFuZCBubyBnZW5lcmF0aW9uIHdhcyB1c2VkLjwvcD48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEdlbmVyYXRvclN0YXRlKFwiZm9ybVwiKX0+VHJ5IGFnYWluPC9CdXR0b24+PC9kaXY+fVxyXG5cclxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJnZW5lcmF0b3ItYWN0aW9uc1wiPlxyXG4gICAgICAgIHtnZW5lcmF0b3JTdGF0ZSA9PT0gXCJmb3JtXCIgJiYgPD48QnV0dG9uIG9uQ2xpY2s9e3N0YXJ0R2VuZXJhdGlvbn0gZGlzYWJsZWQ9eyF2YWxpZCB8fCAhcmVtYWluaW5nfT5HZW5lcmF0ZSByb3V0aW5lPC9CdXR0b24+PHNtYWxsPkFJIGdlbmVyYXRpb24gaXMgbGltaXRlZCwgdXNlIHdpc2VseS48L3NtYWxsPnshcmVtYWluaW5nICYmIDxwIGNsYXNzTmFtZT1cImxpbWl0LW1lc3NhZ2VcIj5Zb3UndmUgdXNlZCBhbGwgMyBnZW5lcmF0aW9ucyB0aGlzIHdlZWsuIFRoZXkgcmVzZXQgb24ge3ByZXR0eURhdGUocmVzZXREYXRlKX0uIEluIHRoZSBtZWFudGltZSwgc3dhcCBleGVyY2lzZXMgaW4gPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi93b3Jrb3V0c1wiKX0+TXkgd29ya291dHM8L2J1dHRvbj4uPC9wPn08Lz59XHJcbiAgICAgICAge2dlbmVyYXRvclN0YXRlID09PSBcInJlc3VsdFwiICYmIHJlc3VsdCAmJiA8PjxkaXYgY2xhc3NOYW1lPVwic2NoZWR1bGUtYWN0aW9uXCI+PGxhYmVsPkFkZCB0byBteSBwbGFuPGlucHV0IHR5cGU9XCJkYXRlXCIgbWluPXtkYXRlS2V5KG5ldyBEYXRlKCkpfSB2YWx1ZT17c2NoZWR1bGVEYXRlfSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRTY2hlZHVsZURhdGUoZXZlbnQudGFyZ2V0LnZhbHVlKX0gLz48L2xhYmVsPjxCdXR0b24gb25DbGljaz17KCkgPT4gYWRkVG9QbGFuKGZhbHNlKX0+QWRkIHRvIG15IHBsYW48L0J1dHRvbj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInJlc3VsdC1hY3Rpb25zXCI+PEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBhZGRUb1BsYW4odHJ1ZSl9PlNhdmUgdG8gTXkgd29ya291dHM8L0J1dHRvbj48QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1SZWdlbmVyYXRlKHRydWUpfSBkaXNhYmxlZD17IXJlbWFpbmluZ30+UmVnZW5lcmF0ZTwvQnV0dG9uPjxidXR0b24gb25DbGljaz17ZGlzY2FyZH0+RGlzY2FyZDwvYnV0dG9uPjwvZGl2Pntjb25maXJtUmVnZW5lcmF0ZSAmJiA8ZGl2IGNsYXNzTmFtZT1cInJlZ2VuZXJhdGUtY29uZmlybVwiPjxwPlJlZ2VuZXJhdGluZyB1c2VzIGFub3RoZXIgb2YgeW91ciB3ZWVrbHkgZ2VuZXJhdGlvbnMuPC9wPjxidXR0b24gb25DbGljaz17KCkgPT4gc2V0Q29uZmlybVJlZ2VuZXJhdGUoZmFsc2UpfT5DYW5jZWw8L2J1dHRvbj48QnV0dG9uIG9uQ2xpY2s9e3N0YXJ0R2VuZXJhdGlvbn0+VXNlIDEgZ2VuZXJhdGlvbjwvQnV0dG9uPjwvZGl2Pn08Lz59XHJcbiAgICAgIDwvZm9vdGVyPlxyXG4gICAgPC9hcnRpY2xlPlxyXG4gIDwvPjtcclxufVxyXG4iXX0=