import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/InfoTip.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/InfoTip.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function InfoTip({ term, definition, onLearnMore, actionLabel = "Learn more", showTerm = true }) {
	_s();
	const [open, setOpen] = useState(false);
	useEffect(() => {
		if (!open) return;
		const closeOnEscape = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", closeOnEscape);
		return () => window.removeEventListener("keydown", closeOnEscape);
	}, [open]);
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `info-tip ${open ? "open" : ""}`,
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-label": `About ${term}`,
			"aria-expanded": open,
			onClick: () => setOpen((current) => !current),
			children: "ⓘ"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "term-tooltip",
			role: "tooltip",
			children: [
				showTerm && /* @__PURE__ */ _jsxDEV("strong", { children: term }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 22
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { children: definition }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => {
						setOpen(false);
						onLearnMore();
					},
					children: actionLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_s(InfoTip, "TyYZn/6rl864qCDCSHPfcighv0g=");
_c = InfoTip;
var _c;
$RefreshReg$(_c, "InfoTip");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/InfoTip.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/InfoTip.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/InfoTip.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/InfoTip.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjs7OztBQUVwQyxPQUFPLFNBQVMsUUFBUSxFQUN0QixNQUNBLFlBQ0EsYUFDQSxjQUFjLGNBQ2QsV0FBVyxRQU9WOztDQUNELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBRXRDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxpQkFBaUIsVUFBeUI7R0FDOUMsSUFBSSxNQUFNLFFBQVEsVUFBVSxRQUFRLEtBQUs7RUFDM0M7RUFDQSxPQUFPLGlCQUFpQixXQUFXLGFBQWE7RUFDaEQsYUFBYSxPQUFPLG9CQUFvQixXQUFXLGFBQWE7Q0FDbEUsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVcsWUFBWSxPQUFPLFNBQVM7WUFBN0MsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsTUFBSztHQUFTLGNBQVksU0FBUztHQUFRLGlCQUFlO0dBQU0sZUFBZSxTQUFTLFlBQVksQ0FBQyxPQUFPO2FBQUc7RUFBUzs7OztZQUNoSSx3QkFBQyxRQUFEO0dBQU0sV0FBVTtHQUFlLE1BQUs7YUFBcEM7SUFDRyxZQUFZLHdCQUFDLFVBQUQsWUFBUyxLQUFhOzs7OztJQUNuQyx3QkFBQyxRQUFELFlBQU8sV0FBaUI7Ozs7O0lBQ3hCLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsZUFBZTtNQUNuQyxRQUFRLEtBQUs7TUFDYixZQUFZO0tBQ2Q7ZUFBSTtJQUFvQjs7Ozs7R0FDcEI7Ozs7O1VBQ0Y7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkluZm9UaXAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBJbmZvVGlwKHtcclxuICB0ZXJtLFxyXG4gIGRlZmluaXRpb24sXHJcbiAgb25MZWFybk1vcmUsXHJcbiAgYWN0aW9uTGFiZWwgPSBcIkxlYXJuIG1vcmVcIixcclxuICBzaG93VGVybSA9IHRydWUsXHJcbn06IHtcclxuICB0ZXJtOiBzdHJpbmc7XHJcbiAgZGVmaW5pdGlvbjogc3RyaW5nO1xyXG4gIG9uTGVhcm5Nb3JlOiAoKSA9PiB2b2lkO1xyXG4gIGFjdGlvbkxhYmVsPzogc3RyaW5nO1xyXG4gIHNob3dUZXJtPzogYm9vbGVhbjtcclxufSkge1xyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghb3BlbikgcmV0dXJuO1xyXG4gICAgY29uc3QgY2xvc2VPbkVzY2FwZSA9IChldmVudDogS2V5Ym9hcmRFdmVudCkgPT4ge1xyXG4gICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkVzY2FwZVwiKSBzZXRPcGVuKGZhbHNlKTtcclxuICAgIH07XHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgY2xvc2VPbkVzY2FwZSk7XHJcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGNsb3NlT25Fc2NhcGUpO1xyXG4gIH0sIFtvcGVuXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmZvLXRpcCAke29wZW4gPyBcIm9wZW5cIiA6IFwiXCJ9YH0+XHJcbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9e2BBYm91dCAke3Rlcm19YH0gYXJpYS1leHBhbmRlZD17b3Blbn0gb25DbGljaz17KCkgPT4gc2V0T3BlbigoY3VycmVudCkgPT4gIWN1cnJlbnQpfT7ik5g8L2J1dHRvbj5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGVybS10b29sdGlwXCIgcm9sZT1cInRvb2x0aXBcIj5cclxuICAgICAgICB7c2hvd1Rlcm0gJiYgPHN0cm9uZz57dGVybX08L3N0cm9uZz59XHJcbiAgICAgICAgPHNwYW4+e2RlZmluaXRpb259PC9zcGFuPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgIHNldE9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgb25MZWFybk1vcmUoKTtcclxuICAgICAgICB9fT57YWN0aW9uTGFiZWx9PC9idXR0b24+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59XHJcbiJdfQ==