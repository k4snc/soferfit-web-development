import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/pages/ProgressPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b6534b64";
import { Button } from "/src/frontend/components/Button.tsx";
import { EmptyState } from "/src/frontend/components/EmptyState.tsx";
import { Icon } from "/src/frontend/components/Icon.tsx";
import { PageHeader } from "/src/frontend/components/PageHeader.tsx";
import { dateKey, prettyDate } from "/src/frontend/lib/format.ts";
var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProgressPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
var _s = $RefreshSig$();
export function ProgressPage({ store, update, toast }) {
	_s();
	const [tab, setTab] = useState("overview");
	const [showWeight, setShowWeight] = useState(false);
	const [editingWeight, setEditingWeight] = useState(null);
	const [weightForm, setWeightForm] = useState({
		date: dateKey(new Date()),
		weight: "",
		waist: "",
		hips: "",
		chest: ""
	});
	const [weightError, setWeightError] = useState("");
	const [showPhoto, setShowPhoto] = useState(false);
	const [photoForm, setPhotoForm] = useState({
		date: dateKey(new Date()),
		angle: "Front",
		image: ""
	});
	const [photoError, setPhotoError] = useState("");
	const [compareMode, setCompareMode] = useState(false);
	const [beforeIndex, setBeforeIndex] = useState(0);
	const [afterIndex, setAfterIndex] = useState(Math.max(0, store.photos.length - 1));
	const [comparePosition, setComparePosition] = useState(50);
	const [selectedBadge, setSelectedBadge] = useState(null);
	const unit = store.user.unitSystem === "metric" ? "kg" : "lb";
	const measurementUnit = store.user.unitSystem === "metric" ? "cm" : "in";
	const sortedWeights = store.weights.map((entry, index) => ({
		...entry,
		sourceIndex: index
	})).sort((a, b) => a.date.localeCompare(b.date));
	const startWeight = sortedWeights[0]?.weight;
	const currentWeight = sortedWeights.at(-1)?.weight;
	const targetWeight = Number(store.user.targetWeight) || undefined;
	const targetProgress = startWeight !== undefined && currentWeight !== undefined && targetWeight !== undefined && startWeight !== targetWeight ? Math.max(0, Math.min(100, Math.round((startWeight - currentWeight) / (startWeight - targetWeight) * 100))) : 0;
	const activeMinutes = store.sessions.reduce((sum, session) => sum + session.duration, 0);
	const sessionDates = Array.from(new Set(store.sessions.map((session) => session.date))).sort();
	let bestStreak = 0;
	let runningStreak = 0;
	sessionDates.forEach((date, index) => {
		const previous = index ? new Date(`${sessionDates[index - 1]}T12:00:00`) : null;
		const current = new Date(`${date}T12:00:00`);
		runningStreak = previous && Math.round((current.getTime() - previous.getTime()) / 864e5) === 1 ? runningStreak + 1 : 1;
		bestStreak = Math.max(bestStreak, runningStreak);
	});
	let currentStreak = 0;
	const completedDateSet = new Set(sessionDates);
	const streakCursor = new Date();
	while (completedDateSet.has(dateKey(streakCursor))) {
		currentStreak += 1;
		streakCursor.setDate(streakCursor.getDate() - 1);
	}
	const challengeStart = new Date(`${store.challenge.startDate}T12:00:00`);
	const challengeDay = Math.max(1, Math.min(store.challenge.length, Math.floor((Date.now() - challengeStart.getTime()) / 864e5) + 1));
	const currentWeek = Math.floor((challengeDay - 1) / 7);
	const weeklyCounts = Array.from({ length: Math.min(8, Math.ceil(store.challenge.length / 7)) }, (_, displayIndex) => {
		const weekIndex = Math.max(0, currentWeek - 3) + displayIndex;
		return {
			week: weekIndex,
			count: store.sessions.filter((session) => Math.floor((new Date(`${session.date}T12:00:00`).getTime() - challengeStart.getTime()) / (7 * 864e5)) === weekIndex).length
		};
	}).filter((item) => item.week < Math.ceil(store.challenge.length / 7));
	const maxWeekly = Math.max(store.challenge.daysPerWeek, ...weeklyCounts.map((item) => item.count));
	const fastChange = (() => {
		if (!weightForm.weight || !sortedWeights.length) return false;
		const previous = sortedWeights.at(-1);
		const days = Math.max(1, Math.abs((new Date(`${weightForm.date}T12:00:00`).getTime() - new Date(`${previous.date}T12:00:00`).getTime()) / 864e5));
		const changeKg = Math.abs(Number(weightForm.weight) - previous.weight) * (store.user.unitSystem === "metric" ? 1 : .453592);
		return changeKg / days * 7 > 1;
	})();
	const unlockTrackingBadge = (id, badges = store.badges) => badges.map((badge) => badge.id === id ? {
		...badge,
		unlocked: true,
		date: badge.date || dateKey(new Date())
	} : badge);
	const openWeightModal = (entryIndex) => {
		if (entryIndex === undefined) {
			setEditingWeight(null);
			setWeightForm({
				date: dateKey(new Date()),
				weight: "",
				waist: "",
				hips: "",
				chest: ""
			});
		} else {
			const entry = store.weights[entryIndex];
			setEditingWeight(entryIndex);
			setWeightForm({
				date: entry.date,
				weight: String(entry.weight),
				waist: String(entry.measurements?.waist ?? ""),
				hips: String(entry.measurements?.hips ?? ""),
				chest: String(entry.measurements?.chest ?? "")
			});
		}
		setWeightError("");
		setShowWeight(true);
	};
	const saveWeight = () => {
		const weight = Number(weightForm.weight);
		const minWeight = store.user.unitSystem === "metric" ? 25 : 55;
		const maxWeight = store.user.unitSystem === "metric" ? 400 : 880;
		const measurements = [
			weightForm.waist,
			weightForm.hips,
			weightForm.chest
		].filter(Boolean).map(Number);
		const minMeasurement = store.user.unitSystem === "metric" ? 30 : 12;
		const maxMeasurement = store.user.unitSystem === "metric" ? 300 : 120;
		if (!weightForm.date || !weight || weight < minWeight || weight > maxWeight || measurements.some((value) => value < minMeasurement || value > maxMeasurement)) {
			setWeightError(`Use ${minWeight}–${maxWeight} ${unit} and ${minMeasurement}–${maxMeasurement} ${measurementUnit} for measurements.`);
			return;
		}
		const entry = {
			date: weightForm.date,
			weight,
			measurements: {
				waist: weightForm.waist ? Number(weightForm.waist) : undefined,
				hips: weightForm.hips ? Number(weightForm.hips) : undefined,
				chest: weightForm.chest ? Number(weightForm.chest) : undefined
			}
		};
		const weights = editingWeight === null ? [...store.weights, entry] : store.weights.map((item, index) => index === editingWeight ? entry : item);
		if (!update({
			...store,
			weights,
			user: {
				...store.user,
				weight: String(weight)
			},
			badges: unlockTrackingBadge("weight-1")
		})) return;
		setShowWeight(false);
		toast(editingWeight === null ? "Weight entry saved." : "Weight entry updated.");
	};
	const choosePhoto = (file) => {
		setPhotoError("");
		if (!file) return;
		if (![
			"image/jpeg",
			"image/png",
			"image/webp"
		].includes(file.type)) return setPhotoError("Choose a JPG, PNG, or WebP image.");
		if (file.size > 5 * 1024 * 1024) return setPhotoError("Choose an image smaller than 5 MB.");
		const reader = new FileReader();
		reader.onload = () => {
			const image = new Image();
			image.onload = () => {
				const scale = Math.min(1, 1600 / Math.max(image.width, image.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(image.width * scale));
				canvas.height = Math.max(1, Math.round(image.height * scale));
				const context = canvas.getContext("2d");
				if (!context) return setPhotoError("We couldn't prepare that image. Please try another.");
				context.drawImage(image, 0, 0, canvas.width, canvas.height);
				setPhotoForm((current) => ({
					...current,
					image: canvas.toDataURL("image/webp", .82)
				}));
			};
			image.onerror = () => setPhotoError("We couldn't preview that image. Please try another.");
			image.src = String(reader.result);
		};
		reader.onerror = () => setPhotoError("We couldn't read that image. Please try another.");
		reader.readAsDataURL(file);
	};
	const savePhoto = () => {
		if (!photoForm.image || !photoForm.date) return setPhotoError("Choose an image and date.");
		const photos = [...store.photos, photoForm].sort((a, b) => a.date.localeCompare(b.date));
		if (!update({
			...store,
			photos,
			badges: unlockTrackingBadge("photo-1")
		})) return;
		setAfterIndex(photos.length - 1);
		setShowPhoto(false);
		setPhotoForm({
			date: dateKey(new Date()),
			angle: "Front",
			image: ""
		});
		toast("Progress photo added.");
	};
	const chartValues = sortedWeights.map((entry) => entry.weight);
	const chartBounds = [...chartValues, ...targetWeight ? [targetWeight] : []];
	const chartMin = chartBounds.length ? Math.min(...chartBounds) - 2 : 0;
	const chartMax = chartBounds.length ? Math.max(...chartBounds) + 2 : 1;
	const chartPoint = (value, index) => ({
		x: sortedWeights.length === 1 ? 40 : 40 + index / (sortedWeights.length - 1) * 560,
		y: 190 - (value - chartMin) / Math.max(1, chartMax - chartMin) * 150
	});
	const points = sortedWeights.map((entry, index) => chartPoint(entry.weight, index));
	const badgeCatalog = [
		{
			category: "Streaks",
			id: "streak-3",
			name: "3-day streak",
			target: 3,
			value: bestStreak,
			detail: "Complete a workout on 3 consecutive days."
		},
		{
			category: "Streaks",
			id: "streak-7",
			name: "7-day streak",
			target: 7,
			value: bestStreak,
			detail: "Complete a workout on 7 consecutive days."
		},
		{
			category: "Streaks",
			id: "streak-14",
			name: "14-day streak",
			target: 14,
			value: bestStreak,
			detail: "Complete a workout on 14 consecutive days."
		},
		{
			category: "Streaks",
			id: "streak-30",
			name: "30-day streak",
			target: 30,
			value: bestStreak,
			detail: "Build a consistent 30-day workout streak."
		},
		{
			category: "Workouts",
			id: "workout-1",
			name: "First workout",
			target: 1,
			value: store.sessions.length,
			detail: "Finish and save your first workout."
		},
		{
			category: "Workouts",
			id: "workout-10",
			name: "10 workouts",
			target: 10,
			value: store.sessions.length,
			detail: "Finish 10 workout sessions."
		},
		{
			category: "Workouts",
			id: "workout-25",
			name: "25 workouts",
			target: 25,
			value: store.sessions.length,
			detail: "Finish 25 workout sessions."
		},
		{
			category: "Workouts",
			id: "workout-50",
			name: "50 workouts",
			target: 50,
			value: store.sessions.length,
			detail: "Finish 50 workout sessions."
		},
		{
			category: "Challenge milestones",
			id: "week-1",
			name: "Week 1 done",
			target: store.challenge.daysPerWeek,
			value: store.sessions.filter((session) => new Date(`${session.date}T12:00:00`).getTime() < challengeStart.getTime() + 7 * 864e5).length,
			detail: "Complete your planned sessions in the first week."
		},
		{
			category: "Challenge milestones",
			id: "halfway",
			name: "Halfway",
			target: Math.ceil(store.challenge.length / 2),
			value: challengeDay,
			detail: "Reach the halfway point of your challenge."
		},
		{
			category: "Challenge milestones",
			id: "finish",
			name: "Finish line",
			target: store.challenge.length,
			value: challengeDay,
			detail: "Reach the final day of your challenge."
		},
		{
			category: "Tracking",
			id: "weight-1",
			name: "First weigh-in",
			target: 1,
			value: store.weights.length,
			detail: "Save your first weight entry."
		},
		{
			category: "Tracking",
			id: "photo-1",
			name: "First photo",
			target: 1,
			value: store.photos.length,
			detail: "Add your first private progress photo."
		}
	];
	const nextBadge = badgeCatalog.find((badge) => badge.value < badge.target);
	const selectedBadgeData = badgeCatalog.find((badge) => badge.id === selectedBadge);
	const photoGroups = store.photos.reduce((groups, photo, index) => {
		const week = Math.max(1, Math.floor((new Date(`${photo.date}T12:00:00`).getTime() - challengeStart.getTime()) / (7 * 864e5)) + 1);
		const key = `Week ${week}`;
		groups[key] = [...groups[key] || [], {
			photo,
			index
		}];
		return groups;
	}, {});
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(PageHeader, {
			eyebrow: "YOUR TRANSFORMATION",
			title: "Progress"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 174,
			columnNumber: 12
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "workout-tabs progress-tabs",
			role: "tablist",
			"aria-label": "Progress views",
			children: [
				["overview", "Overview"],
				["body", "Body"],
				["photos", "Photos"],
				["badges", "Badges"]
			].map(([value, label]) => /* @__PURE__ */ _jsxDEV("button", {
				role: "tab",
				"aria-selected": tab === value,
				className: tab === value ? "active" : "",
				onClick: () => setTab(value),
				children: label
			}, value, false, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 206
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 175,
			columnNumber: 5
		}, this),
		tab === "overview" && /* @__PURE__ */ _jsxDEV("div", {
			className: "progress-overview",
			children: [
				/* @__PURE__ */ _jsxDEV("article", {
					className: "progress-hero",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "target-ring",
						style: { "--target-progress": `${targetProgress * 3.6}deg` },
						children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: [targetProgress, "%"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 128
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "TARGET PROGRESS" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 162
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 123
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 9
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("small", { children: "PHYSICAL PROGRESS" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 14
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: store.weights.length ? "Your trend, at a glance." : "Start with one simple check-in." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 46
						}, this),
						store.weights.length ? /* @__PURE__ */ _jsxDEV("p", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: [
								startWeight,
								" ",
								unit
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 169
							}, this),
							/* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 206
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: [
								currentWeight,
								" ",
								unit
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 227
							}, this),
							/* @__PURE__ */ _jsxDEV(Icon, { name: "arrow" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 266
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: targetWeight ? `${targetWeight} ${unit}` : "Set target" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 287
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 166
						}, this) : /* @__PURE__ */ _jsxDEV("p", { children: "Log your starting weight to begin." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 368
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							onClick: () => {
								setTab("body");
								openWeightModal();
							},
							children: store.weights.length ? "Log weight" : "Add starting weight"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 410
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 9
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 178,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "progress-stat-grid",
					children: [
						[
							"check",
							"WORKOUTS COMPLETED",
							String(store.sessions.length)
						],
						[
							"timer",
							"ACTIVE TIME",
							activeMinutes < 60 ? `${activeMinutes}m` : `${(activeMinutes / 60).toFixed(1)}h`
						],
						[
							"flame",
							"CURRENT STREAK",
							`${currentStreak} ${currentStreak === 1 ? "day" : "days"}`
						],
						[
							"star",
							"BEST STREAK",
							`${bestStreak} ${bestStreak === 1 ? "day" : "days"}`
						]
					].map(([icon, label, value]) => /* @__PURE__ */ _jsxDEV("article", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "dash-stat-icon",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: icon }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 435
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 402
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 502
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: value }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 524
						}, this)
					] }, label, true, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 381
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("article", {
					className: "consistency-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "panel-head",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "CONSISTENCY" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 78
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: "Workouts by week" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 104
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: store.sessions.length ? `${store.sessions.length} total` : "No sessions yet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 135
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 45
					}, this), store.sessions.length ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("div", {
						className: "consistency-bars",
						children: weeklyCounts.map((item) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("i", {
							className: item.week === currentWeek ? "current" : "",
							style: { height: `${Math.max(8, item.count / maxWeekly * 100)}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 342
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["W", item.week + 1] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 470
						}, this)] }, item.week, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 321
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 259
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 257
					}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
						title: "Your rhythm will appear here",
						copy: "Complete your first workout to start building a weekly consistency view."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 519
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 7
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 28
		}, this),
		tab === "body" && /* @__PURE__ */ _jsxDEV("div", {
			className: "body-progress",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "progress-section-head",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "BODY TRACKING" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 51
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Weight over time" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 79
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 46
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => openWeightModal(),
						children: "Log weight"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 110
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 189,
					columnNumber: 7
				}, this),
				/* @__PURE__ */ _jsxDEV("article", {
					className: "weight-chart-card",
					children: sortedWeights.length ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "weight-chart",
						viewBox: "0 0 640 230",
						role: "img",
						"aria-label": "Weight entries over time",
						children: [
							/* @__PURE__ */ _jsxDEV("line", {
								className: "chart-axis",
								x1: "40",
								y1: "190",
								x2: "600",
								y2: "190"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 173
							}, this),
							targetWeight && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("line", {
								className: "target-line",
								x1: "40",
								y1: chartPoint(targetWeight, 0).y,
								x2: "600",
								y2: chartPoint(targetWeight, 0).y
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 258
							}, this), /* @__PURE__ */ _jsxDEV("text", {
								x: "596",
								y: chartPoint(targetWeight, 0).y - 7,
								textAnchor: "end",
								children: [
									"Target ",
									targetWeight,
									" ",
									unit
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 377
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 256
							}, this),
							/* @__PURE__ */ _jsxDEV("polyline", { points: points.map((point) => `${point.x},${point.y}`).join(" ") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 485
							}, this),
							/* @__PURE__ */ _jsxDEV("circle", {
								className: "start-point",
								cx: points[0].x,
								cy: points[0].y,
								r: "6"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 563
							}, this),
							points.map((point, index) => /* @__PURE__ */ _jsxDEV("circle", {
								cx: point.x,
								cy: point.y,
								r: "5"
							}, index, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 667
							}, this)),
							/* @__PURE__ */ _jsxDEV("text", {
								x: points[0].x,
								y: points[0].y - 12,
								textAnchor: "middle",
								children: "Start"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 723
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 72
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "weight-chart-dates",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: prettyDate(sortedWeights[0].date) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 840
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: prettyDate(sortedWeights.at(-1).date) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 888
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 804
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 70
					}, this) : /* @__PURE__ */ _jsxDEV(EmptyState, {
						title: "No entries yet.",
						copy: "Your first weigh-in becomes your starting point."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 953
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 7
				}, this),
				sortedWeights.length > 0 && /* @__PURE__ */ _jsxDEV("article", {
					className: "weight-entry-list",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "panel-head",
						children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "ENTRIES" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 108
						}, this), /* @__PURE__ */ _jsxDEV("h3", { children: "Your check-ins" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 130
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 103
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 75
					}, this), sortedWeights.slice().reverse().map((entry) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: [
						entry.weight,
						" ",
						unit
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 266
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [prettyDate(entry.date), entry.measurements && Object.values(entry.measurements).some(Boolean) ? ` · Measurements added` : ""] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 304
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 261
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => openWeightModal(entry.sourceIndex),
						children: "Edit"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 454
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							update({
								...store,
								weights: store.weights.filter((_, index) => index !== entry.sourceIndex)
							});
							toast("Weight entry deleted.");
						},
						children: "Delete"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 526
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 449
					}, this)] }, `${entry.date}-${entry.sourceIndex}`, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 213
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 36
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 188,
			columnNumber: 24
		}, this),
		tab === "photos" && /* @__PURE__ */ _jsxDEV("div", {
			className: "photos-progress",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "progress-section-head",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("small", { children: "PHOTO LOG" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 51
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: "Progress photos" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 75
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Your photos are private and only visible to you." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 99
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 46
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [store.photos.length >= 2 && /* @__PURE__ */ _jsxDEV(Button, {
					variant: "ghost",
					onClick: () => setCompareMode((value) => !value),
					children: compareMode ? "View gallery" : "Compare"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 194
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					onClick: () => {
						setPhotoError("");
						setShowPhoto(true);
					},
					children: "Add progress photo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 320
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 160
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 7
			}, this), compareMode && store.photos.length >= 2 ? /* @__PURE__ */ _jsxDEV("article", {
				className: "photo-compare",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "compare-pickers",
						children: [/* @__PURE__ */ _jsxDEV("label", { children: ["Before", /* @__PURE__ */ _jsxDEV("select", {
							value: beforeIndex,
							onChange: (event) => setBeforeIndex(Number(event.target.value)),
							children: store.photos.map((photo, index) => /* @__PURE__ */ _jsxDEV("option", {
								value: index,
								children: [
									prettyDate(photo.date),
									" · ",
									photo.angle || "Front"
								]
							}, `${photo.date}-${index}`, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 260
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 131
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 118
						}, this), /* @__PURE__ */ _jsxDEV("label", { children: ["After", /* @__PURE__ */ _jsxDEV("select", {
							value: afterIndex,
							onChange: (event) => setAfterIndex(Number(event.target.value)),
							children: store.photos.map((photo, index) => /* @__PURE__ */ _jsxDEV("option", {
								value: index,
								children: [
									prettyDate(photo.date),
									" · ",
									photo.angle || "Front"
								]
							}, `${photo.date}-${index}`, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 531
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 404
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 392
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 85
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "compare-stage",
						style: { "--compare-position": `${comparePosition}%` },
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: store.photos[beforeIndex]?.image,
								alt: `Progress on ${prettyDate(store.photos[beforeIndex]?.date)}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 779
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("img", {
								src: store.photos[afterIndex]?.image,
								alt: `Progress on ${prettyDate(store.photos[afterIndex]?.date)}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 897
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 892
							}, this),
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 1014
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 669
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "compare-slider",
						children: ["Drag to compare", /* @__PURE__ */ _jsxDEV("input", {
							type: "range",
							min: "0",
							max: "100",
							value: comparePosition,
							onChange: (event) => setComparePosition(Number(event.target.value))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 1074
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 1025
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 50
			}, this) : store.photos.length ? /* @__PURE__ */ _jsxDEV("div", {
				className: "photo-weeks",
				children: Object.entries(photoGroups).map(([week, photos]) => /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: week }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 135
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: photos.map(({ photo, index }) => /* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("img", {
					src: photo.image,
					alt: `${photo.angle || "Front"} progress view from ${prettyDate(photo.date)}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 229
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: photo.angle || "Front" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 344
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: prettyDate(photo.date) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 385
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 338
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						update({
							...store,
							photos: store.photos.filter((_, photoIndex) => photoIndex !== index)
						});
						toast("Photo deleted.");
					},
					children: "Delete"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 431
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 333
				}, this)] }, `${photo.date}-${index}`, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 189
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 150
				}, this)] }, week, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 115
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 33
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "photo-empty",
				children: [
					/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "camera" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 48
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 42
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Take your Day 1 photo" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 77
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "A private photo can help you notice changes that numbers may not capture." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 107
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setShowPhoto(true),
						children: "Add progress photo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 187
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 198,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 26
		}, this),
		tab === "badges" && /* @__PURE__ */ _jsxDEV("div", {
			className: "badges-progress",
			children: [
				/* @__PURE__ */ _jsxDEV("article", {
					className: "badge-summary",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "badge-flame",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "flame" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 72
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 42
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "CURRENT STREAK" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 105
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
							currentStreak,
							" ",
							currentStreak === 1 ? "day" : "days"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 134
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 100
						}, this),
						nextBadge && /* @__PURE__ */ _jsxDEV("div", {
							className: "next-badge",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: ["Next: ", /* @__PURE__ */ _jsxDEV("strong", { children: nextBadge.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 265
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 253
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("i", { style: { width: `${Math.min(100, nextBadge.value / nextBadge.target * 100)}%` } }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 310
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 305
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: [
									Math.min(nextBadge.value, nextBadge.target),
									"/",
									nextBadge.target
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 402
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 225
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 7
				}, this),
				[
					"Streaks",
					"Workouts",
					"Challenge milestones",
					"Tracking"
				].map((category) => /* @__PURE__ */ _jsxDEV("section", {
					className: "badge-category",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: category }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 203,
						columnNumber: 137
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: badgeCatalog.filter((badge) => badge.category === category).map((badge) => {
						const storedBadge = store.badges.find((item) => item.id === badge.id);
						const unlocked = Boolean(storedBadge?.unlocked || badge.value >= badge.target);
						return /* @__PURE__ */ _jsxDEV("button", {
							className: unlocked ? "unlocked" : "",
							onClick: () => setSelectedBadge(badge.id),
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: unlocked ? "star" : "bolt" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 127
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 121
								}, this),
								/* @__PURE__ */ _jsxDEV("strong", { children: badge.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 176
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: unlocked ? `Unlocked ${storedBadge?.date ? prettyDate(storedBadge.date) : "today"}` : `${Math.min(badge.value, badge.target)}/${badge.target}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 205
								}, this)
							]
						}, badge.id, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 16
						}, this);
					}) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 203,
						columnNumber: 156
					}, this)]
				}, category, true, {
					fileName: _jsxFileName,
					lineNumber: 203,
					columnNumber: 86
				}, this)),
				selectedBadgeData && /* @__PURE__ */ _jsxDEV("div", {
					className: "badge-detail",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedBadge(null),
							"aria-label": "Close badge detail",
							children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 138
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 59
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: /* @__PURE__ */ _jsxDEV(Icon, { name: "star" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 174
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 168
						}, this),
						/* @__PURE__ */ _jsxDEV("small", { children: selectedBadgeData.category }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 201
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", { children: selectedBadgeData.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 244
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: selectedBadgeData.detail }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 277
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: [
							Math.min(selectedBadgeData.value, selectedBadgeData.target),
							"/",
							selectedBadgeData.target,
							" complete"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 310
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 208,
					columnNumber: 29
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 201,
			columnNumber: 26
		}, this),
		showWeight && /* @__PURE__ */ _jsxDEV("div", {
			className: "progress-modal-backdrop",
			onMouseDown: () => setShowWeight(false),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "progress-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": "Log weight",
				onMouseDown: (event) => event.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "BODY CHECK-IN" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 252
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: editingWeight === null ? "Log weight" : "Edit entry" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 280
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 247
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowWeight(false),
						"aria-label": "Close",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 413
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 349
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 239
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "progress-form",
						children: [
							/* @__PURE__ */ _jsxDEV("label", { children: ["Date", /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								value: weightForm.date,
								onChange: (event) => setWeightForm({
									...weightForm,
									date: event.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 494
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 483
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: [
								"Weight (",
								unit,
								")",
								/* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									step: ".1",
									value: weightForm.weight,
									onChange: (event) => {
										setWeightForm({
											...weightForm,
											weight: event.target.value
										});
										setWeightError("");
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 650
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 628
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: ["OPTIONAL MEASUREMENTS · ", measurementUnit.toUpperCase()] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 825
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Waist", /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								step: ".1",
								value: weightForm.waist,
								onChange: (event) => setWeightForm({
									...weightForm,
									waist: event.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 905
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 893
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Hips", /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								step: ".1",
								value: weightForm.hips,
								onChange: (event) => setWeightForm({
									...weightForm,
									hips: event.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 1064
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 1053
							}, this),
							/* @__PURE__ */ _jsxDEV("label", { children: ["Chest", /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								step: ".1",
								value: weightForm.chest,
								onChange: (event) => setWeightForm({
									...weightForm,
									chest: event.target.value
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 1222
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 1210
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 452
					}, this),
					fastChange && /* @__PURE__ */ _jsxDEV("p", {
						className: "gentle-note",
						children: "That's a fast change. Gradual progress is safer; we'll keep your plan paced."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 1391
					}, this),
					weightError && /* @__PURE__ */ _jsxDEV("p", {
						className: "inline-validation",
						children: weightError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 1515
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: saveWeight,
						children: "Save entry"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 1566
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 102
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 211,
			columnNumber: 20
		}, this),
		showPhoto && /* @__PURE__ */ _jsxDEV("div", {
			className: "progress-modal-backdrop",
			onMouseDown: () => setShowPhoto(false),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "progress-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": "Add progress photo",
				onMouseDown: (event) => event.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("header", { children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("small", { children: "PRIVATE PHOTO LOG" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 258
					}, this), /* @__PURE__ */ _jsxDEV("h2", { children: "Add progress photo" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 290
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 253
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowPhoto(false),
						"aria-label": "Close",
						children: /* @__PURE__ */ _jsxDEV(Icon, { name: "close" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 386
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 323
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 245
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "photo-upload",
						children: [photoForm.image ? /* @__PURE__ */ _jsxDEV("img", {
							src: photoForm.image,
							alt: "Selected progress preview"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 476
						}, this) : /* @__PURE__ */ _jsxDEV("span", { children: [
							/* @__PURE__ */ _jsxDEV(Icon, { name: "camera" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 546
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", { children: "Choose a photo" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 568
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: "JPG, PNG or WebP · max 5 MB" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 599
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 540
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "file",
							accept: ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp",
							onChange: (event) => choosePhoto(event.target.files?.[0])
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 649
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 425
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "progress-form photo-meta",
						children: [/* @__PURE__ */ _jsxDEV("label", { children: ["Date", /* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							value: photoForm.date,
							onChange: (event) => setPhotoForm({
								...photoForm,
								date: event.target.value
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 853
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 842
						}, this), /* @__PURE__ */ _jsxDEV("label", { children: ["Angle", /* @__PURE__ */ _jsxDEV("select", {
							value: photoForm.angle,
							onChange: (event) => setPhotoForm({
								...photoForm,
								angle: event.target.value
							}),
							children: [
								/* @__PURE__ */ _jsxDEV("option", { children: "Front" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 1137
								}, this),
								/* @__PURE__ */ _jsxDEV("option", { children: "Side" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 1159
								}, this),
								/* @__PURE__ */ _jsxDEV("option", { children: "Back" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 1180
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 996
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 984
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 800
					}, this),
					photoError && /* @__PURE__ */ _jsxDEV("p", {
						className: "inline-validation",
						children: photoError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 1239
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: savePhoto,
						children: "Save photo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 1289
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "privacy-line",
						children: "Your photos are private and only visible to you."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 1336
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 100
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 212,
			columnNumber: 19
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 174,
		columnNumber: 10
	}, this);
}
_s(ProgressPage, "72J5Idukh81bFe3HC9uZPD8rgXI=");
_c = ProgressPage;
var _c;
$RefreshReg$(_c, "ProgressPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/pages/ProgressPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProgressPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProgressPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/pages/ProgressPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsWUFBWTtBQUNyQixTQUFTLGtCQUFrQjtBQUUzQixTQUFTLFNBQVMsa0JBQWtCOzs7O0FBRXBDLE9BQU8sU0FBUyxhQUFhLEVBQUUsT0FBTyxRQUFRLFNBQThIOztDQUUxSyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQXNCLFVBQVU7Q0FDdEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUN0RSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUztFQUFFLE1BQU0sUUFBUSxJQUFJLEtBQUssQ0FBQztFQUFHLFFBQVE7RUFBSSxPQUFPO0VBQUksTUFBTTtFQUFJLE9BQU87Q0FBRyxDQUFDO0NBQ3RILE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBNEU7RUFBRSxNQUFNLFFBQVEsSUFBSSxLQUFLLENBQUM7RUFBRyxPQUFPO0VBQVMsT0FBTztDQUFHLENBQUM7Q0FDdEssTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSyxJQUFJLEdBQUcsTUFBTSxPQUFPLFNBQVMsQ0FBQyxDQUFDO0NBQ2pGLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUN0RSxNQUFNLE9BQU8sTUFBTSxLQUFLLGVBQWUsV0FBVyxPQUFPO0NBQ3pELE1BQU0sa0JBQWtCLE1BQU0sS0FBSyxlQUFlLFdBQVcsT0FBTztDQUNwRSxNQUFNLGdCQUFnQixNQUFNLFFBQVEsS0FBSyxPQUFPLFdBQVc7RUFBRSxHQUFHO0VBQU8sYUFBYTtDQUFNLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSSxDQUFDO0NBQ3pJLE1BQU0sY0FBYyxjQUFjLEVBQUUsRUFBRTtDQUN0QyxNQUFNLGdCQUFnQixjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtDQUM1QyxNQUFNLGVBQWUsT0FBTyxNQUFNLEtBQUssWUFBWSxLQUFLO0NBQ3hELE1BQU0saUJBQWlCLGdCQUFnQixhQUFhLGtCQUFrQixhQUFhLGlCQUFpQixhQUFhLGdCQUFnQixlQUM3SCxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLE9BQVEsY0FBYyxrQkFBa0IsY0FBYyxnQkFBaUIsR0FBRyxDQUFDLENBQUMsSUFDM0c7Q0FDSixNQUFNLGdCQUFnQixNQUFNLFNBQVMsUUFBUSxLQUFLLFlBQVksTUFBTSxRQUFRLFVBQVUsQ0FBQztDQUN2RixNQUFNLGVBQWUsTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsS0FBSyxZQUFZLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7Q0FDN0YsSUFBSSxhQUFhO0NBQ2pCLElBQUksZ0JBQWdCO0NBQ3BCLGFBQWEsU0FBUyxNQUFNLFVBQVU7RUFDcEMsTUFBTSxXQUFXLFFBQVEsSUFBSSxLQUFLLEdBQUcsYUFBYSxRQUFRLEdBQUcsVUFBVSxJQUFJO0VBQzNFLE1BQU0sVUFBVSxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVU7RUFDM0MsZ0JBQWdCLFlBQVksS0FBSyxPQUFPLFFBQVEsUUFBUSxJQUFJLFNBQVMsUUFBUSxLQUFLLEtBQVUsTUFBTSxJQUFJLGdCQUFnQixJQUFJO0VBQzFILGFBQWEsS0FBSyxJQUFJLFlBQVksYUFBYTtDQUNqRCxDQUFDO0NBQ0QsSUFBSSxnQkFBZ0I7Q0FDcEIsTUFBTSxtQkFBbUIsSUFBSSxJQUFJLFlBQVk7Q0FDN0MsTUFBTSxlQUFlLElBQUksS0FBSztDQUM5QixPQUFPLGlCQUFpQixJQUFJLFFBQVEsWUFBWSxDQUFDLEdBQUc7RUFDbEQsaUJBQWlCO0VBQ2pCLGFBQWEsUUFBUSxhQUFhLFFBQVEsSUFBSSxDQUFDO0NBQ2pEO0NBQ0EsTUFBTSxpQkFBaUIsSUFBSSxLQUFLLEdBQUcsTUFBTSxVQUFVLFVBQVUsVUFBVTtDQUN2RSxNQUFNLGVBQWUsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLE1BQU0sVUFBVSxRQUFRLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxlQUFlLFFBQVEsS0FBSyxLQUFVLElBQUksQ0FBQyxDQUFDO0NBQ3ZJLE1BQU0sY0FBYyxLQUFLLE9BQU8sZUFBZSxLQUFLLENBQUM7Q0FDckQsTUFBTSxlQUFlLE1BQU0sS0FBSyxFQUFFLFFBQVEsS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLE1BQU0sVUFBVSxTQUFTLENBQUMsQ0FBQyxFQUFFLElBQUksR0FBRyxpQkFBaUI7RUFDbkgsTUFBTSxZQUFZLEtBQUssSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJO0VBQ2pELE9BQU87R0FDTCxNQUFNO0dBQ04sT0FBTyxNQUFNLFNBQVMsUUFBUSxZQUFZLEtBQUssT0FBTyxJQUFJLEtBQUssR0FBRyxRQUFRLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxJQUFJLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBVyxNQUFNLFNBQVMsQ0FBQyxDQUFDO0VBQ3RLO0NBQ0YsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTSxVQUFVLFNBQVMsQ0FBQyxDQUFDO0NBQ3JFLE1BQU0sWUFBWSxLQUFLLElBQUksTUFBTSxVQUFVLGFBQWEsR0FBRyxhQUFhLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQztDQUNqRyxNQUFNLG9CQUFvQjtFQUN4QixJQUFJLENBQUMsV0FBVyxVQUFVLENBQUMsY0FBYyxRQUFRLE9BQU87RUFDeEQsTUFBTSxXQUFXLGNBQWMsR0FBRyxDQUFDLENBQUM7RUFDcEMsTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxJQUFJLElBQUksS0FBSyxHQUFHLFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLEtBQUssS0FBVSxDQUFDO0VBQ3JKLE1BQU0sV0FBVyxLQUFLLElBQUksT0FBTyxXQUFXLE1BQU0sSUFBSSxTQUFTLE1BQU0sS0FBSyxNQUFNLEtBQUssZUFBZSxXQUFXLElBQUk7RUFDbkgsT0FBTyxXQUFXLE9BQU8sSUFBSTtDQUMvQixFQUFDLENBQUU7Q0FDSCxNQUFNLHVCQUF1QixJQUFZLFNBQVMsTUFBTSxXQUFXLE9BQU8sS0FBSyxVQUFVLE1BQU0sT0FBTyxLQUFLO0VBQUUsR0FBRztFQUFPLFVBQVU7RUFBTSxNQUFNLE1BQU0sUUFBUSxRQUFRLElBQUksS0FBSyxDQUFDO0NBQUUsSUFBSSxLQUFLO0NBRXhMLE1BQU0sbUJBQW1CLGVBQXdCO0VBQy9DLElBQUksZUFBZSxXQUFXO0dBQzVCLGlCQUFpQixJQUFJO0dBQ3JCLGNBQWM7SUFBRSxNQUFNLFFBQVEsSUFBSSxLQUFLLENBQUM7SUFBRyxRQUFRO0lBQUksT0FBTztJQUFJLE1BQU07SUFBSSxPQUFPO0dBQUcsQ0FBQztFQUN6RixPQUFPO0dBQ0wsTUFBTSxRQUFRLE1BQU0sUUFBUTtHQUM1QixpQkFBaUIsVUFBVTtHQUMzQixjQUFjO0lBQUUsTUFBTSxNQUFNO0lBQU0sUUFBUSxPQUFPLE1BQU0sTUFBTTtJQUFHLE9BQU8sT0FBTyxNQUFNLGNBQWMsU0FBUyxFQUFFO0lBQUcsTUFBTSxPQUFPLE1BQU0sY0FBYyxRQUFRLEVBQUU7SUFBRyxPQUFPLE9BQU8sTUFBTSxjQUFjLFNBQVMsRUFBRTtHQUFFLENBQUM7RUFDaE47RUFDQSxlQUFlLEVBQUU7RUFDakIsY0FBYyxJQUFJO0NBQ3BCO0NBQ0EsTUFBTSxtQkFBbUI7RUFDdkIsTUFBTSxTQUFTLE9BQU8sV0FBVyxNQUFNO0VBQ3ZDLE1BQU0sWUFBWSxNQUFNLEtBQUssZUFBZSxXQUFXLEtBQUs7RUFDNUQsTUFBTSxZQUFZLE1BQU0sS0FBSyxlQUFlLFdBQVcsTUFBTTtFQUM3RCxNQUFNLGVBQWU7R0FBQyxXQUFXO0dBQU8sV0FBVztHQUFNLFdBQVc7RUFBSyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxJQUFJLE1BQU07RUFDckcsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLGVBQWUsV0FBVyxLQUFLO0VBQ2pFLE1BQU0saUJBQWlCLE1BQU0sS0FBSyxlQUFlLFdBQVcsTUFBTTtFQUNsRSxJQUFJLENBQUMsV0FBVyxRQUFRLENBQUMsVUFBVSxTQUFTLGFBQWEsU0FBUyxhQUFhLGFBQWEsTUFBTSxVQUFVLFFBQVEsa0JBQWtCLFFBQVEsY0FBYyxHQUFHO0dBQzdKLGVBQWUsT0FBTyxVQUFVLEdBQUcsVUFBVSxHQUFHLEtBQUssT0FBTyxlQUFlLEdBQUcsZUFBZSxHQUFHLGdCQUFnQixtQkFBbUI7R0FDbkk7RUFDRjtFQUNBLE1BQU0sUUFBUTtHQUNaLE1BQU0sV0FBVztHQUNqQjtHQUNBLGNBQWM7SUFDWixPQUFPLFdBQVcsUUFBUSxPQUFPLFdBQVcsS0FBSyxJQUFJO0lBQ3JELE1BQU0sV0FBVyxPQUFPLE9BQU8sV0FBVyxJQUFJLElBQUk7SUFDbEQsT0FBTyxXQUFXLFFBQVEsT0FBTyxXQUFXLEtBQUssSUFBSTtHQUN2RDtFQUNGO0VBQ0EsTUFBTSxVQUFVLGtCQUFrQixPQUFPLENBQUMsR0FBRyxNQUFNLFNBQVMsS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLE1BQU0sVUFBVSxVQUFVLGdCQUFnQixRQUFRLElBQUk7RUFDOUksSUFBSSxDQUFDLE9BQU87R0FBRSxHQUFHO0dBQU87R0FBUyxNQUFNO0lBQUUsR0FBRyxNQUFNO0lBQU0sUUFBUSxPQUFPLE1BQU07R0FBRTtHQUFHLFFBQVEsb0JBQW9CLFVBQVU7RUFBRSxDQUFDLEdBQUc7RUFDOUgsY0FBYyxLQUFLO0VBQ25CLE1BQU0sa0JBQWtCLE9BQU8sd0JBQXdCLHVCQUF1QjtDQUNoRjtDQUNBLE1BQU0sZUFBZSxTQUFnQjtFQUNuQyxjQUFjLEVBQUU7RUFDaEIsSUFBSSxDQUFDLE1BQU07RUFDWCxJQUFJLENBQUM7R0FBQztHQUFjO0dBQWE7RUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLElBQUksR0FBRyxPQUFPLGNBQWMsbUNBQW1DO0VBQzVILElBQUksS0FBSyxPQUFPLElBQUksT0FBTyxNQUFNLE9BQU8sY0FBYyxvQ0FBb0M7RUFDMUYsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLGVBQWU7R0FDcEIsTUFBTSxRQUFRLElBQUksTUFBTTtHQUN4QixNQUFNLGVBQWU7SUFDbkIsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE1BQU0sQ0FBQztJQUNwRSxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxNQUFNLFFBQVEsS0FBSyxDQUFDO0lBQzFELE9BQU8sU0FBUyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssQ0FBQztJQUM1RCxNQUFNLFVBQVUsT0FBTyxXQUFXLElBQUk7SUFDdEMsSUFBSSxDQUFDLFNBQVMsT0FBTyxjQUFjLHFEQUFxRDtJQUN4RixRQUFRLFVBQVUsT0FBTyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtJQUMxRCxjQUFjLGFBQWE7S0FBRSxHQUFHO0tBQVMsT0FBTyxPQUFPLFVBQVUsY0FBYyxHQUFHO0lBQUUsRUFBRTtHQUN4RjtHQUNBLE1BQU0sZ0JBQWdCLGNBQWMscURBQXFEO0dBQ3pGLE1BQU0sTUFBTSxPQUFPLE9BQU8sTUFBTTtFQUNsQztFQUNBLE9BQU8sZ0JBQWdCLGNBQWMsa0RBQWtEO0VBQ3ZGLE9BQU8sY0FBYyxJQUFJO0NBQzNCO0NBQ0EsTUFBTSxrQkFBa0I7RUFDdEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxDQUFDLFVBQVUsTUFBTSxPQUFPLGNBQWMsMkJBQTJCO0VBQ3pGLE1BQU0sU0FBUyxDQUFDLEdBQUcsTUFBTSxRQUFRLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSSxDQUFDO0VBQ3ZGLElBQUksQ0FBQyxPQUFPO0dBQUUsR0FBRztHQUFPO0dBQVEsUUFBUSxvQkFBb0IsU0FBUztFQUFFLENBQUMsR0FBRztFQUMzRSxjQUFjLE9BQU8sU0FBUyxDQUFDO0VBQy9CLGFBQWEsS0FBSztFQUNsQixhQUFhO0dBQUUsTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDO0dBQUcsT0FBTztHQUFTLE9BQU87RUFBRyxDQUFDO0VBQ3JFLE1BQU0sdUJBQXVCO0NBQy9CO0NBRUEsTUFBTSxjQUFjLGNBQWMsS0FBSyxVQUFVLE1BQU0sTUFBTTtDQUM3RCxNQUFNLGNBQWMsQ0FBQyxHQUFHLGFBQWEsR0FBSSxlQUFlLENBQUMsWUFBWSxJQUFJLENBQUMsQ0FBRTtDQUM1RSxNQUFNLFdBQVcsWUFBWSxTQUFTLEtBQUssSUFBSSxHQUFHLFdBQVcsSUFBSSxJQUFJO0NBQ3JFLE1BQU0sV0FBVyxZQUFZLFNBQVMsS0FBSyxJQUFJLEdBQUcsV0FBVyxJQUFJLElBQUk7Q0FDckUsTUFBTSxjQUFjLE9BQWUsV0FBbUI7RUFDcEQsR0FBRyxjQUFjLFdBQVcsSUFBSSxLQUFLLEtBQUssU0FBUyxjQUFjLFNBQVMsS0FBSztFQUMvRSxHQUFHLE9BQVEsUUFBUSxZQUFZLEtBQUssSUFBSSxHQUFHLFdBQVcsUUFBUSxJQUFLO0NBQ3JFO0NBQ0EsTUFBTSxTQUFTLGNBQWMsS0FBSyxPQUFPLFVBQVUsV0FBVyxNQUFNLFFBQVEsS0FBSyxDQUFDO0NBQ2xGLE1BQU0sZUFBZTtFQUNuQjtHQUFFLFVBQVU7R0FBVyxJQUFJO0dBQVksTUFBTTtHQUFnQixRQUFRO0dBQUcsT0FBTztHQUFZLFFBQVE7RUFBNEM7RUFDL0k7R0FBRSxVQUFVO0dBQVcsSUFBSTtHQUFZLE1BQU07R0FBZ0IsUUFBUTtHQUFHLE9BQU87R0FBWSxRQUFRO0VBQTRDO0VBQy9JO0dBQUUsVUFBVTtHQUFXLElBQUk7R0FBYSxNQUFNO0dBQWlCLFFBQVE7R0FBSSxPQUFPO0dBQVksUUFBUTtFQUE2QztFQUNuSjtHQUFFLFVBQVU7R0FBVyxJQUFJO0dBQWEsTUFBTTtHQUFpQixRQUFRO0dBQUksT0FBTztHQUFZLFFBQVE7RUFBNEM7RUFDbEo7R0FBRSxVQUFVO0dBQVksSUFBSTtHQUFhLE1BQU07R0FBaUIsUUFBUTtHQUFHLE9BQU8sTUFBTSxTQUFTO0dBQVEsUUFBUTtFQUFzQztFQUN2SjtHQUFFLFVBQVU7R0FBWSxJQUFJO0dBQWMsTUFBTTtHQUFlLFFBQVE7R0FBSSxPQUFPLE1BQU0sU0FBUztHQUFRLFFBQVE7RUFBOEI7RUFDL0k7R0FBRSxVQUFVO0dBQVksSUFBSTtHQUFjLE1BQU07R0FBZSxRQUFRO0dBQUksT0FBTyxNQUFNLFNBQVM7R0FBUSxRQUFRO0VBQThCO0VBQy9JO0dBQUUsVUFBVTtHQUFZLElBQUk7R0FBYyxNQUFNO0dBQWUsUUFBUTtHQUFJLE9BQU8sTUFBTSxTQUFTO0dBQVEsUUFBUTtFQUE4QjtFQUMvSTtHQUFFLFVBQVU7R0FBd0IsSUFBSTtHQUFVLE1BQU07R0FBZSxRQUFRLE1BQU0sVUFBVTtHQUFhLE9BQU8sTUFBTSxTQUFTLFFBQVEsWUFBWSxJQUFJLEtBQUssR0FBRyxRQUFRLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxJQUFJLGVBQWUsUUFBUSxJQUFJLElBQUksS0FBVSxDQUFDLENBQUM7R0FBUSxRQUFRO0VBQW9EO0VBQ3RUO0dBQUUsVUFBVTtHQUF3QixJQUFJO0dBQVcsTUFBTTtHQUFXLFFBQVEsS0FBSyxLQUFLLE1BQU0sVUFBVSxTQUFTLENBQUM7R0FBRyxPQUFPO0dBQWMsUUFBUTtFQUE2QztFQUM3TDtHQUFFLFVBQVU7R0FBd0IsSUFBSTtHQUFVLE1BQU07R0FBZSxRQUFRLE1BQU0sVUFBVTtHQUFRLE9BQU87R0FBYyxRQUFRO0VBQXlDO0VBQzdLO0dBQUUsVUFBVTtHQUFZLElBQUk7R0FBWSxNQUFNO0dBQWtCLFFBQVE7R0FBRyxPQUFPLE1BQU0sUUFBUTtHQUFRLFFBQVE7RUFBZ0M7RUFDaEo7R0FBRSxVQUFVO0dBQVksSUFBSTtHQUFXLE1BQU07R0FBZSxRQUFRO0dBQUcsT0FBTyxNQUFNLE9BQU87R0FBUSxRQUFRO0VBQXlDO0NBQ3RKO0NBQ0EsTUFBTSxZQUFZLGFBQWEsTUFBTSxVQUFVLE1BQU0sUUFBUSxNQUFNLE1BQU07Q0FDekUsTUFBTSxvQkFBb0IsYUFBYSxNQUFNLFVBQVUsTUFBTSxPQUFPLGFBQWE7Q0FDakYsTUFBTSxjQUFjLE1BQU0sT0FBTyxRQUFvRixRQUFRLE9BQU8sVUFBVTtFQUM1SSxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLElBQUksS0FBSyxHQUFHLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLElBQUksZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFXLElBQUksQ0FBQztFQUNySSxNQUFNLE1BQU0sUUFBUTtFQUNwQixPQUFPLE9BQU8sQ0FBQyxHQUFJLE9BQU8sUUFBUSxDQUFDLEdBQUk7R0FBRTtHQUFPO0VBQU0sQ0FBQztFQUN2RCxPQUFPO0NBQ1QsR0FBRyxDQUFDLENBQUM7Q0FFTCxPQUFPO0VBQUUsd0JBQUMsWUFBRDtHQUFZLFNBQVE7R0FBc0IsT0FBTTtFQUFZOzs7OztFQUNuRSx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUE2QixNQUFLO0dBQVUsY0FBVzthQUFrQjtJQUFDLENBQUMsWUFBWSxVQUFVO0lBQUcsQ0FBQyxRQUFRLE1BQU07SUFBRyxDQUFDLFVBQVUsUUFBUTtJQUFHLENBQUMsVUFBVSxRQUFRO0dBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLFdBQVcsd0JBQUMsVUFBRDtJQUFvQixNQUFLO0lBQU0saUJBQWUsUUFBUTtJQUFPLFdBQVcsUUFBUSxRQUFRLFdBQVc7SUFBSSxlQUFlLE9BQU8sS0FBb0I7Y0FBSTtHQUFjLEdBQXRKOzs7O1VBQXNKLENBQUM7RUFBTzs7Ozs7RUFFblgsUUFBUSxjQUFjLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDckIsd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBbkIsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFjLE9BQU8sRUFBRSxxQkFBcUIsR0FBRyxpQkFBaUIsSUFBSSxLQUFLO2dCQUEwQix3QkFBQyxPQUFELGFBQUssd0JBQUMsVUFBRCxhQUFTLGdCQUFlLEdBQVM7Ozs7Z0JBQUMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztjQUFNOzs7OztLQUFNOzs7O2VBQ2hNLHdCQUFDLE9BQUQ7TUFBSyx3QkFBQyxTQUFELFlBQU8sb0JBQXdCOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSyxNQUFNLFFBQVEsU0FBUyw2QkFBNkIsa0NBQXNDOzs7OztNQUFFLE1BQU0sUUFBUSxTQUFTLHdCQUFDLEtBQUQ7T0FBRyx3QkFBQyxVQUFEO1FBQVM7UUFBWTtRQUFFO09BQWE7Ozs7O09BQUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7T0FBQyx3QkFBQyxVQUFEO1FBQVM7UUFBYztRQUFFO09BQWE7Ozs7O09BQUMsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7T0FBQyx3QkFBQyxVQUFELFlBQVMsZUFBZSxHQUFHLGFBQWEsR0FBRyxTQUFTLGFBQXFCOzs7OztNQUFJOzs7O2lCQUFJLHdCQUFDLEtBQUQsWUFBRyxxQ0FBcUM7Ozs7O01BQUUsd0JBQUMsUUFBRDtPQUFRLGVBQWU7UUFBRSxPQUFPLE1BQU07UUFBRyxnQkFBZ0I7T0FBRztpQkFBSSxNQUFNLFFBQVEsU0FBUyxlQUFlO01BQThCOzs7OztLQUFNOzs7O2FBQ3BoQjs7Ozs7O0lBQ1Qsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtNQUFDO09BQUM7T0FBUztPQUFzQixPQUFPLE1BQU0sU0FBUyxNQUFNO01BQUM7TUFBRztPQUFDO09BQVM7T0FBZSxnQkFBZ0IsS0FBSyxHQUFHLGNBQWMsS0FBSyxJQUFJLGdCQUFnQixHQUFFLENBQUUsUUFBUSxDQUFDLEVBQUU7TUFBRTtNQUFHO09BQUM7T0FBUztPQUFrQixHQUFHLGNBQWMsR0FBRyxrQkFBa0IsSUFBSSxRQUFRO01BQVE7TUFBRztPQUFDO09BQVE7T0FBZSxHQUFHLFdBQVcsR0FBRyxlQUFlLElBQUksUUFBUTtNQUFRO0tBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLE9BQU8sV0FBVyx3QkFBQyxXQUFEO01BQXFCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFpQix3QkFBQyxNQUFELEVBQU0sTUFBTSxLQUErQzs7Ozs7TUFBTzs7Ozs7TUFBQyx3QkFBQyxTQUFELFlBQVEsTUFBYTs7Ozs7TUFBQyx3QkFBQyxVQUFELFlBQVMsTUFBYzs7Ozs7S0FBVSxLQUFsSzs7OztZQUFrSyxDQUFDO0lBQ2xpQjs7Ozs7SUFDTCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQixDQUFzQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUE0Qix3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLGNBQWtCOzs7O2dCQUFDLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7Y0FBTTs7OztnQkFBQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxTQUFTLFNBQVMsR0FBRyxNQUFNLFNBQVMsT0FBTyxVQUFVLGtCQUF3Qjs7OztjQUFNOzs7OztlQUFFLE1BQU0sU0FBUyxTQUFTLCtDQUFFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFvQixhQUFhLEtBQUssU0FBUyx3QkFBQyxPQUFELGFBQXFCLHdCQUFDLEtBQUQ7T0FBRyxXQUFXLEtBQUssU0FBUyxjQUFjLFlBQVk7T0FBSSxPQUFPLEVBQUUsUUFBUSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUSxZQUFZLEdBQUcsRUFBRSxHQUFHO01BQUk7Ozs7Z0JBQUMsd0JBQUMsUUFBRCxhQUFNLEtBQUUsS0FBSyxPQUFPLENBQVE7Ozs7Y0FBTSxLQUE3SyxLQUFLOzs7O2FBQXdLLENBQUM7S0FBTzs7OztjQUFHOzs7O2dCQUFJLHdCQUFDLFlBQUQ7TUFBWSxPQUFNO01BQStCLE1BQUs7S0FBNEU7Ozs7YUFBVzs7Ozs7O0dBQzFvQjs7Ozs7O0VBRUosUUFBUSxVQUFVLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDakIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUF1Qyx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLGdCQUFvQjs7OztlQUFDLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7YUFBTTs7OztlQUFDLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLGdCQUFnQjtnQkFBRztLQUFrQjs7OzthQUFNOzs7Ozs7SUFDekssd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBcUIsY0FBYyxTQUFTLGdEQUFFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQWUsU0FBUTtNQUFjLE1BQUs7TUFBTSxjQUFXO2dCQUExRTtPQUFxRyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFhLElBQUc7UUFBSyxJQUFHO1FBQU0sSUFBRztRQUFNLElBQUc7T0FBTzs7Ozs7T0FBRSxnQkFBZ0IsZ0RBQUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBYyxJQUFHO1FBQUssSUFBSSxXQUFXLGNBQWMsQ0FBQyxDQUFDLENBQUM7UUFBRyxJQUFHO1FBQU0sSUFBSSxXQUFXLGNBQWMsQ0FBQyxDQUFDLENBQUM7T0FBSTs7OztpQkFBQyx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUFNLEdBQUcsV0FBVyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUk7UUFBRyxZQUFXO2tCQUEvRDtTQUFxRTtTQUFRO1NBQWE7U0FBRTtRQUFXOzs7OztlQUFHOzs7OztPQUFFLHdCQUFDLFlBQUQsRUFBVSxRQUFRLE9BQU8sS0FBSyxVQUFVLEdBQUcsTUFBTSxFQUFFLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBSTs7Ozs7T0FBQyx3QkFBQyxVQUFEO1FBQVEsV0FBVTtRQUFjLElBQUksT0FBTyxFQUFFLENBQUM7UUFBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO1FBQUcsR0FBRTtPQUFLOzs7OztPQUFFLE9BQU8sS0FBSyxPQUFPLFVBQVUsd0JBQUMsVUFBRDtRQUFvQixJQUFJLE1BQU07UUFBRyxJQUFJLE1BQU07UUFBRyxHQUFFO09BQUssR0FBeEM7Ozs7Y0FBd0MsQ0FBQztPQUFFLHdCQUFDLFFBQUQ7UUFBTSxHQUFHLE9BQU8sRUFBRSxDQUFDO1FBQUcsR0FBRyxPQUFPLEVBQUUsQ0FBQyxJQUFJO1FBQUksWUFBVztrQkFBUztPQUFXOzs7OztNQUFNOzs7OztlQUFDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQW9DLHdCQUFDLFFBQUQsWUFBTyxXQUFXLGNBQWMsRUFBRSxDQUFDLElBQUksRUFBUTs7OztnQkFBQyx3QkFBQyxRQUFELFlBQU8sV0FBVyxjQUFjLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBRSxJQUFJLEVBQVE7Ozs7Y0FBTTs7Ozs7YUFBRzs7OztnQkFBSSx3QkFBQyxZQUFEO01BQVksT0FBTTtNQUFrQixNQUFLO0tBQW9EOzs7OztJQUFXOzs7OztJQUN6aEMsY0FBYyxTQUFTLEtBQUssd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBbkIsQ0FBdUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWEsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFNBQUQsWUFBTyxVQUFjOzs7O2dCQUFDLHdCQUFDLE1BQUQsWUFBSSxpQkFBa0I7Ozs7Y0FBTTs7Ozs7S0FBTTs7OztlQUFFLGNBQWMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxVQUFVLHdCQUFDLE9BQUQsYUFBZ0Qsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLFVBQUQ7TUFBUyxNQUFNO01BQU87TUFBRTtLQUFhOzs7O2VBQUMsd0JBQUMsUUFBRCxhQUFPLFdBQVcsTUFBTSxJQUFJLEdBQUcsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLE1BQU0sWUFBWSxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksMEJBQTBCLEVBQVM7Ozs7YUFBTTs7OztlQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxVQUFEO01BQVEsZUFBZSxnQkFBZ0IsTUFBTSxXQUFXO2dCQUFHO0tBQVk7Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsZUFBZTtPQUFFLE9BQU87UUFBRSxHQUFHO1FBQU8sU0FBUyxNQUFNLFFBQVEsUUFBUSxHQUFHLFVBQVUsVUFBVSxNQUFNLFdBQVc7T0FBRSxDQUFDO09BQUcsTUFBTSx1QkFBdUI7TUFBRztnQkFBRztLQUFjOzs7O2FBQU07Ozs7YUFBTSxLQUFyZSxHQUFHLE1BQU0sS0FBSyxHQUFHLE1BQU07Ozs7WUFBOGMsQ0FBQyxDQUFXOzs7Ozs7R0FDdHNCOzs7Ozs7RUFFSixRQUFRLFlBQVksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNuQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQXVDLHdCQUFDLE9BQUQ7S0FBSyx3QkFBQyxTQUFELFlBQU8sWUFBZ0I7Ozs7O0tBQUMsd0JBQUMsTUFBRCxZQUFJLGtCQUFtQjs7Ozs7S0FBQyx3QkFBQyxLQUFELFlBQUcsbURBQW1EOzs7OztJQUFNOzs7O2NBQUMsd0JBQUMsT0FBRCxhQUFNLE1BQU0sT0FBTyxVQUFVLEtBQUssd0JBQUMsUUFBRDtLQUFRLFNBQVE7S0FBUSxlQUFlLGdCQUFnQixVQUFVLENBQUMsS0FBSztlQUFJLGNBQWMsaUJBQWlCO0lBQWtCOzs7O2NBQUUsd0JBQUMsUUFBRDtLQUFRLGVBQWU7TUFBRSxjQUFjLEVBQUU7TUFBRyxhQUFhLElBQUk7S0FBRztlQUFHO0lBQTBCOzs7O1lBQU07Ozs7WUFBTTs7Ozs7YUFDamEsZUFBZSxNQUFNLE9BQU8sVUFBVSxJQUFJLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQW1DLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQWlDLHdCQUFDLFNBQUQsYUFBTyxVQUFNLHdCQUFDLFVBQUQ7T0FBUSxPQUFPO09BQWEsV0FBVyxVQUFVLGVBQWUsT0FBTyxNQUFNLE9BQU8sS0FBSyxDQUFDO2lCQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sVUFBVSx3QkFBQyxVQUFEO1FBQVEsT0FBTztrQkFBZjtTQUFzRCxXQUFXLE1BQU0sSUFBSTtTQUFFO1NBQUksTUFBTSxTQUFTO1FBQWdCO1VBQXJGLEdBQUcsTUFBTSxLQUFLLEdBQUc7Ozs7Y0FBb0UsQ0FBQztNQUFVOzs7O2NBQVE7Ozs7Z0JBQUMsd0JBQUMsU0FBRCxhQUFPLFNBQUssd0JBQUMsVUFBRDtPQUFRLE9BQU87T0FBWSxXQUFXLFVBQVUsY0FBYyxPQUFPLE1BQU0sT0FBTyxLQUFLLENBQUM7aUJBQUksTUFBTSxPQUFPLEtBQUssT0FBTyxVQUFVLHdCQUFDLFVBQUQ7UUFBUSxPQUFPO2tCQUFmO1NBQXNELFdBQVcsTUFBTSxJQUFJO1NBQUU7U0FBSSxNQUFNLFNBQVM7UUFBZ0I7VUFBckYsR0FBRyxNQUFNLEtBQUssR0FBRzs7OztjQUFvRSxDQUFDO01BQVU7Ozs7Y0FBUTs7OztjQUFNOzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUFnQixPQUFPLEVBQUUsc0JBQXNCLEdBQUcsZ0JBQWdCLEdBQUc7Z0JBQXBGO09BQThHLHdCQUFDLE9BQUQ7UUFBSyxLQUFLLE1BQU0sT0FBTyxZQUFZLEVBQUU7UUFBTyxLQUFLLGVBQWUsV0FBVyxNQUFNLE9BQU8sWUFBWSxFQUFFLElBQUk7T0FBTTs7Ozs7T0FBQyx3QkFBQyxPQUFELFlBQUssd0JBQUMsT0FBRDtRQUFLLEtBQUssTUFBTSxPQUFPLFdBQVcsRUFBRTtRQUFPLEtBQUssZUFBZSxXQUFXLE1BQU0sT0FBTyxXQUFXLEVBQUUsSUFBSTtPQUFNOzs7O2dCQUFNOzs7OztPQUFDLHdCQUFDLEtBQUQsQ0FBSTs7Ozs7TUFBTTs7Ozs7O0tBQUMsd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQWtDLG1CQUFlLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQVEsS0FBSTtPQUFJLEtBQUk7T0FBTSxPQUFPO09BQWlCLFdBQVcsVUFBVSxtQkFBbUIsT0FBTyxNQUFNLE9BQU8sS0FBSyxDQUFDO01BQUk7Ozs7Y0FBUTs7Ozs7O0lBQVU7Ozs7O2NBQzdyQyxNQUFNLE9BQU8sU0FBUyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFlLE9BQU8sUUFBUSxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxZQUFZLHdCQUFDLFdBQUQsYUFBb0Isd0JBQUMsTUFBRCxZQUFLLEtBQVM7Ozs7Y0FBQyx3QkFBQyxPQUFELFlBQU0sT0FBTyxLQUFLLEVBQUUsT0FBTyxZQUFZLHdCQUFDLFdBQUQsYUFBd0Msd0JBQUMsT0FBRDtLQUFLLEtBQUssTUFBTTtLQUFPLEtBQUssR0FBRyxNQUFNLFNBQVMsUUFBUSxzQkFBc0IsV0FBVyxNQUFNLElBQUk7SUFBTTs7OztjQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFTLE1BQU0sU0FBUyxRQUFnQjs7OztjQUFDLHdCQUFDLFNBQUQsWUFBUSxXQUFXLE1BQU0sSUFBSSxFQUFTOzs7O1lBQU87Ozs7Y0FBQyx3QkFBQyxVQUFEO0tBQVEsZUFBZTtNQUFFLE9BQU87T0FBRSxHQUFHO09BQU8sUUFBUSxNQUFNLE9BQU8sUUFBUSxHQUFHLGVBQWUsZUFBZSxLQUFLO01BQUUsQ0FBQztNQUFHLE1BQU0sZ0JBQWdCO0tBQUc7ZUFBRztJQUFjOzs7O1lBQU07Ozs7WUFBVSxLQUFuWixHQUFHLE1BQU0sS0FBSyxHQUFHOzs7O1dBQWtZLENBQUMsRUFBTzs7OztZQUFVLEtBQS9lOzs7O1dBQStlLENBQUM7R0FBTzs7OztjQUMzbUIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUE2Qix3QkFBQyxRQUFELFlBQU0sd0JBQUMsTUFBRCxFQUFNLE1BQUssU0FBVTs7OztjQUFPOzs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSSx3QkFBeUI7Ozs7O0tBQUMsd0JBQUMsS0FBRCxZQUFHLDRFQUE0RTs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQVEsZUFBZSxhQUFhLElBQUk7Z0JBQUc7S0FBMEI7Ozs7O0lBQU07Ozs7O1dBQzVQOzs7Ozs7RUFFSixRQUFRLFlBQVksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNuQix3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUFtQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBYyx3QkFBQyxNQUFELEVBQU0sTUFBSyxRQUFTOzs7OztNQUFPOzs7OztNQUFDLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxTQUFELFlBQU8saUJBQXFCOzs7O2dCQUFDLHdCQUFDLFVBQUQ7T0FBUztPQUFjO09BQUUsa0JBQWtCLElBQUksUUFBUTtNQUFlOzs7O2NBQU07Ozs7O01BQUUsYUFBYSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUE0Qix3QkFBQyxRQUFELGFBQU0sVUFBTSx3QkFBQyxVQUFELFlBQVMsVUFBVSxLQUFhOzs7O2dCQUFPOzs7OztRQUFDLHdCQUFDLE9BQUQsWUFBSyx3QkFBQyxLQUFELEVBQUcsT0FBTyxFQUFFLE9BQU8sR0FBRyxLQUFLLElBQUksS0FBSyxVQUFVLFFBQVEsVUFBVSxTQUFTLEdBQUcsRUFBRSxHQUFHLEVBQUk7Ozs7aUJBQU07Ozs7O1FBQUMsd0JBQUMsU0FBRDtTQUFRLEtBQUssSUFBSSxVQUFVLE9BQU8sVUFBVSxNQUFNO1NBQUU7U0FBRSxVQUFVO1FBQWM7Ozs7O09BQU07Ozs7OztLQUFXOzs7Ozs7SUFDemU7S0FBQztLQUFXO0tBQVk7S0FBd0I7SUFBVSxDQUFDLENBQUMsS0FBSyxhQUFhLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQW1ELHdCQUFDLE1BQUQsWUFBSyxTQUFhOzs7O2VBQUMsd0JBQUMsT0FBRCxZQUFNLGFBQWEsUUFBUSxVQUFVLE1BQU0sYUFBYSxRQUFRLENBQUMsQ0FBQyxLQUFLLFVBQVU7TUFDcE8sTUFBTSxjQUFjLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLE1BQU0sRUFBRTtNQUNwRSxNQUFNLFdBQVcsUUFBUSxhQUFhLFlBQVksTUFBTSxTQUFTLE1BQU0sTUFBTTtNQUM3RSxPQUFPLHdCQUFDLFVBQUQ7T0FBUSxXQUFXLFdBQVcsYUFBYTtPQUFtQixlQUFlLGlCQUFpQixNQUFNLEVBQUU7aUJBQXRHO1FBQXlHLHdCQUFDLFFBQUQsWUFBTSx3QkFBQyxNQUFELEVBQU0sTUFBTSxXQUFXLFNBQVMsT0FBUzs7OztpQkFBTzs7Ozs7UUFBQyx3QkFBQyxVQUFELFlBQVMsTUFBTSxLQUFhOzs7OztRQUFDLHdCQUFDLFNBQUQsWUFBUSxXQUFXLFlBQVksYUFBYSxPQUFPLFdBQVcsWUFBWSxJQUFJLElBQUksWUFBWSxHQUFHLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxNQUFNLEVBQUUsR0FBRyxNQUFNLFNBQWdCOzs7OztPQUFTO1NBQWhULE1BQU07Ozs7YUFBMFM7S0FDN1csQ0FBQyxFQUFPOzs7O2FBQVU7T0FKc0c7Ozs7V0FJdEcsQ0FBQztJQUNsQixxQkFBcUIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUE4Qix3QkFBQyxVQUFEO09BQVEsZUFBZSxpQkFBaUIsSUFBSTtPQUFHLGNBQVc7aUJBQXFCLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O01BQVM7Ozs7O01BQUMsd0JBQUMsUUFBRCxZQUFNLHdCQUFDLE1BQUQsRUFBTSxNQUFLLE9BQVE7Ozs7ZUFBTzs7Ozs7TUFBQyx3QkFBQyxTQUFELFlBQVEsa0JBQWtCLFNBQWdCOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSyxrQkFBa0IsS0FBUzs7Ozs7TUFBQyx3QkFBQyxLQUFELFlBQUksa0JBQWtCLE9BQVU7Ozs7O01BQUMsd0JBQUMsVUFBRDtPQUFTLEtBQUssSUFBSSxrQkFBa0IsT0FBTyxrQkFBa0IsTUFBTTtPQUFFO09BQUUsa0JBQWtCO09BQU87TUFBaUI7Ozs7O0tBQU07Ozs7OztHQUNuYTs7Ozs7O0VBRUosY0FBYyx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUEwQixtQkFBbUIsY0FBYyxLQUFLO2FBQUcsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBaUIsTUFBSztJQUFTLGNBQVc7SUFBTyxjQUFXO0lBQWEsY0FBYyxVQUFVLE1BQU0sZ0JBQWdCO2NBQXRJO0tBQXlJLHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLGdCQUFvQjs7OztlQUFDLHdCQUFDLE1BQUQsWUFBSyxrQkFBa0IsT0FBTyxlQUFlLGFBQWlCOzs7O2FBQU07Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsZUFBZSxjQUFjLEtBQUs7TUFBRyxjQUFXO2dCQUFRLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFFBQVM7Ozs7O0tBQVM7Ozs7YUFBUzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUErQix3QkFBQyxTQUFELGFBQU8sUUFBSSx3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFPLE9BQU8sV0FBVztRQUFNLFdBQVcsVUFBVSxjQUFjO1NBQUUsR0FBRztTQUFZLE1BQU0sTUFBTSxPQUFPO1FBQU0sQ0FBQztPQUFJOzs7O2VBQVE7Ozs7O09BQUMsd0JBQUMsU0FBRDtRQUFPO1FBQVM7UUFBSztRQUFDLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVMsTUFBSztTQUFLLE9BQU8sV0FBVztTQUFRLFdBQVcsVUFBVTtVQUFFLGNBQWM7V0FBRSxHQUFHO1dBQVksUUFBUSxNQUFNLE9BQU87VUFBTSxDQUFDO1VBQUcsZUFBZSxFQUFFO1NBQUc7UUFBSTs7Ozs7T0FBUTs7Ozs7T0FBQyx3QkFBQyxRQUFELGFBQU0sNEJBQXlCLGdCQUFnQixZQUFZLENBQVE7Ozs7O09BQUMsd0JBQUMsU0FBRCxhQUFPLFNBQUssd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBUyxNQUFLO1FBQUssT0FBTyxXQUFXO1FBQU8sV0FBVyxVQUFVLGNBQWM7U0FBRSxHQUFHO1NBQVksT0FBTyxNQUFNLE9BQU87UUFBTSxDQUFDO09BQUk7Ozs7ZUFBUTs7Ozs7T0FBQyx3QkFBQyxTQUFELGFBQU8sUUFBSSx3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFTLE1BQUs7UUFBSyxPQUFPLFdBQVc7UUFBTSxXQUFXLFVBQVUsY0FBYztTQUFFLEdBQUc7U0FBWSxNQUFNLE1BQU0sT0FBTztRQUFNLENBQUM7T0FBSTs7OztlQUFROzs7OztPQUFDLHdCQUFDLFNBQUQsYUFBTyxTQUFLLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQVMsTUFBSztRQUFLLE9BQU8sV0FBVztRQUFPLFdBQVcsVUFBVSxjQUFjO1NBQUUsR0FBRztTQUFZLE9BQU8sTUFBTSxPQUFPO1FBQU0sQ0FBQztPQUFJOzs7O2VBQVE7Ozs7O01BQU07Ozs7OztLQUFFLGNBQWMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWM7S0FBK0U7Ozs7O0tBQUcsZUFBZSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBcUI7S0FBZTs7Ozs7S0FBRSx3QkFBQyxRQUFEO01BQVEsU0FBUztnQkFBWTtLQUFrQjs7Ozs7SUFBTTs7Ozs7O0VBQU07Ozs7O0VBQ25sRCxhQUFhLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQTBCLG1CQUFtQixhQUFhLEtBQUs7YUFBRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFpQixNQUFLO0lBQVMsY0FBVztJQUFPLGNBQVc7SUFBcUIsY0FBYyxVQUFVLE1BQU0sZ0JBQWdCO2NBQTlJO0tBQWlKLHdCQUFDLFVBQUQsYUFBUSx3QkFBQyxPQUFELGFBQUssd0JBQUMsU0FBRCxZQUFPLG9CQUF3Qjs7OztlQUFDLHdCQUFDLE1BQUQsWUFBSSxxQkFBc0I7Ozs7YUFBTTs7OztlQUFDLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLGFBQWEsS0FBSztNQUFHLGNBQVc7Z0JBQVEsd0JBQUMsTUFBRCxFQUFNLE1BQUssUUFBUzs7Ozs7S0FBUzs7OzthQUFTOzs7OztLQUFDLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUFpQyxVQUFVLFFBQVEsd0JBQUMsT0FBRDtPQUFLLEtBQUssVUFBVTtPQUFPLEtBQUk7TUFBNkI7Ozs7aUJBQUksd0JBQUMsUUFBRDtPQUFNLHdCQUFDLE1BQUQsRUFBTSxNQUFLLFNBQVU7Ozs7O09BQUMsd0JBQUMsVUFBRCxZQUFRLGlCQUFzQjs7Ozs7T0FBQyx3QkFBQyxTQUFELFlBQU8sOEJBQWtDOzs7OztNQUFPOzs7O2dCQUFFLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQU8sUUFBTztPQUF3RCxXQUFXLFVBQVUsWUFBWSxNQUFNLE9BQU8sUUFBUSxFQUFFO01BQUk7Ozs7Y0FBUTs7Ozs7O0tBQUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBMEMsd0JBQUMsU0FBRCxhQUFPLFFBQUksd0JBQUMsU0FBRDtPQUFPLE1BQUs7T0FBTyxPQUFPLFVBQVU7T0FBTSxXQUFXLFVBQVUsYUFBYTtRQUFFLEdBQUc7UUFBVyxNQUFNLE1BQU0sT0FBTztPQUFNLENBQUM7TUFBSTs7OztjQUFROzs7O2dCQUFDLHdCQUFDLFNBQUQsYUFBTyxTQUFLLHdCQUFDLFVBQUQ7T0FBUSxPQUFPLFVBQVU7T0FBTyxXQUFXLFVBQVUsYUFBYTtRQUFFLEdBQUc7UUFBVyxPQUFPLE1BQU0sT0FBTztPQUFtQyxDQUFDO2lCQUExSTtRQUE2SSx3QkFBQyxVQUFELFlBQVEsUUFBYTs7Ozs7UUFBQyx3QkFBQyxVQUFELFlBQVEsT0FBWTs7Ozs7UUFBQyx3QkFBQyxVQUFELFlBQVEsT0FBWTs7Ozs7T0FBUzs7Ozs7Y0FBUTs7OztjQUFNOzs7Ozs7S0FBRSxjQUFjLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFxQjtLQUFjOzs7OztLQUFFLHdCQUFDLFFBQUQ7TUFBUSxTQUFTO2dCQUFXO0tBQWtCOzs7OztLQUFDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFlO0tBQW1EOzs7OztJQUFNOzs7Ozs7RUFBTTs7Ozs7Q0FDOTRDOzs7OztBQUNKIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2dyZXNzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEVtcHR5U3RhdGUgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9FbXB0eVN0YXRlXCI7XHJcbmltcG9ydCB7IEljb24gfSBmcm9tIFwiLi4vY29tcG9uZW50cy9JY29uXCI7XHJcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9QYWdlSGVhZGVyXCI7XHJcbmltcG9ydCB0eXBlIHsgRml0bmVzc1N0b3JlIH0gZnJvbSBcIi4uL2ZpdG5lc3NTdG9yZVwiO1xyXG5pbXBvcnQgeyBkYXRlS2V5LCBwcmV0dHlEYXRlIH0gZnJvbSBcIi4uL2xpYi9mb3JtYXRcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQcm9ncmVzc1BhZ2UoeyBzdG9yZSwgdXBkYXRlLCB0b2FzdCB9OiB7IHN0b3JlOiBGaXRuZXNzU3RvcmU7IHVwZGF0ZTogKG5leHQ6IEZpdG5lc3NTdG9yZSkgPT4gYm9vbGVhbjsgdG9hc3Q6IChtZXNzYWdlOiBzdHJpbmcsIGVycm9yPzogYm9vbGVhbikgPT4gdm9pZCB9KSB7XHJcbiAgdHlwZSBQcm9ncmVzc1RhYiA9IFwib3ZlcnZpZXdcIiB8IFwiYm9keVwiIHwgXCJwaG90b3NcIiB8IFwiYmFkZ2VzXCI7XHJcbiAgY29uc3QgW3RhYiwgc2V0VGFiXSA9IHVzZVN0YXRlPFByb2dyZXNzVGFiPihcIm92ZXJ2aWV3XCIpO1xyXG4gIGNvbnN0IFtzaG93V2VpZ2h0LCBzZXRTaG93V2VpZ2h0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdGluZ1dlaWdodCwgc2V0RWRpdGluZ1dlaWdodF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbd2VpZ2h0Rm9ybSwgc2V0V2VpZ2h0Rm9ybV0gPSB1c2VTdGF0ZSh7IGRhdGU6IGRhdGVLZXkobmV3IERhdGUoKSksIHdlaWdodDogXCJcIiwgd2Fpc3Q6IFwiXCIsIGhpcHM6IFwiXCIsIGNoZXN0OiBcIlwiIH0pO1xyXG4gIGNvbnN0IFt3ZWlnaHRFcnJvciwgc2V0V2VpZ2h0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dQaG90bywgc2V0U2hvd1Bob3RvXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGhvdG9Gb3JtLCBzZXRQaG90b0Zvcm1dID0gdXNlU3RhdGU8eyBkYXRlOiBzdHJpbmc7IGFuZ2xlOiBcIkZyb250XCIgfCBcIlNpZGVcIiB8IFwiQmFja1wiOyBpbWFnZTogc3RyaW5nIH0+KHsgZGF0ZTogZGF0ZUtleShuZXcgRGF0ZSgpKSwgYW5nbGU6IFwiRnJvbnRcIiwgaW1hZ2U6IFwiXCIgfSk7XHJcbiAgY29uc3QgW3Bob3RvRXJyb3IsIHNldFBob3RvRXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NvbXBhcmVNb2RlLCBzZXRDb21wYXJlTW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2JlZm9yZUluZGV4LCBzZXRCZWZvcmVJbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbYWZ0ZXJJbmRleCwgc2V0QWZ0ZXJJbmRleF0gPSB1c2VTdGF0ZShNYXRoLm1heCgwLCBzdG9yZS5waG90b3MubGVuZ3RoIC0gMSkpO1xyXG4gIGNvbnN0IFtjb21wYXJlUG9zaXRpb24sIHNldENvbXBhcmVQb3NpdGlvbl0gPSB1c2VTdGF0ZSg1MCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQmFkZ2UsIHNldFNlbGVjdGVkQmFkZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgdW5pdCA9IHN0b3JlLnVzZXIudW5pdFN5c3RlbSA9PT0gXCJtZXRyaWNcIiA/IFwia2dcIiA6IFwibGJcIjtcclxuICBjb25zdCBtZWFzdXJlbWVudFVuaXQgPSBzdG9yZS51c2VyLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyBcImNtXCIgOiBcImluXCI7XHJcbiAgY29uc3Qgc29ydGVkV2VpZ2h0cyA9IHN0b3JlLndlaWdodHMubWFwKChlbnRyeSwgaW5kZXgpID0+ICh7IC4uLmVudHJ5LCBzb3VyY2VJbmRleDogaW5kZXggfSkpLnNvcnQoKGEsIGIpID0+IGEuZGF0ZS5sb2NhbGVDb21wYXJlKGIuZGF0ZSkpO1xyXG4gIGNvbnN0IHN0YXJ0V2VpZ2h0ID0gc29ydGVkV2VpZ2h0c1swXT8ud2VpZ2h0O1xyXG4gIGNvbnN0IGN1cnJlbnRXZWlnaHQgPSBzb3J0ZWRXZWlnaHRzLmF0KC0xKT8ud2VpZ2h0O1xyXG4gIGNvbnN0IHRhcmdldFdlaWdodCA9IE51bWJlcihzdG9yZS51c2VyLnRhcmdldFdlaWdodCkgfHwgdW5kZWZpbmVkO1xyXG4gIGNvbnN0IHRhcmdldFByb2dyZXNzID0gc3RhcnRXZWlnaHQgIT09IHVuZGVmaW5lZCAmJiBjdXJyZW50V2VpZ2h0ICE9PSB1bmRlZmluZWQgJiYgdGFyZ2V0V2VpZ2h0ICE9PSB1bmRlZmluZWQgJiYgc3RhcnRXZWlnaHQgIT09IHRhcmdldFdlaWdodFxyXG4gICAgPyBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAsIE1hdGgucm91bmQoKChzdGFydFdlaWdodCAtIGN1cnJlbnRXZWlnaHQpIC8gKHN0YXJ0V2VpZ2h0IC0gdGFyZ2V0V2VpZ2h0KSkgKiAxMDApKSlcclxuICAgIDogMDtcclxuICBjb25zdCBhY3RpdmVNaW51dGVzID0gc3RvcmUuc2Vzc2lvbnMucmVkdWNlKChzdW0sIHNlc3Npb24pID0+IHN1bSArIHNlc3Npb24uZHVyYXRpb24sIDApO1xyXG4gIGNvbnN0IHNlc3Npb25EYXRlcyA9IEFycmF5LmZyb20obmV3IFNldChzdG9yZS5zZXNzaW9ucy5tYXAoKHNlc3Npb24pID0+IHNlc3Npb24uZGF0ZSkpKS5zb3J0KCk7XHJcbiAgbGV0IGJlc3RTdHJlYWsgPSAwO1xyXG4gIGxldCBydW5uaW5nU3RyZWFrID0gMDtcclxuICBzZXNzaW9uRGF0ZXMuZm9yRWFjaCgoZGF0ZSwgaW5kZXgpID0+IHtcclxuICAgIGNvbnN0IHByZXZpb3VzID0gaW5kZXggPyBuZXcgRGF0ZShgJHtzZXNzaW9uRGF0ZXNbaW5kZXggLSAxXX1UMTI6MDA6MDBgKSA6IG51bGw7XHJcbiAgICBjb25zdCBjdXJyZW50ID0gbmV3IERhdGUoYCR7ZGF0ZX1UMTI6MDA6MDBgKTtcclxuICAgIHJ1bm5pbmdTdHJlYWsgPSBwcmV2aW91cyAmJiBNYXRoLnJvdW5kKChjdXJyZW50LmdldFRpbWUoKSAtIHByZXZpb3VzLmdldFRpbWUoKSkgLyA4Nl80MDBfMDAwKSA9PT0gMSA/IHJ1bm5pbmdTdHJlYWsgKyAxIDogMTtcclxuICAgIGJlc3RTdHJlYWsgPSBNYXRoLm1heChiZXN0U3RyZWFrLCBydW5uaW5nU3RyZWFrKTtcclxuICB9KTtcclxuICBsZXQgY3VycmVudFN0cmVhayA9IDA7XHJcbiAgY29uc3QgY29tcGxldGVkRGF0ZVNldCA9IG5ldyBTZXQoc2Vzc2lvbkRhdGVzKTtcclxuICBjb25zdCBzdHJlYWtDdXJzb3IgPSBuZXcgRGF0ZSgpO1xyXG4gIHdoaWxlIChjb21wbGV0ZWREYXRlU2V0LmhhcyhkYXRlS2V5KHN0cmVha0N1cnNvcikpKSB7XHJcbiAgICBjdXJyZW50U3RyZWFrICs9IDE7XHJcbiAgICBzdHJlYWtDdXJzb3Iuc2V0RGF0ZShzdHJlYWtDdXJzb3IuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgfVxyXG4gIGNvbnN0IGNoYWxsZW5nZVN0YXJ0ID0gbmV3IERhdGUoYCR7c3RvcmUuY2hhbGxlbmdlLnN0YXJ0RGF0ZX1UMTI6MDA6MDBgKTtcclxuICBjb25zdCBjaGFsbGVuZ2VEYXkgPSBNYXRoLm1heCgxLCBNYXRoLm1pbihzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoLCBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gY2hhbGxlbmdlU3RhcnQuZ2V0VGltZSgpKSAvIDg2XzQwMF8wMDApICsgMSkpO1xyXG4gIGNvbnN0IGN1cnJlbnRXZWVrID0gTWF0aC5mbG9vcigoY2hhbGxlbmdlRGF5IC0gMSkgLyA3KTtcclxuICBjb25zdCB3ZWVrbHlDb3VudHMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBNYXRoLm1pbig4LCBNYXRoLmNlaWwoc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDcpKSB9LCAoXywgZGlzcGxheUluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB3ZWVrSW5kZXggPSBNYXRoLm1heCgwLCBjdXJyZW50V2VlayAtIDMpICsgZGlzcGxheUluZGV4O1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgd2Vlazogd2Vla0luZGV4LFxyXG4gICAgICBjb3VudDogc3RvcmUuc2Vzc2lvbnMuZmlsdGVyKChzZXNzaW9uKSA9PiBNYXRoLmZsb29yKChuZXcgRGF0ZShgJHtzZXNzaW9uLmRhdGV9VDEyOjAwOjAwYCkuZ2V0VGltZSgpIC0gY2hhbGxlbmdlU3RhcnQuZ2V0VGltZSgpKSAvICg3ICogODZfNDAwXzAwMCkpID09PSB3ZWVrSW5kZXgpLmxlbmd0aCxcclxuICAgIH07XHJcbiAgfSkuZmlsdGVyKChpdGVtKSA9PiBpdGVtLndlZWsgPCBNYXRoLmNlaWwoc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDcpKTtcclxuICBjb25zdCBtYXhXZWVrbHkgPSBNYXRoLm1heChzdG9yZS5jaGFsbGVuZ2UuZGF5c1BlcldlZWssIC4uLndlZWtseUNvdW50cy5tYXAoKGl0ZW0pID0+IGl0ZW0uY291bnQpKTtcclxuICBjb25zdCBmYXN0Q2hhbmdlID0gKCgpID0+IHtcclxuICAgIGlmICghd2VpZ2h0Rm9ybS53ZWlnaHQgfHwgIXNvcnRlZFdlaWdodHMubGVuZ3RoKSByZXR1cm4gZmFsc2U7XHJcbiAgICBjb25zdCBwcmV2aW91cyA9IHNvcnRlZFdlaWdodHMuYXQoLTEpITtcclxuICAgIGNvbnN0IGRheXMgPSBNYXRoLm1heCgxLCBNYXRoLmFicygobmV3IERhdGUoYCR7d2VpZ2h0Rm9ybS5kYXRlfVQxMjowMDowMGApLmdldFRpbWUoKSAtIG5ldyBEYXRlKGAke3ByZXZpb3VzLmRhdGV9VDEyOjAwOjAwYCkuZ2V0VGltZSgpKSAvIDg2XzQwMF8wMDApKTtcclxuICAgIGNvbnN0IGNoYW5nZUtnID0gTWF0aC5hYnMoTnVtYmVyKHdlaWdodEZvcm0ud2VpZ2h0KSAtIHByZXZpb3VzLndlaWdodCkgKiAoc3RvcmUudXNlci51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gMSA6IC40NTM1OTIpO1xyXG4gICAgcmV0dXJuIGNoYW5nZUtnIC8gZGF5cyAqIDcgPiAxO1xyXG4gIH0pKCk7XHJcbiAgY29uc3QgdW5sb2NrVHJhY2tpbmdCYWRnZSA9IChpZDogc3RyaW5nLCBiYWRnZXMgPSBzdG9yZS5iYWRnZXMpID0+IGJhZGdlcy5tYXAoKGJhZGdlKSA9PiBiYWRnZS5pZCA9PT0gaWQgPyB7IC4uLmJhZGdlLCB1bmxvY2tlZDogdHJ1ZSwgZGF0ZTogYmFkZ2UuZGF0ZSB8fCBkYXRlS2V5KG5ldyBEYXRlKCkpIH0gOiBiYWRnZSk7XHJcblxyXG4gIGNvbnN0IG9wZW5XZWlnaHRNb2RhbCA9IChlbnRyeUluZGV4PzogbnVtYmVyKSA9PiB7XHJcbiAgICBpZiAoZW50cnlJbmRleCA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHNldEVkaXRpbmdXZWlnaHQobnVsbCk7XHJcbiAgICAgIHNldFdlaWdodEZvcm0oeyBkYXRlOiBkYXRlS2V5KG5ldyBEYXRlKCkpLCB3ZWlnaHQ6IFwiXCIsIHdhaXN0OiBcIlwiLCBoaXBzOiBcIlwiLCBjaGVzdDogXCJcIiB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IGVudHJ5ID0gc3RvcmUud2VpZ2h0c1tlbnRyeUluZGV4XTtcclxuICAgICAgc2V0RWRpdGluZ1dlaWdodChlbnRyeUluZGV4KTtcclxuICAgICAgc2V0V2VpZ2h0Rm9ybSh7IGRhdGU6IGVudHJ5LmRhdGUsIHdlaWdodDogU3RyaW5nKGVudHJ5LndlaWdodCksIHdhaXN0OiBTdHJpbmcoZW50cnkubWVhc3VyZW1lbnRzPy53YWlzdCA/PyBcIlwiKSwgaGlwczogU3RyaW5nKGVudHJ5Lm1lYXN1cmVtZW50cz8uaGlwcyA/PyBcIlwiKSwgY2hlc3Q6IFN0cmluZyhlbnRyeS5tZWFzdXJlbWVudHM/LmNoZXN0ID8/IFwiXCIpIH0pO1xyXG4gICAgfVxyXG4gICAgc2V0V2VpZ2h0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRTaG93V2VpZ2h0KHRydWUpO1xyXG4gIH07XHJcbiAgY29uc3Qgc2F2ZVdlaWdodCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHdlaWdodCA9IE51bWJlcih3ZWlnaHRGb3JtLndlaWdodCk7XHJcbiAgICBjb25zdCBtaW5XZWlnaHQgPSBzdG9yZS51c2VyLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyAyNSA6IDU1O1xyXG4gICAgY29uc3QgbWF4V2VpZ2h0ID0gc3RvcmUudXNlci51bml0U3lzdGVtID09PSBcIm1ldHJpY1wiID8gNDAwIDogODgwO1xyXG4gICAgY29uc3QgbWVhc3VyZW1lbnRzID0gW3dlaWdodEZvcm0ud2Fpc3QsIHdlaWdodEZvcm0uaGlwcywgd2VpZ2h0Rm9ybS5jaGVzdF0uZmlsdGVyKEJvb2xlYW4pLm1hcChOdW1iZXIpO1xyXG4gICAgY29uc3QgbWluTWVhc3VyZW1lbnQgPSBzdG9yZS51c2VyLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyAzMCA6IDEyO1xyXG4gICAgY29uc3QgbWF4TWVhc3VyZW1lbnQgPSBzdG9yZS51c2VyLnVuaXRTeXN0ZW0gPT09IFwibWV0cmljXCIgPyAzMDAgOiAxMjA7XHJcbiAgICBpZiAoIXdlaWdodEZvcm0uZGF0ZSB8fCAhd2VpZ2h0IHx8IHdlaWdodCA8IG1pbldlaWdodCB8fCB3ZWlnaHQgPiBtYXhXZWlnaHQgfHwgbWVhc3VyZW1lbnRzLnNvbWUoKHZhbHVlKSA9PiB2YWx1ZSA8IG1pbk1lYXN1cmVtZW50IHx8IHZhbHVlID4gbWF4TWVhc3VyZW1lbnQpKSB7XHJcbiAgICAgIHNldFdlaWdodEVycm9yKGBVc2UgJHttaW5XZWlnaHR94oCTJHttYXhXZWlnaHR9ICR7dW5pdH0gYW5kICR7bWluTWVhc3VyZW1lbnR94oCTJHttYXhNZWFzdXJlbWVudH0gJHttZWFzdXJlbWVudFVuaXR9IGZvciBtZWFzdXJlbWVudHMuYCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGVudHJ5ID0ge1xyXG4gICAgICBkYXRlOiB3ZWlnaHRGb3JtLmRhdGUsXHJcbiAgICAgIHdlaWdodCxcclxuICAgICAgbWVhc3VyZW1lbnRzOiB7XHJcbiAgICAgICAgd2Fpc3Q6IHdlaWdodEZvcm0ud2Fpc3QgPyBOdW1iZXIod2VpZ2h0Rm9ybS53YWlzdCkgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgaGlwczogd2VpZ2h0Rm9ybS5oaXBzID8gTnVtYmVyKHdlaWdodEZvcm0uaGlwcykgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgY2hlc3Q6IHdlaWdodEZvcm0uY2hlc3QgPyBOdW1iZXIod2VpZ2h0Rm9ybS5jaGVzdCkgOiB1bmRlZmluZWQsXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gICAgY29uc3Qgd2VpZ2h0cyA9IGVkaXRpbmdXZWlnaHQgPT09IG51bGwgPyBbLi4uc3RvcmUud2VpZ2h0cywgZW50cnldIDogc3RvcmUud2VpZ2h0cy5tYXAoKGl0ZW0sIGluZGV4KSA9PiBpbmRleCA9PT0gZWRpdGluZ1dlaWdodCA/IGVudHJ5IDogaXRlbSk7XHJcbiAgICBpZiAoIXVwZGF0ZSh7IC4uLnN0b3JlLCB3ZWlnaHRzLCB1c2VyOiB7IC4uLnN0b3JlLnVzZXIsIHdlaWdodDogU3RyaW5nKHdlaWdodCkgfSwgYmFkZ2VzOiB1bmxvY2tUcmFja2luZ0JhZGdlKFwid2VpZ2h0LTFcIikgfSkpIHJldHVybjtcclxuICAgIHNldFNob3dXZWlnaHQoZmFsc2UpO1xyXG4gICAgdG9hc3QoZWRpdGluZ1dlaWdodCA9PT0gbnVsbCA/IFwiV2VpZ2h0IGVudHJ5IHNhdmVkLlwiIDogXCJXZWlnaHQgZW50cnkgdXBkYXRlZC5cIik7XHJcbiAgfTtcclxuICBjb25zdCBjaG9vc2VQaG90byA9IChmaWxlPzogRmlsZSkgPT4ge1xyXG4gICAgc2V0UGhvdG9FcnJvcihcIlwiKTtcclxuICAgIGlmICghZmlsZSkgcmV0dXJuO1xyXG4gICAgaWYgKCFbXCJpbWFnZS9qcGVnXCIsIFwiaW1hZ2UvcG5nXCIsIFwiaW1hZ2Uvd2VicFwiXS5pbmNsdWRlcyhmaWxlLnR5cGUpKSByZXR1cm4gc2V0UGhvdG9FcnJvcihcIkNob29zZSBhIEpQRywgUE5HLCBvciBXZWJQIGltYWdlLlwiKTtcclxuICAgIGlmIChmaWxlLnNpemUgPiA1ICogMTAyNCAqIDEwMjQpIHJldHVybiBzZXRQaG90b0Vycm9yKFwiQ2hvb3NlIGFuIGltYWdlIHNtYWxsZXIgdGhhbiA1IE1CLlwiKTtcclxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcbiAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xyXG4gICAgICBjb25zdCBpbWFnZSA9IG5ldyBJbWFnZSgpO1xyXG4gICAgICBpbWFnZS5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc2NhbGUgPSBNYXRoLm1pbigxLCAxNjAwIC8gTWF0aC5tYXgoaW1hZ2Uud2lkdGgsIGltYWdlLmhlaWdodCkpO1xyXG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIik7XHJcbiAgICAgICAgY2FudmFzLndpZHRoID0gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChpbWFnZS53aWR0aCAqIHNjYWxlKSk7XHJcbiAgICAgICAgY2FudmFzLmhlaWdodCA9IE1hdGgubWF4KDEsIE1hdGgucm91bmQoaW1hZ2UuaGVpZ2h0ICogc2NhbGUpKTtcclxuICAgICAgICBjb25zdCBjb250ZXh0ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcclxuICAgICAgICBpZiAoIWNvbnRleHQpIHJldHVybiBzZXRQaG90b0Vycm9yKFwiV2UgY291bGRuJ3QgcHJlcGFyZSB0aGF0IGltYWdlLiBQbGVhc2UgdHJ5IGFub3RoZXIuXCIpO1xyXG4gICAgICAgIGNvbnRleHQuZHJhd0ltYWdlKGltYWdlLCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xyXG4gICAgICAgIHNldFBob3RvRm9ybSgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgaW1hZ2U6IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS93ZWJwXCIsIC44MikgfSkpO1xyXG4gICAgICB9O1xyXG4gICAgICBpbWFnZS5vbmVycm9yID0gKCkgPT4gc2V0UGhvdG9FcnJvcihcIldlIGNvdWxkbid0IHByZXZpZXcgdGhhdCBpbWFnZS4gUGxlYXNlIHRyeSBhbm90aGVyLlwiKTtcclxuICAgICAgaW1hZ2Uuc3JjID0gU3RyaW5nKHJlYWRlci5yZXN1bHQpO1xyXG4gICAgfTtcclxuICAgIHJlYWRlci5vbmVycm9yID0gKCkgPT4gc2V0UGhvdG9FcnJvcihcIldlIGNvdWxkbid0IHJlYWQgdGhhdCBpbWFnZS4gUGxlYXNlIHRyeSBhbm90aGVyLlwiKTtcclxuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xyXG4gIH07XHJcbiAgY29uc3Qgc2F2ZVBob3RvID0gKCkgPT4ge1xyXG4gICAgaWYgKCFwaG90b0Zvcm0uaW1hZ2UgfHwgIXBob3RvRm9ybS5kYXRlKSByZXR1cm4gc2V0UGhvdG9FcnJvcihcIkNob29zZSBhbiBpbWFnZSBhbmQgZGF0ZS5cIik7XHJcbiAgICBjb25zdCBwaG90b3MgPSBbLi4uc3RvcmUucGhvdG9zLCBwaG90b0Zvcm1dLnNvcnQoKGEsIGIpID0+IGEuZGF0ZS5sb2NhbGVDb21wYXJlKGIuZGF0ZSkpO1xyXG4gICAgaWYgKCF1cGRhdGUoeyAuLi5zdG9yZSwgcGhvdG9zLCBiYWRnZXM6IHVubG9ja1RyYWNraW5nQmFkZ2UoXCJwaG90by0xXCIpIH0pKSByZXR1cm47XHJcbiAgICBzZXRBZnRlckluZGV4KHBob3Rvcy5sZW5ndGggLSAxKTtcclxuICAgIHNldFNob3dQaG90byhmYWxzZSk7XHJcbiAgICBzZXRQaG90b0Zvcm0oeyBkYXRlOiBkYXRlS2V5KG5ldyBEYXRlKCkpLCBhbmdsZTogXCJGcm9udFwiLCBpbWFnZTogXCJcIiB9KTtcclxuICAgIHRvYXN0KFwiUHJvZ3Jlc3MgcGhvdG8gYWRkZWQuXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoYXJ0VmFsdWVzID0gc29ydGVkV2VpZ2h0cy5tYXAoKGVudHJ5KSA9PiBlbnRyeS53ZWlnaHQpO1xyXG4gIGNvbnN0IGNoYXJ0Qm91bmRzID0gWy4uLmNoYXJ0VmFsdWVzLCAuLi4odGFyZ2V0V2VpZ2h0ID8gW3RhcmdldFdlaWdodF0gOiBbXSldO1xyXG4gIGNvbnN0IGNoYXJ0TWluID0gY2hhcnRCb3VuZHMubGVuZ3RoID8gTWF0aC5taW4oLi4uY2hhcnRCb3VuZHMpIC0gMiA6IDA7XHJcbiAgY29uc3QgY2hhcnRNYXggPSBjaGFydEJvdW5kcy5sZW5ndGggPyBNYXRoLm1heCguLi5jaGFydEJvdW5kcykgKyAyIDogMTtcclxuICBjb25zdCBjaGFydFBvaW50ID0gKHZhbHVlOiBudW1iZXIsIGluZGV4OiBudW1iZXIpID0+ICh7XHJcbiAgICB4OiBzb3J0ZWRXZWlnaHRzLmxlbmd0aCA9PT0gMSA/IDQwIDogNDAgKyBpbmRleCAvIChzb3J0ZWRXZWlnaHRzLmxlbmd0aCAtIDEpICogNTYwLFxyXG4gICAgeTogMTkwIC0gKCh2YWx1ZSAtIGNoYXJ0TWluKSAvIE1hdGgubWF4KDEsIGNoYXJ0TWF4IC0gY2hhcnRNaW4pKSAqIDE1MCxcclxuICB9KTtcclxuICBjb25zdCBwb2ludHMgPSBzb3J0ZWRXZWlnaHRzLm1hcCgoZW50cnksIGluZGV4KSA9PiBjaGFydFBvaW50KGVudHJ5LndlaWdodCwgaW5kZXgpKTtcclxuICBjb25zdCBiYWRnZUNhdGFsb2cgPSBbXHJcbiAgICB7IGNhdGVnb3J5OiBcIlN0cmVha3NcIiwgaWQ6IFwic3RyZWFrLTNcIiwgbmFtZTogXCIzLWRheSBzdHJlYWtcIiwgdGFyZ2V0OiAzLCB2YWx1ZTogYmVzdFN0cmVhaywgZGV0YWlsOiBcIkNvbXBsZXRlIGEgd29ya291dCBvbiAzIGNvbnNlY3V0aXZlIGRheXMuXCIgfSxcclxuICAgIHsgY2F0ZWdvcnk6IFwiU3RyZWFrc1wiLCBpZDogXCJzdHJlYWstN1wiLCBuYW1lOiBcIjctZGF5IHN0cmVha1wiLCB0YXJnZXQ6IDcsIHZhbHVlOiBiZXN0U3RyZWFrLCBkZXRhaWw6IFwiQ29tcGxldGUgYSB3b3Jrb3V0IG9uIDcgY29uc2VjdXRpdmUgZGF5cy5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJTdHJlYWtzXCIsIGlkOiBcInN0cmVhay0xNFwiLCBuYW1lOiBcIjE0LWRheSBzdHJlYWtcIiwgdGFyZ2V0OiAxNCwgdmFsdWU6IGJlc3RTdHJlYWssIGRldGFpbDogXCJDb21wbGV0ZSBhIHdvcmtvdXQgb24gMTQgY29uc2VjdXRpdmUgZGF5cy5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJTdHJlYWtzXCIsIGlkOiBcInN0cmVhay0zMFwiLCBuYW1lOiBcIjMwLWRheSBzdHJlYWtcIiwgdGFyZ2V0OiAzMCwgdmFsdWU6IGJlc3RTdHJlYWssIGRldGFpbDogXCJCdWlsZCBhIGNvbnNpc3RlbnQgMzAtZGF5IHdvcmtvdXQgc3RyZWFrLlwiIH0sXHJcbiAgICB7IGNhdGVnb3J5OiBcIldvcmtvdXRzXCIsIGlkOiBcIndvcmtvdXQtMVwiLCBuYW1lOiBcIkZpcnN0IHdvcmtvdXRcIiwgdGFyZ2V0OiAxLCB2YWx1ZTogc3RvcmUuc2Vzc2lvbnMubGVuZ3RoLCBkZXRhaWw6IFwiRmluaXNoIGFuZCBzYXZlIHlvdXIgZmlyc3Qgd29ya291dC5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJXb3Jrb3V0c1wiLCBpZDogXCJ3b3Jrb3V0LTEwXCIsIG5hbWU6IFwiMTAgd29ya291dHNcIiwgdGFyZ2V0OiAxMCwgdmFsdWU6IHN0b3JlLnNlc3Npb25zLmxlbmd0aCwgZGV0YWlsOiBcIkZpbmlzaCAxMCB3b3Jrb3V0IHNlc3Npb25zLlwiIH0sXHJcbiAgICB7IGNhdGVnb3J5OiBcIldvcmtvdXRzXCIsIGlkOiBcIndvcmtvdXQtMjVcIiwgbmFtZTogXCIyNSB3b3Jrb3V0c1wiLCB0YXJnZXQ6IDI1LCB2YWx1ZTogc3RvcmUuc2Vzc2lvbnMubGVuZ3RoLCBkZXRhaWw6IFwiRmluaXNoIDI1IHdvcmtvdXQgc2Vzc2lvbnMuXCIgfSxcclxuICAgIHsgY2F0ZWdvcnk6IFwiV29ya291dHNcIiwgaWQ6IFwid29ya291dC01MFwiLCBuYW1lOiBcIjUwIHdvcmtvdXRzXCIsIHRhcmdldDogNTAsIHZhbHVlOiBzdG9yZS5zZXNzaW9ucy5sZW5ndGgsIGRldGFpbDogXCJGaW5pc2ggNTAgd29ya291dCBzZXNzaW9ucy5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJDaGFsbGVuZ2UgbWlsZXN0b25lc1wiLCBpZDogXCJ3ZWVrLTFcIiwgbmFtZTogXCJXZWVrIDEgZG9uZVwiLCB0YXJnZXQ6IHN0b3JlLmNoYWxsZW5nZS5kYXlzUGVyV2VlaywgdmFsdWU6IHN0b3JlLnNlc3Npb25zLmZpbHRlcigoc2Vzc2lvbikgPT4gbmV3IERhdGUoYCR7c2Vzc2lvbi5kYXRlfVQxMjowMDowMGApLmdldFRpbWUoKSA8IGNoYWxsZW5nZVN0YXJ0LmdldFRpbWUoKSArIDcgKiA4Nl80MDBfMDAwKS5sZW5ndGgsIGRldGFpbDogXCJDb21wbGV0ZSB5b3VyIHBsYW5uZWQgc2Vzc2lvbnMgaW4gdGhlIGZpcnN0IHdlZWsuXCIgfSxcclxuICAgIHsgY2F0ZWdvcnk6IFwiQ2hhbGxlbmdlIG1pbGVzdG9uZXNcIiwgaWQ6IFwiaGFsZndheVwiLCBuYW1lOiBcIkhhbGZ3YXlcIiwgdGFyZ2V0OiBNYXRoLmNlaWwoc3RvcmUuY2hhbGxlbmdlLmxlbmd0aCAvIDIpLCB2YWx1ZTogY2hhbGxlbmdlRGF5LCBkZXRhaWw6IFwiUmVhY2ggdGhlIGhhbGZ3YXkgcG9pbnQgb2YgeW91ciBjaGFsbGVuZ2UuXCIgfSxcclxuICAgIHsgY2F0ZWdvcnk6IFwiQ2hhbGxlbmdlIG1pbGVzdG9uZXNcIiwgaWQ6IFwiZmluaXNoXCIsIG5hbWU6IFwiRmluaXNoIGxpbmVcIiwgdGFyZ2V0OiBzdG9yZS5jaGFsbGVuZ2UubGVuZ3RoLCB2YWx1ZTogY2hhbGxlbmdlRGF5LCBkZXRhaWw6IFwiUmVhY2ggdGhlIGZpbmFsIGRheSBvZiB5b3VyIGNoYWxsZW5nZS5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJUcmFja2luZ1wiLCBpZDogXCJ3ZWlnaHQtMVwiLCBuYW1lOiBcIkZpcnN0IHdlaWdoLWluXCIsIHRhcmdldDogMSwgdmFsdWU6IHN0b3JlLndlaWdodHMubGVuZ3RoLCBkZXRhaWw6IFwiU2F2ZSB5b3VyIGZpcnN0IHdlaWdodCBlbnRyeS5cIiB9LFxyXG4gICAgeyBjYXRlZ29yeTogXCJUcmFja2luZ1wiLCBpZDogXCJwaG90by0xXCIsIG5hbWU6IFwiRmlyc3QgcGhvdG9cIiwgdGFyZ2V0OiAxLCB2YWx1ZTogc3RvcmUucGhvdG9zLmxlbmd0aCwgZGV0YWlsOiBcIkFkZCB5b3VyIGZpcnN0IHByaXZhdGUgcHJvZ3Jlc3MgcGhvdG8uXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IG5leHRCYWRnZSA9IGJhZGdlQ2F0YWxvZy5maW5kKChiYWRnZSkgPT4gYmFkZ2UudmFsdWUgPCBiYWRnZS50YXJnZXQpO1xyXG4gIGNvbnN0IHNlbGVjdGVkQmFkZ2VEYXRhID0gYmFkZ2VDYXRhbG9nLmZpbmQoKGJhZGdlKSA9PiBiYWRnZS5pZCA9PT0gc2VsZWN0ZWRCYWRnZSk7XHJcbiAgY29uc3QgcGhvdG9Hcm91cHMgPSBzdG9yZS5waG90b3MucmVkdWNlPFJlY29yZDxzdHJpbmcsIHsgcGhvdG86IEZpdG5lc3NTdG9yZVtcInBob3Rvc1wiXVtudW1iZXJdOyBpbmRleDogbnVtYmVyIH1bXT4+KChncm91cHMsIHBob3RvLCBpbmRleCkgPT4ge1xyXG4gICAgY29uc3Qgd2VlayA9IE1hdGgubWF4KDEsIE1hdGguZmxvb3IoKG5ldyBEYXRlKGAke3Bob3RvLmRhdGV9VDEyOjAwOjAwYCkuZ2V0VGltZSgpIC0gY2hhbGxlbmdlU3RhcnQuZ2V0VGltZSgpKSAvICg3ICogODZfNDAwXzAwMCkpICsgMSk7XHJcbiAgICBjb25zdCBrZXkgPSBgV2VlayAke3dlZWt9YDtcclxuICAgIGdyb3Vwc1trZXldID0gWy4uLihncm91cHNba2V5XSB8fCBbXSksIHsgcGhvdG8sIGluZGV4IH1dO1xyXG4gICAgcmV0dXJuIGdyb3VwcztcclxuICB9LCB7fSk7XHJcblxyXG4gIHJldHVybiA8PjxQYWdlSGVhZGVyIGV5ZWJyb3c9XCJZT1VSIFRSQU5TRk9STUFUSU9OXCIgdGl0bGU9XCJQcm9ncmVzc1wiIC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIndvcmtvdXQtdGFicyBwcm9ncmVzcy10YWJzXCIgcm9sZT1cInRhYmxpc3RcIiBhcmlhLWxhYmVsPVwiUHJvZ3Jlc3Mgdmlld3NcIj57W1tcIm92ZXJ2aWV3XCIsIFwiT3ZlcnZpZXdcIl0sIFtcImJvZHlcIiwgXCJCb2R5XCJdLCBbXCJwaG90b3NcIiwgXCJQaG90b3NcIl0sIFtcImJhZGdlc1wiLCBcIkJhZGdlc1wiXV0ubWFwKChbdmFsdWUsIGxhYmVsXSkgPT4gPGJ1dHRvbiBrZXk9e3ZhbHVlfSByb2xlPVwidGFiXCIgYXJpYS1zZWxlY3RlZD17dGFiID09PSB2YWx1ZX0gY2xhc3NOYW1lPXt0YWIgPT09IHZhbHVlID8gXCJhY3RpdmVcIiA6IFwiXCJ9IG9uQ2xpY2s9eygpID0+IHNldFRhYih2YWx1ZSBhcyBQcm9ncmVzc1RhYil9PntsYWJlbH08L2J1dHRvbj4pfTwvZGl2PlxyXG5cclxuICAgIHt0YWIgPT09IFwib3ZlcnZpZXdcIiAmJiA8ZGl2IGNsYXNzTmFtZT1cInByb2dyZXNzLW92ZXJ2aWV3XCI+XHJcbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInByb2dyZXNzLWhlcm9cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhcmdldC1yaW5nXCIgc3R5bGU9e3sgXCItLXRhcmdldC1wcm9ncmVzc1wiOiBgJHt0YXJnZXRQcm9ncmVzcyAqIDMuNn1kZWdgIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc30+PGRpdj48c3Ryb25nPnt0YXJnZXRQcm9ncmVzc30lPC9zdHJvbmc+PHNwYW4+VEFSR0VUIFBST0dSRVNTPC9zcGFuPjwvZGl2PjwvZGl2PlxyXG4gICAgICAgIDxkaXY+PHNtYWxsPlBIWVNJQ0FMIFBST0dSRVNTPC9zbWFsbD48aDI+e3N0b3JlLndlaWdodHMubGVuZ3RoID8gXCJZb3VyIHRyZW5kLCBhdCBhIGdsYW5jZS5cIiA6IFwiU3RhcnQgd2l0aCBvbmUgc2ltcGxlIGNoZWNrLWluLlwifTwvaDI+e3N0b3JlLndlaWdodHMubGVuZ3RoID8gPHA+PHN0cm9uZz57c3RhcnRXZWlnaHR9IHt1bml0fTwvc3Ryb25nPjxJY29uIG5hbWU9XCJhcnJvd1wiIC8+PHN0cm9uZz57Y3VycmVudFdlaWdodH0ge3VuaXR9PC9zdHJvbmc+PEljb24gbmFtZT1cImFycm93XCIgLz48c3Ryb25nPnt0YXJnZXRXZWlnaHQgPyBgJHt0YXJnZXRXZWlnaHR9ICR7dW5pdH1gIDogXCJTZXQgdGFyZ2V0XCJ9PC9zdHJvbmc+PC9wPiA6IDxwPkxvZyB5b3VyIHN0YXJ0aW5nIHdlaWdodCB0byBiZWdpbi48L3A+fTxCdXR0b24gb25DbGljaz17KCkgPT4geyBzZXRUYWIoXCJib2R5XCIpOyBvcGVuV2VpZ2h0TW9kYWwoKTsgfX0+e3N0b3JlLndlaWdodHMubGVuZ3RoID8gXCJMb2cgd2VpZ2h0XCIgOiBcIkFkZCBzdGFydGluZyB3ZWlnaHRcIn08L0J1dHRvbj48L2Rpdj5cclxuICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2dyZXNzLXN0YXQtZ3JpZFwiPlxyXG4gICAgICAgIHtbW1wiY2hlY2tcIiwgXCJXT1JLT1VUUyBDT01QTEVURURcIiwgU3RyaW5nKHN0b3JlLnNlc3Npb25zLmxlbmd0aCldLCBbXCJ0aW1lclwiLCBcIkFDVElWRSBUSU1FXCIsIGFjdGl2ZU1pbnV0ZXMgPCA2MCA/IGAke2FjdGl2ZU1pbnV0ZXN9bWAgOiBgJHsoYWN0aXZlTWludXRlcyAvIDYwKS50b0ZpeGVkKDEpfWhgXSwgW1wiZmxhbWVcIiwgXCJDVVJSRU5UIFNUUkVBS1wiLCBgJHtjdXJyZW50U3RyZWFrfSAke2N1cnJlbnRTdHJlYWsgPT09IDEgPyBcImRheVwiIDogXCJkYXlzXCJ9YF0sIFtcInN0YXJcIiwgXCJCRVNUIFNUUkVBS1wiLCBgJHtiZXN0U3RyZWFrfSAke2Jlc3RTdHJlYWsgPT09IDEgPyBcImRheVwiIDogXCJkYXlzXCJ9YF1dLm1hcCgoW2ljb24sIGxhYmVsLCB2YWx1ZV0pID0+IDxhcnRpY2xlIGtleT17bGFiZWx9PjxzcGFuIGNsYXNzTmFtZT1cImRhc2gtc3RhdC1pY29uXCI+PEljb24gbmFtZT17aWNvbiBhcyBcImNoZWNrXCIgfCBcInRpbWVyXCIgfCBcImZsYW1lXCIgfCBcInN0YXJcIn0gLz48L3NwYW4+PHNtYWxsPntsYWJlbH08L3NtYWxsPjxzdHJvbmc+e3ZhbHVlfTwvc3Ryb25nPjwvYXJ0aWNsZT4pfVxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwiY29uc2lzdGVuY3ktY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwicGFuZWwtaGVhZFwiPjxkaXY+PHNtYWxsPkNPTlNJU1RFTkNZPC9zbWFsbD48aDM+V29ya291dHMgYnkgd2VlazwvaDM+PC9kaXY+PHNwYW4+e3N0b3JlLnNlc3Npb25zLmxlbmd0aCA/IGAke3N0b3JlLnNlc3Npb25zLmxlbmd0aH0gdG90YWxgIDogXCJObyBzZXNzaW9ucyB5ZXRcIn08L3NwYW4+PC9kaXY+e3N0b3JlLnNlc3Npb25zLmxlbmd0aCA/IDw+PGRpdiBjbGFzc05hbWU9XCJjb25zaXN0ZW5jeS1iYXJzXCI+e3dlZWtseUNvdW50cy5tYXAoKGl0ZW0pID0+IDxkaXYga2V5PXtpdGVtLndlZWt9PjxpIGNsYXNzTmFtZT17aXRlbS53ZWVrID09PSBjdXJyZW50V2VlayA/IFwiY3VycmVudFwiIDogXCJcIn0gc3R5bGU9e3sgaGVpZ2h0OiBgJHtNYXRoLm1heCg4LCBpdGVtLmNvdW50IC8gbWF4V2Vla2x5ICogMTAwKX0lYCB9fSAvPjxzcGFuPld7aXRlbS53ZWVrICsgMX08L3NwYW4+PC9kaXY+KX08L2Rpdj48Lz4gOiA8RW1wdHlTdGF0ZSB0aXRsZT1cIllvdXIgcmh5dGhtIHdpbGwgYXBwZWFyIGhlcmVcIiBjb3B5PVwiQ29tcGxldGUgeW91ciBmaXJzdCB3b3Jrb3V0IHRvIHN0YXJ0IGJ1aWxkaW5nIGEgd2Vla2x5IGNvbnNpc3RlbmN5IHZpZXcuXCIgLz59PC9hcnRpY2xlPlxyXG4gICAgPC9kaXY+fVxyXG5cclxuICAgIHt0YWIgPT09IFwiYm9keVwiICYmIDxkaXYgY2xhc3NOYW1lPVwiYm9keS1wcm9ncmVzc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2dyZXNzLXNlY3Rpb24taGVhZFwiPjxkaXY+PHNtYWxsPkJPRFkgVFJBQ0tJTkc8L3NtYWxsPjxoMj5XZWlnaHQgb3ZlciB0aW1lPC9oMj48L2Rpdj48QnV0dG9uIG9uQ2xpY2s9eygpID0+IG9wZW5XZWlnaHRNb2RhbCgpfT5Mb2cgd2VpZ2h0PC9CdXR0b24+PC9kaXY+XHJcbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cIndlaWdodC1jaGFydC1jYXJkXCI+e3NvcnRlZFdlaWdodHMubGVuZ3RoID8gPD48c3ZnIGNsYXNzTmFtZT1cIndlaWdodC1jaGFydFwiIHZpZXdCb3g9XCIwIDAgNjQwIDIzMFwiIHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPVwiV2VpZ2h0IGVudHJpZXMgb3ZlciB0aW1lXCI+PGxpbmUgY2xhc3NOYW1lPVwiY2hhcnQtYXhpc1wiIHgxPVwiNDBcIiB5MT1cIjE5MFwiIHgyPVwiNjAwXCIgeTI9XCIxOTBcIiAvPnt0YXJnZXRXZWlnaHQgJiYgPD48bGluZSBjbGFzc05hbWU9XCJ0YXJnZXQtbGluZVwiIHgxPVwiNDBcIiB5MT17Y2hhcnRQb2ludCh0YXJnZXRXZWlnaHQsIDApLnl9IHgyPVwiNjAwXCIgeTI9e2NoYXJ0UG9pbnQodGFyZ2V0V2VpZ2h0LCAwKS55fSAvPjx0ZXh0IHg9XCI1OTZcIiB5PXtjaGFydFBvaW50KHRhcmdldFdlaWdodCwgMCkueSAtIDd9IHRleHRBbmNob3I9XCJlbmRcIj5UYXJnZXQge3RhcmdldFdlaWdodH0ge3VuaXR9PC90ZXh0PjwvPn08cG9seWxpbmUgcG9pbnRzPXtwb2ludHMubWFwKChwb2ludCkgPT4gYCR7cG9pbnQueH0sJHtwb2ludC55fWApLmpvaW4oXCIgXCIpfSAvPjxjaXJjbGUgY2xhc3NOYW1lPVwic3RhcnQtcG9pbnRcIiBjeD17cG9pbnRzWzBdLnh9IGN5PXtwb2ludHNbMF0ueX0gcj1cIjZcIiAvPntwb2ludHMubWFwKChwb2ludCwgaW5kZXgpID0+IDxjaXJjbGUga2V5PXtpbmRleH0gY3g9e3BvaW50Lnh9IGN5PXtwb2ludC55fSByPVwiNVwiIC8+KX08dGV4dCB4PXtwb2ludHNbMF0ueH0geT17cG9pbnRzWzBdLnkgLSAxMn0gdGV4dEFuY2hvcj1cIm1pZGRsZVwiPlN0YXJ0PC90ZXh0Pjwvc3ZnPjxkaXYgY2xhc3NOYW1lPVwid2VpZ2h0LWNoYXJ0LWRhdGVzXCI+PHNwYW4+e3ByZXR0eURhdGUoc29ydGVkV2VpZ2h0c1swXS5kYXRlKX08L3NwYW4+PHNwYW4+e3ByZXR0eURhdGUoc29ydGVkV2VpZ2h0cy5hdCgtMSkhLmRhdGUpfTwvc3Bhbj48L2Rpdj48Lz4gOiA8RW1wdHlTdGF0ZSB0aXRsZT1cIk5vIGVudHJpZXMgeWV0LlwiIGNvcHk9XCJZb3VyIGZpcnN0IHdlaWdoLWluIGJlY29tZXMgeW91ciBzdGFydGluZyBwb2ludC5cIiAvPn08L2FydGljbGU+XHJcbiAgICAgIHtzb3J0ZWRXZWlnaHRzLmxlbmd0aCA+IDAgJiYgPGFydGljbGUgY2xhc3NOYW1lPVwid2VpZ2h0LWVudHJ5LWxpc3RcIj48ZGl2IGNsYXNzTmFtZT1cInBhbmVsLWhlYWRcIj48ZGl2PjxzbWFsbD5FTlRSSUVTPC9zbWFsbD48aDM+WW91ciBjaGVjay1pbnM8L2gzPjwvZGl2PjwvZGl2Pntzb3J0ZWRXZWlnaHRzLnNsaWNlKCkucmV2ZXJzZSgpLm1hcCgoZW50cnkpID0+IDxkaXYga2V5PXtgJHtlbnRyeS5kYXRlfS0ke2VudHJ5LnNvdXJjZUluZGV4fWB9PjxkaXY+PHN0cm9uZz57ZW50cnkud2VpZ2h0fSB7dW5pdH08L3N0cm9uZz48c3Bhbj57cHJldHR5RGF0ZShlbnRyeS5kYXRlKX17ZW50cnkubWVhc3VyZW1lbnRzICYmIE9iamVjdC52YWx1ZXMoZW50cnkubWVhc3VyZW1lbnRzKS5zb21lKEJvb2xlYW4pID8gYCDCtyBNZWFzdXJlbWVudHMgYWRkZWRgIDogXCJcIn08L3NwYW4+PC9kaXY+PGRpdj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9wZW5XZWlnaHRNb2RhbChlbnRyeS5zb3VyY2VJbmRleCl9PkVkaXQ8L2J1dHRvbj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHsgdXBkYXRlKHsgLi4uc3RvcmUsIHdlaWdodHM6IHN0b3JlLndlaWdodHMuZmlsdGVyKChfLCBpbmRleCkgPT4gaW5kZXggIT09IGVudHJ5LnNvdXJjZUluZGV4KSB9KTsgdG9hc3QoXCJXZWlnaHQgZW50cnkgZGVsZXRlZC5cIik7IH19PkRlbGV0ZTwvYnV0dG9uPjwvZGl2PjwvZGl2Pil9PC9hcnRpY2xlPn1cclxuICAgIDwvZGl2Pn1cclxuXHJcbiAgICB7dGFiID09PSBcInBob3Rvc1wiICYmIDxkaXYgY2xhc3NOYW1lPVwicGhvdG9zLXByb2dyZXNzXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3Mtc2VjdGlvbi1oZWFkXCI+PGRpdj48c21hbGw+UEhPVE8gTE9HPC9zbWFsbD48aDI+UHJvZ3Jlc3MgcGhvdG9zPC9oMj48cD5Zb3VyIHBob3RvcyBhcmUgcHJpdmF0ZSBhbmQgb25seSB2aXNpYmxlIHRvIHlvdS48L3A+PC9kaXY+PGRpdj57c3RvcmUucGhvdG9zLmxlbmd0aCA+PSAyICYmIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgb25DbGljaz17KCkgPT4gc2V0Q29tcGFyZU1vZGUoKHZhbHVlKSA9PiAhdmFsdWUpfT57Y29tcGFyZU1vZGUgPyBcIlZpZXcgZ2FsbGVyeVwiIDogXCJDb21wYXJlXCJ9PC9CdXR0b24+fTxCdXR0b24gb25DbGljaz17KCkgPT4geyBzZXRQaG90b0Vycm9yKFwiXCIpOyBzZXRTaG93UGhvdG8odHJ1ZSk7IH19PkFkZCBwcm9ncmVzcyBwaG90bzwvQnV0dG9uPjwvZGl2PjwvZGl2PlxyXG4gICAgICB7Y29tcGFyZU1vZGUgJiYgc3RvcmUucGhvdG9zLmxlbmd0aCA+PSAyID8gPGFydGljbGUgY2xhc3NOYW1lPVwicGhvdG8tY29tcGFyZVwiPjxkaXYgY2xhc3NOYW1lPVwiY29tcGFyZS1waWNrZXJzXCI+PGxhYmVsPkJlZm9yZTxzZWxlY3QgdmFsdWU9e2JlZm9yZUluZGV4fSBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRCZWZvcmVJbmRleChOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSl9PntzdG9yZS5waG90b3MubWFwKChwaG90bywgaW5kZXgpID0+IDxvcHRpb24gdmFsdWU9e2luZGV4fSBrZXk9e2Ake3Bob3RvLmRhdGV9LSR7aW5kZXh9YH0+e3ByZXR0eURhdGUocGhvdG8uZGF0ZSl9IMK3IHtwaG90by5hbmdsZSB8fCBcIkZyb250XCJ9PC9vcHRpb24+KX08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5BZnRlcjxzZWxlY3QgdmFsdWU9e2FmdGVySW5kZXh9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEFmdGVySW5kZXgoTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSkpfT57c3RvcmUucGhvdG9zLm1hcCgocGhvdG8sIGluZGV4KSA9PiA8b3B0aW9uIHZhbHVlPXtpbmRleH0ga2V5PXtgJHtwaG90by5kYXRlfS0ke2luZGV4fWB9PntwcmV0dHlEYXRlKHBob3RvLmRhdGUpfSDCtyB7cGhvdG8uYW5nbGUgfHwgXCJGcm9udFwifTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImNvbXBhcmUtc3RhZ2VcIiBzdHlsZT17eyBcIi0tY29tcGFyZS1wb3NpdGlvblwiOiBgJHtjb21wYXJlUG9zaXRpb259JWAgfSBhcyBSZWFjdC5DU1NQcm9wZXJ0aWVzfT48aW1nIHNyYz17c3RvcmUucGhvdG9zW2JlZm9yZUluZGV4XT8uaW1hZ2V9IGFsdD17YFByb2dyZXNzIG9uICR7cHJldHR5RGF0ZShzdG9yZS5waG90b3NbYmVmb3JlSW5kZXhdPy5kYXRlKX1gfSAvPjxkaXY+PGltZyBzcmM9e3N0b3JlLnBob3Rvc1thZnRlckluZGV4XT8uaW1hZ2V9IGFsdD17YFByb2dyZXNzIG9uICR7cHJldHR5RGF0ZShzdG9yZS5waG90b3NbYWZ0ZXJJbmRleF0/LmRhdGUpfWB9IC8+PC9kaXY+PGkgLz48L2Rpdj48bGFiZWwgY2xhc3NOYW1lPVwiY29tcGFyZS1zbGlkZXJcIj5EcmFnIHRvIGNvbXBhcmU8aW5wdXQgdHlwZT1cInJhbmdlXCIgbWluPVwiMFwiIG1heD1cIjEwMFwiIHZhbHVlPXtjb21wYXJlUG9zaXRpb259IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldENvbXBhcmVQb3NpdGlvbihOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSl9IC8+PC9sYWJlbD48L2FydGljbGU+XHJcbiAgICAgICAgOiBzdG9yZS5waG90b3MubGVuZ3RoID8gPGRpdiBjbGFzc05hbWU9XCJwaG90by13ZWVrc1wiPntPYmplY3QuZW50cmllcyhwaG90b0dyb3VwcykubWFwKChbd2VlaywgcGhvdG9zXSkgPT4gPHNlY3Rpb24ga2V5PXt3ZWVrfT48aDM+e3dlZWt9PC9oMz48ZGl2PntwaG90b3MubWFwKCh7IHBob3RvLCBpbmRleCB9KSA9PiA8YXJ0aWNsZSBrZXk9e2Ake3Bob3RvLmRhdGV9LSR7aW5kZXh9YH0+PGltZyBzcmM9e3Bob3RvLmltYWdlfSBhbHQ9e2Ake3Bob3RvLmFuZ2xlIHx8IFwiRnJvbnRcIn0gcHJvZ3Jlc3MgdmlldyBmcm9tICR7cHJldHR5RGF0ZShwaG90by5kYXRlKX1gfSAvPjxkaXY+PHNwYW4+PHN0cm9uZz57cGhvdG8uYW5nbGUgfHwgXCJGcm9udFwifTwvc3Ryb25nPjxzbWFsbD57cHJldHR5RGF0ZShwaG90by5kYXRlKX08L3NtYWxsPjwvc3Bhbj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHsgdXBkYXRlKHsgLi4uc3RvcmUsIHBob3Rvczogc3RvcmUucGhvdG9zLmZpbHRlcigoXywgcGhvdG9JbmRleCkgPT4gcGhvdG9JbmRleCAhPT0gaW5kZXgpIH0pOyB0b2FzdChcIlBob3RvIGRlbGV0ZWQuXCIpOyB9fT5EZWxldGU8L2J1dHRvbj48L2Rpdj48L2FydGljbGU+KX08L2Rpdj48L3NlY3Rpb24+KX08L2Rpdj5cclxuICAgICAgICAgIDogPGRpdiBjbGFzc05hbWU9XCJwaG90by1lbXB0eVwiPjxzcGFuPjxJY29uIG5hbWU9XCJjYW1lcmFcIiAvPjwvc3Bhbj48aDM+VGFrZSB5b3VyIERheSAxIHBob3RvPC9oMz48cD5BIHByaXZhdGUgcGhvdG8gY2FuIGhlbHAgeW91IG5vdGljZSBjaGFuZ2VzIHRoYXQgbnVtYmVycyBtYXkgbm90IGNhcHR1cmUuPC9wPjxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd1Bob3RvKHRydWUpfT5BZGQgcHJvZ3Jlc3MgcGhvdG88L0J1dHRvbj48L2Rpdj59XHJcbiAgICA8L2Rpdj59XHJcblxyXG4gICAge3RhYiA9PT0gXCJiYWRnZXNcIiAmJiA8ZGl2IGNsYXNzTmFtZT1cImJhZGdlcy1wcm9ncmVzc1wiPlxyXG4gICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJiYWRnZS1zdW1tYXJ5XCI+PHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UtZmxhbWVcIj48SWNvbiBuYW1lPVwiZmxhbWVcIiAvPjwvc3Bhbj48ZGl2PjxzbWFsbD5DVVJSRU5UIFNUUkVBSzwvc21hbGw+PHN0cm9uZz57Y3VycmVudFN0cmVha30ge2N1cnJlbnRTdHJlYWsgPT09IDEgPyBcImRheVwiIDogXCJkYXlzXCJ9PC9zdHJvbmc+PC9kaXY+e25leHRCYWRnZSAmJiA8ZGl2IGNsYXNzTmFtZT1cIm5leHQtYmFkZ2VcIj48c3Bhbj5OZXh0OiA8c3Ryb25nPntuZXh0QmFkZ2UubmFtZX08L3N0cm9uZz48L3NwYW4+PGRpdj48aSBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5taW4oMTAwLCBuZXh0QmFkZ2UudmFsdWUgLyBuZXh0QmFkZ2UudGFyZ2V0ICogMTAwKX0lYCB9fSAvPjwvZGl2PjxzbWFsbD57TWF0aC5taW4obmV4dEJhZGdlLnZhbHVlLCBuZXh0QmFkZ2UudGFyZ2V0KX0ve25leHRCYWRnZS50YXJnZXR9PC9zbWFsbD48L2Rpdj59PC9hcnRpY2xlPlxyXG4gICAgICB7W1wiU3RyZWFrc1wiLCBcIldvcmtvdXRzXCIsIFwiQ2hhbGxlbmdlIG1pbGVzdG9uZXNcIiwgXCJUcmFja2luZ1wiXS5tYXAoKGNhdGVnb3J5KSA9PiA8c2VjdGlvbiBjbGFzc05hbWU9XCJiYWRnZS1jYXRlZ29yeVwiIGtleT17Y2F0ZWdvcnl9PjxoMj57Y2F0ZWdvcnl9PC9oMj48ZGl2PntiYWRnZUNhdGFsb2cuZmlsdGVyKChiYWRnZSkgPT4gYmFkZ2UuY2F0ZWdvcnkgPT09IGNhdGVnb3J5KS5tYXAoKGJhZGdlKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc3RvcmVkQmFkZ2UgPSBzdG9yZS5iYWRnZXMuZmluZCgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gYmFkZ2UuaWQpO1xyXG4gICAgICAgIGNvbnN0IHVubG9ja2VkID0gQm9vbGVhbihzdG9yZWRCYWRnZT8udW5sb2NrZWQgfHwgYmFkZ2UudmFsdWUgPj0gYmFkZ2UudGFyZ2V0KTtcclxuICAgICAgICByZXR1cm4gPGJ1dHRvbiBjbGFzc05hbWU9e3VubG9ja2VkID8gXCJ1bmxvY2tlZFwiIDogXCJcIn0ga2V5PXtiYWRnZS5pZH0gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRCYWRnZShiYWRnZS5pZCl9PjxzcGFuPjxJY29uIG5hbWU9e3VubG9ja2VkID8gXCJzdGFyXCIgOiBcImJvbHRcIn0gLz48L3NwYW4+PHN0cm9uZz57YmFkZ2UubmFtZX08L3N0cm9uZz48c21hbGw+e3VubG9ja2VkID8gYFVubG9ja2VkICR7c3RvcmVkQmFkZ2U/LmRhdGUgPyBwcmV0dHlEYXRlKHN0b3JlZEJhZGdlLmRhdGUpIDogXCJ0b2RheVwifWAgOiBgJHtNYXRoLm1pbihiYWRnZS52YWx1ZSwgYmFkZ2UudGFyZ2V0KX0vJHtiYWRnZS50YXJnZXR9YH08L3NtYWxsPjwvYnV0dG9uPjtcclxuICAgICAgfSl9PC9kaXY+PC9zZWN0aW9uPil9XHJcbiAgICAgIHtzZWxlY3RlZEJhZGdlRGF0YSAmJiA8ZGl2IGNsYXNzTmFtZT1cImJhZGdlLWRldGFpbFwiPjxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRCYWRnZShudWxsKX0gYXJpYS1sYWJlbD1cIkNsb3NlIGJhZGdlIGRldGFpbFwiPjxJY29uIG5hbWU9XCJjbG9zZVwiIC8+PC9idXR0b24+PHNwYW4+PEljb24gbmFtZT1cInN0YXJcIiAvPjwvc3Bhbj48c21hbGw+e3NlbGVjdGVkQmFkZ2VEYXRhLmNhdGVnb3J5fTwvc21hbGw+PGgzPntzZWxlY3RlZEJhZGdlRGF0YS5uYW1lfTwvaDM+PHA+e3NlbGVjdGVkQmFkZ2VEYXRhLmRldGFpbH08L3A+PHN0cm9uZz57TWF0aC5taW4oc2VsZWN0ZWRCYWRnZURhdGEudmFsdWUsIHNlbGVjdGVkQmFkZ2VEYXRhLnRhcmdldCl9L3tzZWxlY3RlZEJhZGdlRGF0YS50YXJnZXR9IGNvbXBsZXRlPC9zdHJvbmc+PC9kaXY+fVxyXG4gICAgPC9kaXY+fVxyXG5cclxuICAgIHtzaG93V2VpZ2h0ICYmIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtbW9kYWwtYmFja2Ryb3BcIiBvbk1vdXNlRG93bj17KCkgPT4gc2V0U2hvd1dlaWdodChmYWxzZSl9PjxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtbW9kYWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsPVwiTG9nIHdlaWdodFwiIG9uTW91c2VEb3duPXsoZXZlbnQpID0+IGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpfT48aGVhZGVyPjxkaXY+PHNtYWxsPkJPRFkgQ0hFQ0stSU48L3NtYWxsPjxoMj57ZWRpdGluZ1dlaWdodCA9PT0gbnVsbCA/IFwiTG9nIHdlaWdodFwiIDogXCJFZGl0IGVudHJ5XCJ9PC9oMj48L2Rpdj48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dXZWlnaHQoZmFsc2UpfSBhcmlhLWxhYmVsPVwiQ2xvc2VcIj48SWNvbiBuYW1lPVwiY2xvc2VcIiAvPjwvYnV0dG9uPjwvaGVhZGVyPjxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtZm9ybVwiPjxsYWJlbD5EYXRlPGlucHV0IHR5cGU9XCJkYXRlXCIgdmFsdWU9e3dlaWdodEZvcm0uZGF0ZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0V2VpZ2h0Rm9ybSh7IC4uLndlaWdodEZvcm0sIGRhdGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0gLz48L2xhYmVsPjxsYWJlbD5XZWlnaHQgKHt1bml0fSk8aW5wdXQgdHlwZT1cIm51bWJlclwiIHN0ZXA9XCIuMVwiIHZhbHVlPXt3ZWlnaHRGb3JtLndlaWdodH0gb25DaGFuZ2U9eyhldmVudCkgPT4geyBzZXRXZWlnaHRGb3JtKHsgLi4ud2VpZ2h0Rm9ybSwgd2VpZ2h0OiBldmVudC50YXJnZXQudmFsdWUgfSk7IHNldFdlaWdodEVycm9yKFwiXCIpOyB9fSAvPjwvbGFiZWw+PHNwYW4+T1BUSU9OQUwgTUVBU1VSRU1FTlRTIMK3IHttZWFzdXJlbWVudFVuaXQudG9VcHBlckNhc2UoKX08L3NwYW4+PGxhYmVsPldhaXN0PGlucHV0IHR5cGU9XCJudW1iZXJcIiBzdGVwPVwiLjFcIiB2YWx1ZT17d2VpZ2h0Rm9ybS53YWlzdH0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0V2VpZ2h0Rm9ybSh7IC4uLndlaWdodEZvcm0sIHdhaXN0OiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48bGFiZWw+SGlwczxpbnB1dCB0eXBlPVwibnVtYmVyXCIgc3RlcD1cIi4xXCIgdmFsdWU9e3dlaWdodEZvcm0uaGlwc30gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0V2VpZ2h0Rm9ybSh7IC4uLndlaWdodEZvcm0sIGhpcHM6IGV2ZW50LnRhcmdldC52YWx1ZSB9KX0gLz48L2xhYmVsPjxsYWJlbD5DaGVzdDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgc3RlcD1cIi4xXCIgdmFsdWU9e3dlaWdodEZvcm0uY2hlc3R9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFdlaWdodEZvcm0oeyAuLi53ZWlnaHRGb3JtLCBjaGVzdDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pfSAvPjwvbGFiZWw+PC9kaXY+e2Zhc3RDaGFuZ2UgJiYgPHAgY2xhc3NOYW1lPVwiZ2VudGxlLW5vdGVcIj5UaGF0J3MgYSBmYXN0IGNoYW5nZS4gR3JhZHVhbCBwcm9ncmVzcyBpcyBzYWZlcjsgd2UnbGwga2VlcCB5b3VyIHBsYW4gcGFjZWQuPC9wPn17d2VpZ2h0RXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiaW5saW5lLXZhbGlkYXRpb25cIj57d2VpZ2h0RXJyb3J9PC9wPn08QnV0dG9uIG9uQ2xpY2s9e3NhdmVXZWlnaHR9PlNhdmUgZW50cnk8L0J1dHRvbj48L2Rpdj48L2Rpdj59XHJcbiAgICB7c2hvd1Bob3RvICYmIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtbW9kYWwtYmFja2Ryb3BcIiBvbk1vdXNlRG93bj17KCkgPT4gc2V0U2hvd1Bob3RvKGZhbHNlKX0+PGRpdiBjbGFzc05hbWU9XCJwcm9ncmVzcy1tb2RhbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJBZGQgcHJvZ3Jlc3MgcGhvdG9cIiBvbk1vdXNlRG93bj17KGV2ZW50KSA9PiBldmVudC5zdG9wUHJvcGFnYXRpb24oKX0+PGhlYWRlcj48ZGl2PjxzbWFsbD5QUklWQVRFIFBIT1RPIExPRzwvc21hbGw+PGgyPkFkZCBwcm9ncmVzcyBwaG90bzwvaDI+PC9kaXY+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGhvdG8oZmFsc2UpfSBhcmlhLWxhYmVsPVwiQ2xvc2VcIj48SWNvbiBuYW1lPVwiY2xvc2VcIiAvPjwvYnV0dG9uPjwvaGVhZGVyPjxsYWJlbCBjbGFzc05hbWU9XCJwaG90by11cGxvYWRcIj57cGhvdG9Gb3JtLmltYWdlID8gPGltZyBzcmM9e3Bob3RvRm9ybS5pbWFnZX0gYWx0PVwiU2VsZWN0ZWQgcHJvZ3Jlc3MgcHJldmlld1wiIC8+IDogPHNwYW4+PEljb24gbmFtZT1cImNhbWVyYVwiIC8+PHN0cm9uZz5DaG9vc2UgYSBwaG90bzwvc3Ryb25nPjxzbWFsbD5KUEcsIFBORyBvciBXZWJQIMK3IG1heCA1IE1CPC9zbWFsbD48L3NwYW4+fTxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5qcGcsLmpwZWcsLnBuZywud2VicCxpbWFnZS9qcGVnLGltYWdlL3BuZyxpbWFnZS93ZWJwXCIgb25DaGFuZ2U9eyhldmVudCkgPT4gY2hvb3NlUGhvdG8oZXZlbnQudGFyZ2V0LmZpbGVzPy5bMF0pfSAvPjwvbGFiZWw+PGRpdiBjbGFzc05hbWU9XCJwcm9ncmVzcy1mb3JtIHBob3RvLW1ldGFcIj48bGFiZWw+RGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtwaG90b0Zvcm0uZGF0ZX0gb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0UGhvdG9Gb3JtKHsgLi4ucGhvdG9Gb3JtLCBkYXRlOiBldmVudC50YXJnZXQudmFsdWUgfSl9IC8+PC9sYWJlbD48bGFiZWw+QW5nbGU8c2VsZWN0IHZhbHVlPXtwaG90b0Zvcm0uYW5nbGV9IG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBob3RvRm9ybSh7IC4uLnBob3RvRm9ybSwgYW5nbGU6IGV2ZW50LnRhcmdldC52YWx1ZSBhcyBcIkZyb250XCIgfCBcIlNpZGVcIiB8IFwiQmFja1wiIH0pfT48b3B0aW9uPkZyb250PC9vcHRpb24+PG9wdGlvbj5TaWRlPC9vcHRpb24+PG9wdGlvbj5CYWNrPC9vcHRpb24+PC9zZWxlY3Q+PC9sYWJlbD48L2Rpdj57cGhvdG9FcnJvciAmJiA8cCBjbGFzc05hbWU9XCJpbmxpbmUtdmFsaWRhdGlvblwiPntwaG90b0Vycm9yfTwvcD59PEJ1dHRvbiBvbkNsaWNrPXtzYXZlUGhvdG99PlNhdmUgcGhvdG88L0J1dHRvbj48cCBjbGFzc05hbWU9XCJwcml2YWN5LWxpbmVcIj5Zb3VyIHBob3RvcyBhcmUgcHJpdmF0ZSBhbmQgb25seSB2aXNpYmxlIHRvIHlvdS48L3A+PC9kaXY+PC9kaXY+fVxyXG4gIDwvPjtcclxufVxyXG4iXX0=