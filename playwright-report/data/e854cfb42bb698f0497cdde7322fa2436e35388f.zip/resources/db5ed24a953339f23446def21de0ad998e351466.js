import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/BodyMap.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/BodyMap.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b6534b64";
export function BodyMap({ gender, orientation, selected, fullBody, disabled, onSelect }) {
	const armWidth = gender === "Man" ? 0 : 3;
	const zones = [
		{
			key: "shoulders",
			muscle: "Shoulders",
			d: "M77 88c9-10 18-13 31-13l7 18-25 13Zm86 0c-9-10-18-13-31-13l-7 18 25 13Z"
		},
		{
			key: "chest",
			muscle: "Chest",
			d: "M99 98c10-6 16-5 21 1v34c-13 1-24-4-29-13Zm42 0c-10-6-16-5-21 1v34c13 1 24-4 29-13Z"
		},
		{
			key: "core",
			muscle: "Core",
			d: "M103 137c11 3 23 3 34 0l-2 59h-30Z"
		},
		{
			key: "quads",
			muscle: "Quads",
			d: "M91 207c8-6 18-7 27-2l-8 91-24-2Zm58 0c-8-6-18-7-27-2l8 91 24-2Z"
		},
		{
			key: "calves",
			muscle: "Calves",
			d: "M86 302h24l-5 80H89Zm68 0h-24l5 80h16Z"
		},
		...orientation === "Front" ? [{
			key: "biceps-left",
			muscle: "Biceps",
			d: `M${70 + armWidth} 106c8-5 15 1 14 10l-6 38-15-3 4-34Z`
		}, {
			key: "biceps-right",
			muscle: "Biceps",
			d: `M${170 - armWidth} 106c-8-5-15 1-14 10l6 38 15-3-4-34Z`
		}] : [{
			key: "triceps-left",
			muscle: "Triceps",
			d: `M${70 + armWidth} 104c9-3 15 3 13 12l-7 39-15-5 5-34Z`
		}, {
			key: "triceps-right",
			muscle: "Triceps",
			d: `M${170 - armWidth} 104c-9-3-15 3-13 12l7 39 15-5-5-34Z`
		}],
		{
			key: "forearms-left",
			muscle: "Forearms",
			d: `M${61 + armWidth} 154l15 5-13 48-15-4Z`
		},
		{
			key: "forearms-right",
			muscle: "Forearms",
			d: `M${179 - armWidth} 154l-15 5 13 48 15-4Z`
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "body-wrap",
		children: [/* @__PURE__ */ _jsxDEV("svg", {
			className: `body-svg body-${gender.toLowerCase()} orientation-${orientation.toLowerCase()} ${disabled ? "is-disabled" : ""}`,
			viewBox: "0 0 240 410",
			role: "img",
			"aria-label": `${gender} ${orientation.toLowerCase()} muscle map`,
			focusable: "false",
			children: [
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "120",
					cy: "39",
					rx: "24",
					ry: "28",
					className: "body-base"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "body-base",
					d: gender === "Man" ? "M91 77c18-14 40-14 58 0l25 99-24 30 6 94-4 98h-23l-9-126-9 126H88l-4-98 6-94-24-30Z" : "M96 77c16-12 32-12 48 0l17 93-25 34 17 95-2 99h-22l-9-126-9 126H89l-2-99 17-95-25-34Z"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "body-base",
					d: "m91 84-26 16-22 112 17 4 34-100Zm58 0 26 16 22 112-17 4-34-100Z"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				zones.map((zone) => /* @__PURE__ */ _jsxDEV("path", {
					d: zone.d,
					className: `muscle-zone ${fullBody ? "full-body-selected" : selected === zone.muscle ? "selected" : ""}`,
					onClick: () => !disabled && onSelect(zone.muscle),
					role: "button",
					tabIndex: disabled ? -1 : 0,
					"aria-disabled": disabled,
					"aria-label": `${selected === zone.muscle ? "Deselect" : "Select"} ${zone.muscle}`,
					onKeyDown: (event) => !disabled && (event.key === "Enter" || event.key === " ") && onSelect(zone.muscle),
					children: /* @__PURE__ */ _jsxDEV("title", { children: zone.muscle }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this)
				}, zone.key, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 11
				}, this)),
				/* @__PURE__ */ _jsxDEV("path", {
					className: "body-lines",
					d: "M120 73v126M92 207l28-8 28 8M105 137h30M92 300h56"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: `map-hint ${selected || fullBody ? "hidden" : ""}`,
			children: "Click any muscle group or tap 'Full Body' to begin"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
}
_c = BodyMap;
var _c;
$RefreshReg$(_c, "BodyMap");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/frontend/components/BodyMap.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/BodyMap.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/BodyMap.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Documents/ChatGPT/soft_eng_project/soferfit-web-development/src/frontend/components/BodyMap.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFFQSxPQUFPLFNBQVMsUUFBUSxFQUN0QixRQUNBLGFBQ0EsVUFDQSxVQUNBLFVBQ0EsWUFRQztDQUNELE1BQU0sV0FBVyxXQUFXLFFBQVEsSUFBSTtDQUN4QyxNQUFNLFFBQXNEO0VBQzFEO0dBQUUsS0FBSztHQUFhLFFBQVE7R0FBYSxHQUFHO0VBQTBFO0VBQ3RIO0dBQUUsS0FBSztHQUFTLFFBQVE7R0FBUyxHQUFHO0VBQXNGO0VBQzFIO0dBQUUsS0FBSztHQUFRLFFBQVE7R0FBUSxHQUFHO0VBQXFDO0VBQ3ZFO0dBQUUsS0FBSztHQUFTLFFBQVE7R0FBUyxHQUFHO0VBQW1FO0VBQ3ZHO0dBQUUsS0FBSztHQUFVLFFBQVE7R0FBVSxHQUFHO0VBQXlDO0VBQy9FLEdBQUksZ0JBQWdCLFVBQ2hCLENBQ0U7R0FBRSxLQUFLO0dBQWUsUUFBUTtHQUFvQixHQUFHLElBQUksS0FBSyxTQUFTO0VBQXNDLEdBQzdHO0dBQUUsS0FBSztHQUFnQixRQUFRO0dBQW9CLEdBQUcsSUFBSSxNQUFNLFNBQVM7RUFBc0MsQ0FDakgsSUFDQSxDQUNFO0dBQUUsS0FBSztHQUFnQixRQUFRO0dBQXFCLEdBQUcsSUFBSSxLQUFLLFNBQVM7RUFBc0MsR0FDL0c7R0FBRSxLQUFLO0dBQWlCLFFBQVE7R0FBcUIsR0FBRyxJQUFJLE1BQU0sU0FBUztFQUFzQyxDQUNuSDtFQUNKO0dBQUUsS0FBSztHQUFpQixRQUFRO0dBQVksR0FBRyxJQUFJLEtBQUssU0FBUztFQUF1QjtFQUN4RjtHQUFFLEtBQUs7R0FBa0IsUUFBUTtHQUFZLEdBQUcsSUFBSSxNQUFNLFNBQVM7RUFBd0I7Q0FDN0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVyxpQkFBaUIsT0FBTyxZQUFZLEVBQUUsZUFBZSxZQUFZLFlBQVksRUFBRSxHQUFHLFdBQVcsZ0JBQWdCO0dBQU0sU0FBUTtHQUFjLE1BQUs7R0FBTSxjQUFZLEdBQUcsT0FBTyxHQUFHLFlBQVksWUFBWSxFQUFFO0dBQWMsV0FBVTthQUEvTztJQUNFLHdCQUFDLFdBQUQ7S0FBUyxJQUFHO0tBQU0sSUFBRztLQUFLLElBQUc7S0FBSyxJQUFHO0tBQUssV0FBVTtJQUFhOzs7OztJQUNqRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFZLEdBQUcsV0FBVyxRQUN0Qyx3RkFDQTtJQUEwRjs7Ozs7SUFDOUYsd0JBQUMsUUFBRDtLQUFNLFdBQVU7S0FBWSxHQUFFO0lBQW1FOzs7OztJQUNoRyxNQUFNLEtBQUssU0FDVix3QkFBQyxRQUFEO0tBRUUsR0FBRyxLQUFLO0tBQ1IsV0FBVyxlQUFlLFdBQVcsdUJBQXVCLGFBQWEsS0FBSyxTQUFTLGFBQWE7S0FDcEcsZUFBZSxDQUFDLFlBQVksU0FBUyxLQUFLLE1BQU07S0FDaEQsTUFBSztLQUNMLFVBQVUsV0FBVyxDQUFDLElBQUk7S0FDMUIsaUJBQWU7S0FDZixjQUFZLEdBQUcsYUFBYSxLQUFLLFNBQVMsYUFBYSxTQUFTLEdBQUcsS0FBSztLQUN4RSxZQUFZLFVBQVUsQ0FBQyxhQUFhLE1BQU0sUUFBUSxXQUFXLE1BQU0sUUFBUSxRQUFRLFNBQVMsS0FBSyxNQUFNO2VBRXZHLHdCQUFDLFNBQUQsWUFBUSxLQUFLLE9BQWM7Ozs7O0lBQ3ZCLEdBWEMsS0FBSzs7OztXQVdOLENBQ1A7SUFDRCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFhLEdBQUU7SUFBcUQ7Ozs7O0dBQ2pGOzs7OztZQUNMLHdCQUFDLFFBQUQ7R0FBTSxXQUFXLFlBQVksWUFBWSxXQUFXLFdBQVc7YUFBTTtFQUF3RDs7OztVQUMxSDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQm9keU1hcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBHZW5kZXIsIE11c2NsZSwgT3JpZW50YXRpb24gfSBmcm9tIFwiLi4vdHlwZXNcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBCb2R5TWFwKHtcclxuICBnZW5kZXIsXHJcbiAgb3JpZW50YXRpb24sXHJcbiAgc2VsZWN0ZWQsXHJcbiAgZnVsbEJvZHksXHJcbiAgZGlzYWJsZWQsXHJcbiAgb25TZWxlY3QsXHJcbn06IHtcclxuICBnZW5kZXI6IEdlbmRlcjtcclxuICBvcmllbnRhdGlvbjogT3JpZW50YXRpb247XHJcbiAgc2VsZWN0ZWQ6IE11c2NsZSB8IG51bGw7XHJcbiAgZnVsbEJvZHk6IGJvb2xlYW47XHJcbiAgZGlzYWJsZWQ6IGJvb2xlYW47XHJcbiAgb25TZWxlY3Q6IChtdXNjbGU6IE11c2NsZSkgPT4gdm9pZDtcclxufSkge1xyXG4gIGNvbnN0IGFybVdpZHRoID0gZ2VuZGVyID09PSBcIk1hblwiID8gMCA6IDM7XHJcbiAgY29uc3Qgem9uZXM6IHsga2V5OiBzdHJpbmc7IG11c2NsZTogTXVzY2xlOyBkOiBzdHJpbmcgfVtdID0gW1xyXG4gICAgeyBrZXk6IFwic2hvdWxkZXJzXCIsIG11c2NsZTogXCJTaG91bGRlcnNcIiwgZDogXCJNNzcgODhjOS0xMCAxOC0xMyAzMS0xM2w3IDE4LTI1IDEzWm04NiAwYy05LTEwLTE4LTEzLTMxLTEzbC03IDE4IDI1IDEzWlwiIH0sXHJcbiAgICB7IGtleTogXCJjaGVzdFwiLCBtdXNjbGU6IFwiQ2hlc3RcIiwgZDogXCJNOTkgOThjMTAtNiAxNi01IDIxIDF2MzRjLTEzIDEtMjQtNC0yOS0xM1ptNDIgMGMtMTAtNi0xNi01LTIxIDF2MzRjMTMgMSAyNC00IDI5LTEzWlwiIH0sXHJcbiAgICB7IGtleTogXCJjb3JlXCIsIG11c2NsZTogXCJDb3JlXCIsIGQ6IFwiTTEwMyAxMzdjMTEgMyAyMyAzIDM0IDBsLTIgNTloLTMwWlwiIH0sXHJcbiAgICB7IGtleTogXCJxdWFkc1wiLCBtdXNjbGU6IFwiUXVhZHNcIiwgZDogXCJNOTEgMjA3YzgtNiAxOC03IDI3LTJsLTggOTEtMjQtMlptNTggMGMtOC02LTE4LTctMjctMmw4IDkxIDI0LTJaXCIgfSxcclxuICAgIHsga2V5OiBcImNhbHZlc1wiLCBtdXNjbGU6IFwiQ2FsdmVzXCIsIGQ6IFwiTTg2IDMwMmgyNGwtNSA4MEg4OVptNjggMGgtMjRsNSA4MGgxNlpcIiB9LFxyXG4gICAgLi4uKG9yaWVudGF0aW9uID09PSBcIkZyb250XCJcclxuICAgICAgPyBbXHJcbiAgICAgICAgICB7IGtleTogXCJiaWNlcHMtbGVmdFwiLCBtdXNjbGU6IFwiQmljZXBzXCIgYXMgTXVzY2xlLCBkOiBgTSR7NzAgKyBhcm1XaWR0aH0gMTA2YzgtNSAxNSAxIDE0IDEwbC02IDM4LTE1LTMgNC0zNFpgIH0sXHJcbiAgICAgICAgICB7IGtleTogXCJiaWNlcHMtcmlnaHRcIiwgbXVzY2xlOiBcIkJpY2Vwc1wiIGFzIE11c2NsZSwgZDogYE0kezE3MCAtIGFybVdpZHRofSAxMDZjLTgtNS0xNSAxLTE0IDEwbDYgMzggMTUtMy00LTM0WmAgfSxcclxuICAgICAgICBdXHJcbiAgICAgIDogW1xyXG4gICAgICAgICAgeyBrZXk6IFwidHJpY2Vwcy1sZWZ0XCIsIG11c2NsZTogXCJUcmljZXBzXCIgYXMgTXVzY2xlLCBkOiBgTSR7NzAgKyBhcm1XaWR0aH0gMTA0YzktMyAxNSAzIDEzIDEybC03IDM5LTE1LTUgNS0zNFpgIH0sXHJcbiAgICAgICAgICB7IGtleTogXCJ0cmljZXBzLXJpZ2h0XCIsIG11c2NsZTogXCJUcmljZXBzXCIgYXMgTXVzY2xlLCBkOiBgTSR7MTcwIC0gYXJtV2lkdGh9IDEwNGMtOS0zLTE1IDMtMTMgMTJsNyAzOSAxNS01LTUtMzRaYCB9LFxyXG4gICAgICAgIF0pLFxyXG4gICAgeyBrZXk6IFwiZm9yZWFybXMtbGVmdFwiLCBtdXNjbGU6IFwiRm9yZWFybXNcIiwgZDogYE0kezYxICsgYXJtV2lkdGh9IDE1NGwxNSA1LTEzIDQ4LTE1LTRaYCB9LFxyXG4gICAgeyBrZXk6IFwiZm9yZWFybXMtcmlnaHRcIiwgbXVzY2xlOiBcIkZvcmVhcm1zXCIsIGQ6IGBNJHsxNzkgLSBhcm1XaWR0aH0gMTU0bC0xNSA1IDEzIDQ4IDE1LTRaYCB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJvZHktd3JhcFwiPlxyXG4gICAgICA8c3ZnIGNsYXNzTmFtZT17YGJvZHktc3ZnIGJvZHktJHtnZW5kZXIudG9Mb3dlckNhc2UoKX0gb3JpZW50YXRpb24tJHtvcmllbnRhdGlvbi50b0xvd2VyQ2FzZSgpfSAke2Rpc2FibGVkID8gXCJpcy1kaXNhYmxlZFwiIDogXCJcIn1gfSB2aWV3Qm94PVwiMCAwIDI0MCA0MTBcIiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17YCR7Z2VuZGVyfSAke29yaWVudGF0aW9uLnRvTG93ZXJDYXNlKCl9IG11c2NsZSBtYXBgfSBmb2N1c2FibGU9XCJmYWxzZVwiPlxyXG4gICAgICAgIDxlbGxpcHNlIGN4PVwiMTIwXCIgY3k9XCIzOVwiIHJ4PVwiMjRcIiByeT1cIjI4XCIgY2xhc3NOYW1lPVwiYm9keS1iYXNlXCIgLz5cclxuICAgICAgICA8cGF0aCBjbGFzc05hbWU9XCJib2R5LWJhc2VcIiBkPXtnZW5kZXIgPT09IFwiTWFuXCJcclxuICAgICAgICAgID8gXCJNOTEgNzdjMTgtMTQgNDAtMTQgNTggMGwyNSA5OS0yNCAzMCA2IDk0LTQgOThoLTIzbC05LTEyNi05IDEyNkg4OGwtNC05OCA2LTk0LTI0LTMwWlwiXHJcbiAgICAgICAgICA6IFwiTTk2IDc3YzE2LTEyIDMyLTEyIDQ4IDBsMTcgOTMtMjUgMzQgMTcgOTUtMiA5OWgtMjJsLTktMTI2LTkgMTI2SDg5bC0yLTk5IDE3LTk1LTI1LTM0WlwifSAvPlxyXG4gICAgICAgIDxwYXRoIGNsYXNzTmFtZT1cImJvZHktYmFzZVwiIGQ9XCJtOTEgODQtMjYgMTYtMjIgMTEyIDE3IDQgMzQtMTAwWm01OCAwIDI2IDE2IDIyIDExMi0xNyA0LTM0LTEwMFpcIiAvPlxyXG4gICAgICAgIHt6b25lcy5tYXAoKHpvbmUpID0+IChcclxuICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgIGtleT17em9uZS5rZXl9XHJcbiAgICAgICAgICAgIGQ9e3pvbmUuZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgbXVzY2xlLXpvbmUgJHtmdWxsQm9keSA/IFwiZnVsbC1ib2R5LXNlbGVjdGVkXCIgOiBzZWxlY3RlZCA9PT0gem9uZS5tdXNjbGUgPyBcInNlbGVjdGVkXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+ICFkaXNhYmxlZCAmJiBvblNlbGVjdCh6b25lLm11c2NsZSl9XHJcbiAgICAgICAgICAgIHJvbGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICB0YWJJbmRleD17ZGlzYWJsZWQgPyAtMSA6IDB9XHJcbiAgICAgICAgICAgIGFyaWEtZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtgJHtzZWxlY3RlZCA9PT0gem9uZS5tdXNjbGUgPyBcIkRlc2VsZWN0XCIgOiBcIlNlbGVjdFwifSAke3pvbmUubXVzY2xlfWB9XHJcbiAgICAgICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiAhZGlzYWJsZWQgJiYgKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiIHx8IGV2ZW50LmtleSA9PT0gXCIgXCIpICYmIG9uU2VsZWN0KHpvbmUubXVzY2xlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHRpdGxlPnt6b25lLm11c2NsZX08L3RpdGxlPlxyXG4gICAgICAgICAgPC9wYXRoPlxyXG4gICAgICAgICkpfVxyXG4gICAgICAgIDxwYXRoIGNsYXNzTmFtZT1cImJvZHktbGluZXNcIiBkPVwiTTEyMCA3M3YxMjZNOTIgMjA3bDI4LTggMjggOE0xMDUgMTM3aDMwTTkyIDMwMGg1NlwiIC8+XHJcbiAgICAgIDwvc3ZnPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2BtYXAtaGludCAke3NlbGVjdGVkIHx8IGZ1bGxCb2R5ID8gXCJoaWRkZW5cIiA6IFwiXCJ9YH0+Q2xpY2sgYW55IG11c2NsZSBncm91cCBvciB0YXAgJ0Z1bGwgQm9keScgdG8gYmVnaW48L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==