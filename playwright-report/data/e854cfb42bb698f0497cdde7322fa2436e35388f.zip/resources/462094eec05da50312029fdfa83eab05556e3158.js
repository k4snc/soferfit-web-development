export const exercises = {
	Chest: [
		{
			bodyweight: "Tempo push-up",
			gym: "Dumbbell bench press",
			level: "Beginner",
			reps: "3 × 10"
		},
		{
			bodyweight: "Incline push-up",
			gym: "Incline press",
			level: "Intermediate",
			reps: "4 × 8"
		},
		{
			bodyweight: "Wide push-up",
			gym: "Cable fly",
			level: "Intermediate",
			reps: "3 × 12"
		},
		{
			bodyweight: "Plank push-up",
			gym: "Chest press",
			level: "Intermediate",
			reps: "3 × 10"
		},
		{
			bodyweight: "Knee push-up",
			gym: "Pec deck",
			level: "Beginner",
			reps: "3 × 12"
		}
	],
	Shoulders: [
		{
			bodyweight: "Pike push-up",
			gym: "Arnold press",
			level: "Beginner",
			reps: "3 × 8"
		},
		{
			bodyweight: "Wall walk",
			gym: "Shoulder press",
			level: "Intermediate",
			reps: "4 × 10"
		},
		{
			bodyweight: "Arm circles",
			gym: "Lateral raise",
			level: "Beginner",
			reps: "3 × 15"
		},
		{
			bodyweight: "Plank shoulder tap",
			gym: "Front raise",
			level: "Beginner",
			reps: "3 × 12"
		},
		{
			bodyweight: "Down-dog press",
			gym: "Face pull",
			level: "Intermediate",
			reps: "4 × 12"
		}
	],
	Biceps: [
		{
			bodyweight: "Self-resisted curl",
			gym: "Dumbbell curl",
			level: "Beginner",
			reps: "3 × 12"
		},
		{
			bodyweight: "Towel curl",
			gym: "Cable curl",
			level: "Beginner",
			reps: "3 × 15"
		},
		{
			bodyweight: "Chin-up hold",
			gym: "Preacher curl",
			level: "Intermediate",
			reps: "3 × 30s"
		},
		{
			bodyweight: "Reverse plank pull",
			gym: "Hammer curl",
			level: "Intermediate",
			reps: "4 × 10"
		}
	],
	Triceps: [
		{
			bodyweight: "Diamond push-up",
			gym: "Cable pushdown",
			level: "Intermediate",
			reps: "3 × 10"
		},
		{
			bodyweight: "Bench dip",
			gym: "Skull crusher",
			level: "Beginner",
			reps: "3 × 12"
		},
		{
			bodyweight: "Close-grip push-up",
			gym: "Overhead extension",
			level: "Intermediate",
			reps: "4 × 8"
		},
		{
			bodyweight: "Triceps floor press",
			gym: "Close-grip bench press",
			level: "Intermediate",
			reps: "3 × 10"
		}
	],
	Forearms: [
		{
			bodyweight: "Fingertip plank",
			gym: "Wrist curl",
			level: "Beginner",
			reps: "3 × 20s"
		},
		{
			bodyweight: "Towel squeeze",
			gym: "Reverse wrist curl",
			level: "Beginner",
			reps: "3 × 15"
		},
		{
			bodyweight: "Bear crawl hold",
			gym: "Farmer carry",
			level: "Intermediate",
			reps: "3 × 30s"
		},
		{
			bodyweight: "Knuckle plank",
			gym: "Plate pinch",
			level: "Intermediate",
			reps: "3 × 20s"
		}
	],
	Core: [
		{
			bodyweight: "Dead bug",
			gym: "Cable crunch",
			level: "Beginner",
			reps: "3 × 12"
		},
		{
			bodyweight: "Hollow hold",
			gym: "Weighted sit-up",
			level: "Intermediate",
			reps: "3 × 30s"
		},
		{
			bodyweight: "Bicycle crunch",
			gym: "Cable woodchop",
			level: "Intermediate",
			reps: "4 × 12"
		},
		{
			bodyweight: "Forearm plank",
			gym: "Ab rollout",
			level: "Beginner",
			reps: "3 × 40s"
		},
		{
			bodyweight: "Lying knee raise",
			gym: "Hanging knee raise",
			level: "Advanced",
			reps: "3 × 10"
		}
	],
	Quads: [
		{
			bodyweight: "Air squat",
			gym: "Goblet squat",
			level: "Beginner",
			reps: "4 × 10"
		},
		{
			bodyweight: "Reverse lunge",
			gym: "Barbell reverse lunge",
			level: "Beginner",
			reps: "3 × 12"
		},
		{
			bodyweight: "Wall sit",
			gym: "Leg extension",
			level: "Intermediate",
			reps: "3 × 15"
		},
		{
			bodyweight: "Split squat",
			gym: "Weighted split squat",
			level: "Intermediate",
			reps: "3 × 10"
		},
		{
			bodyweight: "Stair step-up",
			gym: "Box step-up",
			level: "Beginner",
			reps: "3 × 12"
		}
	],
	Calves: [
		{
			bodyweight: "Standing raise",
			gym: "Smith machine raise",
			level: "Beginner",
			reps: "4 × 15"
		},
		{
			bodyweight: "Seated raise",
			gym: "Seated calf machine",
			level: "Intermediate",
			reps: "3 × 12"
		},
		{
			bodyweight: "Pogo jump",
			gym: "Weighted pogo jump",
			level: "Athletic",
			reps: "3 × 30s"
		},
		{
			bodyweight: "Single-leg raise",
			gym: "Leg press calf raise",
			level: "Intermediate",
			reps: "3 × 12"
		},
		{
			bodyweight: "Tiptoe walk",
			gym: "Farmer walk",
			level: "Beginner",
			reps: "3 × 40s"
		}
	]
};
export const fullBodyExercises = {
	"No Equipment / Bodyweight": [
		{
			name: "Push-up to shoulder tap",
			tag: "Push"
		},
		{
			name: "Prone snow angel",
			tag: "Pull"
		},
		{
			name: "Reverse lunge to knee drive",
			tag: "Legs"
		},
		{
			name: "Plank knee drive",
			tag: "Core"
		},
		{
			name: "Burpee",
			tag: "Full Body"
		}
	],
	"Gym Equipment": [
		{
			name: "Dumbbell thruster",
			tag: "Push"
		},
		{
			name: "Cable row",
			tag: "Pull"
		},
		{
			name: "Goblet squat",
			tag: "Legs"
		},
		{
			name: "Cable woodchop",
			tag: "Core"
		},
		{
			name: "Kettlebell swing",
			tag: "Full Body"
		}
	]
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLFlBQWdHO0NBQzNHLE9BQU87RUFDTDtHQUFFLFlBQVk7R0FBaUIsS0FBSztHQUF3QixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQzlGO0dBQUUsWUFBWTtHQUFtQixLQUFLO0dBQWlCLE9BQU87R0FBZ0IsTUFBTTtFQUFRO0VBQzVGO0dBQUUsWUFBWTtHQUFnQixLQUFLO0dBQWEsT0FBTztHQUFnQixNQUFNO0VBQVM7RUFDdEY7R0FBRSxZQUFZO0dBQWlCLEtBQUs7R0FBZSxPQUFPO0dBQWdCLE1BQU07RUFBUztFQUN6RjtHQUFFLFlBQVk7R0FBZ0IsS0FBSztHQUFZLE9BQU87R0FBWSxNQUFNO0VBQVM7Q0FDbkY7Q0FDQSxXQUFXO0VBQ1Q7R0FBRSxZQUFZO0dBQWdCLEtBQUs7R0FBZ0IsT0FBTztHQUFZLE1BQU07RUFBUTtFQUNwRjtHQUFFLFlBQVk7R0FBYSxLQUFLO0dBQWtCLE9BQU87R0FBZ0IsTUFBTTtFQUFTO0VBQ3hGO0dBQUUsWUFBWTtHQUFlLEtBQUs7R0FBaUIsT0FBTztHQUFZLE1BQU07RUFBUztFQUNyRjtHQUFFLFlBQVk7R0FBc0IsS0FBSztHQUFlLE9BQU87R0FBWSxNQUFNO0VBQVM7RUFDMUY7R0FBRSxZQUFZO0dBQWtCLEtBQUs7R0FBYSxPQUFPO0dBQWdCLE1BQU07RUFBUztDQUMxRjtDQUNBLFFBQVE7RUFDTjtHQUFFLFlBQVk7R0FBc0IsS0FBSztHQUFpQixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQzVGO0dBQUUsWUFBWTtHQUFjLEtBQUs7R0FBYyxPQUFPO0dBQVksTUFBTTtFQUFTO0VBQ2pGO0dBQUUsWUFBWTtHQUFnQixLQUFLO0dBQWlCLE9BQU87R0FBZ0IsTUFBTTtFQUFVO0VBQzNGO0dBQUUsWUFBWTtHQUFzQixLQUFLO0dBQWUsT0FBTztHQUFnQixNQUFNO0VBQVM7Q0FDaEc7Q0FDQSxTQUFTO0VBQ1A7R0FBRSxZQUFZO0dBQW1CLEtBQUs7R0FBa0IsT0FBTztHQUFnQixNQUFNO0VBQVM7RUFDOUY7R0FBRSxZQUFZO0dBQWEsS0FBSztHQUFpQixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQ25GO0dBQUUsWUFBWTtHQUFzQixLQUFLO0dBQXNCLE9BQU87R0FBZ0IsTUFBTTtFQUFRO0VBQ3BHO0dBQUUsWUFBWTtHQUF1QixLQUFLO0dBQTBCLE9BQU87R0FBZ0IsTUFBTTtFQUFTO0NBQzVHO0NBQ0EsVUFBVTtFQUNSO0dBQUUsWUFBWTtHQUFtQixLQUFLO0dBQWMsT0FBTztHQUFZLE1BQU07RUFBVTtFQUN2RjtHQUFFLFlBQVk7R0FBaUIsS0FBSztHQUFzQixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQzVGO0dBQUUsWUFBWTtHQUFtQixLQUFLO0dBQWdCLE9BQU87R0FBZ0IsTUFBTTtFQUFVO0VBQzdGO0dBQUUsWUFBWTtHQUFpQixLQUFLO0dBQWUsT0FBTztHQUFnQixNQUFNO0VBQVU7Q0FDNUY7Q0FDQSxNQUFNO0VBQ0o7R0FBRSxZQUFZO0dBQVksS0FBSztHQUFnQixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQ2pGO0dBQUUsWUFBWTtHQUFlLEtBQUs7R0FBbUIsT0FBTztHQUFnQixNQUFNO0VBQVU7RUFDNUY7R0FBRSxZQUFZO0dBQWtCLEtBQUs7R0FBa0IsT0FBTztHQUFnQixNQUFNO0VBQVM7RUFDN0Y7R0FBRSxZQUFZO0dBQWlCLEtBQUs7R0FBYyxPQUFPO0dBQVksTUFBTTtFQUFVO0VBQ3JGO0dBQUUsWUFBWTtHQUFvQixLQUFLO0dBQXNCLE9BQU87R0FBWSxNQUFNO0VBQVM7Q0FDakc7Q0FDQSxPQUFPO0VBQ0w7R0FBRSxZQUFZO0dBQWEsS0FBSztHQUFnQixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQ2xGO0dBQUUsWUFBWTtHQUFpQixLQUFLO0dBQXlCLE9BQU87R0FBWSxNQUFNO0VBQVM7RUFDL0Y7R0FBRSxZQUFZO0dBQVksS0FBSztHQUFpQixPQUFPO0dBQWdCLE1BQU07RUFBUztFQUN0RjtHQUFFLFlBQVk7R0FBZSxLQUFLO0dBQXdCLE9BQU87R0FBZ0IsTUFBTTtFQUFTO0VBQ2hHO0dBQUUsWUFBWTtHQUFpQixLQUFLO0dBQWUsT0FBTztHQUFZLE1BQU07RUFBUztDQUN2RjtDQUNBLFFBQVE7RUFDTjtHQUFFLFlBQVk7R0FBa0IsS0FBSztHQUF1QixPQUFPO0dBQVksTUFBTTtFQUFTO0VBQzlGO0dBQUUsWUFBWTtHQUFnQixLQUFLO0dBQXVCLE9BQU87R0FBZ0IsTUFBTTtFQUFTO0VBQ2hHO0dBQUUsWUFBWTtHQUFhLEtBQUs7R0FBc0IsT0FBTztHQUFZLE1BQU07RUFBVTtFQUN6RjtHQUFFLFlBQVk7R0FBb0IsS0FBSztHQUF3QixPQUFPO0dBQWdCLE1BQU07RUFBUztFQUNyRztHQUFFLFlBQVk7R0FBZSxLQUFLO0dBQWUsT0FBTztHQUFZLE1BQU07RUFBVTtDQUN0RjtBQUNGO0FBRUEsT0FBTyxNQUFNLG9CQUF3RTtDQUNuRiw2QkFBNkI7RUFDM0I7R0FBRSxNQUFNO0dBQTJCLEtBQUs7RUFBTztFQUMvQztHQUFFLE1BQU07R0FBb0IsS0FBSztFQUFPO0VBQ3hDO0dBQUUsTUFBTTtHQUErQixLQUFLO0VBQU87RUFDbkQ7R0FBRSxNQUFNO0dBQW9CLEtBQUs7RUFBTztFQUN4QztHQUFFLE1BQU07R0FBVSxLQUFLO0VBQVk7Q0FDckM7Q0FDQSxpQkFBaUI7RUFDZjtHQUFFLE1BQU07R0FBcUIsS0FBSztFQUFPO0VBQ3pDO0dBQUUsTUFBTTtHQUFhLEtBQUs7RUFBTztFQUNqQztHQUFFLE1BQU07R0FBZ0IsS0FBSztFQUFPO0VBQ3BDO0dBQUUsTUFBTTtHQUFrQixLQUFLO0VBQU87RUFDdEM7R0FBRSxNQUFNO0dBQW9CLEtBQUs7RUFBWTtDQUMvQztBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImV4ZXJjaXNlcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEVxdWlwbWVudCwgTXVzY2xlIH0gZnJvbSBcIi4uL3R5cGVzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgZXhlcmNpc2VzOiBSZWNvcmQ8TXVzY2xlLCB7IGJvZHl3ZWlnaHQ6IHN0cmluZzsgZ3ltOiBzdHJpbmc7IGxldmVsOiBzdHJpbmc7IHJlcHM6IHN0cmluZyB9W10+ID0ge1xyXG4gIENoZXN0OiBbXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiVGVtcG8gcHVzaC11cFwiLCBneW06IFwiRHVtYmJlbGwgYmVuY2ggcHJlc3NcIiwgbGV2ZWw6IFwiQmVnaW5uZXJcIiwgcmVwczogXCIzIMOXIDEwXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJJbmNsaW5lIHB1c2gtdXBcIiwgZ3ltOiBcIkluY2xpbmUgcHJlc3NcIiwgbGV2ZWw6IFwiSW50ZXJtZWRpYXRlXCIsIHJlcHM6IFwiNCDDlyA4XCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJXaWRlIHB1c2gtdXBcIiwgZ3ltOiBcIkNhYmxlIGZseVwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDEyXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJQbGFuayBwdXNoLXVwXCIsIGd5bTogXCJDaGVzdCBwcmVzc1wiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDEwXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJLbmVlIHB1c2gtdXBcIiwgZ3ltOiBcIlBlYyBkZWNrXCIsIGxldmVsOiBcIkJlZ2lubmVyXCIsIHJlcHM6IFwiMyDDlyAxMlwiIH0sXHJcbiAgXSxcclxuICBTaG91bGRlcnM6IFtcclxuICAgIHsgYm9keXdlaWdodDogXCJQaWtlIHB1c2gtdXBcIiwgZ3ltOiBcIkFybm9sZCBwcmVzc1wiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgOFwiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiV2FsbCB3YWxrXCIsIGd5bTogXCJTaG91bGRlciBwcmVzc1wiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCI0IMOXIDEwXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJBcm0gY2lyY2xlc1wiLCBneW06IFwiTGF0ZXJhbCByYWlzZVwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTVcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIlBsYW5rIHNob3VsZGVyIHRhcFwiLCBneW06IFwiRnJvbnQgcmFpc2VcIiwgbGV2ZWw6IFwiQmVnaW5uZXJcIiwgcmVwczogXCIzIMOXIDEyXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJEb3duLWRvZyBwcmVzc1wiLCBneW06IFwiRmFjZSBwdWxsXCIsIGxldmVsOiBcIkludGVybWVkaWF0ZVwiLCByZXBzOiBcIjQgw5cgMTJcIiB9LFxyXG4gIF0sXHJcbiAgQmljZXBzOiBbXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiU2VsZi1yZXNpc3RlZCBjdXJsXCIsIGd5bTogXCJEdW1iYmVsbCBjdXJsXCIsIGxldmVsOiBcIkJlZ2lubmVyXCIsIHJlcHM6IFwiMyDDlyAxMlwiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiVG93ZWwgY3VybFwiLCBneW06IFwiQ2FibGUgY3VybFwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTVcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkNoaW4tdXAgaG9sZFwiLCBneW06IFwiUHJlYWNoZXIgY3VybFwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDMwc1wiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiUmV2ZXJzZSBwbGFuayBwdWxsXCIsIGd5bTogXCJIYW1tZXIgY3VybFwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCI0IMOXIDEwXCIgfSxcclxuICBdLFxyXG4gIFRyaWNlcHM6IFtcclxuICAgIHsgYm9keXdlaWdodDogXCJEaWFtb25kIHB1c2gtdXBcIiwgZ3ltOiBcIkNhYmxlIHB1c2hkb3duXCIsIGxldmVsOiBcIkludGVybWVkaWF0ZVwiLCByZXBzOiBcIjMgw5cgMTBcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkJlbmNoIGRpcFwiLCBneW06IFwiU2t1bGwgY3J1c2hlclwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTJcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkNsb3NlLWdyaXAgcHVzaC11cFwiLCBneW06IFwiT3ZlcmhlYWQgZXh0ZW5zaW9uXCIsIGxldmVsOiBcIkludGVybWVkaWF0ZVwiLCByZXBzOiBcIjQgw5cgOFwiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiVHJpY2VwcyBmbG9vciBwcmVzc1wiLCBneW06IFwiQ2xvc2UtZ3JpcCBiZW5jaCBwcmVzc1wiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDEwXCIgfSxcclxuICBdLFxyXG4gIEZvcmVhcm1zOiBbXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiRmluZ2VydGlwIHBsYW5rXCIsIGd5bTogXCJXcmlzdCBjdXJsXCIsIGxldmVsOiBcIkJlZ2lubmVyXCIsIHJlcHM6IFwiMyDDlyAyMHNcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIlRvd2VsIHNxdWVlemVcIiwgZ3ltOiBcIlJldmVyc2Ugd3Jpc3QgY3VybFwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTVcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkJlYXIgY3Jhd2wgaG9sZFwiLCBneW06IFwiRmFybWVyIGNhcnJ5XCIsIGxldmVsOiBcIkludGVybWVkaWF0ZVwiLCByZXBzOiBcIjMgw5cgMzBzXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJLbnVja2xlIHBsYW5rXCIsIGd5bTogXCJQbGF0ZSBwaW5jaFwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDIwc1wiIH0sXHJcbiAgXSxcclxuICBDb3JlOiBbXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiRGVhZCBidWdcIiwgZ3ltOiBcIkNhYmxlIGNydW5jaFwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTJcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkhvbGxvdyBob2xkXCIsIGd5bTogXCJXZWlnaHRlZCBzaXQtdXBcIiwgbGV2ZWw6IFwiSW50ZXJtZWRpYXRlXCIsIHJlcHM6IFwiMyDDlyAzMHNcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkJpY3ljbGUgY3J1bmNoXCIsIGd5bTogXCJDYWJsZSB3b29kY2hvcFwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCI0IMOXIDEyXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJGb3JlYXJtIHBsYW5rXCIsIGd5bTogXCJBYiByb2xsb3V0XCIsIGxldmVsOiBcIkJlZ2lubmVyXCIsIHJlcHM6IFwiMyDDlyA0MHNcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIkx5aW5nIGtuZWUgcmFpc2VcIiwgZ3ltOiBcIkhhbmdpbmcga25lZSByYWlzZVwiLCBsZXZlbDogXCJBZHZhbmNlZFwiLCByZXBzOiBcIjMgw5cgMTBcIiB9LFxyXG4gIF0sXHJcbiAgUXVhZHM6IFtcclxuICAgIHsgYm9keXdlaWdodDogXCJBaXIgc3F1YXRcIiwgZ3ltOiBcIkdvYmxldCBzcXVhdFwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjQgw5cgMTBcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIlJldmVyc2UgbHVuZ2VcIiwgZ3ltOiBcIkJhcmJlbGwgcmV2ZXJzZSBsdW5nZVwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTJcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIldhbGwgc2l0XCIsIGd5bTogXCJMZWcgZXh0ZW5zaW9uXCIsIGxldmVsOiBcIkludGVybWVkaWF0ZVwiLCByZXBzOiBcIjMgw5cgMTVcIiB9LFxyXG4gICAgeyBib2R5d2VpZ2h0OiBcIlNwbGl0IHNxdWF0XCIsIGd5bTogXCJXZWlnaHRlZCBzcGxpdCBzcXVhdFwiLCBsZXZlbDogXCJJbnRlcm1lZGlhdGVcIiwgcmVwczogXCIzIMOXIDEwXCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJTdGFpciBzdGVwLXVwXCIsIGd5bTogXCJCb3ggc3RlcC11cFwiLCBsZXZlbDogXCJCZWdpbm5lclwiLCByZXBzOiBcIjMgw5cgMTJcIiB9LFxyXG4gIF0sXHJcbiAgQ2FsdmVzOiBbXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiU3RhbmRpbmcgcmFpc2VcIiwgZ3ltOiBcIlNtaXRoIG1hY2hpbmUgcmFpc2VcIiwgbGV2ZWw6IFwiQmVnaW5uZXJcIiwgcmVwczogXCI0IMOXIDE1XCIgfSxcclxuICAgIHsgYm9keXdlaWdodDogXCJTZWF0ZWQgcmFpc2VcIiwgZ3ltOiBcIlNlYXRlZCBjYWxmIG1hY2hpbmVcIiwgbGV2ZWw6IFwiSW50ZXJtZWRpYXRlXCIsIHJlcHM6IFwiMyDDlyAxMlwiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiUG9nbyBqdW1wXCIsIGd5bTogXCJXZWlnaHRlZCBwb2dvIGp1bXBcIiwgbGV2ZWw6IFwiQXRobGV0aWNcIiwgcmVwczogXCIzIMOXIDMwc1wiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiU2luZ2xlLWxlZyByYWlzZVwiLCBneW06IFwiTGVnIHByZXNzIGNhbGYgcmFpc2VcIiwgbGV2ZWw6IFwiSW50ZXJtZWRpYXRlXCIsIHJlcHM6IFwiMyDDlyAxMlwiIH0sXHJcbiAgICB7IGJvZHl3ZWlnaHQ6IFwiVGlwdG9lIHdhbGtcIiwgZ3ltOiBcIkZhcm1lciB3YWxrXCIsIGxldmVsOiBcIkJlZ2lubmVyXCIsIHJlcHM6IFwiMyDDlyA0MHNcIiB9LFxyXG4gIF0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgZnVsbEJvZHlFeGVyY2lzZXM6IFJlY29yZDxFcXVpcG1lbnQsIHsgbmFtZTogc3RyaW5nOyB0YWc6IHN0cmluZyB9W10+ID0ge1xyXG4gIFwiTm8gRXF1aXBtZW50IC8gQm9keXdlaWdodFwiOiBbXHJcbiAgICB7IG5hbWU6IFwiUHVzaC11cCB0byBzaG91bGRlciB0YXBcIiwgdGFnOiBcIlB1c2hcIiB9LFxyXG4gICAgeyBuYW1lOiBcIlByb25lIHNub3cgYW5nZWxcIiwgdGFnOiBcIlB1bGxcIiB9LFxyXG4gICAgeyBuYW1lOiBcIlJldmVyc2UgbHVuZ2UgdG8ga25lZSBkcml2ZVwiLCB0YWc6IFwiTGVnc1wiIH0sXHJcbiAgICB7IG5hbWU6IFwiUGxhbmsga25lZSBkcml2ZVwiLCB0YWc6IFwiQ29yZVwiIH0sXHJcbiAgICB7IG5hbWU6IFwiQnVycGVlXCIsIHRhZzogXCJGdWxsIEJvZHlcIiB9LFxyXG4gIF0sXHJcbiAgXCJHeW0gRXF1aXBtZW50XCI6IFtcclxuICAgIHsgbmFtZTogXCJEdW1iYmVsbCB0aHJ1c3RlclwiLCB0YWc6IFwiUHVzaFwiIH0sXHJcbiAgICB7IG5hbWU6IFwiQ2FibGUgcm93XCIsIHRhZzogXCJQdWxsXCIgfSxcclxuICAgIHsgbmFtZTogXCJHb2JsZXQgc3F1YXRcIiwgdGFnOiBcIkxlZ3NcIiB9LFxyXG4gICAgeyBuYW1lOiBcIkNhYmxlIHdvb2RjaG9wXCIsIHRhZzogXCJDb3JlXCIgfSxcclxuICAgIHsgbmFtZTogXCJLZXR0bGViZWxsIHN3aW5nXCIsIHRhZzogXCJGdWxsIEJvZHlcIiB9LFxyXG4gIF0sXHJcbn07XHJcbiJdfQ==